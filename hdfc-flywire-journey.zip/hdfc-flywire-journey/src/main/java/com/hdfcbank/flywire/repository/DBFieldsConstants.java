package com.hdfcbank.flywire.repository;

public class DBFieldsConstants {
	private DBFieldsConstants() {
	}

	public static final String ID = "ID";
	public static final String CORRELATION_ID = "CORRELATION_ID";
	public static final String PAYMENT_ID = "PAYMENT_ID";
	public static final String AMOUNT_COLLECT = "AMOUNT_COLLECT";
	public static final String CURRENCY_COLLECT = "CURRENCY_COLLECT";
	public static final String AMOUNT_DISBURSE = "AMOUNT_DISBURSE";
	public static final String CURRENCY_DISBURSE = "CURRENCY_DISBURSE";
	public static final String SETTLEMENT_CURRENCY = "SETTLEMENT_CURRENCY";
	public static final String RECIPIENT_NAME = "RECIPIENT_NAME";
	public static final String RECIPIENT_COUNTRY = "RECIPIENT_COUNTRY";
	public static final String PARTNER_ID = "PARTNER_ID";
	public static final String RETURN_URL = "RETURN_URL";
	public static final String NOTIFY_URL = "NOTIFY_URL";
	public static final String X_FLYWIRE_DIGEST = "X_FLYWIRE_DIGEST";
	public static final String FLYWIRE_CREATED_AT = "FLYWIRE_CREATED_AT";
	public static final String STAGE = "STAGE";
	public static final String ACCOUNT_NUMBER = "ACCOUNT_NUMBER";
	public static final String ACCOUNT_STATUS = "ACCOUNT_STATUS";
	public static final String ACCOUNT_TYPE = "ACCOUNT_TYPE";
	public static final String ACCOUNT_BRANCH_NAME = "ACCOUNT_BRANCH_NAME";
	public static final String BALANCE_AVAILABLE = "BALANCE_AVAILABLE";
	public static final String CLEARING_BALANCE = "CLEARING_BALANCE";
	public static final String BRANCH_CODE = "BRANCH_CODE";
	public static final String CUSTOMER_ACCOUNT_RELATION = "CUSTOMER_ACCOUNT_RELATION";
	public static final String DAT_ACCOUNT_OPENING = "DAT_ACCOUNT_OPENING";
	public static final String NOMINEE_AVAILABLE = "NOMINEE_AVAILABLE";
	public static final String PRODUCT_CODE = "PRODUCT_CODE";
	public static final String PRODUCT_NAME = "PRODUCT_NAME";
	public static final String PRODUCT_TYPE = "PRODUCT_TYPE";
	public static final String CUSTOMER_FULL_NAME = "CUSTOMER_FULL_NAME";
	public static final String CUSTOMER_EMAIL_ID = "CUSTOMER_EMAIL_ID";
	public static final String CUSTOMER_GENDER = "CUSTOMER_GENDER";
	public static final String CUSTOMER_ID = "CUSTOMER_ID";
	public static final String CUSTOMER_TYPE = "CUSTOMER_TYPE";
	public static final String CUSTOMER_TYPE_DESC = "CUSTOMER_TYPE_DESC";
	public static final String DATE_OF_BIRTH = "DATE_OF_BIRTH";
	public static final String ETHNIC_CODE = "ETHNIC_CODE";
	public static final String ETHNIC_CODE_DESC = "ETHNIC_CODE_DESC";
	public static final String EXISTING_CUSTOMER = "EXISTING_CUSTOMER";
	public static final String MOBILE_NUMBER = "MOBILE_NUMBER";
	public static final String PAN_NO = "PAN_NO";
	public static final String PAN_NO_AVAILABLE = "PAN_NO_AVAILABLE";
	public static final String PAN_STATUS = "PAN_STATUS";
	public static final String RM_BRANCH_CODE = "RM_BRANCH_CODE";
	public static final String RELATIONSHIP_WITH_STUDENT = "RELATIONSHIP_WITH_STUDENT";
	public static final String SOURCE_OF_FUND = "SOURCE_OF_FUND";
	public static final String BORROWER_FROM = "BORROWER_FROM";
	public static final String BANK_CHARGES = "BANK_CHARGES";
	public static final String COUNTRY_OF_UNIVERSITY = "COUNTRY_OF_UNIVERSITY";
	public static final String ADDITIONAL_COMMENTS = "ADDITIONAL_COMMENTS";
	public static final String LOAN_DOCS = "LOAN_DOCS";
	public static final String BANK_STATEMENT_DOCS = "BANK_STATEMENT_DOCS";
	public static final String LRS_TRANSACTION = "LRS_TRANSACTION";
	public static final String LRS_TRANSACTION_DETAILS = "LRS_TRANSACTION_DETAILS";
	public static final String TERMS_AND_CONDITION_CHECKS = "TERMS_AND_CONDITION_CHECKS";
	public static final String BENEFICIARY_NAME = "BENEFICIARY_NAME";
	public static final String BENEFICIARY_ADDRESS = "BENEFICIARY_ADDRESS";
	public static final String BENEFICIARY_COUNTRY = "BENEFICIARY_COUNTRY";
	public static final String BENEFICIARY_CONTACT_NUMBER = "CONTACT_NUMBER";
	public static final String BENEFICIARY_BANK_NAME = "BENEFICIARY_BANK_NAME";
	public static final String BENEFICIARY_BANK_ADDRESS = "BENEFICIARY_BANK_ADDRESS";
	public static final String BENEFICIARY_ACCOUNT_NO = "BENEFICIARY_ACCOUNT_NO";
	
	public static final String LOAN_DOCS_EXT = "LOAN_DOCS_EXT";
	public static final String BANK_STATEMENT_DOCS_EXT = "BANK_STATEMENT_DOCS_EXT";
	public static final String CREATED_AT = "CREATED_AT";
	public static final String MODIFIED_AT = "MODIFIED_AT";
	public static final String ACCOUNT_DETAILS="ACCOUNT_DETAILS";
	
	public static final String PARTNER_NAME = "PARTNER_NAME";
	public static final String DATE_INITITATED = "DATE_INITITATED";
	
	public static final String SWIFT_CODE="SWIFT_CODE";
	public static final String CHIP_UID="CHIP_UID";
	public static final String ABA_NUMBER="ABA_NUMBER";
	public static final String IBAN_NO="IBAN_NO";
	public static final String CURRENCY="CURRENCY";
}
