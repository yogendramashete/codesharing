package com.hdfcbank.flywire.model.flywire;

import javax.validation.constraints.NotNull;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
@Builder
public class FlywireDetails{
	
	@NotNull
	private String paymentId;
	@NotNull
	private String createdAt;
	@NotNull
	private String amountCollect;
	@NotNull
	private String currencyCollect;
	@NotNull
	private String amountDisburse;
	@NotNull
	private String currencyDisburse;
	@NotNull
	private String settlementCurrency;
	@NotNull
	private String recipientName;
	@NotNull
	private String recipientCountry;
	@NotNull
	private String partnerId;
	@NotNull
	private String returnUrl;// we will not call this as our payment is offline
	@NotNull
	private String notifyUrl;//we will not call this as our payment is offline
	@NotNull
	private String xFlywireDigest;
}
