package com.hdfcbank.flywire.model.obp.sms.request;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
public class RequestString {
	@JsonProperty(required = true)
	private String userid; //User ID for division example: bbmbotp
	@JsonProperty(required = true)
	private String pwd; //  Password of the division example: UTZHV9iPf
	@JsonProperty(required = true)
	private String ctype; 
	@JsonProperty(required = true)
	private String sender;//example: HDFCBank
	@JsonProperty(required = true)
	private String pno; //Mobile No example: 9819289118
	@JsonProperty(required = true)
	private String msgtxt; //Message text  example: testing
	@JsonProperty(required = true)
	private String dcode;//Department Code example: GREENPIN
//	@JsonProperty(required = false)
//	private String submitdate;
	@JsonProperty(required = true)
	private String brd;
	@JsonProperty(required = false)
	private String intflag;
	@JsonProperty(required = true)
	private String msgid;// Message ID example: 9.88051216302E11
	@JsonProperty(required = true)
	private String msgtype; //Message Type  example: S
//	@JsonProperty(required = false)
//	private String priority;
//	@JsonProperty(required = false)
//	private String otpflag;
//	@JsonProperty(required = false)
//	private String alert;
//	@JsonProperty(required = false)
//	private String tag;
//	@JsonProperty(required = false)
//	private String countrycode;
//	@JsonProperty(required = false)
//	private String languageid;
//	@JsonProperty(required = false)
//	private String subjectLine;
//	@JsonProperty(required = false)
//	private String ornid;
//	@JsonProperty(required = false)
//	private String attachement;
//	@JsonProperty(required = false)
//	private String tempid;
}
