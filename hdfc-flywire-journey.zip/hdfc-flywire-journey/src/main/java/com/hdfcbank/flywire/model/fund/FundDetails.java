package com.hdfcbank.flywire.model.fund;

import java.util.List;

import javax.validation.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonPropertyOrder({"relationshipWithStudent", "countryOfUniversity","bankCharges","sourceOfFund","borrowedFrom","additionalComments","fundDetailsDocs"})
public class FundDetails {
	@NotBlank
	private String relationshipWithStudent;
	@NotBlank
	private String countryOfUniversity;
	@NotBlank
	private String bankCharges;
	@NotBlank
	private String sourceOfFund;
	
	private String borrowedFrom;
	@NotBlank
	private String additionalComments;
	
	private List<FundDetailsDocs> fundDetailsDocs;
}
