package com.hdfcbank.flywire.model.casa;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
public class SessionContext {
	
	private String channel;
	private String bankCode;
	private String userId;
	private String transactionBranch;
	private String userReferenceNumber;

}
