package com.hdfcbank.flywire.model.otp;

import javax.validation.constraints.NotBlank;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class OTPVerificationRequest {

	@NotBlank
	private String refNo;
	@NotBlank
	private String otp;
	@NotBlank
	private String txnId;
}
