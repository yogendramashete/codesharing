package com.hdfcbank.flywire.exception;

public class FlywireException extends RuntimeException {
	
	/**
	 * 
	 */
	
	private static final long serialVersionUID = 1L;

	public FlywireException() {
		super();
	}

	public FlywireException(String message, Throwable cause) {
		super(message, cause);
	}

	public FlywireException(String message) {
		super(message);
	}

	public FlywireException(Throwable cause) {
		super(cause);
	}
}