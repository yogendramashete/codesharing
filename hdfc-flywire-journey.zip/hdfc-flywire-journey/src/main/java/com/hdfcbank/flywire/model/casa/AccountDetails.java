package com.hdfcbank.flywire.model.casa;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class AccountDetails {
	private String accountNumber;
	private String accountStatus;
	private String accountType;
	private String acctBranchName;
	private Double balAvailable;
	private String branchCode;
	private Double clearBalance;
	private String custAcctRel;
	private String datAcctOpen;
	private String nomineeAvailable;
	private Integer productCode;
	private String productName;
	private String productType;
}
