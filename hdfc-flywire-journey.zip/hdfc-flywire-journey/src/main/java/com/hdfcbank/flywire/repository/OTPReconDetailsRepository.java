package com.hdfcbank.flywire.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.hdfcbank.flywire.model.dbentity.OTPReconDetails;

@Repository
public interface OTPReconDetailsRepository extends JpaRepository<OTPReconDetails, Long> {
	public List<OTPReconDetails> findByTransactionDate(String fromDate);

}
