package com.hdfcbank.flywire.model.obp.otp.verification.response;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ResponseString {

	@JsonProperty(required = false)
	private String statusCode;
	@JsonProperty(required = false)
	private String refNo;
	@JsonProperty(required = false)
	private String errorDetail;
	@JsonProperty(required = false)
	private String messageHash;
}
