package com.hdfcbank.flywire.model.obp.otp.generation.request;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class GenerateOTPRestRequestDTO {

	@JsonProperty(required = true)
	private RequestString requestString;
	@JsonProperty(required = true)
	private HeaderParams[] headerParams;
}
