package com.hdfcbank.flywire.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SftpConfiguration {

	@Bean("dealProSftpProperties")
	@ConfigurationProperties(prefix = "filetransfer.sftp.dealpro")
	public SftpProperties getDealProSftpProperties() {
		return new SftpProperties();
	}

	
	@Bean("otpReconSftpProperties")
	@ConfigurationProperties(prefix = "filetransfer.sftp.otprecon")
	public SftpProperties getOTPReconSftpProperties() {
		return new SftpProperties();
	}

}