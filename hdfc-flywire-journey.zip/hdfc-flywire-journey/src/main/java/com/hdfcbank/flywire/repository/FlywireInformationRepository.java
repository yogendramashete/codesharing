package com.hdfcbank.flywire.repository;

import static com.hdfcbank.flywire.repository.DBFieldsConstants.*;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Types;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.support.SqlLobValue;
import org.springframework.jdbc.support.lob.DefaultLobHandler;
import org.springframework.jdbc.support.lob.LobHandler;
import org.springframework.stereotype.Repository;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hdfcbank.flywire.constant.AppConstant;
import com.hdfcbank.flywire.enums.AttachmentType;
import com.hdfcbank.flywire.enums.Stage;
import com.hdfcbank.flywire.exception.FlywireException;
import com.hdfcbank.flywire.model.casa.AccountDetails;
import com.hdfcbank.flywire.model.casa.CustomerCASADetails;
import com.hdfcbank.flywire.model.flywire.FlywireDetails;
import com.hdfcbank.flywire.model.flywire.LRSTransaction;
import com.hdfcbank.flywire.model.fund.BeneficiaryDetails;
import com.hdfcbank.flywire.model.fund.FundDetails;
import com.hdfcbank.flywire.model.fund.FundDetailsDocs;
import com.hdfcbank.flywire.model.nbauth.NbAuthStatus;
import com.hdfcbank.flywire.model.otp.OTPCustomerDetails;

import oracle.jdbc.OracleTypes;

@Repository
public class FlywireInformationRepository {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Autowired
	private NamedParameterJdbcTemplate namedParamJdbcTemplate;

	@Autowired
	private ObjectMapper objectMapper;

	@Value("${transaction.insertFlywireInfoQuery}")
	private String insertFlywireInfoQuery;

	@Value("${transaction.updateLRSandTNCInfoQuery}")
	private String updateLRSandTNCInfoQuery;

	@Value("${transaction.updateCustomerCASADetailsQuery}")
	private String updateCustomerCASADetailsQuery;

	@Value("${transaction.updateCustomerAccountDetailsQuery}")
	private String updateCustomerAccountDetailsQuery;

	@Value("${transaction.getCorrelationIdQuery}")
	private String getCorrelationIdQuery;

	@Value("${transaction.updateEducationalDocQuery}")
	private String updateEducationalDocQuery;

	@Value("${transaction.updateBankStatementDocQuery}")
	private String updateBankStatementDocQuery;

	@Value("${transaction.amount}")
	private String transactionAmountSql;

	@Value("${fund.details.update}")
	private String fundDetailsUpdate;

	@Value("${beneficiary.details}")
	private String beneficiaryDetailsSql;

	@Value("${transaction.getAccountDetails}")
	private String getAccountDetails;

	@Value("${transaction.getCustomerIdAndPhoneQuery}")
	private String getCustomerIdAndPhoneQuery;

	@Value("${transaction.updateUITerminationStage}")
	private String updateUITerminationStage;

	@Value("${transaction.updateNBResponseStage}")
	private String updateNBResponseQuery;

	public void saveFlywireInformation(String correlationId, FlywireDetails flywireDetails, String stage)
			throws FlywireException {
		try {
			MapSqlParameterSource parameters = new MapSqlParameterSource();
			parameters.addValue("correlationId", correlationId, Types.VARCHAR);
			parameters.addValue("journeyId", correlationId, Types.VARCHAR);
			parameters.addValue("paymentId", flywireDetails.getPaymentId(), Types.VARCHAR);
			parameters.addValue("flywireCreatedAt", flywireDetails.getCreatedAt(), Types.VARCHAR);
			parameters.addValue("amountCollect", flywireDetails.getAmountCollect(), Types.VARCHAR);
			parameters.addValue("currencyCollect", flywireDetails.getCurrencyCollect(), Types.VARCHAR);
			parameters.addValue("amountDisburse", flywireDetails.getAmountDisburse(), Types.VARCHAR);
			parameters.addValue("currencyDisburse", flywireDetails.getCurrencyDisburse(), Types.VARCHAR);
			parameters.addValue("settlementCurrency", flywireDetails.getSettlementCurrency(), Types.VARCHAR);
			parameters.addValue("recipientName", flywireDetails.getRecipientName(), Types.VARCHAR);
			parameters.addValue("recipientCountry", flywireDetails.getRecipientCountry(), Types.VARCHAR);
			parameters.addValue("partnerId", flywireDetails.getPartnerId(), Types.VARCHAR);
			parameters.addValue("returnUrl", flywireDetails.getReturnUrl(), Types.VARCHAR);
			parameters.addValue("notifyUrl", flywireDetails.getNotifyUrl(), Types.VARCHAR);
			parameters.addValue("xFlywireDigest", flywireDetails.getXFlywireDigest(), Types.VARCHAR);
			parameters.addValue("stage", stage, Types.VARCHAR);

			namedParamJdbcTemplate.update(insertFlywireInfoQuery, parameters);
		} catch (Exception e) {
			throw new FlywireException(e.getMessage());
		}
	}

	public void saveCustomerCASADetails(String correlationId, CustomerCASADetails customerCASADetails, String stage)
			throws FlywireException {
		try {
			MapSqlParameterSource parameters = new MapSqlParameterSource();
			parameters.addValue("correlationId", correlationId, Types.VARCHAR);
			parameters.addValue("customerFullName", customerCASADetails.getCustomerFullName(), Types.VARCHAR);
			parameters.addValue("customerEmailId", customerCASADetails.getCustomerEmailId(), Types.VARCHAR);
			parameters.addValue("customerGender", customerCASADetails.getCustomerGender(), Types.VARCHAR);
			parameters.addValue("customerId", customerCASADetails.getCustomerId(), Types.VARCHAR);
			parameters.addValue("customerType", customerCASADetails.getCustomerType(), Types.VARCHAR);
			parameters.addValue("customerTypeDesc", customerCASADetails.getCustomerTypeDesc(), Types.VARCHAR);
			parameters.addValue("dob", customerCASADetails.getDateOfBirth(), Types.VARCHAR);
			parameters.addValue("ethnicCode", customerCASADetails.getEthnicCode(), Types.VARCHAR);
			parameters.addValue("ethnicCodeDesc", customerCASADetails.getEthnicCodeDesc(), Types.VARCHAR);
			parameters.addValue("existingCustomer", customerCASADetails.getExistingCustomer(), Types.VARCHAR);
			parameters.addValue("mobileNumber", customerCASADetails.getMobileNumber(), Types.VARCHAR);
			parameters.addValue("panNo", customerCASADetails.getPanNo(), Types.VARCHAR);
			parameters.addValue("panNoAvailable", customerCASADetails.getPanNoAvailable(), Types.VARCHAR);
			parameters.addValue("panStatus", customerCASADetails.getPanStatus(), Types.VARCHAR);
			parameters.addValue("rmBranchCode", customerCASADetails.getRMBranchCode(), Types.VARCHAR);
			parameters.addValue("stage", stage, Types.VARCHAR);
			parameters.addValue("accountDetails",
					objectMapper.writeValueAsString(customerCASADetails.getCasaAccountDetails()), Types.CLOB);

			namedParamJdbcTemplate.update(updateCustomerCASADetailsQuery, parameters);
		} catch (DataAccessException | JsonProcessingException e) {
			throw new FlywireException(e.getMessage());
		}
	}

	public List<AccountDetails> getAccountDetails(String correlationId) throws FlywireException {
		try {
			return jdbcTemplate.queryForObject(getAccountDetails, new Object[] { correlationId },
					new int[] { Types.VARCHAR }, (rs, rowNum) -> {
						try {
							return objectMapper.readValue(rs.getString(ACCOUNT_DETAILS),
									new TypeReference<List<AccountDetails>>() {
									});
						} catch (IOException e) {
							throw new FlywireException(e.getMessage());
						}

					});
		} catch (DataAccessException e) {
			throw new FlywireException(e.getMessage());
		}
	}

	public void saveCustomerAccountDetails(String correlationId, AccountDetails accountDetails, String stage)
			throws FlywireException {
		try {
			MapSqlParameterSource parameters = new MapSqlParameterSource();
			parameters.addValue("correlationId", correlationId, Types.VARCHAR);
			parameters.addValue("stage", stage, Types.VARCHAR);
			parameters.addValue("accountNumber", accountDetails.getAccountNumber(), Types.VARCHAR);
			parameters.addValue("accountStatus", accountDetails.getAccountStatus(), Types.VARCHAR);
			parameters.addValue("accountType", accountDetails.getAccountType(), Types.VARCHAR);
			parameters.addValue("accountBranchName", accountDetails.getAcctBranchName(), Types.VARCHAR);
			parameters.addValue("balanceAvailable", accountDetails.getBalAvailable(), Types.VARCHAR);
			parameters.addValue("clearingBalance", accountDetails.getClearBalance(), Types.VARCHAR);
			parameters.addValue("branchCode", accountDetails.getBranchCode(), Types.VARCHAR);
			parameters.addValue("customerAccountRelation", accountDetails.getCustAcctRel(), Types.VARCHAR);
			parameters.addValue("dateAccountOpening", accountDetails.getDatAcctOpen(), Types.VARCHAR);
			parameters.addValue("nomineeAvailable", accountDetails.getNomineeAvailable(), Types.VARCHAR);
			parameters.addValue("productCode", accountDetails.getProductCode(), Types.VARCHAR);
			parameters.addValue("productName", accountDetails.getProductName(), Types.VARCHAR);
			parameters.addValue("productType", accountDetails.getProductType(), Types.VARCHAR);

			namedParamJdbcTemplate.update(updateCustomerAccountDetailsQuery, parameters);
		} catch (Exception e) {
			throw new FlywireException(e.getMessage());
		}
	}

	public void saveFlywireLRSandTNCInformation(String correlationId, boolean isLRS,
			List<LRSTransaction> lrsTransactions, String stage) throws FlywireException {
		try {

			MapSqlParameterSource parameters = new MapSqlParameterSource();
			parameters.addValue("lrsTransaction", (isLRS ? Boolean.TRUE.toString() : Boolean.FALSE.toString()),
					Types.VARCHAR);
			if (null != lrsTransactions)
				parameters.addValue("lrsTransactionDetails", objectMapper.writeValueAsString(lrsTransactions),
						Types.CLOB);

			else
				parameters.addValue("lrsTransactionDetails", null, Types.NULL);
			parameters.addValue("stage", stage, Types.VARCHAR);
			parameters.addValue("correlationId", correlationId, Types.VARCHAR);
			parameters.addValue("termsAndConditionsCheck", Boolean.TRUE.toString(), Types.VARCHAR);

			namedParamJdbcTemplate.update(updateLRSandTNCInfoQuery, parameters);
		} catch (Exception e) {
			throw new FlywireException(e.getMessage());
		}
	}

	public boolean isCorrelationIdValid(String correlationId) throws FlywireException {
		try {
			int count = jdbcTemplate.queryForObject(getCorrelationIdQuery, Integer.class, correlationId);
			return count == 1;
		} catch (Exception e) {
			throw new FlywireException(e.getMessage());
		}
	}

	public FlywireDetails fetchFlywireDetails(String correlationId) throws FlywireException {
		try {
			return jdbcTemplate.queryForObject(transactionAmountSql, new Object[] { correlationId },
					new int[] { Types.VARCHAR },
					(rs, rowNum) -> new FlywireDetails(rs.getString(PAYMENT_ID), rs.getString(FLYWIRE_CREATED_AT),
							rs.getString(AMOUNT_COLLECT), rs.getString(CURRENCY_COLLECT), rs.getString(AMOUNT_DISBURSE),
							rs.getString(CURRENCY_DISBURSE), rs.getString(SETTLEMENT_CURRENCY),
							rs.getString(RECIPIENT_NAME), rs.getString(RECIPIENT_COUNTRY), rs.getString(PARTNER_ID),
							rs.getString(RETURN_URL), rs.getString(NOTIFY_URL), rs.getString(X_FLYWIRE_DIGEST)));
		} catch (Exception e) {
			throw new FlywireException(e.getMessage());
		}

	}

	public void saveFundDetails(String correlationId, FundDetails fd) throws FlywireException {
		try {
			MapSqlParameterSource parameters = new MapSqlParameterSource();
			parameters.addValue("relationshipWithStudent", fd.getRelationshipWithStudent(), Types.VARCHAR);
			parameters.addValue("sourceOfFund", fd.getSourceOfFund(), Types.VARCHAR);
			parameters.addValue("bankCharges", fd.getBankCharges(), Types.VARCHAR);
			parameters.addValue("borrowedFrom", fd.getBorrowedFrom(), Types.VARCHAR);
			parameters.addValue("countryOfUniversity", fd.getCountryOfUniversity(), Types.VARCHAR);
			parameters.addValue("additionalComments", fd.getAdditionalComments(), Types.VARCHAR);
			parameters.addValue("correlationId", correlationId, Types.VARCHAR);
			namedParamJdbcTemplate.update(fundDetailsUpdate, parameters);

			if (fd.getFundDetailsDocs() != null) {
				fd.getFundDetailsDocs().forEach(doc -> saveAttachment(correlationId, doc));
			}
		} catch (Exception e) {
			throw new FlywireException(e.getMessage());
		}

	}

	private void saveAttachment(String correlationId, FundDetailsDocs docs) throws FlywireException {
		/*
		 * try { String stage = attachmentType.equals(AttachmentType.BANKSTMT.name()) ?
		 * Stage.BANKSTMT_UPLOADED.name() : Stage.LOANDOC_UPLOADED.name(); var len =
		 * attachment.readAllBytes().length; LobHandler lobHandler = new
		 * DefaultLobHandler(); jdbcTemplate.update(
		 * AttachmentType.BANKSTMT.name().equals(attachmentType) ?
		 * updateBankStatementDocQuery : updateEducationalDocQuery, new Object[] { new
		 * SqlLobValue(attachment, len, lobHandler), attachmentExtension, stage,
		 * correlationId }, new int[] { Types.BLOB, Types.VARCHAR, Types.VARCHAR,
		 * Types.VARCHAR }); } catch (Exception e) { throw new
		 * FlywireException(e.getMessage()); }
		 */
		try {
			byte[] bytes = docs.getContent().getBytes();
			String stage = AttachmentType.BANKSTMT.name().equals(docs.getType()) ? Stage.BANKSTMT_UPLOADED.name()
					: Stage.LOANDOC_UPLOADED.name();

			String sql = AttachmentType.BANKSTMT.name().equals(docs.getType()) ? updateBankStatementDocQuery
					: updateEducationalDocQuery;

			MapSqlParameterSource parameters = new MapSqlParameterSource();
			//parameters.addValue("EXT", docs.getExtension());
			parameters.addValue("CORRELATION_ID", correlationId);
			//parameters.addValue("STAGE", stage);
		    parameters.addValue("CONTENT",
					new SqlLobValue(new ByteArrayInputStream(bytes), bytes.length, new DefaultLobHandler()),
					OracleTypes.BLOB);
			jdbcTemplate.update(sql, parameters);
		} catch (FlywireException e) {
			throw new FlywireException(e.getMessage());
		}
	}

	public BeneficiaryDetails fetchBeneficiaryDetails(String currency) throws FlywireException {
		try {
			return jdbcTemplate.queryForObject(beneficiaryDetailsSql, new Object[] { currency },
					new int[] { Types.VARCHAR },
					(rs, rowNum) -> BeneficiaryDetails.builder().beneficiaryName(rs.getString(BENEFICIARY_NAME))
							.beneficiaryAddress(rs.getString(BENEFICIARY_ADDRESS))
							.beneficiaryCountry(rs.getString(BENEFICIARY_COUNTRY)).build());
		} catch (Exception e) {
			throw new FlywireException(e.getMessage());
		}
	}

	public OTPCustomerDetails fetchOTPCustomerDetails(String correlationId) throws FlywireException {
		try {
			return jdbcTemplate.queryForObject(getCustomerIdAndPhoneQuery, new Object[] { correlationId },
					new int[] { Types.VARCHAR }, (rs, rowNum) -> OTPCustomerDetails.builder()
							.customerId(rs.getString(CUSTOMER_ID)).phoneNumber(rs.getString(MOBILE_NUMBER)).build());
		} catch (Exception e) {
			throw new FlywireException(e.getMessage());
		}
	}

	public void updateUITerminationStage(String correlationId) {
		try {
			MapSqlParameterSource parameters = new MapSqlParameterSource();
			parameters.addValue("correlationId", correlationId, Types.VARCHAR);
			parameters.addValue("stage", Stage.UI_TERMINATED.name(), Types.VARCHAR);

			namedParamJdbcTemplate.update(updateUITerminationStage, parameters);

		} catch (Exception e) {
			throw new FlywireException(e.getMessage());
		}
	}

	public void saveNBAuthStatus(String correlationId, NbAuthStatus nbAuthStatus) {
		try {
			MapSqlParameterSource parameters = new MapSqlParameterSource();
			parameters.addValue("correlationId", correlationId, Types.VARCHAR);
			parameters.addValue("stage",
					AppConstant.ZERO.equalsIgnoreCase(nbAuthStatus.getRetrunCode()) ? Stage.NB_AUTH_COMPLETED.name()
							: Stage.NB_AUTH_ERROR.name(),
					Types.VARCHAR);
			parameters.addValue("nbAuthStatus", objectMapper.writeValueAsString(nbAuthStatus), Types.CLOB);

			namedParamJdbcTemplate.update(updateNBResponseQuery, parameters);
		} catch (Exception e) {
			throw new FlywireException(e.getMessage());
		}

	}
}
