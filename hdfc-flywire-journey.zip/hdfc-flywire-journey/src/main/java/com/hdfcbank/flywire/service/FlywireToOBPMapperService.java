package com.hdfcbank.flywire.service;

import com.hdfcbank.flywire.exception.FlywireException;
import com.hdfcbank.flywire.model.casa.SessionContext;
import com.hdfcbank.flywire.model.obp.otp.generation.request.RequestDTO;
import com.hdfcbank.flywire.model.otp.OTPCustomerDetails;
import com.hdfcbank.flywire.model.otp.OTPVerificationRequest;
import com.hdfcbank.flywire.model.sms.SMSPushRequest;

public interface FlywireToOBPMapperService {

	public RequestDTO mapFlywireOTPGenerationToOBPOTPGenerationRequest(OTPCustomerDetails otpCustomerDetails)
			throws FlywireException;

	public com.hdfcbank.flywire.model.obp.otp.verification.request.RequestDTO mapFlywireOTPVerificationToOBPOTPVerificationRequest(
			OTPVerificationRequest otpVerificationRequest, OTPCustomerDetails otpCustomerDetails)
			throws FlywireException;

	public com.hdfcbank.flywire.model.obp.sms.request.RequestDTO mapFlywireSMSPushToOBPSMSPushRequest(
			SMSPushRequest smsPushRequest, OTPCustomerDetails otpCustomerDetails, String correlationId) throws FlywireException;

	public SessionContext getSessionContext(String correlationId) throws FlywireException;

}
