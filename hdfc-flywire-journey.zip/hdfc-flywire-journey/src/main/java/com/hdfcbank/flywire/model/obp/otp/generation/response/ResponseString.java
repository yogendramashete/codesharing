package com.hdfcbank.flywire.model.obp.otp.generation.response;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ResponseString {

	@JsonProperty(required = false)
	private String statusCode;
	@JsonProperty(required = false)
	private String refNo;
	@JsonProperty(required = false)
	private String errorDetail;
	@JsonProperty(required = false)
	private String datatimeGen;
	@JsonProperty(required = false)
	private String messageHash;
	@JsonProperty(required = false)
	private String txnId;
	@JsonProperty(required = false)
	private String freshPassword;
	@JsonProperty(required = false)
	private String datetimeExpire;
	@JsonProperty(required = false)
	private String passwordValue;
}
