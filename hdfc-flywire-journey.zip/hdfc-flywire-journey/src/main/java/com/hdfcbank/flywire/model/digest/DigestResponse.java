package com.hdfcbank.flywire.model.digest;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class DigestResponse {

	private String digest;
	private String errorMsg;
}
