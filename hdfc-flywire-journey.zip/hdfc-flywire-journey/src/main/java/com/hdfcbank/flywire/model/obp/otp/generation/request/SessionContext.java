package com.hdfcbank.flywire.model.obp.otp.generation.request;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
public class SessionContext {
	@JsonProperty(required = true)
	private String bankCode;//example: 08
	@JsonProperty(required = true)
	private String channel;//example: IB01 ( For NetBanking Channel)
	@JsonProperty(required = true)
	private String externalReferenceNo;
//	@JsonProperty(required = false)
//	private String serviceCode;
	@JsonProperty(required = true)
	private String transactionBranch;//example: 089999
	@JsonProperty(required = true)
	private String userId;//example: IB01_USER ( For NetBanking Channel)
	@JsonProperty(required = false)
	private String transactingPartyCode;
}
