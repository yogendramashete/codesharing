package com.hdfcbank.flywire.model.dealpro;

import java.sql.Blob;

import lombok.Builder;
import lombok.Data;
import lombok.ToString;

@Data
@Builder
@ToString
public class DealProCSVMaker {

	private String id;
	private String correlationId;
	private String paymentId;
	private String amountCollect;
	private String currencyCollect;
	private String amountDisburse;
	private String currencydDsburse;
	private String settlementCurrency;
	private String recipientName;
	private String recipientCountry;
	private String partnerId;
	private String returnURL;
	private String notifyURL;
	private String flywireCreateAt;
	private String stage;
	private String accountNumber;
	private String accountStatus;
	private String accountType;
	private String accountBranchName;
	private String balanceAvailable;
	private String clearingBalance;
	private String branchCode;
	private String customerAccountRelation;
	private String productCode;
	private String productName;
	private String productType;
	private String customerFullName;
	private String customerEmailId;
	private String customerGender;
	private String customerId;
	private String customerType;
	private String dateOfBirth;
	private String ethnicCode;
	private String ethnicCodeDesc;
	private String mobileNumber;
	private String panNo;
	private String panStatus;
	private String rmBranchCode;
	private String relationshipWithStudent;
	private String sourceOfFund;
	private String bankCharges;
	private String borrowerFrom;
	private String countryOfUniversity;
	private String additionalComments;
	private Blob loanDocs;
	private Blob bankStatementDocs;
	private String loanDocsExt;
	private String bankStatementDocsExt;
	private String lrsTransaction;
	private String lrsTransactionDetails;
	private String termsAndConditionChecks;
	private String createdAt;
	private String modifiedAt;
	private String customerTypeDesc;
	private String beneficiaryName;
	private String beneficiaryAddress;
	private String beneficiaryCountry;
	private String beneficiaryContactNumber;
	private String beneficiaryBankName;
	private String beneficiaryBankAddress;
	private String beneficiaryAccountNo;
	private String swiftCode;
	private String abaNumber;
	private String chipUid;
	private String ibanNo;
	

}
