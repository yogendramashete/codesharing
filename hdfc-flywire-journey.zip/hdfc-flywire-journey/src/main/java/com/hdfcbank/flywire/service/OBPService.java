package com.hdfcbank.flywire.service;

import com.hdfcbank.flywire.exception.FlywireException;
import com.hdfcbank.flywire.model.api.ApiResponse;
import com.hdfcbank.flywire.model.casa.CustomerCASA;
import com.hdfcbank.flywire.model.casa.FlywireResponseDetails;
import com.hdfcbank.flywire.model.otp.OTPGenerationResponse;
import com.hdfcbank.flywire.model.otp.OTPVerificationRequest;
import com.hdfcbank.flywire.model.otp.OTPVerificationResponse;
import com.hdfcbank.flywire.model.sms.SMSPushRequest;
import com.hdfcbank.flywire.model.sms.SMSPushResponse;

public interface OBPService {

	ApiResponse<FlywireResponseDetails> getCASADetails(CustomerCASA customerReq, String correlationId) throws FlywireException;

	public OTPGenerationResponse otpGeneration(String correlationId)throws FlywireException;

	public OTPVerificationResponse otpVerification(OTPVerificationRequest otpVerificationRequest, String correlationId)throws FlywireException;

	public SMSPushResponse smsPushNotification(SMSPushRequest smsPushRequest, String correlationId)throws FlywireException;

}
