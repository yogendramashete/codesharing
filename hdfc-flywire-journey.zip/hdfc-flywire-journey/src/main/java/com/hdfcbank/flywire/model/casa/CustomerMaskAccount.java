package com.hdfcbank.flywire.model.casa;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
public class CustomerMaskAccount {

	private String accountNo;
	private Double balance;
	private String balanceStatus;
	private String accountType;
}
