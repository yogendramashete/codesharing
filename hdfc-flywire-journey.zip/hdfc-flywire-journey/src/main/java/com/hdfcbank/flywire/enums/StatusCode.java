package com.hdfcbank.flywire.enums;

public enum StatusCode {
	SUCCESS(000, "Success - Customer successfully completed journey"),
	FAILED_1X(111, "Failed - Customer is not able to provide HDFC Bank credential at the start of journey"),
	FAILED_2X(222, "Failed - Customer is not able to provide authentication at the start of the journey"),
	FAILED_3X(333, "Failed - Customer is not eligible to do transaction with HDFC Bank"),
	FAILED_4X(444, "Failed - Customer does not have sufficient balance to place transaction request"),
	FAILED_5X(555, "Failed - Customer is not able to provide authentication at the end of the journey"),
	FAILED_6X(666, "Failed – Technical error at HDFC Bank end"),
	API_SUCCESS(000,"Success - Customer data is saved successfully"),
	API_ERROR(666, "Failed - Internal Server Error"),
	INVALID_CASE_ERROR(222, "No match found. Please verify your details again");

	private final int key;
	private final String value;

	StatusCode(int key, String value) {
		this.key = key;
		this.value = value;
	}

	public int getKey() {
		return key;
	}

	public String getValue() {
		return value;
	}
}
