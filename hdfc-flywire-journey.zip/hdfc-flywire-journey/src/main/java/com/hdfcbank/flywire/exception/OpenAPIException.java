package com.hdfcbank.flywire.exception;

import java.util.Map;

public class OpenAPIException extends RuntimeException{
    
    private Integer statusCode;
    private Map<String, Object>  detailedMessage;

    public  OpenAPIException(Integer statusCode,  Map<String, Object>  detailedMessage){
        this.statusCode = statusCode;
        this.detailedMessage = detailedMessage;

    }
    public OpenAPIException() {
    }


    public OpenAPIException(String message) {
        super(message);
    }

    public OpenAPIException(String message, Throwable cause) {
        super(message, cause);
    }

    public Integer getStatusCode() {
        return statusCode;
    }

    public Map<String, Object> getDetailedMessage() {
        return detailedMessage;
    }
}
