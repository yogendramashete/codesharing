package com.hdfcbank.flywire.model.casa;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class Status {

	private String errorCode;
	private ExtendedReply extendedReply;
	private String internalReferenceNumber;
	private Boolean isOverriden;
	private PostingDate postingDate;
	private String replyCode;
	private String replyText;
	private String userReferenceNumber;

}
