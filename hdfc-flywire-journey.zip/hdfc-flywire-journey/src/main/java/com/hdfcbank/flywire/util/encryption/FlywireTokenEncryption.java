package com.hdfcbank.flywire.util.encryption;

import java.nio.charset.StandardCharsets;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

import com.hdfcbank.flywire.exception.FlywireException;
import com.hdfcbank.flywire.model.digest.DigestRequest;
import com.hdfcbank.flywire.model.flywire.FlywireDetails;

import lombok.extern.log4j.Log4j2;

@Log4j2
public class FlywireTokenEncryption {
	private FlywireTokenEncryption() {
	}

	private static final String DELIMITER = "|";

	public static String encryptString(String signatureString, String sharedSecret, String algorithm)
			throws FlywireException {
		try {
			Mac sha256Hmac = Mac.getInstance(algorithm);
			SecretKeySpec secretKey = new SecretKeySpec(sharedSecret.getBytes(StandardCharsets.UTF_8), algorithm);
			sha256Hmac.init(secretKey);
			return Base64.getEncoder()
					.encodeToString(sha256Hmac.doFinal(signatureString.getBytes(StandardCharsets.UTF_8)));
		} catch (NoSuchAlgorithmException | InvalidKeyException e) {
			log.error(e.getMessage());
			throw new FlywireException(e.getMessage());
		}
	}

	public static String createSignatureString(FlywireDetails flywireDetails) {
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append(flywireDetails.getAmountCollect() + DELIMITER);
		stringBuilder.append(flywireDetails.getAmountDisburse() + DELIMITER);
		stringBuilder.append(flywireDetails.getCreatedAt() + DELIMITER);
		stringBuilder.append(flywireDetails.getCurrencyCollect() + DELIMITER);
		stringBuilder.append(flywireDetails.getCurrencyDisburse() + DELIMITER);
		stringBuilder.append(flywireDetails.getNotifyUrl() + DELIMITER);
		stringBuilder.append(flywireDetails.getPartnerId() + DELIMITER);
		stringBuilder.append(flywireDetails.getPaymentId() + DELIMITER);
		stringBuilder.append(flywireDetails.getRecipientCountry() + DELIMITER);
		stringBuilder.append(flywireDetails.getRecipientName() + DELIMITER);
		stringBuilder.append(flywireDetails.getReturnUrl() + DELIMITER);
		stringBuilder.append(flywireDetails.getSettlementCurrency());
		return stringBuilder.toString();
	}

	public static String createSignatureString(DigestRequest digestRequest) {
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append(digestRequest.getPartnerId() + DELIMITER);
		stringBuilder.append(digestRequest.getPaymentId() + DELIMITER);
		stringBuilder.append(digestRequest.getStatusCode());
		return stringBuilder.toString();
	}
}
