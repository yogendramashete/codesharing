package com.hdfcbank.flywire.model.flywire;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SaveFlywireDetailsResponse {
	private String journeyId;
	private String errorMsg;
}

