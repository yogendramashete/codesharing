package com.hdfcbank.flywire.util.converter;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;

public class TimestampConverter {

	private static final String TIME = "HHmmss";
	private static final String DATE = "ddMMyy";
	private static final String TIMESTAMP = "yyyy-MM-dd HH:mm:ss";

	private TimestampConverter() {
	}
	

	public static String getCurrentTimeStamp() {
		return new SimpleDateFormat(TIMESTAMP).format(new Timestamp(System.currentTimeMillis()));
	}

	public static String getCurrentDate() {
		return new SimpleDateFormat(DATE).format(new Timestamp(System.currentTimeMillis()));
	}

	public static String getCurrentTime() {
		return new SimpleDateFormat(TIME).format(new Timestamp(System.currentTimeMillis()));
	}

	public static String getDate(long millis) {
		return new SimpleDateFormat(DATE).format(new Timestamp(millis));
	}

	public static String getTime(long millis) {
		return new SimpleDateFormat(TIME).format(new Timestamp(millis));
	}

}
