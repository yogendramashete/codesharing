package com.hdfcbank.flywire.util.converter;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class TimestampConverter {

	private static final String TIME = "HHmmss";
	private static final String DATE = "ddMMyy";
	private static final String DATE_FORMAT_1 = "yyMMdd";

	private static final String TIMESTAMP = "yyyy-MM-dd HH:mm:ss";

	private TimestampConverter() {
	}
	

	public static String getCurrentTimeStamp() {
		return new SimpleDateFormat(TIMESTAMP).format(new Timestamp(System.currentTimeMillis()));
	}

	public static String getCurrentDate() {
		return new SimpleDateFormat(DATE).format(new Timestamp(System.currentTimeMillis()));
	}

	public static String getCurrentTime() {
		return new SimpleDateFormat(TIME).format(new Timestamp(System.currentTimeMillis()));
	}

	public static String getDate(long millis) {
		return new SimpleDateFormat(DATE).format(new Timestamp(millis));
	}

	public static String getTime(long millis) {
		return new SimpleDateFormat(TIME).format(new Timestamp(millis));
	}

	public static String getFormatterDate(String date) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern(DATE);
		DateTimeFormatter formatter2 = DateTimeFormatter.ofPattern(DATE_FORMAT_1);
		return LocalDate.parse(date, formatter).format(formatter2);
	}

}
