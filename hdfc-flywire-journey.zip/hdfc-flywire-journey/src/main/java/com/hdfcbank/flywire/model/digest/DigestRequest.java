package com.hdfcbank.flywire.model.digest;

import javax.validation.constraints.NotBlank;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class DigestRequest {
	
	@NotBlank
	private String partnerId;
	@NotBlank
	private String paymentId;
	@NotBlank
	private String statusCode;

}
