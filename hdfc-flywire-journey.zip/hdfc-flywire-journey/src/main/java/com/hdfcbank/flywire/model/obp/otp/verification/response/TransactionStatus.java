package com.hdfcbank.flywire.model.obp.otp.verification.response;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TransactionStatus {

	@JsonProperty(required = true)
	private String errorCode;
	@JsonProperty(required = false)
	private Object extendedReply;
	@JsonProperty(required = true)
	private Long replyCode;
	@JsonProperty(required = true)
	private String replyText;
	@JsonProperty(required = true)
	private String userReferenceNumber;
	@JsonProperty(required = false)
	private String internalReferenceNumber;
	@JsonProperty(required = true)
	private String externalReferenceNo;
	@JsonProperty(required = false)
	private Boolean isOverriden;
	@JsonProperty(required = false)
	private String memo;
	@JsonProperty(required = false)
	private ValidationError[] validationErrors;
	@JsonProperty(required = false)
	private PostingDate postingDate;
}
