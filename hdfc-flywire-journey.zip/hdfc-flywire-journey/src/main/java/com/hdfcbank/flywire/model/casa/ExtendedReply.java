package com.hdfcbank.flywire.model.casa;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;

import lombok.ToString;

@ToString
@JsonAutoDetect(fieldVisibility = Visibility.ANY)
public class ExtendedReply {

}
