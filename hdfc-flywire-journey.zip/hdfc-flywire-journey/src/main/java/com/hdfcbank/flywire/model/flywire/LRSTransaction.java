package com.hdfcbank.flywire.model.flywire;

import javax.validation.constraints.NotBlank;

import com.hdfcbank.flywire.model.otp.OTPVerificationRequest;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class LRSTransaction {
	@NotBlank
	private String transactionDate;
	@NotBlank
	private String currency;
	@NotBlank
	private String amount;
	@NotBlank
	private String adBranchName;
	@NotBlank
	private String branchAddr1;
	@NotBlank
	private String branchAddr2;

}
