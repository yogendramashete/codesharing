package com.hdfcbank.flywire.exception;

import java.util.Map;

import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.Collections;
import lombok.extern.log4j.Log4j2;

@Log4j2
@Component("v1ExceptionHandler")
public class RestClientExceptionHandler {

	private final ObjectMapper objectMapper = new ObjectMapper();
	private static final String API_CALL_EXCEPTION_MSG = "Api Call Exception";

	public <T> T handleApiCallException(Exception exception) {
		try {
			log.error(API_CALL_EXCEPTION_MSG, exception);
			throw exception;
		} catch (HttpClientErrorException ex) {
			throw new OpenAPIException(ex.getRawStatusCode(), getErrorMessage(ex));
		} catch (Exception ex) {
			log.error("error in API retrying again" + ex.getMessage());
			throw new OpenRestAPIRetryException(ex);
		}
	}

	private Map<String, Object> getErrorMessage(HttpClientErrorException exception) {
		try {
			return objectMapper.readValue(exception.getResponseBodyAsString(), Map.class);
		} catch (Exception e) {
			return Collections.emptyMap();

		}

	}

}
