package com.hdfcbank.flywire.service;

import com.hdfcbank.flywire.exception.FlywireException;

public interface OTPReconDetailsService {

	public String createReconFile(String fromDate)  throws FlywireException;
}
