package com.hdfcbank.flywire.constant;

import java.util.List;

public final class AppConstant {

	private AppConstant() {
	}

	public static final String CORRELATION_ID = "correlationId";
	public static final String KEY = "KEY";
	public static final String VALUE = "VALUE";
	public static final String SUCCESS = "SUCCESS";
	public static final String FAILURE = "FAILURE";
	public static final String FLYWIRE = "FLYWIRE";
	
	public static final String SMS_RESPONSE_STRING = "smsResponseString";
	
	public static final String JOURNEY_ID = "journeyId";
	
	public static final String RESIDENT = "RESIDENT";

	public static final String EMPTY = "";
	
	public static final String EDUCATION = "Education"; 
	public static final String SCHEME = "Libralised Remittance Scheme"; 

	public static final List<String> CUST_TYPE_LIST = List.of("9", "3", "5", "2", "4", "8", "Q", "R", "I", "Y", "Z");
	public static final List<String> ACCOUNT_STATUS = List.of("6", "8");

	public static final List<Integer> PRODUCT_CODE = List.of(101, 106, 108, 109, 118, 119, 121, 122, 123, 124, 128, 129,
			131, 140, 143, 144, 147, 148, 151, 156, 158, 159, 189, 190, 201, 217, 218, 237, 241, 242, 254, 265);

	public static final Double TRANSACTION_MIN_AMT = 100d;
	public static final Double TRANSACTION_MAX_AMT = 25000d;
	public static final String SUFFICIENT = "SUFFICIENT";
	public static final String NON_SUFFICIENT = "NON-SUFFICIENT";

	public static final String NOT_MASK_LAST_4_DIGIT = "\\w(?=\\w{4})";
	public static final String EMAIL_MASK = "(?<=..)[^@](?=[^@]*?..@)|(?:(?<=@..)|(?!^)\\G(?=[^@]*$)).(?=.*\\.)";
	
	public static final String MASK_CHAR = "*";
	
	public static final String APPLICATION_IDENTIFIER = "46";
	public static final String VERIFICATION = "verification";
	

	public static final String ZERO = "0";

	public static final String ERROR_MSG = "Technical error. Please try after some time.";

}