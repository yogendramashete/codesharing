package com.hdfcbank.flywire.util.hash;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;

import com.hdfcbank.flywire.exception.FlywireException;

import lombok.extern.log4j.Log4j2;

@Log4j2
public class HashingUtil {
	private HashingUtil() {
	}
	
	private static final String SHA_VERSION ="SHA-1";
	
	public static String calculateHash(String... fields) throws FlywireException {
		String hashText = null;
		StringBuilder sb = new StringBuilder();
		for (String field : fields)
			sb.append(field).append("|");
		String input = sb.substring(0, sb.length() - 1);
		try {
			MessageDigest md = MessageDigest.getInstance(SHA_VERSION);
			byte[] messageDigest = md.digest(input.getBytes(StandardCharsets.UTF_8));
			hashText = Base64.getEncoder().encodeToString(messageDigest);
		} catch (NoSuchAlgorithmException e) {
			log.error("Error calculating hash");
			throw new FlywireException(e.getMessage());
		}
		return hashText;
	}

}
