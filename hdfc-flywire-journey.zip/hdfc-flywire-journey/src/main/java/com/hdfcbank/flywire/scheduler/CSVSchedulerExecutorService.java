package com.hdfcbank.flywire.scheduler;

import java.util.Date;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.hdfcbank.flywire.config.SftpProperties;
import com.hdfcbank.flywire.exception.FlywireException;
import com.hdfcbank.flywire.model.dealpro.DealProCSVMaker;
import com.hdfcbank.flywire.service.DealProCSVMakerService1;
import com.hdfcbank.flywire.service.OTPReconDetailsService;
import com.hdfcbank.flywire.util.converter.TimestampConverter;
import com.hdfcbank.flywire.util.sftp.FileTransferServiceUtil;

import lombok.extern.log4j.Log4j2;

@Component
@Log4j2
public class CSVSchedulerExecutorService {

	private static final String ZIP_EXT = ".zip";

	// Millseconds in a day
	private static final long ONE_DAY_MILLI_SECONDS = 24 * 60 * 60 * 1000L;

	@Autowired
	private DealProCSVMakerService1 csvMakerService;

	@Autowired
	private OTPReconDetailsService otpReconDetailsService;

	@Autowired
	@Qualifier("otpReconSftpProperties")
	private SftpProperties otpReconSftpProperties;

	@Value("${scheduler.active}")
	private boolean isSchedulerActive;

	@Value("${file.base.path.dealpro}")
	private String dealproBasePathLocation;

	@Value("${file.base.path.otprecon}")
	private String otpBasePathLocation;

	@Scheduled(cron = "${scheduler.dealpro.cron}")
	public void callCsvMaker() {
		if (!isSchedulerActive)
			return;

		log.info("DealPro: DB data extraction csv generation triggered");
		ExecutorService dealProPool = Executors.newWorkStealingPool();
		try {

			List<DealProCSVMaker> dealProCSVMakersList = csvMakerService.exportToCSV();
			if (dealProCSVMakersList.isEmpty()) {
				log.info("DealPro: No records for DB data extraction csv generation");
				return;
			}

			dealProCSVMakersList.forEach(
					dealProCSVMaker -> dealProPool.submit(() -> csvMakerService.buildDealProCSV(dealProCSVMaker)));

			log.info("DealPro: DB data extraction csv generation completed successfully");
		} catch (FlywireException e) {
			log.error("DealPro: Error in DB data extraction csv generation ", e);
		} finally {
			dealProPool.shutdown();
		}

	}

	@Scheduled(cron = "${scheduler.otprecon.cron}")
	public void callOTPReconCsvMaker() {
		if (!isSchedulerActive)
			return;

		String yesterdayDate = TimestampConverter.getDate(new Date().getTime() - ONE_DAY_MILLI_SECONDS);
		log.info("OTPRecon: DB data extraction csv generation triggered : " + yesterdayDate);
		try {
			String localFilePath = otpReconDetailsService.createReconFile(yesterdayDate);
			if (null == localFilePath) {
				log.info("OTPRecon: No records found for DB data extraction csv generation");
				return;
			}

			FileTransferServiceUtil.uploadFile(otpBasePathLocation + localFilePath, otpReconSftpProperties);
			log.info("OTPRecon: DB data extraction csv generation completed successfully");
		} catch (FlywireException e) {
			log.error("OTPRecon: Error in DB data extraction csv generation ", e);
		}
	}

}
