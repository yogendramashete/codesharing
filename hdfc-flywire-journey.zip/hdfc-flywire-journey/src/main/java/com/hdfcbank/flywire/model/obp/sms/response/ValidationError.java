package com.hdfcbank.flywire.model.obp.sms.response;

import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ValidationError {
	@JsonProperty(required = false)
	private String objectName;
	@JsonProperty(required = false)
	private String attributeName;
	@JsonProperty(required = false)
	private String attributeValue;
	@JsonProperty(required = false)
	private String errorCode;
	@JsonProperty(required = false)
	private String errorMessage;
	@JsonProperty(required = false)
	private String methodName;
	@JsonProperty(required = false)
	private String applicableAttributes;
	@JsonProperty(required = false)
	private String errorMessageParams;
	@JsonProperty(required = false)
	private BigDecimal associatedSeverity;
}