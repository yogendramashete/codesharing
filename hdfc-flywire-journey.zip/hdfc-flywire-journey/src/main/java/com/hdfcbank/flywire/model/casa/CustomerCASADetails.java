package com.hdfcbank.flywire.model.casa;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@JsonPropertyOrder({ "casaAccountDetails" })
@ToString
public class CustomerCASADetails {

	@JsonProperty("casaAccountDetails")
	private List<AccountDetails> casaAccountDetails;

	private String customerEmailId;
	private String customerFullName;
	private String customerGender;
	private Integer customerId;
	private String customerType;
	private String customerTypeDesc;
	private String dateOfBirth;
	private String ethnicCode;
	private String ethnicCodeDesc;
	private String existingCustomer;
	private String mobileNumber;
	private String panNo;
	private String panNoAvailable;
	private String panStatus;
	@JsonProperty("rMBranchCode")
	private Integer rMBranchCode;
}
