package com.hdfcbank.flywire.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hdfcbank.flywire.constant.AppConstant;
import com.hdfcbank.flywire.exception.FlywireException;
import com.hdfcbank.flywire.model.api.ApiResponse;
import com.hdfcbank.flywire.service.FlywireService;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j2;

@Log4j2
@AllArgsConstructor
public class CorrelationIdVerificationFilter implements Filter {

	private FlywireService flywireService;

	private final ObjectMapper objectMapper = new ObjectMapper();

	@Override
	public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain chain)
			throws IOException, ServletException, FlywireException {
		var request = (HttpServletRequest) servletRequest;
		var response = (HttpServletResponse) servletResponse;

		String correlationId = request.getHeader(AppConstant.CORRELATION_ID);
		if (correlationId.isBlank()
				|| (!correlationId.isBlank() && !flywireService.isCorrelationIdValid(correlationId))) {
			response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
			log.info("Unauthorized for req : {}", request.getRequestURI());
			response.setContentType(MediaType.APPLICATION_JSON_VALUE);
			response.setStatus(HttpStatus.UNAUTHORIZED.value());
			ApiResponse<Object> resp = ApiResponse.builder().status(HttpStatus.UNAUTHORIZED.value())
					.message(HttpStatus.UNAUTHORIZED.getReasonPhrase()).build();
			response.getWriter().append(objectMapper.writeValueAsString(resp));
		} else {
			chain.doFilter(request, response);
			response.addHeader(AppConstant.CORRELATION_ID, correlationId);
		}
	}

	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
		//Blank init
	}

	@Override
	public void destroy() {
		// Blank destroy
	}
}
