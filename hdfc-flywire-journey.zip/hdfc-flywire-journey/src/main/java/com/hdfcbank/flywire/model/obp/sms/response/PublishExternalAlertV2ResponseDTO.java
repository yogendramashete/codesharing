package com.hdfcbank.flywire.model.obp.sms.response;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PublishExternalAlertV2ResponseDTO {

	@JsonProperty(required = true, value="status")
	private TransactionStatus transactionStatus;
	@JsonProperty(required = false)
	private String maintenanceType;
	@JsonProperty(required = false)
	private String configVersionId;
	@JsonProperty(required = false)
	private String divisionCode;
	@JsonProperty(required = false)
	private String currentTimestampInMilliSeconds;
	@JsonProperty(required = false)
	private String incrementedCounter;
	@JsonProperty(required = false)
	private String serverId;
	@JsonProperty(required = false)
	private String serverInstanceId;
	@JsonProperty(required = false)
	private String errorMsg;
}
