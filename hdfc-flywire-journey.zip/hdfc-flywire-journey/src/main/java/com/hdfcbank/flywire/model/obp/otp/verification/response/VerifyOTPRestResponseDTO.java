package com.hdfcbank.flywire.model.obp.otp.verification.response;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class VerifyOTPRestResponseDTO {

	@JsonProperty(required = true, value="status")
	private TransactionStatus transactionStatus;
	@JsonProperty(required = false)
	private String maintenanceType;
	@JsonProperty(required = false)
	private String configVersionId;
	@JsonProperty(required = false)
	private ResponseString responseString;
}
