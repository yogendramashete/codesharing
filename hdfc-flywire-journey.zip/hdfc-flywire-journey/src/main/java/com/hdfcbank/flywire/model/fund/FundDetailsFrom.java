package com.hdfcbank.flywire.model.fund;

import org.springframework.web.multipart.MultipartFile;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@EqualsAndHashCode
public class FundDetailsFrom extends FundDetails {
	private MultipartFile loanDoc;
	private MultipartFile bankStat;
}
