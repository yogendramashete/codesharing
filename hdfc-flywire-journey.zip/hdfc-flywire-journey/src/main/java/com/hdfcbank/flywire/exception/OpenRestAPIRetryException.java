package com.hdfcbank.flywire.exception;

public class OpenRestAPIRetryException extends RuntimeException{

    public OpenRestAPIRetryException() {
        super();
    }

    public OpenRestAPIRetryException(String message) {
        super(message);
    }

    public OpenRestAPIRetryException(String message, Throwable cause) {
        super(message, cause);
    }

    public OpenRestAPIRetryException(Throwable cause) {
        super(cause);
    }

}
