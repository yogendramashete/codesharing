package com.hdfcbank.flywire.model.otp;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Builder
@Setter
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties("passwordValue")
public class OTPGenerationResponse {

	private String passwordValue;
	private String refNo;
	private String txnId;
	private String errMsg;
}
