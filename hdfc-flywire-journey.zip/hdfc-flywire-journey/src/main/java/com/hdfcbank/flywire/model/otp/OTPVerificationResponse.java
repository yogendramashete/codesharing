package com.hdfcbank.flywire.model.otp;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Builder
@Getter
@Setter
public class OTPVerificationResponse {

	private String errorMsg;
	private String status;
}
