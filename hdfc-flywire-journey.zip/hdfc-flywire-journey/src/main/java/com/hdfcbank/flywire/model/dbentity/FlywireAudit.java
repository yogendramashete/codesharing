package com.hdfcbank.flywire.model.dbentity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Table(name = "FLYWIRE_AUDIT")
@Entity
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FlywireAudit {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID")
	private Long id;
	@Column(name = "CORRELATION_ID")
	private String correlationId;
	@Column(name = "STAGE")
	private String stage;
	@Column(name = "REQUEST")
	@Lob
	private String request;
	@Column(name = "RESPONSE")
	@Lob
	private String response;
	@Column(name = "CREATED_AT")
	private String createdAt;
	@Column(name = "REMARK")
	private String remark;
}
