package com.hdfcbank.flywire.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.hdfcbank.flywire.model.dbentity.FlywireAudit;

@Repository
public interface FlywireAuditRepository extends JpaRepository<FlywireAudit, Long> {

}
