package com.hdfcbank.flywire.model.obp.sms.response;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ExtendedReply {

	@JsonProperty(required = false)
	private String messages;
}
