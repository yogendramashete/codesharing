package com.hdfcbank.flywire.config;

import lombok.Data;

@Data
public class SftpProperties {

	private String host;
	private String addIdentity;
	private Integer port;
	private String username;
	private Integer sessionTimeout;
	private Integer channelTimeout;
	private String remotePath;
	private String password;
}
