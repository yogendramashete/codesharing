package com.hdfcbank.flywire.service;

import javax.validation.Valid;

import com.hdfcbank.flywire.exception.FlywireException;
import com.hdfcbank.flywire.model.account.SelectedAccountRequest;
import com.hdfcbank.flywire.model.account.SelectedAccountResponse;
import com.hdfcbank.flywire.model.api.ApiResponse;
import com.hdfcbank.flywire.model.checksum.ChecksumRequest;
import com.hdfcbank.flywire.model.checksum.ChecksumResponse;
import com.hdfcbank.flywire.model.digest.DigestRequest;
import com.hdfcbank.flywire.model.digest.DigestResponse;
import com.hdfcbank.flywire.model.flywire.ConsentRequest;
import com.hdfcbank.flywire.model.flywire.FlywireDetails;
import com.hdfcbank.flywire.model.fund.FundDetails;
import com.hdfcbank.flywire.model.fund.FundDetailsDocs;
import com.hdfcbank.flywire.model.nbauth.NbAuthStatus;

public interface FlywireService {

	public boolean isRequestTokenValid(FlywireDetails flywireDetails) throws FlywireException;

	public boolean isCorrelationIdValid(String correlationId) throws FlywireException;

	public void storeConsent(String correlationId, ConsentRequest consentRequest) throws FlywireException;

	public void storeFlywireDetails(String correlationId, FlywireDetails flywireDetails) throws FlywireException;

	public void saveFundDetails(String bankPaymentId, FundDetails fundDetails) throws FlywireException;

	public SelectedAccountResponse submitAccount(String correlationId, SelectedAccountRequest selectAccountRequest)
			throws FlywireException;

	public void uiTerminated(String correlationId) throws FlywireException;

	public ChecksumResponse buildChecksum(String correlationId, ChecksumRequest checksumRequest)
			throws FlywireException;

	public void auditLog(String correlationId, Object request, ApiResponse response, String stage,
			String exceptionMessage) throws FlywireException;

	public DigestResponse buildDigest(@Valid DigestRequest digestRequest) throws FlywireException;

	public void saveNBAuthStatus(String correlationId, @Valid NbAuthStatus nbAuthStatus) throws FlywireException;

	public void fileUploadTest(FundDetailsDocs fundDetailsDocs);

	public void downloadImage(String id);
}
