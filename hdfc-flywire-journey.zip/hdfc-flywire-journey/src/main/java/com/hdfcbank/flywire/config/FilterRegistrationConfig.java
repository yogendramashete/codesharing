package com.hdfcbank.flywire.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.hdfcbank.flywire.filter.CorrelationIdVerificationFilter;
import com.hdfcbank.flywire.service.FlywireService;

@Configuration
public class FilterRegistrationConfig {

	@Bean
	public FilterRegistrationBean<CorrelationIdVerificationFilter> correlationIdVerificationFilter(@Autowired FlywireService flywireService) {
		FilterRegistrationBean<CorrelationIdVerificationFilter> registrationBean = new FilterRegistrationBean<>();

		registrationBean.setFilter(new CorrelationIdVerificationFilter(flywireService));
		registrationBean.addUrlPatterns("/otpGeneration/*", "/otpVerification/*", "/getCASADetails/*", "/uploadFile/*",
				"/setFundDetails/*", "/setFundDetailsForm/*", "/setConsent/*", "/smsConfirmation/*" , "/submitAccount/*", "/getCheckSum/*");
		registrationBean.setOrder(1);

		return registrationBean;
	}
}