package com.hdfcbank.flywire.service;

import java.util.List;

import com.hdfcbank.flywire.exception.FlywireException;
import com.hdfcbank.flywire.model.dealpro.DealProCSVMaker;

public interface DealProCSVMakerService1 {
	public List<DealProCSVMaker> exportToCSV() throws FlywireException;
	public void buildDealProCSV(DealProCSVMaker dealProCSVMaker) throws FlywireException;
	public void updateDealProStatus(String correlationId, String dealproStatus)throws FlywireException;
	
	
}
