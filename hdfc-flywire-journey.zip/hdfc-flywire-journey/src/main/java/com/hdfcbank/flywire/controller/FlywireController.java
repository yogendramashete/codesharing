package com.hdfcbank.flywire.controller;

import java.util.Date;
import java.util.List;

import javax.validation.Valid;

import org.apache.commons.lang3.RandomStringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.hdfcbank.flywire.config.SftpProperties;
import com.hdfcbank.flywire.constant.AppConstant;
import com.hdfcbank.flywire.enums.Stage;
import com.hdfcbank.flywire.enums.StatusCode;
import com.hdfcbank.flywire.exception.FlywireException;
import com.hdfcbank.flywire.model.account.SelectedAccountRequest;
import com.hdfcbank.flywire.model.account.SelectedAccountResponse;
import com.hdfcbank.flywire.model.api.ApiResponse;
import com.hdfcbank.flywire.model.casa.CustomerCASA;
import com.hdfcbank.flywire.model.casa.FlywireResponseDetails;
import com.hdfcbank.flywire.model.checksum.ChecksumRequest;
import com.hdfcbank.flywire.model.checksum.ChecksumResponse;
import com.hdfcbank.flywire.model.dealpro.DealProCSVMaker;
import com.hdfcbank.flywire.model.digest.DigestRequest;
import com.hdfcbank.flywire.model.digest.DigestResponse;
import com.hdfcbank.flywire.model.flywire.ConsentRequest;
import com.hdfcbank.flywire.model.flywire.FlywireDetails;
import com.hdfcbank.flywire.model.flywire.SaveFlywireDetailsResponse;
import com.hdfcbank.flywire.model.fund.FundDetails;
import com.hdfcbank.flywire.model.fund.FundDetailsDocs;
import com.hdfcbank.flywire.model.nbauth.NbAuthStatus;
import com.hdfcbank.flywire.model.otp.OTPGenerationResponse;
import com.hdfcbank.flywire.model.otp.OTPVerificationRequest;
import com.hdfcbank.flywire.model.otp.OTPVerificationResponse;
import com.hdfcbank.flywire.model.sms.SMSPushRequest;
import com.hdfcbank.flywire.model.sms.SMSPushResponse;
import com.hdfcbank.flywire.model.uiterminated.UITerminatedRequest;
import com.hdfcbank.flywire.service.DealProCSVMakerService1;
import com.hdfcbank.flywire.service.FlywireService;
import com.hdfcbank.flywire.service.OBPService;
import com.hdfcbank.flywire.service.OTPReconDetailsService;
import com.hdfcbank.flywire.util.converter.TimestampConverter;
import com.hdfcbank.flywire.util.sftp.FileTransferServiceUtil;

import io.micrometer.core.instrument.util.StringUtils;
import io.swagger.annotations.ApiOperation;
import lombok.extern.log4j.Log4j2;

@Log4j2
@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class FlywireController {

	private static final int CORRELATION_ID_LENGTH = 10;
	@Autowired
	private FlywireService flywireService;

	@Autowired
	private OBPService obpService;

	@Autowired
	private DealProCSVMakerService1 dealProCSVMakerService1;
	
	@Autowired
	private OTPReconDetailsService otpReconDetailsService;
	
	@Value("${file.base.path.otprecon}")
	private String otpBasePathLocation;


	@Autowired
	@Qualifier("otpReconSftpProperties")
	private SftpProperties otpReconSftpProperties;
	
	@ApiOperation("Save flywire details in REST call")
	@PostMapping(value = "/saveFlywireDetails", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ApiResponse<SaveFlywireDetailsResponse>> saveFlywireDetails(
			@Valid @RequestBody FlywireDetails flywireDetails) {
		var correlationId = RandomStringUtils.randomAlphanumeric(CORRELATION_ID_LENGTH);
		log.info("FlywireController :: saveFlywireDetails : paymentId : " + flywireDetails.getPaymentId());
		ApiResponse<SaveFlywireDetailsResponse> resp = null;
		try {
			if (!flywireService.isRequestTokenValid(flywireDetails)) {
				log.info("Invalid Token");
				resp = ApiResponse.<SaveFlywireDetailsResponse>builder().status(HttpStatus.UNAUTHORIZED.value())
						.message(HttpStatus.UNAUTHORIZED.getReasonPhrase())
						.data(SaveFlywireDetailsResponse.builder().errorMsg("Invalid Token").build()).build();
			} else {
				flywireService.storeFlywireDetails(correlationId, flywireDetails);
				resp = ApiResponse.<SaveFlywireDetailsResponse>builder().status(StatusCode.API_SUCCESS.getKey())
						.message(StatusCode.API_SUCCESS.getValue())
						.data(SaveFlywireDetailsResponse.builder().journeyId(correlationId).build()).build();
			}
			flywireService.auditLog(correlationId, flywireDetails, resp, Stage.FLYWIRE_INFO_INITIALIZED.name(),
					AppConstant.SUCCESS);
		} catch (FlywireException e) {
			log.error(e);
			resp = ApiResponse.<SaveFlywireDetailsResponse>builder().status(StatusCode.API_ERROR.getKey())
					.message(StatusCode.API_ERROR.getValue())
					.data(SaveFlywireDetailsResponse.builder().errorMsg(e.getMessage()).build()).build();
			flywireService.auditLog(correlationId, flywireDetails, resp, Stage.FLYWIRE_INITIALIZE_ERROR.name(),
					e.getMessage());
		}
		return ResponseEntity.status(HttpStatus.OK).header(AppConstant.CORRELATION_ID, correlationId).body(resp);
	}

	@ApiOperation("OTP generation")
	@GetMapping(value = "/otpGeneration/{journeyId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ApiResponse<OTPGenerationResponse>> otpGeneration(
			@RequestHeader(name = AppConstant.CORRELATION_ID, required = true) String correlationId,
			@PathVariable(name = AppConstant.JOURNEY_ID, required = true) String journeyId) {
		log.info("FlywireController :: otpGeneration : correlationId : " + correlationId);
		ApiResponse<OTPGenerationResponse> resp = null;
		try {
			OTPGenerationResponse otpGenerationResponse = obpService.otpGeneration(correlationId);
			if (null == otpGenerationResponse || otpGenerationResponse.getPasswordValue().isBlank()) {
				log.error("Failure in OTP generation");
				throw new FlywireException(AppConstant.ERROR_MSG);
			}

			SMSPushRequest smsPushRequest = SMSPushRequest.builder()
					.smsMsgKeywordValue(otpGenerationResponse.getPasswordValue())
					.refNo(otpGenerationResponse.getRefNo()).build();
			SMSPushResponse smsPushResponse = obpService.smsPushNotification(smsPushRequest, correlationId);

			if (null == smsPushResponse) {
				otpGenerationResponse.setErrMsg("Error sending SMS");
				resp = ApiResponse.<OTPGenerationResponse>builder().status(StatusCode.API_ERROR.getKey())
						.message(StatusCode.API_ERROR.getValue()).data(otpGenerationResponse).build();
			} else if (!StringUtils.isBlank(smsPushResponse.getErrorMsg())) {
				otpGenerationResponse.setErrMsg(smsPushResponse.getErrorMsg());
				resp = ApiResponse.<OTPGenerationResponse>builder().status(StatusCode.API_ERROR.getKey())
						.message(StatusCode.API_ERROR.getValue()).data(otpGenerationResponse).build();
			} else
				resp = ApiResponse.<OTPGenerationResponse>builder().status(StatusCode.API_SUCCESS.getKey())
						.message(StatusCode.API_SUCCESS.getValue()).data(otpGenerationResponse).build();
			flywireService.auditLog(correlationId, null, resp, Stage.OTP_INITIATED.name(), AppConstant.SUCCESS);
		} catch (FlywireException e) {
			log.error(e);
			OTPGenerationResponse otpGenerationResponse = OTPGenerationResponse.builder().errMsg(e.getMessage())
					.build();
			resp = ApiResponse.<OTPGenerationResponse>builder().status(StatusCode.API_ERROR.getKey())
					.message(StatusCode.API_ERROR.getValue()).data(otpGenerationResponse).build();
			flywireService.auditLog(correlationId, null, resp, Stage.OTP_GEN_ERROR.name(), e.getMessage());
		}
		return ResponseEntity.ok(resp);
	}

	@ApiOperation("OTP verification")
	@PostMapping(value = "/otpVerification/{journeyId}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ApiResponse<OTPVerificationResponse>> otpVerification(
			@RequestHeader(name = AppConstant.CORRELATION_ID, required = true) String correlationId,
			@PathVariable(name = AppConstant.JOURNEY_ID, required = true) String journeyId,
			@Valid @RequestBody OTPVerificationRequest otpVerificationRequest) {
		log.info("FlywireController :: otpVerification : correlationId : " + correlationId);
		ApiResponse<OTPVerificationResponse> resp = null;
		try {
			OTPVerificationResponse otpVerificationResponse = obpService.otpVerification(otpVerificationRequest,
					correlationId);
			if (null != otpVerificationResponse.getErrorMsg()) {
				resp = ApiResponse.<OTPVerificationResponse>builder().status(StatusCode.API_ERROR.getKey())
						.message(StatusCode.API_ERROR.getValue()).data(otpVerificationResponse).build();
				flywireService.auditLog(correlationId, otpVerificationRequest, resp, Stage.OTP_VERIFY_ERROR.name(),
						AppConstant.FAILURE);
			} else {
				resp = ApiResponse.<OTPVerificationResponse>builder().status(StatusCode.API_SUCCESS.getKey())
						.message(StatusCode.API_SUCCESS.getValue()).data(otpVerificationResponse).build();
				flywireService.auditLog(correlationId, otpVerificationRequest, resp, Stage.OTP_COMPLETED.name(),
						AppConstant.SUCCESS);
			}
		} catch (FlywireException e) {
			log.error(e);
			OTPVerificationResponse otpVerificationResponse = OTPVerificationResponse.builder()
					.status(AppConstant.FAILURE).errorMsg(e.getMessage()).build();
			resp = ApiResponse.<OTPVerificationResponse>builder().status(StatusCode.API_ERROR.getKey())
					.message(StatusCode.API_ERROR.getValue()).data(otpVerificationResponse).build();
			flywireService.auditLog(correlationId, otpVerificationRequest, resp, Stage.OTP_VERIFY_ERROR.name(),
					e.getMessage());
		}
		return ResponseEntity.ok(resp);
	}

	@ApiOperation("Get CASA details")
	@PostMapping(value = "/getCASADetails/{journeyId}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ApiResponse<FlywireResponseDetails>> getCASADetails(
			@RequestHeader(name = AppConstant.CORRELATION_ID, required = true) String correlationId,
			@PathVariable(name = AppConstant.JOURNEY_ID, required = true) String journeyId,
			@RequestBody @Valid CustomerCASA customerReq) {
		log.info("FlywireController :: getCASADetails : correlationId : " + correlationId);
		var response = obpService.getCASADetails(customerReq, correlationId);
		return ResponseEntity.ok(response);
	}

	@ApiOperation("Save Fund details")
	@PostMapping(value = "/setFundDetails/{journeyId}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ApiResponse<Void>> fundDetails(
			@RequestHeader(name = AppConstant.CORRELATION_ID, required = true) String correlationId,
			@PathVariable(name = AppConstant.JOURNEY_ID, required = true) String journeyId,
			@Valid @RequestBody FundDetails fundDetails) {
		log.info("FlywireController :: FundDetails  : correlationId : " + correlationId);
		ApiResponse<Void> resp = null;
		try {
			flywireService.saveFundDetails(correlationId, fundDetails);
			resp = ApiResponse.<Void>builder().status(StatusCode.API_SUCCESS.getKey())
					.message(StatusCode.API_SUCCESS.getValue()).build();
			flywireService.auditLog(correlationId, fundDetails, resp, Stage.FUND_DETAILS_COMPLETED.name(),
					AppConstant.SUCCESS);
		} catch (FlywireException e) {
			log.error(e);
			resp = ApiResponse.<Void>builder().status(StatusCode.API_ERROR.getKey())
					.message(StatusCode.API_ERROR.getValue()).build();
			flywireService.auditLog(correlationId, fundDetails, resp, Stage.FUND_DETAILS_ERROR.name(), e.getMessage());
		}
		return ResponseEntity.ok(resp);
	}

	@ApiOperation("Save LRS Details and TNC consent")
	@PostMapping(value = "/setConsent/{journeyId}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ApiResponse<Void>> saveConsent(
			@RequestHeader(name = AppConstant.CORRELATION_ID, required = true) String correlationId,
			@PathVariable(name = AppConstant.JOURNEY_ID, required = true) String journeyId,
			@Valid @RequestBody(required = false) ConsentRequest consentRequest) {
		log.info("FlywireController :: lrsInfo : correlationId : " + correlationId);
		ApiResponse<Void> resp = null;
		try {
			flywireService.storeConsent(correlationId, consentRequest);
			resp = ApiResponse.<Void>builder().status(StatusCode.API_SUCCESS.getKey())
					.message(StatusCode.API_SUCCESS.getValue()).build();
			flywireService.auditLog(correlationId, consentRequest, resp, Stage.LRS_TNC_COMPLETED.name(),
					AppConstant.SUCCESS);
		} catch (FlywireException e) {
			log.error(e);
			resp = ApiResponse.<Void>builder().status(StatusCode.API_ERROR.getKey())
					.message(StatusCode.API_ERROR.getValue()).build();
			flywireService.auditLog(correlationId, consentRequest, resp, Stage.LRS_TNC_ERROR.name(), e.getMessage());
		}
		return ResponseEntity.ok(resp);
	}

	@ApiOperation("Send sms after sucessful journey")
	@PostMapping(value = "/smsConfirmation/{journeyId}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ApiResponse<SMSPushResponse>> sendSmsConfirmation(
			@RequestHeader(name = AppConstant.CORRELATION_ID, required = true) String correlationId,
			@PathVariable(name = AppConstant.JOURNEY_ID, required = true) String journeyId,
			@Valid @RequestBody(required = true) SMSPushRequest smsPushRequest) {
		log.info("FlywireController :: sendSmsConfirmation : correlationId : " + correlationId);
		ApiResponse<SMSPushResponse> resp = null;
		try {
			SMSPushResponse smsPushResponse = obpService.smsPushNotification(smsPushRequest, correlationId);
			if (null == smsPushResponse)
				throw new FlywireException("No response receieved");
			else if (!StringUtils.isBlank(smsPushResponse.getErrorMsg()))
				resp = ApiResponse.<SMSPushResponse>builder().status(StatusCode.API_ERROR.getKey())
						.message(StatusCode.API_ERROR.getValue()).data(smsPushResponse).build();
			else
				resp = ApiResponse.<SMSPushResponse>builder().status(StatusCode.API_SUCCESS.getKey())
						.message(StatusCode.API_SUCCESS.getValue()).data(smsPushResponse).build();

			flywireService.auditLog(correlationId, smsPushRequest, resp, Stage.SMS_PUSHED.name(), AppConstant.SUCCESS);
		} catch (FlywireException e) {
			log.error(e);
			SMSPushResponse smsPushResponse = SMSPushResponse.builder().errorMsg(e.getMessage())
					.status(AppConstant.FAILURE).build();
			resp = ApiResponse.<SMSPushResponse>builder().status(StatusCode.API_ERROR.getKey())
					.message(StatusCode.API_ERROR.getValue()).data(smsPushResponse).build();
			flywireService.auditLog(correlationId, smsPushRequest, resp, Stage.SMS_PUSH_ERROR.name(), e.getMessage());
		}
		return ResponseEntity.ok(resp);
	}

	@ApiOperation("Build checkum for NB Auth")
	@PostMapping(value = "/getCheckSum/{journeyId}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ApiResponse<ChecksumResponse>> getCheckSum(
			@RequestHeader(name = AppConstant.CORRELATION_ID, required = true) String correlationId,
			@PathVariable(name = AppConstant.JOURNEY_ID, required = true) String journeyId,
			@Valid @RequestBody ChecksumRequest checksumRequest) {
		log.info("FlywireController :: getCheckSum : correlationId : " + correlationId);
		ApiResponse<ChecksumResponse> resp = null;
		try {
			ChecksumResponse checksumResponse = flywireService.buildChecksum(correlationId, checksumRequest);
			resp = ApiResponse.<ChecksumResponse>builder().status(StatusCode.API_SUCCESS.getKey())
					.data(checksumResponse).message(StatusCode.API_SUCCESS.getValue()).build();
			flywireService.auditLog(correlationId, checksumRequest, resp, Stage.CHECKSUM_DONE.name(),
					AppConstant.SUCCESS);
		} catch (FlywireException e) {
			log.error(e);
			ChecksumResponse checksumResponse = ChecksumResponse.builder().errorMsg(e.getMessage()).build();
			resp = ApiResponse.<ChecksumResponse>builder().status(StatusCode.API_ERROR.getKey())
					.message(StatusCode.API_ERROR.getValue()).data(checksumResponse).build();
			flywireService.auditLog(correlationId, checksumRequest, resp, Stage.CHECKSUM_ERROR.name(), e.getMessage());
		}
		return ResponseEntity.ok(resp);
	}

	@ApiOperation("Submit selected bank account")
	@PostMapping(value = "/submitAccount/{journeyId}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ApiResponse<SelectedAccountResponse>> submitAccount(
			@RequestHeader(name = AppConstant.CORRELATION_ID, required = true) String correlationId,
			@PathVariable(name = AppConstant.JOURNEY_ID, required = true) String journeyId,
			@Valid @RequestBody SelectedAccountRequest selectAccountRequest) {
		log.info("FlywireController :: submitAccount : correlationId : " + correlationId);
		ApiResponse<SelectedAccountResponse> resp = null;
		try {
			SelectedAccountResponse selectAccountResponse = flywireService.submitAccount(correlationId,
					selectAccountRequest);

			if (selectAccountResponse.getAccountSelected().booleanValue()) {
				resp = ApiResponse.<SelectedAccountResponse>builder().status(StatusCode.API_SUCCESS.getKey())
						.message(StatusCode.API_SUCCESS.getValue()).data(selectAccountResponse).build();
				flywireService.auditLog(correlationId, selectAccountRequest, resp, Stage.CASA_SUBMITTED.name(),
						AppConstant.SUCCESS);
			} else {
				resp = ApiResponse.<SelectedAccountResponse>builder().status(StatusCode.API_ERROR.getKey())
						.message(StatusCode.API_ERROR.getValue()).data(selectAccountResponse).build();
				flywireService.auditLog(correlationId, selectAccountRequest, resp, Stage.CASA_SUBMITTED_ERROR.name(),
						AppConstant.FAILURE);
			}
		} catch (FlywireException e) {
			log.error(e);
			SelectedAccountResponse selectAccountResponse = SelectedAccountResponse.builder().errorMsg(e.getMessage())
					.build();
			resp = ApiResponse.<SelectedAccountResponse>builder().status(StatusCode.API_ERROR.getKey())
					.message(StatusCode.API_ERROR.getValue()).data(selectAccountResponse).build();
			flywireService.auditLog(correlationId, selectAccountRequest, resp, Stage.CASA_ERROR.name(), e.getMessage());
		}
		return ResponseEntity.ok(resp);
	}

	@ApiOperation("Submit selected bank account")
	@PostMapping(value = "/uiTerminated/{journeyId}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ApiResponse<Void>> uiTerminated(
			@RequestHeader(name = AppConstant.CORRELATION_ID, required = true) String correlationId,
			@PathVariable(name = AppConstant.JOURNEY_ID, required = true) String journeyId,
			@Valid @RequestBody UITerminatedRequest terminatedRequest) {
		log.info("FlywireController :: uiTerminated : correlationId : " + correlationId);
		ApiResponse<Void> resp = null;
		try {
			flywireService.uiTerminated(correlationId);

			resp = ApiResponse.<Void>builder().status(StatusCode.API_SUCCESS.getKey())
					.message(StatusCode.API_SUCCESS.getValue()).build();
			flywireService.auditLog(correlationId, terminatedRequest, resp, Stage.UI_TERMINATED.name(),
					AppConstant.SUCCESS);
		} catch (FlywireException e) {
			log.error(e);
			resp = ApiResponse.<Void>builder().status(StatusCode.API_ERROR.getKey())
					.message(StatusCode.API_ERROR.getValue()).build();
			flywireService.auditLog(correlationId, terminatedRequest, resp, Stage.UI_TERMINATED_ERROR.name(),
					e.getMessage());
		}
		return ResponseEntity.ok(resp);
	}

	@ApiOperation("Build status Digest for Flywire")
	@PostMapping(value = "/getStatusDigest/{journeyId}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ApiResponse<DigestResponse>> getStatusDigest(
			@RequestHeader(name = AppConstant.CORRELATION_ID, required = true) String correlationId,
			@PathVariable(name = AppConstant.JOURNEY_ID, required = true) String journeyId,
			@Valid @RequestBody DigestRequest digestRequest) {
		log.info("FlywireController :: getCheckSum : correlationId : " + correlationId);
		ApiResponse<DigestResponse> resp = null;
		try {
			DigestResponse digestResponse = flywireService.buildDigest(digestRequest);
			resp = ApiResponse.<DigestResponse>builder().status(StatusCode.API_SUCCESS.getKey()).data(digestResponse)
					.message(StatusCode.API_SUCCESS.getValue()).build();
			flywireService.auditLog(correlationId, digestResponse, resp, Stage.CHECKSUM_DONE.name(),
					AppConstant.SUCCESS);
		} catch (FlywireException e) {
			log.error(e);
			DigestResponse digestResponse = DigestResponse.builder().errorMsg(e.getMessage()).build();
			resp = ApiResponse.<DigestResponse>builder().status(StatusCode.API_ERROR.getKey())
					.message(StatusCode.API_ERROR.getValue()).data(digestResponse).build();
			flywireService.auditLog(correlationId, digestRequest, resp, Stage.CHECKSUM_ERROR.name(), e.getMessage());
		}
		return ResponseEntity.ok(resp);
	}

	@ApiOperation("Save NBAuth status")
	@PostMapping(value = "/getNBAuthStatus/{journeyId}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public void getNBAuthStatus(@RequestHeader(name = AppConstant.CORRELATION_ID, required = true) String correlationId,
			@PathVariable(name = AppConstant.JOURNEY_ID, required = true) String journeyId,
			@Valid @RequestBody NbAuthStatus nbAuthStatus) {
		log.info("FlywireController :: getNBAuthStatus : correlationId : " + correlationId);
		try {
			flywireService.saveNBAuthStatus(correlationId, nbAuthStatus);
			flywireService.auditLog(correlationId, nbAuthStatus, null, Stage.NB_AUTH_COMPLETED.name(),
					AppConstant.SUCCESS);
		} catch (FlywireException e) {
			log.error(e);
			flywireService.auditLog(correlationId, nbAuthStatus, null, Stage.NB_AUTH_ERROR.name(), e.getMessage());
		}

	}

	@GetMapping(value = "/getDealProCSVTest", produces = MediaType.APPLICATION_JSON_VALUE)
	public void getDealProFileTest() {
		log.info("FlywireController :: getDealProFileTest ");
		try {
			List<DealProCSVMaker> list = dealProCSVMakerService1.exportToCSV();
			log.info("list size is =" + list.size());
			list.forEach(obj -> dealProCSVMakerService1.buildDealProCSV(obj));
			
		} catch (FlywireException e) {
			log.error(e);

		}

	}
	
	
	/*@PostMapping(value = "/fileUploadTest/{id}", consumes = MediaType.APPLICATION_JSON_VALUE)
	public void fileUploadTest(@PathVariable(name = "id", required = true) String id, @RequestBody FundDetailsDocs fundDetailsDocs) {	
			flywireService.fileUploadTest(id,fundDetailsDocs);
			
	}
	
	@PostMapping(value = "/downloadImage/{id}", consumes = MediaType.APPLICATION_JSON_VALUE)
	public void getNBAuthStatus(@PathVariable(name = "id", required = true) String id) {
		flywireService.downloadImage(id);

	}*/
	
	@ApiOperation("create recon file for a date, format is ddmmyy")
	@GetMapping(value = "/generateRconCSV{date}", produces = MediaType.APPLICATION_JSON_VALUE)
	public void generateRconCSV(@PathVariable(name = "date", required = true) String date) {
				log.info("OTPRecon: generateRconCSV : " + date);
		try {
			String localFilePath = otpReconDetailsService.createReconFile(date);
			if (null == localFilePath) {
				log.info("OTPRecon: No records found for DB data extraction csv generation");
				return;
			}

			FileTransferServiceUtil.uploadFile(otpBasePathLocation + localFilePath, otpReconSftpProperties);
			log.info("OTPRecon: DB data extraction csv generation completed successfully");
		} catch (FlywireException e) {
			log.error("OTPRecon: Error in DB data extraction csv generation ", e);
		}
	}
}
