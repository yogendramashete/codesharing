package com.hdfcbank.flywire.model.casa;

import java.util.List;

import com.hdfcbank.flywire.model.fund.BeneficiaryDetails;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
public class FlywireResponseDetails {
	//private FlywireDetails flywireDetails;
	private BeneficiaryDetails beneficiaryDetails;
	private List<CustomerMaskAccount> accounts;
	private String customerEmailId;
	private String customerFullName;
	private Integer customerId;
	private String customerTypeDesc;
	private String panNo;
	
	
}
