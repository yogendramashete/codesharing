package com.hdfcbank.flywire.service.impl;

import static com.hdfcbank.flywire.constant.AppConstant.CUST_TYPE_LIST;
import static com.hdfcbank.flywire.constant.AppConstant.EMAIL_MASK;
import static com.hdfcbank.flywire.constant.AppConstant.MASK_CHAR;
import static com.hdfcbank.flywire.constant.AppConstant.NON_SUFFICIENT;
import static com.hdfcbank.flywire.constant.AppConstant.NOT_MASK_LAST_4_DIGIT;
import static com.hdfcbank.flywire.constant.AppConstant.SUFFICIENT;
import static com.hdfcbank.flywire.constant.AppConstant.TRANSACTION_MAX_AMT;
import static com.hdfcbank.flywire.constant.AppConstant.TRANSACTION_MIN_AMT;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.ResourceUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hdfcbank.flywire.constant.AppConstant;
import com.hdfcbank.flywire.enums.Stage;
import com.hdfcbank.flywire.enums.StatusCode;
import com.hdfcbank.flywire.exception.FlywireException;
import com.hdfcbank.flywire.model.api.ApiResponse;
import com.hdfcbank.flywire.model.casa.AccountDetails;
import com.hdfcbank.flywire.model.casa.CustomerCASA;
import com.hdfcbank.flywire.model.casa.CustomerCASADetails;
import com.hdfcbank.flywire.model.casa.CustomerMaskAccount;
import com.hdfcbank.flywire.model.casa.FlywireResponseDetails;
import com.hdfcbank.flywire.model.casa.Request;
import com.hdfcbank.flywire.model.casa.Response;
import com.hdfcbank.flywire.model.dbentity.FlywireAudit;
import com.hdfcbank.flywire.model.dbentity.OTPReconDetails;
import com.hdfcbank.flywire.model.flywire.FlywireDetails;
import com.hdfcbank.flywire.model.fund.BeneficiaryDetails;
import com.hdfcbank.flywire.model.obp.otp.generation.request.RequestDTO;
import com.hdfcbank.flywire.model.obp.otp.generation.response.GenerateOTPRestResponseDTO;
import com.hdfcbank.flywire.model.obp.otp.generation.response.ResponseString;
import com.hdfcbank.flywire.model.obp.otp.verification.response.VerifyOTPRestResponseDTO;
import com.hdfcbank.flywire.model.obp.sms.response.PublishExternalAlertV2ResponseDTO;
import com.hdfcbank.flywire.model.otp.OTPCustomerDetails;
import com.hdfcbank.flywire.model.otp.OTPGenerationResponse;
import com.hdfcbank.flywire.model.otp.OTPVerificationRequest;
import com.hdfcbank.flywire.model.otp.OTPVerificationResponse;
import com.hdfcbank.flywire.model.sms.SMSPushRequest;
import com.hdfcbank.flywire.model.sms.SMSPushResponse;
import com.hdfcbank.flywire.repository.FlywireAuditRepository;
import com.hdfcbank.flywire.repository.FlywireInformationRepository;
import com.hdfcbank.flywire.repository.OTPReconDetailsRepository;
import com.hdfcbank.flywire.service.FlywireToOBPMapperService;
import com.hdfcbank.flywire.service.OBPService;
import com.hdfcbank.flywire.util.converter.TimestampConverter;
import com.hdfcbank.flywire.util.hash.HashingUtil;
import com.hdfcbank.flywire.util.rest.RestClient;

import lombok.extern.log4j.Log4j2;

@Service
@Log4j2
public class OBPServiceImpl implements OBPService {

	private static final String OTP_GENERATE_RESPONSE_HASH_CONSTANT_PREFIX = "static:genpwdres:07:";
	private static final String OTP_VERIFY_RESPONSE_HASH_CONSTANT_PREFIX = "static:verpwdres:04:";

	@Autowired
	private ObjectMapper objectMapper;

	@Value("${obp.endpoints.casa.url}")
	private String casaURL;

	@Value("${obp.endpoints.otp.generation.url}")
	private String otpGenerationURL;

	@Value("${obp.endpoints.otp.verification.url}")
	private String otpVerificationURL;

	@Value("${obp.endpoints.sms.url}")
	private String smsUrl;

	@Value("${obp.endpoints.sms.channelId}")
	private String smsChannelId;

	@Value("${casa.default-output}")
	private boolean defaultOutput;

	@Value("${obp.otp.hashKey}")
	private String otpHashKey;

	@Autowired
	private RestClient restClient;

	@Autowired
	private FlywireToOBPMapperService flywireToOBPMapperServiceImpl;

	@Autowired
	private FlywireAuditRepository flywireAuditRepository;

	@Autowired
	private FlywireInformationRepository flywireInformationRepository;

	@Autowired
	private OTPReconDetailsRepository otpReconDetailsRepository;

	@SuppressWarnings("unchecked")
	@Override
	public ApiResponse<FlywireResponseDetails> getCASADetails(CustomerCASA customerReq, String correlationId)
			throws FlywireException {
		log.info("in OBPServiceImpl :: getDemographicDetails");
		String requestStr = null;
		try {

			Request request = Request.builder().customerCASA(customerReq)
					.sessionContext(flywireToOBPMapperServiceImpl.getSessionContext(correlationId)).build();
			requestStr = objectMapper.writeValueAsString(request);
			log.info("requestStr =" + requestStr);
			Response response;
			if (!defaultOutput) {
				ResponseEntity<Response> restResp = restClient.invokeAPI(casaURL, HttpMethod.POST, null, request, null,
						new ParameterizedTypeReference<Response>() {
						}, correlationId, Stage.OBP_CASA);
				response = restResp.getBody();

			} else {
				File file = ResourceUtils.getFile("classpath:casa_response.json");
				response = objectMapper.readValue(file, Response.class);
			}
			if (null == response || (null == response.getCustomerCASADetailsDTO()))
				return invalidCasaError();

			flywireInformationRepository.saveCustomerCASADetails(correlationId,
					response.getCustomerCASADetailsDTO().get(0), Stage.CASA_FETCH_DONE.name());
			FlywireDetails flywireDetails = flywireInformationRepository.fetchFlywireDetails(correlationId);
			BeneficiaryDetails beneficiaryDetails = flywireInformationRepository
					.fetchBeneficiaryDetails(flywireDetails.getSettlementCurrency());
			String responseStr = objectMapper.writeValueAsString(response);
			log.info("transactionAmt " + flywireDetails);
			var validationResponse = validationCheck(response, flywireDetails, beneficiaryDetails, correlationId);
			FlywireAudit flywireAudit = FlywireAudit.builder().correlationId(correlationId)
					.stage(Stage.CASA_COMPLETED.toString()).request(requestStr).response(responseStr).build();
			flywireAuditRepository.save(flywireAudit);
			return validationResponse;

		} catch (FlywireException | IOException e) {
			FlywireAudit flywireAudit = FlywireAudit.builder().correlationId(correlationId)
					.stage(Stage.CASA_ERROR.toString()).request(requestStr).remark(e.getMessage()).build();
			flywireAuditRepository.save(flywireAudit);
			log.error(e);
			throw new FlywireException(e.getMessage());
		}

	}

	@SuppressWarnings("rawtypes")
	private ApiResponse invalidCasaError() {
		return ApiResponse.builder().status(StatusCode.INVALID_CASE_ERROR.getKey())
				.message(StatusCode.INVALID_CASE_ERROR.getValue()).build();
	}

	@SuppressWarnings("rawtypes")
	private ApiResponse validationCheck(Response response, FlywireDetails flywireDetails,
			BeneficiaryDetails beneficiaryDetails, String correlationId) {
		log.info("OBPService :: validationCheck ()");
		try {
			List<CustomerMaskAccount> maskAccountDetails = new ArrayList<>();
			FlywireResponseDetails flywireResponseDetails;
			Double tnxAmtUSD = Double.parseDouble(flywireDetails.getAmountDisburse());
			Double tnxAmtINR = Double.parseDouble(flywireDetails.getAmountCollect());
			CustomerCASADetails casaDetails = response.getCustomerCASADetailsDTO().get(0);
			List<AccountDetails> accountdeatils = casaDetails.getCasaAccountDetails();
			// boolean flags check
			boolean isEmail = !StringUtils.isBlank(casaDetails.getCustomerEmailId());
			boolean isCustType = CUST_TYPE_LIST.contains(casaDetails.getCustomerType().trim());
			boolean isValidAmt = TRANSACTION_MIN_AMT <= tnxAmtUSD && TRANSACTION_MAX_AMT >= tnxAmtUSD;
			// check account check
			List<AccountDetails> filterAccount = accountdeatils.stream()
					.filter(acc -> AppConstant.ACCOUNT_STATUS.contains(acc.getAccountStatus()))
					// .filter(acc -> AppConstant.RESIDENT.equals(acc.getAccountType()))
					.filter(acc -> !AppConstant.PRODUCT_CODE.contains(acc.getProductCode()))
					.collect(Collectors.toList());
			log.info("correlationId= " + correlationId + " isCustType= " + isCustType + " isEmail= " + isEmail
					+ " isValidAmt= " + isValidAmt + " filterAccount= " + filterAccount.size());
			if (isCustType && isEmail && isValidAmt && !filterAccount.isEmpty()) {
				filterAccount.forEach(acc -> maskAccountDetails.add(CustomerMaskAccount.builder()
						.accountNo(acc.getAccountNumber().replaceAll(NOT_MASK_LAST_4_DIGIT, MASK_CHAR))
						.accountType(acc.getProductType()).balance(acc.getClearBalance())
						.balanceStatus(acc.getClearBalance() > tnxAmtINR ? SUFFICIENT : NON_SUFFICIENT).build()));
				boolean match = maskAccountDetails.stream().anyMatch(s -> SUFFICIENT.contains(s.getBalanceStatus()));
				if (!match) {
					return ApiResponse.builder().status(StatusCode.FAILED_4X.getKey())
							.message(StatusCode.FAILED_4X.getValue()).build();
				}
				flywireResponseDetails = FlywireResponseDetails.builder().beneficiaryDetails(beneficiaryDetails)
						.accounts(maskAccountDetails)
						.customerEmailId(casaDetails.getCustomerEmailId().replaceAll(EMAIL_MASK, MASK_CHAR))
						.customerFullName(casaDetails.getCustomerFullName()).customerId(casaDetails.getCustomerId())
						.customerTypeDesc(casaDetails.getCustomerTypeDesc())
						.panNo(casaDetails.getPanNo().replaceAll(NOT_MASK_LAST_4_DIGIT, MASK_CHAR)).build();
			} else {
				return ApiResponse.builder().status(StatusCode.FAILED_3X.getKey())
						.message(StatusCode.FAILED_3X.getValue()).build();
			}
			return ApiResponse.builder().data(flywireResponseDetails).status(StatusCode.SUCCESS.getKey())
					.message(StatusCode.SUCCESS.getValue()).build();
		} catch (FlywireException e) {
			log.error(e);
			throw new FlywireException(e.getMessage());
		}
	}

	@Override
	public OTPGenerationResponse otpGeneration(String correlationId) throws FlywireException {
		try {
			OTPCustomerDetails otpCustomerDetails = flywireInformationRepository.fetchOTPCustomerDetails(correlationId);

			RequestDTO requestDTO = flywireToOBPMapperServiceImpl
					.mapFlywireOTPGenerationToOBPOTPGenerationRequest(otpCustomerDetails);

			ResponseEntity<GenerateOTPRestResponseDTO> response = restClient.invokeAPI(otpGenerationURL,
					HttpMethod.POST, null, requestDTO, null,
					new ParameterizedTypeReference<GenerateOTPRestResponseDTO>() {
					}, correlationId, Stage.OBP_OTP_GEN);

			log.info("OTP Generation Response : " + response);

			OTPReconDetails otpReconDetails = OTPReconDetails.builder().correlationId(correlationId)
					.transactionDate(TimestampConverter.getCurrentDate())
					.transactionTime(TimestampConverter.getCurrentTime()).stage("G")
					.orn(requestDTO.getGenerateOTPRestRequestDTO().getRequestString().getRefNo())
					.mobileNo(otpCustomerDetails.getPhoneNumber()).channelID(AppConstant.APPLICATION_IDENTIFIER)
					.transactionName(AppConstant.VERIFICATION).transactionType(AppConstant.VERIFICATION).build();

			GenerateOTPRestResponseDTO generateOTPRestResponseDTO = response.getBody();

			if (null != generateOTPRestResponseDTO) {
				ResponseString responseString = generateOTPRestResponseDTO.getResponseString();
				if (null != responseString) {
					boolean isHashValid = isMessageHashValid(OTP_GENERATE_RESPONSE_HASH_CONSTANT_PREFIX,
							responseString.getMessageHash(), responseString.getStatusCode(), responseString.getRefNo(),
							responseString.getPasswordValue(), responseString.getDatatimeGen(),
							responseString.getDatetimeExpire(), responseString.getErrorDetail(), otpHashKey);

					if (!isHashValid) {
						log.error("OTP Generate Hash no valid for correlationId: " + correlationId);
						throw new FlywireException(AppConstant.ERROR_MSG);
					}

					if ("00".equals(responseString.getStatusCode()))
						otpReconDetails.setStatus("0");
					else
						otpReconDetails.setStatus("1");

					otpReconDetailsRepository.save(otpReconDetails);

					return OTPGenerationResponse.builder().passwordValue(responseString.getPasswordValue())
							.refNo(responseString.getRefNo()).txnId(responseString.getTxnId()).build();
				}
			} else {
				log.error("OBP OTP generation response not valid");
				throw new FlywireException(AppConstant.ERROR_MSG);
			}
			return null;
		} catch (Exception e) {
			log.error(e.getMessage());
			throw new FlywireException(AppConstant.ERROR_MSG);
		}
	}

	@Override
	public OTPVerificationResponse otpVerification(OTPVerificationRequest otpVerificationRequest, String correlationId)
			throws FlywireException {
		try {
			OTPCustomerDetails otpCustomerDetails = flywireInformationRepository.fetchOTPCustomerDetails(correlationId);

			com.hdfcbank.flywire.model.obp.otp.verification.request.RequestDTO requestDTO = flywireToOBPMapperServiceImpl
					.mapFlywireOTPVerificationToOBPOTPVerificationRequest(otpVerificationRequest, otpCustomerDetails);

			ResponseEntity<VerifyOTPRestResponseDTO> response = restClient.invokeAPI(otpVerificationURL,
					HttpMethod.POST, null, requestDTO, null,
					new ParameterizedTypeReference<VerifyOTPRestResponseDTO>() {
					}, correlationId, Stage.OBP_OTP_VER);

			log.info("OTP Verification Response :  " + response);

			OTPReconDetails otpReconDetails = OTPReconDetails.builder().correlationId(correlationId)
					.transactionDate(TimestampConverter.getCurrentDate())
					.transactionTime(TimestampConverter.getCurrentTime()).stage("V")
					.orn(requestDTO.getVerifyOTPRestRequestDTO().getRequestString().getRefNo())
					.mobileNo(otpCustomerDetails.getPhoneNumber()).channelID(AppConstant.APPLICATION_IDENTIFIER)
					.transactionName(AppConstant.VERIFICATION).transactionType(AppConstant.VERIFICATION).build();

			VerifyOTPRestResponseDTO verifyOTPRestResponseDTO = response.getBody();

			if (null != verifyOTPRestResponseDTO) {
				com.hdfcbank.flywire.model.obp.otp.verification.response.ResponseString responseString = verifyOTPRestResponseDTO
						.getResponseString();

				boolean isHashValid = isMessageHashValid(OTP_VERIFY_RESPONSE_HASH_CONSTANT_PREFIX,
						responseString.getMessageHash(), responseString.getStatusCode(), responseString.getRefNo(),
						responseString.getErrorDetail(), otpHashKey);

				if (!isHashValid) {
					log.error("OTP Verify Hash no valid for correlationId: " + correlationId);
					throw new FlywireException("OTP Verify Hash no valid for correlationId:" + correlationId);
				}

				boolean isOTPVerifySuccessful = "00".equals(responseString.getStatusCode());
				if (isOTPVerifySuccessful)
					otpReconDetails.setStatus("0");
				else
					otpReconDetails.setStatus("1");

				otpReconDetailsRepository.save(otpReconDetails);

				if (isOTPVerifySuccessful)
					return OTPVerificationResponse.builder().status(AppConstant.SUCCESS).build();
				return OTPVerificationResponse.builder().status(AppConstant.FAILURE).errorMsg("OTP Verification Failed")
						.build();
			}
			return OTPVerificationResponse.builder().status(AppConstant.FAILURE)
					.errorMsg("No response from OTP Verification service").build();
		} catch (Exception e) {
			throw new FlywireException(e.getMessage());
		}
	}

	@Override
	public SMSPushResponse smsPushNotification(SMSPushRequest smsPushRequest, String correlationId)
			throws FlywireException {
		try {
			OTPCustomerDetails otpCustomerDetails = flywireInformationRepository.fetchOTPCustomerDetails(correlationId);

			com.hdfcbank.flywire.model.obp.sms.request.RequestDTO requestDTO = flywireToOBPMapperServiceImpl
					.mapFlywireSMSPushToOBPSMSPushRequest(smsPushRequest, otpCustomerDetails, correlationId);

			ResponseEntity<PublishExternalAlertV2ResponseDTO> response = restClient.invokeAPI(smsUrl, HttpMethod.POST,
					null, requestDTO, null, new ParameterizedTypeReference<PublishExternalAlertV2ResponseDTO>() {
					}, correlationId, Stage.OBP_SMS);

			log.info("SMS Generation Response : " + response);

			PublishExternalAlertV2ResponseDTO publishExternalAlertV2ResponseDTO = response.getBody();
			if (null == publishExternalAlertV2ResponseDTO) {
				log.error("Got null response");
				throw new FlywireException(AppConstant.ERROR_MSG);
			}

			if (publishExternalAlertV2ResponseDTO.getTransactionStatus().getReplyCode() == 0
					&& publishExternalAlertV2ResponseDTO.getTransactionStatus().getErrorCode().equals("0")
					&& null == publishExternalAlertV2ResponseDTO.getErrorMsg()) {
				String responseString = "APP-" + publishExternalAlertV2ResponseDTO.getDivisionCode() + "-"
						+ publishExternalAlertV2ResponseDTO.getCurrentTimestampInMilliSeconds() + "-"
						+ publishExternalAlertV2ResponseDTO.getIncrementedCounter() + "-"
						+ publishExternalAlertV2ResponseDTO.getServerId() + "-"
						+ publishExternalAlertV2ResponseDTO.getServerInstanceId();
				log.info("SMS Push success correlationId: " + correlationId + " responseString: " + responseString);
				return SMSPushResponse.builder().responseString(responseString).status(AppConstant.SUCCESS).build();

			}
			log.info("SMS Push failure correlationId: " + correlationId + " responseString: "
					+ publishExternalAlertV2ResponseDTO.getErrorMsg());
			return SMSPushResponse.builder().status(AppConstant.FAILURE)
					.errorMsg(publishExternalAlertV2ResponseDTO.getErrorMsg()).build();
		} catch (Exception e) {
			log.error("Error in sms push notification " + e.getMessage());
			throw new FlywireException(AppConstant.ERROR_MSG);
		}

	}

	private boolean isMessageHashValid(String prefix, String receivedHash, String... fields) {
		return receivedHash.equals(prefix + HashingUtil.calculateHash(fields));
	}
}
