package com.hdfcbank.flywire.service.impl;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.hdfcbank.flywire.constant.AppConstant;
import com.hdfcbank.flywire.exception.FlywireException;
import com.hdfcbank.flywire.model.obp.otp.generation.request.GenerateOTPRestRequestDTO;
import com.hdfcbank.flywire.model.obp.otp.generation.request.HeaderParams;
import com.hdfcbank.flywire.model.obp.otp.generation.request.RequestDTO;
import com.hdfcbank.flywire.model.obp.otp.generation.request.RequestString;
import com.hdfcbank.flywire.model.obp.otp.generation.request.SessionContext;
import com.hdfcbank.flywire.model.obp.otp.verification.request.VerifyOTPRestRequestDTO;
import com.hdfcbank.flywire.model.obp.sms.request.PublishExternalAlertV2RequestDTO;
import com.hdfcbank.flywire.model.otp.OTPCustomerDetails;
import com.hdfcbank.flywire.model.otp.OTPVerificationRequest;
import com.hdfcbank.flywire.model.sms.SMSPushRequest;
import com.hdfcbank.flywire.service.FlywireToOBPMapperService;
import com.hdfcbank.flywire.util.converter.TimestampConverter;
import com.hdfcbank.flywire.util.hash.HashingUtil;

import lombok.extern.log4j.Log4j2;

@Component
@Log4j2
public class FlywireToOBPMapperServiceImpl implements FlywireToOBPMapperService {

	private static final String API_KEY = "apiKey";
	private static final String API_USER = "apiUser";

	private static final String OTP_GENERATE_REQUEST_HASH_CONSTANT_PREFIX = "static:genpwdreq:06:";
	private static final String OTP_VERIFY_REQUEST_HASH_CONSTANT_PREFIX = "static:verpwdreq:06:";

	@Value("${obp.bankCode: 08}")
	private String bankCode;

	@Value("${obp.channel: FLYWR}")
	private String channel;

	@Value("${obp.userId: DevUser01}")
	private String userId;

	@Value("${obp.transactionBranch: 089999}")
	private String transactionBranch;

	@Value("${obp.transactingPartyCode: 50000010}")
	private String transactingPartyCode;

	@Value("${obp.otp.otpInstanceId: 8888}")
	private String otpInstanceId;

	@Value("${obp.otp.apiKeyValue}")
	private String apiKeyValue;

	@Value("${obp.otp.apiUserValue: testing}")
	private String apiUserValue;

	@Value("${obp.otp.hashKey}")
	private String otpHashKey;

	@Value("${obp.sms.messageType: S}")
	private String messageType;

	@Value("${obp.sms.smsSender: HDFCBank}")
	private String smsSender;

	@Value("${obp.sms.ctype}")
	private String ctype;

	@Value("${obp.sms.brd}")
	private String brd;

	@Value("${obp.sms.intflag}")
	private String intflag;

	@Value("${obp.sms.otp.messageText}")
	private String smsOtpMessageText;

	@Value("${obp.sms.confirm.messageText}")
	private String smsConfirmMessageText;

	@Value("${obp.sms.otp.userId}")
	private String smsOtpUserId;

	@Value("${obp.sms.otp.pwd}")
	private String smsOtpPwd;

	@Value("${obp.sms.otp.dcode}")
	private String smsOtpDcode;

	@Value("${obp.sms.confirm.userId}")
	private String smsConfirmUserId;

	@Value("${obp.sms.confirm.pwd}")
	private String smsConfirmPwd;

	@Value("${obp.sms.confirm.dcode}")
	private String smsConfirmDcode;

	@Override
	public RequestDTO mapFlywireOTPGenerationToOBPOTPGenerationRequest(OTPCustomerDetails otpCustomerDetails)
			throws FlywireException {
		try {
			String refNo = generateORN();
			SessionContext sessionContext = SessionContext.builder().bankCode(bankCode).channel(channel).userId(userId)
					.transactionBranch(transactionBranch).externalReferenceNo(refNo)
					.transactingPartyCode(transactingPartyCode).build();

			HeaderParams[] headerParams = { new HeaderParams(API_USER, apiKeyValue),
					new HeaderParams(API_KEY, apiUserValue) };
			String forceNew = "false";
			String linkData = StringUtils.leftPad("0", 19, otpCustomerDetails.getCustomerId());
			GenerateOTPRestRequestDTO generateOTPRestRequestDTO = new GenerateOTPRestRequestDTO(RequestString.builder()
					.instanceId(otpInstanceId)
					.apiUser(apiKeyValue)
					.linkData(linkData)
					.refNo(refNo)
					.messageHash(generateRequestHash(OTP_GENERATE_REQUEST_HASH_CONSTANT_PREFIX, otpInstanceId,
							apiKeyValue, linkData, refNo, forceNew, otpHashKey))
					.build(), headerParams);

			return RequestDTO.builder().sessionContext(sessionContext)
					.generateOTPRestRequestDTO(generateOTPRestRequestDTO).build();
		} catch (Exception e) {
			log.error("Error in mapping OTP generation request data ", e);
			throw new FlywireException("Error in mapping OTP generation request data " + e.getMessage());
		}
	}

	@Override
	public com.hdfcbank.flywire.model.obp.otp.verification.request.RequestDTO mapFlywireOTPVerificationToOBPOTPVerificationRequest(
			OTPVerificationRequest otpVerificationRequest, OTPCustomerDetails otpCustomerDetails)
			throws FlywireException {
		try {

			com.hdfcbank.flywire.model.obp.otp.verification.request.SessionContext sessionContext = com.hdfcbank.flywire.model.obp.otp.verification.request.SessionContext
					.builder().bankCode(bankCode).channel(channel).userId(userId).transactionBranch(transactionBranch)
					.externalReferenceNo(otpVerificationRequest.getRefNo()).transactingPartyCode(transactingPartyCode)
					.build();

			com.hdfcbank.flywire.model.obp.otp.verification.request.HeaderParams[] headerParams = {
					new com.hdfcbank.flywire.model.obp.otp.verification.request.HeaderParams(API_USER, apiKeyValue),
					new com.hdfcbank.flywire.model.obp.otp.verification.request.HeaderParams(API_KEY, apiUserValue) };

			String linkData = StringUtils.leftPad("0", 19, otpCustomerDetails.getCustomerId());
			VerifyOTPRestRequestDTO verifyOTPRestRequestDTO = new VerifyOTPRestRequestDTO(
					com.hdfcbank.flywire.model.obp.otp.verification.request.RequestString.builder()
							.messageHash(generateRequestHash(OTP_VERIFY_REQUEST_HASH_CONSTANT_PREFIX, otpInstanceId,
									apiKeyValue, linkData, otpVerificationRequest.getRefNo(),
									otpVerificationRequest.getOtp(), otpHashKey))
							.instanceId(otpInstanceId)
							.apiUser(apiKeyValue)
							.passwordValue(otpVerificationRequest.getOtp())
							.linkData(linkData)
							.refNo(otpVerificationRequest.getRefNo())
							.txnId(otpVerificationRequest.getTxnId())
							.build(),
					headerParams);

			return com.hdfcbank.flywire.model.obp.otp.verification.request.RequestDTO.builder()
					.sessionContext(sessionContext).verifyOTPRestRequestDTO(verifyOTPRestRequestDTO).build();
		} catch (Exception e) {
			log.error("Error in mapping OTP verify request data ", e);
			throw new FlywireException("Error in mapping OTP verify request data " + e.getMessage());
		}
	}

	@Override
	public com.hdfcbank.flywire.model.obp.sms.request.RequestDTO mapFlywireSMSPushToOBPSMSPushRequest(
			SMSPushRequest smsPushRequest, OTPCustomerDetails otpCustomerDetails, String correlationId)
			throws FlywireException {
		try {
			com.hdfcbank.flywire.model.obp.sms.request.SessionContext sessionContext = com.hdfcbank.flywire.model.obp.sms.request.SessionContext
					.builder().bankCode(bankCode).channel(channel).userId(userId).transactionBranch(transactionBranch)
					.externalReferenceNo(smsPushRequest.getRefNo()).transactingPartyCode(transactingPartyCode).build();
			PublishExternalAlertV2RequestDTO publishExternalAlertV2RequestDTO = null;

			String otpPassword = smsPushRequest.getSmsMsgKeywordValue();
			if (!StringUtils.isBlank(otpPassword))
				publishExternalAlertV2RequestDTO = new PublishExternalAlertV2RequestDTO(
						com.hdfcbank.flywire.model.obp.sms.request.RequestString.builder().userid(smsOtpUserId)
								.pwd(smsOtpPwd).sender(smsSender).pno(otpCustomerDetails.getPhoneNumber())
								.msgtxt(smsOtpMessageText.replace(":otp", otpPassword)).dcode(smsOtpDcode)
								.msgtype(messageType).msgid(smsPushRequest.getRefNo()).ctype(ctype).brd(brd)
								.intflag(intflag).build());
			else
				publishExternalAlertV2RequestDTO = new PublishExternalAlertV2RequestDTO(
						com.hdfcbank.flywire.model.obp.sms.request.RequestString.builder().userid(smsConfirmUserId)
								.pwd(smsConfirmPwd).sender(smsSender).pno(otpCustomerDetails.getPhoneNumber())
								.msgtxt(smsConfirmMessageText.replace(":correlationId", correlationId))
								.dcode(smsConfirmDcode).msgtype(messageType).msgid(smsPushRequest.getRefNo())
								.ctype(ctype).brd(brd).intflag(intflag).build());

			return com.hdfcbank.flywire.model.obp.sms.request.RequestDTO.builder().sessionContext(sessionContext)
					.publishExternalAlertV2RequestDTO(publishExternalAlertV2RequestDTO).build();
		} catch (Exception e) {
			log.error("Error in mapping SMS Push request data ", e);
			throw new FlywireException("Error in mapping SMS Push request data " + e.getMessage());
		}
	}

	private String generateRequestHash(String prefix, String... fields) throws FlywireException {
		return prefix + HashingUtil.calculateHash(fields);
	}

	private String generateORN() {
		String date = TimestampConverter.getCurrentDate();
		String traceAuditNumber = RandomStringUtils.randomNumeric(8);

		return AppConstant.APPLICATION_IDENTIFIER + date + traceAuditNumber;
	}

	@Override
	public com.hdfcbank.flywire.model.casa.SessionContext getSessionContext(String correlationId)
			throws FlywireException {
		try {
			return com.hdfcbank.flywire.model.casa.SessionContext.builder().bankCode(bankCode).channel(channel)
					.userId(userId).transactionBranch(transactionBranch).userReferenceNumber(correlationId).build();
		} catch (Exception e) {
			log.error("Error in mapping casa session request data ", e);
			throw new FlywireException("Error in mapping casa session request data " + e.getMessage());
		}
	}

}
