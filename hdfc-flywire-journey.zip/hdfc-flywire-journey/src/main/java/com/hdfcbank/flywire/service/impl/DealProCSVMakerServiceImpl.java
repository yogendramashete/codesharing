package com.hdfcbank.flywire.service.impl;

import static com.hdfcbank.flywire.repository.DBFieldsConstants.*;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.FilenameFilter;
import java.io.IOException;
import java.sql.Blob;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Service;

import com.hdfcbank.flywire.constant.AppConstant;
import com.hdfcbank.flywire.enums.Stage;
import com.hdfcbank.flywire.exception.FlywireException;
import com.hdfcbank.flywire.model.dealpro.DealProCSVMaker;
import com.hdfcbank.flywire.service.DealProCSVMakerService;
import com.opencsv.CSVWriter;

import lombok.extern.log4j.Log4j2;

@Service
@Log4j2
public class DealProCSVMakerServiceImpl implements DealProCSVMakerService {

	private static final String FLYWIRE_1_CSV = "-FLYWIRE-1.csv";

	private static final String BANKSTMTDOC = "-BANKSTMTDOC.";

	private static final String LOANDOC = "-LOANDOC.";

	private static final String FLYWIRE_2_CSV = "-FLYWIRE-2.csv";

	private static final String ZIP_EXT = ".zip";

	@Value("${file.base.path.dealpro}")
	private String basePathLocation;

	@Autowired
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
	
	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Value("${dealpro.csvFile1Query}")
	private String csvFile1Query;

	@Value("${dealpro.csvFile2Query}")
	private String csvFile2Query;

	@Value("${dealpro.attachmentsQuery}")
	private String attachmentsQuery;

	@Value("${dealpro.dealproStatusUpdate}")
	private String dealproStatusUpdate;

	@Override
	public List<String> exportToCSV() throws FlywireException {
		try {
			List<String> correlationIdList = writeFirstCSVFile();
			if (!correlationIdList.isEmpty()) {
				writeSecondCSVFile(correlationIdList);
				writeAttachmentFiles(correlationIdList);
				createZipForAll(correlationIdList);
			}
			return correlationIdList;
		} catch (Exception e) {
			log.error("Error while creating dealpro upload file ", e);
			throw new FlywireException("Error while creating dealpro upload file " + e.getMessage());
		}
	}

	@Override
	public void updateDealProStatus(String correlationId, String dealproStatus) throws FlywireException {
		try {
			Map<String, Object> parameters = new HashMap<>();
			parameters.put("correlationId", correlationId);
			parameters.put("dealproStatus", dealproStatus);
			namedParameterJdbcTemplate.update(dealproStatusUpdate, parameters);
		} catch (Exception e) {
			log.error("Error updating status for dealpro file upload ", e);
			throw new FlywireException("Error updating status for dealpro file upload ", e);
		}
	}

	private void createZipForAll(List<String> correlationIdList) {
		File root = new File(basePathLocation);
		for (String correlationId : correlationIdList) {
			FilenameFilter beginswithm = (directory, filename) -> filename.startsWith(correlationId + "-");
			zip(Arrays.asList(root.listFiles(beginswithm)), basePathLocation + correlationId + ZIP_EXT);
		}
	}

	public static File zip(List<File> files, String filename) {
		File zipfile = new File(filename);
		// Create a buffer for reading the files
		byte[] buf = new byte[1024];
		try {
			// create the ZIP file
			ZipOutputStream out = new ZipOutputStream(new FileOutputStream(zipfile));
			// compress the files
			for (int i = 0; i < files.size(); i++) {
				FileInputStream in = new FileInputStream(files.get(i).getCanonicalFile());
				// add ZIP entry to output stream
				out.putNextEntry(new ZipEntry(files.get(i).getName()));
				// transfer bytes from the file to the ZIP file
				int len;
				while ((len = in.read(buf)) > 0) {
					out.write(buf, 0, len);
				}
				// complete the entry
				out.closeEntry();
				in.close();
			}
			// complete the ZIP file
			out.close();
			return zipfile;
		} catch (IOException ex) {
			throw new FlywireException(ex.getMessage());
		}
	}

	private void writeSecondCSVFile(List<String> correlationIdList) throws FlywireException {
		SqlParameterSource parameterSource = new MapSqlParameterSource("correlationIdList", correlationIdList);
		log.info("csvFile1Query = " + csvFile2Query + " param = " + parameterSource.getParameterNames());
		namedParameterJdbcTemplate.query(csvFile2Query, parameterSource, (rs, rownum) -> {
			String correlationId = rs.getString(CORRELATION_ID);
			String[] data = new String[7];
			data[0] = rs.getString(FLYWIRE_CREATED_AT);
			data[1] = rs.getString(PARTNER_ID);
			data[2] = rs.getString(PAYMENT_ID);
			data[3] = rs.getString(RELATIONSHIP_WITH_STUDENT);
			data[4] = rs.getString(NOTIFY_URL);
			data[5] = rs.getString(RECIPIENT_NAME);
			data[6] = getCurrencyRate(rs.getString(AMOUNT_COLLECT), rs.getString(AMOUNT_DISBURSE));
			String csvFileLocation = basePathLocation + correlationId + FLYWIRE_2_CSV;

			try (CSVWriter writer = new CSVWriter(new FileWriter(csvFileLocation))) {
				String[] csvHeader1 = { "Date Initiated", "Partner Name", "Partner Payment ID",
						"Customer's Relationship with Student", "Payment Status Webhook URL",
						"Ultimate Beneficiary Name", "Currency Rate" };
				writer.writeNext(csvHeader1);
				writer.writeNext(data);
				writer.flush();
			} catch (IOException e) {
				log.error(e);
				throw new FlywireException(e.getMessage());
			}
			return null;
		});
	}

	private String getCurrencyRate(String amountCollect, String amountDisbuse) {
		Double currencyRate = Double.parseDouble(amountCollect) / Double.parseDouble(amountDisbuse);
		return Double.toString(currencyRate);
	}

	private void writeAttachmentFiles(List<String> correlationIdList) throws FlywireException {
		SqlParameterSource parameterSource = new MapSqlParameterSource("correlationIdList", correlationIdList);
		log.info("attachmentsQuery = " + attachmentsQuery + " param= " + parameterSource.getParameterNames());
		namedParameterJdbcTemplate.query(attachmentsQuery, parameterSource, (rs, rownum) -> {

			String correlationId = rs.getString(CORRELATION_ID);
			String loanDocsExt = rs.getString(LOAN_DOCS_EXT);
			String bankStmtExt = rs.getString(BANK_STATEMENT_DOCS_EXT);
			log.info("correlationId = " + correlationId + " loanDocsExt= " + loanDocsExt +" bankStmtExt ="+bankStmtExt);
			if (StringUtils.isNotBlank(loanDocsExt)) {
				writeFile(correlationId, rs.getBlob(LOAN_DOCS), LOANDOC, loanDocsExt);
			}
			if (StringUtils.isNotBlank(bankStmtExt)) {
				writeFile(correlationId, rs.getBlob(BANK_STATEMENT_DOCS), BANKSTMTDOC, bankStmtExt);
			}
			return null;

		});

	}

	private void writeFile(String correlationId, Blob attachment, String fileNamePart, String ext)
			throws FlywireException {
		String blobFileLocation = basePathLocation + correlationId + fileNamePart + ext;
		try (FileOutputStream fout = new FileOutputStream(blobFileLocation)) {
			byte[] barr = attachment.getBytes(1, (int) attachment.length());
			fout.write(Base64.getDecoder().decode(barr));
		} catch (Exception e) {
			log.error(e);
			throw new FlywireException(e.getMessage());
		}
	}

	private List<String> writeFirstCSVFile() throws FlywireException {
		List<String> correlationIdList = new ArrayList<>();
		SqlParameterSource parameterSource = new MapSqlParameterSource("stages",
				List.of(Stage.NB_AUTH_COMPLETED.name(), Stage.SMS_PUSHED.name()));
		log.info("csvFile1Query = " + csvFile1Query + " param= " + parameterSource.getParameterNames());

		namedParameterJdbcTemplate.query(csvFile1Query, parameterSource, (rs, rownum) -> {
			while (rs.next()) {
				String correlationId = rs.getString(CORRELATION_ID);
				correlationIdList.add(correlationId);
				String[] data = new String[56];
				data[0] = rs.getString(CREATED_AT);
				data[1] = rs.getString(CORRELATION_ID);
				data[2] = rs.getString(CUSTOMER_ID);
				data[3] = rs.getString(ACCOUNT_BRANCH_NAME);
				data[4] = rs.getString(PRODUCT_CODE);
				data[5] = rs.getString(CUSTOMER_FULL_NAME);
				data[6] = rs.getString(ACCOUNT_NUMBER);
				data[7] = AppConstant.EMPTY; // Remitter Address
				data[8] = rs.getString(PAN_NO);
				data[9] = rs.getString(CUSTOMER_ACCOUNT_RELATION);

				data[10] = rs.getString(ACCOUNT_TYPE);
				data[11] = rs.getString(CUSTOMER_TYPE_DESC);
				data[12] = rs.getString(SETTLEMENT_CURRENCY);
				data[13] = rs.getString(AMOUNT_DISBURSE);
				data[14] = AppConstant.EDUCATION;
				data[15] = rs.getString(ADDITIONAL_COMMENTS);
				data[16] = AppConstant.EMPTY;

				data[17] = rs.getString(BENEFICIARY_NAME);
				data[18] = rs.getString(BENEFICIARY_ADDRESS);
				data[19] = rs.getString(BENEFICIARY_COUNTRY);
				data[20] = rs.getString(BENEFICIARY_CONTACT_NUMBER);
				data[21] = rs.getString(BENEFICIARY_BANK_NAME);
				data[22] = rs.getString(BENEFICIARY_BANK_ADDRESS);
				data[23] = rs.getString(BENEFICIARY_ACCOUNT_NO);
				data[24] = rs.getString(SWIFT_CODE);
				data[25] = rs.getString(ABA_NUMBER);
				data[26] = rs.getString(CHIP_UID);
				data[27] = rs.getString(IBAN_NO);

				data[28] = AppConstant.EMPTY;
				data[29] = AppConstant.EMPTY;
				data[30] = AppConstant.EMPTY;
				data[31] = AppConstant.EMPTY;
				data[32] = AppConstant.EMPTY;
				data[33] = AppConstant.EMPTY;
				data[34] = AppConstant.EMPTY;

				data[35] = rs.getString(BANK_CHARGES);
				data[36] = AppConstant.EMPTY; // Sender to Receiver Info
				data[37] = AppConstant.SCHEME;

				data[38] = rs.getString(CUSTOMER_EMAIL_ID);
				data[39] = rs.getString(MOBILE_NUMBER);
				data[40] = rs.getString(ETHNIC_CODE);

				data[41] = AppConstant.EMPTY;
				data[42] = AppConstant.EMPTY;
				data[43] = AppConstant.EMPTY;
				data[44] = AppConstant.EMPTY;
				data[45] = AppConstant.EMPTY;
				data[46] = AppConstant.EMPTY;
				data[47] = AppConstant.EMPTY;
				data[48] = AppConstant.EMPTY;
				data[49] = AppConstant.EMPTY;
				data[50] = AppConstant.EMPTY;
				data[51] = AppConstant.EMPTY;

				data[52] = rs.getString(RECIPIENT_COUNTRY);// Recipient_country
				data[53] = rs.getString(LRS_TRANSACTION);
				data[54] = rs.getString(SOURCE_OF_FUND);
				data[55] = rs.getString(RECIPIENT_NAME);// Name of Institution

				String csvFileLocation = basePathLocation + correlationId + FLYWIRE_1_CSV;

				try (CSVWriter writer = new CSVWriter(new FileWriter(csvFileLocation))) {
					writer.writeNext(getHeader());
					writer.writeNext(data);
					writer.flush();
				} catch (IOException e) {
					log.error(e);
					throw new FlywireException(e.getMessage());
				}
			}
			return null;
		});
		return correlationIdList;
	}

	private String[] getHeader() {
		String[] header = { "Date", "NB Ref no", "Customer ID", "Account Number branch code",
				"Account Number prod code", "Customer Name", "Account Number", "Remitter Address", "PanCard",
				"Account Number Relationship", "Resident Non Resident", "Individua Non Individual", "FCY Currency Type",
				"FCY Amount", "Purpose of Remittance", "Additional field 1 Name", "Additional field 2 Name",
				"Beneficiary name", "Beneficiary Address", "Country of Beneficiary", "Contact Number",
				"Beneficiary Bank Name", "Beneficiary Bank Address", "Beneficiary Account No", "SWIFT Code",
				"SWIFT ABA No", "SWIFT CHIP UID", "SWIFT IBAN No.", "Name of Intermediary Bank",
				"Intermediate Bank Address", "Acc No BenefBank in InterBank", "SWIFTCode of inter bank",
				"SWIFTABANo of inter bank", "SWIFTCHIPUID of inter bank", "SWIFTIBANNo of inter bank",
				"Corr Bank Charges borne by", "Sender to Receiver Info", "Scheme", "Email ID", "Mobile no.",
				"Ethnic Code", "Rate Improvement", "TT Commission Amount", "Banned Entity Check Done",
				"FEMA Limit Check Done", "FATF Country Check", "Trade FX Trn ref no.", "TTSelling OW Rem card rate",
				"USD TT Sell OW Rem card rate", "USD Equivalent", "Card Rate applied to customer", "Rate Type",
				"Ultimate_Service_Country", "Tax residency of India", "Source of funds", "Name of Institution" };
		log.info("header count size is = " + header.length);
		return header;

	}

	
}
