package com.hdfcbank.flywire.model.fund;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BeneficiaryDetails {

	private String beneficiaryName;
	private String beneficiaryAddress;
	private String beneficiaryCountry;
}
