package com.hdfcbank.flywire.model.casa;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonPropertyOrder({"FetchCustomerCASADetailsReqDTO"})
@Builder
public class Request {

	@JsonProperty("FetchCustomerCASADetailsReqDTO")
	private CustomerCASA customerCASA;
	private SessionContext sessionContext;
}
