package com.hdfcbank.flywire.service.impl;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.hdfcbank.flywire.exception.FlywireException;
import com.hdfcbank.flywire.model.dbentity.OTPReconDetails;
import com.hdfcbank.flywire.repository.OTPReconDetailsRepository;
import com.hdfcbank.flywire.service.OTPReconDetailsService;
import com.opencsv.CSVWriter;

import lombok.extern.log4j.Log4j2;

@Service
@Log4j2
public class OTPReconDetailsServiceImpl implements OTPReconDetailsService {

	private static final String FILENAME_PREFIX = "FLYWIRE_";
	private static final String FILENAME_EXTENSION = ".csv";

	@Value("${file.base.path.otprecon}")
	private String basePathLocation;

	@Autowired
	private OTPReconDetailsRepository otpReconDetailsRepository;

	@Override
	public String createReconFile(String date) throws FlywireException {
		try {
			List<OTPReconDetails> otpReconDetails = otpReconDetailsRepository.findByTransactionDate(date);
			if (otpReconDetails.isEmpty())
				return null;

			var dataList = new ArrayList<String[]>();
			for (OTPReconDetails otpReconDetail : otpReconDetails) {
				var data = new String[9];
				data[0] = otpReconDetail.getChannelID();
				data[1] = otpReconDetail.getOrn();
				data[2] = otpReconDetail.getMobileNo();
				data[3] = otpReconDetail.getTransactionDate();
				data[4] = otpReconDetail.getTransactionTime();
				data[5] = otpReconDetail.getTransactionType();
				data[6] = otpReconDetail.getTransactionName();
				data[7] = otpReconDetail.getStage();
				data[8] = otpReconDetail.getStatus();

				dataList.add(data);
			}

			String csvFileLocation = basePathLocation + FILENAME_PREFIX + date + FILENAME_EXTENSION;

			writeFile(dataList, csvFileLocation);

			return csvFileLocation;
		} catch (Exception e) {
			log.error("Error creating OTP recon file  ", e);
			throw new FlywireException("Error creating OTP recon file  " + e.getMessage());
		}
	}

	private void writeFile(ArrayList<String[]> data, String csvFileLocation) {
		try (CSVWriter writer = new CSVWriter(new FileWriter(csvFileLocation))) {
			String[] csvHeader = { "Channel Id", "ORN", "Mobile Number", "Transaction Date", "Transaction Time",
					"Transaction Type", "Transaction Name", "Generation/Verification", "Status" };
			writer.writeNext(csvHeader);
			writer.writeAll(data);
			writer.flush();
		} catch (IOException e) {
			log.error("Error writing to file ", e);
			throw new FlywireException(e.getMessage());
		}
	}

}
