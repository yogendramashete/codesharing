package com.hdfcbank.flywire.util.rest;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hdfcbank.flywire.enums.Stage;
import com.hdfcbank.flywire.exception.RestClientExceptionHandler;
import com.hdfcbank.flywire.model.dbentity.FlywireAudit;
import com.hdfcbank.flywire.repository.FlywireAuditRepository;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;
import lombok.extern.log4j.Log4j2;

@Component
@Log4j2
public class RestClient {

	private RestTemplate restTemplate;
	private RestClientExceptionHandler restClientExceptionHandler;
	private ObjectMapper objectMapper;
	private FlywireAuditRepository flywireAuditRepository;

	public RestClient(@Autowired RestTemplate restTemplate, RestClientExceptionHandler restClientExceptionHandler,
			@Autowired ObjectMapper objectMapper, @Autowired FlywireAuditRepository flywireAuditRepository) {
		this.restTemplate = restTemplate;
		this.restClientExceptionHandler = restClientExceptionHandler;
		this.objectMapper = objectMapper;
		this.flywireAuditRepository = flywireAuditRepository;

	}

	@CircuitBreaker(name = "backend", fallbackMethod = "failureinvokeAPI")
	@Retry(name = "backend")
	public <T> ResponseEntity<T> invokeAPI(String url, HttpMethod method, MultiValueMap<String, String> queryParams,
			Object body, Map<String, String> headerParams, ParameterizedTypeReference<T> returnType,
			String correlationId, Stage stage) {
		FlywireAudit flywireAudit = null;
		try {

			final UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url);
			if (queryParams != null) {
				builder.queryParams(queryParams);
			}
			final RequestEntity.BodyBuilder requestBuilder = RequestEntity.method(method, builder.build().toUri());
			if (headerParams != null) {
				addHeadersToRequest(headerParams, requestBuilder);
			}
			RequestEntity<Object> requestEntity = requestBuilder.body(body);
			flywireAudit = FlywireAudit.builder().correlationId(correlationId).stage(stage.name())
					.request(objectMapper.writeValueAsString(requestEntity)).build();

			log.info("REQUEST: = " + objectMapper.writeValueAsString(requestEntity));
			ResponseEntity<T> responseEntity = restTemplate.exchange(requestEntity, returnType);
			log.info("RESPONSE: = " + objectMapper.writeValueAsString(responseEntity));

			flywireAudit.setResponse(objectMapper.writeValueAsString(responseEntity));

			if (responseEntity.getStatusCode() == HttpStatus.NO_CONTENT) {
				return null;
			} else if (responseEntity.getStatusCode().is2xxSuccessful()) {
				if (returnType == null) {
					return null;
				}
				return responseEntity;
			} else {
				return null;
				// The error handler built into the RestTemplate should handle 400 and 500
				// series errors.
				// throw new RestClientException("API returned " + statusCode + " and it wasn't
				// handled by the RestTemplate error handler");
			}

		} catch (Exception restException) {
			return this.restClientExceptionHandler.handleApiCallException(restException);
		} finally {
			if (null != flywireAudit)
				flywireAuditRepository.save(flywireAudit);
		}
	}

	public <T> ResponseEntity<T> failureinvokeAPI(String path, HttpMethod method,
			MultiValueMap<String, String> queryParams, Object body, Map<String, String> headerParams,
			ParameterizedTypeReference<T> returnType, String correlationId, Stage stage, Exception ex) {

		ResponseEntity<T> responseEntity = new ResponseEntity<>(HttpStatus.SERVICE_UNAVAILABLE);
		log.error("Circuit Breaker called for path : " + path + " and body: " + body.toString());
		return responseEntity;
	}

	/**
	 * Add headers to the request that is being built
	 *
	 * @param headers        The headers to add
	 * @param requestBuilder The current request
	 */
	private void addHeadersToRequest(Map<String, String> headers, RequestEntity.BodyBuilder requestBuilder) {
		for (Map.Entry<String, String> entry : headers.entrySet()) {
			requestBuilder.header(entry.getKey(), entry.getValue());
		}
	}

}
