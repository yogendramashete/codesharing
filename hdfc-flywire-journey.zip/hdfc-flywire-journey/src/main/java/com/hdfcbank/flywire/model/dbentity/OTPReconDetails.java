package com.hdfcbank.flywire.model.dbentity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Table(name = "OTP_RECON_DETAILS")
@Entity
@Getter
@Setter
@Builder
@ToString(includeFieldNames = false, exclude = { "id", "correlationId" })
@NoArgsConstructor
@AllArgsConstructor
public class OTPReconDetails {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID")
	private Long id;
	@Column(name = "CORRELATION_ID", length = 15)
	private String correlationId;
	@Column(name = "CHANNEL_ID", length = 10)
	private String channelID;
	@Column(name = "ORN", length = 20)
	private String orn;
	@Column(name = "MOBILE_NO", length = 15)
	private String mobileNo;
	@Column(name = "TRANSACTION_DATE", length = 10) // DDMMYY
	private String transactionDate;
	@Column(name = "TRANSACTION_TIME", length = 10) // HHMMSS
	private String transactionTime;
	@Column(name = "TRANSACTION_TYPE", length = 20)
	private String transactionType;
	@Column(name = "TRANSACTION_NAME", length = 20)
	private String transactionName;
	@Column(name = "STAGE", length = 1) // G/V
	private String stage;
	@Column(name = "STATUS", length = 1) // SUCCESSFUL "0", WHEN ITS FAILED FOR ANY REASON "1"
	private String status;
}
