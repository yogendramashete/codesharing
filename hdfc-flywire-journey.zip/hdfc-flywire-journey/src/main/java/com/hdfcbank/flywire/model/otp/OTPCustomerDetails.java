package com.hdfcbank.flywire.model.otp;

import javax.validation.constraints.NotBlank;

import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class OTPCustomerDetails {
	@NotBlank
	private String customerId;
	@NotBlank
	private String phoneNumber;
}
