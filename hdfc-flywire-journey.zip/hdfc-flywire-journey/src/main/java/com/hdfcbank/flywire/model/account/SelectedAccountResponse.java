package com.hdfcbank.flywire.model.account;

import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class SelectedAccountResponse {

	private Boolean accountSelected;
	private String errorMsg;
}
