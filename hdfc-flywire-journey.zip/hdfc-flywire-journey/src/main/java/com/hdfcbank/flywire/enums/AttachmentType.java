package com.hdfcbank.flywire.enums;

public enum AttachmentType {
	LOANDOC, BANKSTMT;
}
