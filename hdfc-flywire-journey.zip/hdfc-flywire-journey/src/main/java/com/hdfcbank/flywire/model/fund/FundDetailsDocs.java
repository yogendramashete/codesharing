package com.hdfcbank.flywire.model.fund;

import javax.validation.constraints.NotBlank;

import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class FundDetailsDocs {
	@NotBlank
	private String type;
	@NotBlank
	private String extension;
	@NotBlank
	private String content;
	

}
