package com.hdfcbank.flywire.service.impl;

import static com.hdfcbank.flywire.repository.DBFieldsConstants.*;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Blob;
import java.util.Arrays;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.xml.bind.DatatypeConverter;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Service;

import com.hdfcbank.flywire.config.SftpProperties;
import com.hdfcbank.flywire.constant.AppConstant;
import com.hdfcbank.flywire.enums.Stage;
import com.hdfcbank.flywire.exception.FlywireException;
import com.hdfcbank.flywire.model.dealpro.DealProCSVMaker;
import com.hdfcbank.flywire.service.DealProCSVMakerService1;
import com.hdfcbank.flywire.util.sftp.FileTransferServiceUtil;
import com.opencsv.CSVWriter;
import com.opencsv.ICSVWriter;

import lombok.extern.log4j.Log4j2;

@Service
@Log4j2
public class DealProCSVMakerServiceImpl1 implements DealProCSVMakerService1 {

	private static final String FLYWIRE_1_CSV = "_FLYWIRE_1.csv";

	private static final String BANKSTMTDOC = "_BANKSTMTDOC.";

	private static final String LOANDOC = "_LOANDOC.";

	private static final String FLYWIRE_2_CSV = "_FLYWIRE_2.csv";

	private static final String ZIP_EXT = ".zip";

	@Value("${file.base.path.dealpro}")
	private String basePathLocation;

	@Autowired
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

	@Value("${dealpro.csvFile1Query}")
	private String csvFile1Query;

	@Value("${dealpro.csvFile2Query}")
	private String csvFile2Query;

	@Value("${dealpro.attachmentsQuery}")
	private String attachmentsQuery;

	@Value("${dealpro.dealproStatusUpdate}")
	private String dealproStatusUpdate;

	@Autowired
	@Qualifier("dealProSftpProperties")
	private SftpProperties dealProSftpProperties;

	@Override
	public List<DealProCSVMaker> exportToCSV() throws FlywireException {
		SqlParameterSource parameterSource = new MapSqlParameterSource("stages",
				List.of(Stage.NB_AUTH_COMPLETED.name(), Stage.SMS_PUSHED.name()));

		return namedParameterJdbcTemplate.query(csvFile1Query, parameterSource, (rs, rowNum) -> DealProCSVMaker
				.builder().id(rs.getString(ID)).correlationId(rs.getString(CORRELATION_ID))
				.createdAt(rs.getString(CREATED_AT)).customerId(rs.getString(CUSTOMER_ID))
				.customerGender(rs.getString(CUSTOMER_GENDER))
				.customerType(rs.getString(CUSTOMER_TYPE))
				.customerTypeDesc(rs.getString(CUSTOMER_TYPE_DESC))
				.dateOfBirth(rs.getString(DATE_OF_BIRTH)).accountBranchName(rs.getString(ACCOUNT_BRANCH_NAME))
				.customerFullName(rs.getString(CUSTOMER_FULL_NAME)).accountNumber(rs.getString(ACCOUNT_NUMBER))
				.panNo(rs.getString(PAN_NO)).customerAccountRelation(rs.getString(CUSTOMER_ACCOUNT_RELATION))
				.accountType(rs.getString(ACCOUNT_TYPE))
				.paymentId(rs.getString(PAYMENT_ID)).amountCollect(rs.getString(AMOUNT_COLLECT))
				.currencyCollect(rs.getString(CURRENCY_COLLECT)).currencydDsburse(rs.getString(CURRENCY_DISBURSE))
				.partnerId(rs.getString(PARTNER_ID)).returnURL(rs.getString(RETURN_URL))
				.notifyURL(rs.getString(NOTIFY_URL)).flywireCreateAt(rs.getString(FLYWIRE_CREATED_AT))
				.clearingBalance(rs.getString(CLEARING_BALANCE)).branchCode(rs.getString(BRANCH_CODE))
				.productCode(rs.getString(PRODUCT_CODE)).productName(rs.getString(PRODUCT_NAME))
				.productType(rs.getString(PRODUCT_TYPE)).accountStatus(rs.getString(ACCOUNT_STATUS))
				.settlementCurrency(rs.getString(SETTLEMENT_CURRENCY)).amountDisburse(rs.getString(AMOUNT_DISBURSE))
				.additionalComments(rs.getString(ADDITIONAL_COMMENTS)).beneficiaryName(rs.getString(BENEFICIARY_NAME))
				.beneficiaryAddress(rs.getString(BENEFICIARY_ADDRESS))
				.beneficiaryCountry(rs.getString(BENEFICIARY_COUNTRY))
				.beneficiaryContactNumber(rs.getString(BENEFICIARY_CONTACT_NUMBER))
				.beneficiaryBankName(rs.getString(BENEFICIARY_BANK_NAME))
				.beneficiaryBankAddress(rs.getString(BENEFICIARY_BANK_ADDRESS))
				.beneficiaryAccountNo(rs.getString(BENEFICIARY_ACCOUNT_NO)).swiftCode(rs.getString(SWIFT_CODE))
				.abaNumber(rs.getString(ABA_NUMBER)).chipUid(rs.getString(CHIP_UID)).ibanNo(rs.getString(IBAN_NO))
				.bankCharges(rs.getString(BANK_CHARGES)).customerEmailId(rs.getString(CUSTOMER_EMAIL_ID))
				.mobileNumber(rs.getString(MOBILE_NUMBER)).ethnicCode(rs.getString(ETHNIC_CODE))
				.ethnicCodeDesc(rs.getString(ETHNIC_CODE_DESC)).recipientCountry(rs.getString(RECIPIENT_COUNTRY))
				.lrsTransaction(rs.getString(LRS_TRANSACTION)).sourceOfFund(rs.getString(SOURCE_OF_FUND))
				.recipientName(rs.getString(RECIPIENT_NAME)).bankStatementDocsExt(rs.getString(BANK_STATEMENT_DOCS_EXT))
				.loanDocsExt(rs.getString(LOAN_DOCS_EXT))
				.relationshipWithStudent(rs.getString(RELATIONSHIP_WITH_STUDENT))
				.borrowerFrom(rs.getString(BORROWER_FROM)).countryOfUniversity(rs.getString(COUNTRY_OF_UNIVERSITY))
				.additionalComments(rs.getString(ADDITIONAL_COMMENTS))
				.termsAndConditionChecks(rs.getString(TERMS_AND_CONDITION_CHECKS)).modifiedAt(rs.getString(MODIFIED_AT))
				.build());

	}

	@Override
	public void buildDealProCSV(DealProCSVMaker dealProCSVMaker) throws FlywireException {
		log.info("DealProCSVMaker =" + dealProCSVMaker.toString());
		try {
			writeFirstCSVFile(dealProCSVMaker);
			writeSecondCSVFile(dealProCSVMaker);
			if (dealProCSVMaker.getLoanDocsExt() != null || dealProCSVMaker.getBankStatementDocsExt() != null)
				writeAttachmentFiles(dealProCSVMaker.getCorrelationId(), dealProCSVMaker.getPaymentId());

			// createZipForAll(dealProCSVMaker.getPaymentId());
			updateDealProStatus(dealProCSVMaker.getCorrelationId(), Stage.DEALPRO_FILE_UPLOADED.name());
		} catch (FlywireException e) {
			log.error("Error while creating dealpro files ", e);
			throw new FlywireException("Error while creating dealpro upload file " + e.getMessage());
		}
	}

	@Override
	public void updateDealProStatus(String correlationId, String dealproStatus) throws FlywireException {
		try {
			Map<String, Object> parameters = new HashMap<>();
			parameters.put("correlationId", correlationId);
			parameters.put("dealproStatus", dealproStatus);
			namedParameterJdbcTemplate.update(dealproStatusUpdate, parameters);
		} catch (Exception e) {
			log.error("Error updating status for dealpro file upload ", e);
			throw new FlywireException("Error updating status for dealpro file upload ", e);
		}
	}

	private void createZipForAll(String correlationId) {
		File root = new File(basePathLocation);
		FilenameFilter beginswithm = (directory, filename) -> filename.startsWith(correlationId + "-");
		zip(Arrays.asList(root.listFiles(beginswithm)), basePathLocation + correlationId + ZIP_EXT);

	}

	public static File zip(List<File> files, String filename) {
		File zipfile = new File(filename);
		// Create a buffer for reading the files
		byte[] buf = new byte[1024];
		try {
			// create the ZIP file
			ZipOutputStream out = new ZipOutputStream(new FileOutputStream(zipfile));
			// compress the files
			for (int i = 0; i < files.size(); i++) {
				FileInputStream in = new FileInputStream(files.get(i).getCanonicalFile());
				// add ZIP entry to output stream
				out.putNextEntry(new ZipEntry(files.get(i).getName()));
				// transfer bytes from the file to the ZIP file
				int len;
				while ((len = in.read(buf)) > 0) {
					out.write(buf, 0, len);
				}
				// complete the entry
				out.closeEntry();
				in.close();
			}
			// complete the ZIP file
			out.close();
			return zipfile;
		} catch (IOException ex) {
			throw new FlywireException(ex.getMessage());
		}
	}

	private void writeSecondCSVFile(DealProCSVMaker dealProCSVMaker) throws FlywireException {
		String correlationId = dealProCSVMaker.getCorrelationId();
		log.info("writeSecondCSVFile :: correlationId =" + correlationId);
		String[] data = new String[7];
		data[0] = dealProCSVMaker.getFlywireCreateAt();
		data[1] = dealProCSVMaker.getPartnerId();
		data[2] = dealProCSVMaker.getPaymentId();
		data[3] = dealProCSVMaker.getRelationshipWithStudent();
		data[4] = dealProCSVMaker.getNotifyURL();
		data[5] = dealProCSVMaker.getRecipientName();
		data[6] = getCurrencyRate(dealProCSVMaker.getAmountCollect(), dealProCSVMaker.getAmountDisburse());
		String csvFileLocation = basePathLocation + dealProCSVMaker.getPaymentId() + FLYWIRE_2_CSV;
		//try (CSVWriter writer = new CSVWriter(new FileWriter(csvFileLocation))) {
		try (CSVWriter writer = new CSVWriter(new FileWriter(csvFileLocation), ICSVWriter.DEFAULT_SEPARATOR, ICSVWriter.NO_QUOTE_CHARACTER, ICSVWriter.DEFAULT_ESCAPE_CHARACTER, ICSVWriter.DEFAULT_LINE_END)){
			String[] csvHeader1 = { "Date Initiated", "Partner Name", "Partner Payment ID",
					"Customer's Relationship with Student", "Payment Status Webhook URL", "Ultimate Beneficiary Name",
					"Currency Rate" };
			writer.writeNext(csvHeader1);
			writer.writeNext(data);
			writer.flush();
		} catch (IOException e) {
			log.error(e);
			throw new FlywireException(e.getMessage());
		}
		FileTransferServiceUtil.uploadFile(csvFileLocation, dealProSftpProperties);
	}

	private String getCurrencyRate(String amountCollect, String amountDisbuse) {
		//log.info("amountCollect= " + amountCollect + "amountDisbuse= " + amountDisbuse);
		Double currencyRate = Double.parseDouble(amountCollect) / Double.parseDouble(amountDisbuse);
		return Double.toString(currencyRate);
	}

	private void writeAttachmentFiles(String correlationId, String paymentId) throws FlywireException {
		SqlParameterSource parameterSource = new MapSqlParameterSource("correlationIdList", correlationId);
		log.info("attachmentsQuery = " + attachmentsQuery + " param= " + correlationId);
		namedParameterJdbcTemplate.query(attachmentsQuery, parameterSource, (rs, rownum) -> {
			String loanDocsExt = rs.getString(LOAN_DOCS_EXT);
			String bankStmtExt = rs.getString(BANK_STATEMENT_DOCS_EXT);
			log.info("correlationId = " + correlationId + " loanDocsExt= " + loanDocsExt + " bankStmtExt ="
					+ bankStmtExt);
			if (StringUtils.isNotBlank(loanDocsExt)) {
				writeFile(paymentId, rs.getBlob(LOAN_DOCS), LOANDOC, loanDocsExt);
			}
			if (StringUtils.isNotBlank(bankStmtExt)) {
				writeFile(paymentId, rs.getBlob(BANK_STATEMENT_DOCS), BANKSTMTDOC, bankStmtExt);
			}
			return null;

		});

	}
	/*
	 * private void writeAttachmentFiles(DealProCSVMaker dealProCSVMaker) throws
	 * FlywireException { String correlationId = dealProCSVMaker.getPaymentId();
	 * String loanDocsExt = dealProCSVMaker.getLoanDocsExt(); String bankStmtExt =
	 * dealProCSVMaker.getBankStatementDocsExt(); if
	 * (StringUtils.isNotBlank(loanDocsExt)) { log.info("loanDocs base64 = " +
	 * dealProCSVMaker.getLoanDocs()); writeFile(correlationId,
	 * dealProCSVMaker.getLoanDocs(), LOANDOC, loanDocsExt); } if
	 * (StringUtils.isNotBlank(bankStmtExt)) { log.info("bankStmt base64 = " +
	 * dealProCSVMaker.getBankStatementDocs()); writeFile(correlationId,
	 * dealProCSVMaker.getBankStatementDocs(), BANKSTMTDOC, bankStmtExt); }
	 * 
	 * }
	 */

	private void writeFile(String correlationId, Blob attachment, String fileNamePart, String ext)
			throws FlywireException {
		String blobFileLocation = basePathLocation + correlationId + fileNamePart + ext;
		try (FileOutputStream fout = new FileOutputStream(blobFileLocation)) {
			byte[] barr = attachment.getBytes(1, (int) attachment.length());
			fout.write(Base64.getDecoder().decode(barr));
			FileTransferServiceUtil.uploadFile(blobFileLocation, dealProSftpProperties);
		} catch (Exception e) {
			log.error(e);
			throw new FlywireException(e.getMessage());
		}
	}

	private void writeFirstCSVFile(DealProCSVMaker dealProCSVMaker) throws FlywireException {

		log.info("writeFirstCSVFile = " + dealProCSVMaker.getCorrelationId());

		String correlationId = dealProCSVMaker.getCorrelationId();
		String[] data = new String[56];
		data[0] = dealProCSVMaker.getCreatedAt();
		data[1] = correlationId;
		data[2] = dealProCSVMaker.getCustomerId();
		data[3] = dealProCSVMaker.getBranchCode();
		data[4] = dealProCSVMaker.getProductCode();
		data[5] = dealProCSVMaker.getCustomerFullName();
		data[6] = dealProCSVMaker.getAccountNumber();
		data[7] = AppConstant.EMPTY; // Remitter Address
		data[8] = dealProCSVMaker.getPanNo();
		data[9] = dealProCSVMaker.getCustomerAccountRelation();

		data[10] = dealProCSVMaker.getAccountType();
		data[11] = dealProCSVMaker.getCustomerTypeDesc();
		data[12] = dealProCSVMaker.getSettlementCurrency();
		data[13] = dealProCSVMaker.getAmountDisburse();
		data[14] = AppConstant.EDUCATION;
		data[15] = dealProCSVMaker.getAdditionalComments();
		data[16] = AppConstant.EMPTY;

		data[17] = dealProCSVMaker.getBeneficiaryName();
		data[18] = dealProCSVMaker.getBeneficiaryAddress();
		data[19] = dealProCSVMaker.getBeneficiaryCountry();
		data[20] = dealProCSVMaker.getBeneficiaryContactNumber();
		data[21] = dealProCSVMaker.getBeneficiaryBankName();
		data[22] = dealProCSVMaker.getBeneficiaryBankAddress();
		data[23] = dealProCSVMaker.getBeneficiaryAccountNo();
		data[24] = dealProCSVMaker.getSwiftCode();
		data[25] = dealProCSVMaker.getAbaNumber();
		data[26] = dealProCSVMaker.getChipUid();
		data[27] = dealProCSVMaker.getIbanNo();

		data[28] = AppConstant.EMPTY;
		data[29] = AppConstant.EMPTY;
		data[30] = AppConstant.EMPTY;
		data[31] = AppConstant.EMPTY;
		data[32] = AppConstant.EMPTY;
		data[33] = AppConstant.EMPTY;
		data[34] = AppConstant.EMPTY;

		data[35] = dealProCSVMaker.getBankCharges();
		data[36] = AppConstant.EMPTY; // Sender to Receiver Info
		data[37] = AppConstant.SCHEME;

		data[38] = dealProCSVMaker.getCustomerEmailId();
		data[39] = dealProCSVMaker.getMobileNumber();
		data[40] = dealProCSVMaker.getEthnicCode();

		data[41] = AppConstant.EMPTY;
		data[42] = AppConstant.EMPTY;
		data[43] = AppConstant.EMPTY;
		data[44] = AppConstant.EMPTY;
		data[45] = AppConstant.EMPTY;
		data[46] = AppConstant.EMPTY;
		data[47] = AppConstant.EMPTY;
		data[48] = AppConstant.EMPTY;
		data[49] = AppConstant.EMPTY;
		data[50] = getCurrencyRate(dealProCSVMaker.getAmountCollect(), dealProCSVMaker.getAmountDisburse());//Card Rate applied to customer
		data[51] = AppConstant.EMPTY;

		data[52] = dealProCSVMaker.getRecipientCountry();// Recipient_country
		data[53] = dealProCSVMaker.getLrsTransaction();
		data[54] = dealProCSVMaker.getSourceOfFund();
		data[55] = dealProCSVMaker.getRecipientName();// Name of Institution

		String csvFileLocation = basePathLocation + dealProCSVMaker.getPaymentId() + FLYWIRE_1_CSV;
		//File file = File.createTempFile(dealProCSVMaker.getPaymentId(), FLYWIRE_1_CSV);
		try (CSVWriter writer = new CSVWriter(new FileWriter(csvFileLocation), ICSVWriter.DEFAULT_SEPARATOR, ICSVWriter.NO_QUOTE_CHARACTER, ICSVWriter.DEFAULT_ESCAPE_CHARACTER, ICSVWriter.DEFAULT_LINE_END)) {
			
			writer.writeNext(getHeader());
			writer.writeNext(data);
			writer.flush();
		} catch (IOException e) {
			log.error(e);
			throw new FlywireException(e.getMessage());
		}
		FileTransferServiceUtil.uploadFile(csvFileLocation, dealProSftpProperties);

	}

	private String[] getHeader() {
		String[] header = { "Date", "NB Ref no", "Customer ID", "Account Number branch code",
				"Account Number prod code", "Customer Name", "Account Number", "Remitter Address", "PanCard",
				"Account Number Relationship", "Resident Non Resident", "Individua Non Individual", "FCY Currency Type",
				"FCY Amount", "Purpose of Remittance", "Additional field 1 Name", "Additional field 2 Name",
				"Beneficiary name", "Beneficiary Address", "Country of Beneficiary", "Contact Number",
				"Beneficiary Bank Name", "Beneficiary Bank Address", "Beneficiary Account No", "SWIFT Code",
				"SWIFT ABA No", "SWIFT CHIP UID", "SWIFT IBAN No.", "Name of Intermediary Bank",
				"Intermediate Bank Address", "Acc No BenefBank in InterBank", "SWIFTCode of inter bank",
				"SWIFTABANo of inter bank", "SWIFTCHIPUID of inter bank", "SWIFTIBANNo of inter bank",
				"Corr Bank Charges borne by", "Sender to Receiver Info", "Scheme", "Email ID", "Mobile no.",
				"Ethnic Code", "Rate Improvement", "TT Commission Amount", "Banned Entity Check Done",
				"FEMA Limit Check Done", "FATF Country Check", "Trade FX Trn ref no.", "TTSelling OW Rem card rate",
				"USD TT Sell OW Rem card rate", "USD Equivalent", "Card Rate applied to customer", "Rate Type",
				"Ultimate_Service_Country", "Tax residency of India", "Source of funds", "Name of Institution" };
		log.info("header count size is = " + header.length);
		return header;

	}

}
