package com.hdfcbank.flywire.config;

import static com.hdfcbank.flywire.constant.AppConstant.KEY;
import static com.hdfcbank.flywire.constant.AppConstant.VALUE;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.EnvironmentAware;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.core.env.Environment;
import org.springframework.core.env.MapPropertySource;
import org.springframework.jdbc.core.JdbcTemplate;

@Configuration
public class PropertiesDatabaseInitializer implements InitializingBean, EnvironmentAware {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Autowired
	private ConfigurableEnvironment environment;

	private static final String PROPERTY_SOURCE_NAME = "propertiesInsideDatabase";

	@Value("${properties.database.config.tables}")
	private String sql;

	@Override
	public void afterPropertiesSet() {
		if (environment != null) {
			Map<String, Object> configMap = new HashMap<>();

			List<Map<String, Object>> maps = jdbcTemplate.queryForList(sql);
			for (Map<String, Object> map : maps) {
				configMap.put(String.valueOf(map.get(KEY)), map.get(VALUE));
			}

			environment.getPropertySources().addFirst(new MapPropertySource(PROPERTY_SOURCE_NAME, configMap));
		}
	}

	@Override
	public void setEnvironment(Environment environment) {
		if (environment instanceof ConfigurableEnvironment) {
			this.environment = (ConfigurableEnvironment) environment;
		}
	}
}