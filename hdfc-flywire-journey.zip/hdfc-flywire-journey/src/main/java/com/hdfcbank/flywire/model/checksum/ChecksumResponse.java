package com.hdfcbank.flywire.model.checksum;

import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class ChecksumResponse {

	private Long checksum;
	private String errorMsg;
}
