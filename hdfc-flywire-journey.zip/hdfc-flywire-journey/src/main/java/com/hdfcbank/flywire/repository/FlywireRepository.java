package com.hdfcbank.flywire.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hdfcbank.flywire.model.dbentity.FlywireAudit;

public interface FlywireRepository extends JpaRepository<FlywireAudit, Long> {

}
