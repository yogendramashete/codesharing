package com.hdfcbank.flywire.service.impl;

import static com.hdfcbank.flywire.constant.AppConstant.MASK_CHAR;
import static com.hdfcbank.flywire.constant.AppConstant.NOT_MASK_LAST_4_DIGIT;

import java.io.ByteArrayInputStream;
import java.util.Base64;
import java.util.List;
import java.util.zip.CRC32;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.support.SqlLobValue;
import org.springframework.jdbc.support.lob.DefaultLobHandler;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hdfcbank.flywire.constant.AppConstant;
import com.hdfcbank.flywire.enums.AttachmentType;
import com.hdfcbank.flywire.enums.Stage;
import com.hdfcbank.flywire.exception.FlywireException;
import com.hdfcbank.flywire.model.account.SelectedAccountRequest;
import com.hdfcbank.flywire.model.account.SelectedAccountResponse;
import com.hdfcbank.flywire.model.api.ApiResponse;
import com.hdfcbank.flywire.model.casa.AccountDetails;
import com.hdfcbank.flywire.model.checksum.ChecksumRequest;
import com.hdfcbank.flywire.model.checksum.ChecksumResponse;
import com.hdfcbank.flywire.model.dbentity.FlywireAudit;
import com.hdfcbank.flywire.model.digest.DigestRequest;
import com.hdfcbank.flywire.model.digest.DigestResponse;
import com.hdfcbank.flywire.model.flywire.ConsentRequest;
import com.hdfcbank.flywire.model.flywire.FlywireDetails;
import com.hdfcbank.flywire.model.fund.FundDetails;
import com.hdfcbank.flywire.model.fund.FundDetailsDocs;
import com.hdfcbank.flywire.model.nbauth.NbAuthStatus;
import com.hdfcbank.flywire.repository.FlywireAuditRepository;
import com.hdfcbank.flywire.repository.FlywireInformationRepository;
import com.hdfcbank.flywire.service.FlywireService;
import com.hdfcbank.flywire.util.encryption.FlywireTokenEncryption;

import lombok.extern.log4j.Log4j2;
import oracle.jdbc.OracleTypes;

@Service
@Log4j2
public class FlywireServiceImpl implements FlywireService {

	@Value("${flywire.token.encryption.sharedSecret:rKPY113mMkJ%33HsD}")
	private String sharedSecret;

	@Value("${flywire.token.encryption.algorithm:HmacSHA256}")
	private String algorithm;
	@Value("${nbauth.txn-id}")
	private String nbAuthTxnID;
	@Value("${nbauth.master-key}")
	private String nbAuthMasterKey;
	@Value("${transaction.updateEducationalDocQuery}")
	private String updateEducationalDocQuery;

	@Value("${transaction.updateBankStatementDocQuery}")
	private String updateBankStatementDocQuery;
	@Autowired
	private ObjectMapper objectMapper;
	@Autowired
	private FlywireAuditRepository flywireAuditRepository;

	@Autowired
	NamedParameterJdbcTemplate jdbcTemplate;

	@Autowired
	private FlywireInformationRepository flywireInformationRepository;

	@Override
	public void storeConsent(String correlationId, ConsentRequest consentRequest) throws FlywireException {
		try {
			if (consentRequest.getIsLRS().booleanValue()) {
				if (null != consentRequest.getLrsTransactions() && !consentRequest.getLrsTransactions().isEmpty())
					flywireInformationRepository.saveFlywireLRSandTNCInformation(correlationId,
							consentRequest.getIsLRS(), consentRequest.getLrsTransactions(),
							Stage.LRS_TNC_COMPLETED.name());
				else
					throw new FlywireException("Is LRS true but no transactions");
			} else
				flywireInformationRepository.saveFlywireLRSandTNCInformation(correlationId, consentRequest.getIsLRS(),
						null, Stage.LRS_TNC_COMPLETED.name());
		} catch (Exception e) {
			log.error("Error saving consent data", e);
			throw new FlywireException("Error saving consent data " + e.getMessage());
		}
	}

	@Override
	public void storeFlywireDetails(String correlationId, FlywireDetails flywireDetails) throws FlywireException {
		try {
			flywireInformationRepository.saveFlywireInformation(correlationId, flywireDetails,
					Stage.FLYWIRE_INFO_INITIALIZED.name());
		} catch (Exception e) {
			log.error("Error saving flywire details", e);
			throw new FlywireException("Error saving flywire details " + e.getMessage());
		}
	}

	@Override
	public boolean isRequestTokenValid(FlywireDetails flywireDetails) throws FlywireException {
		try {
			String signatureString = FlywireTokenEncryption.createSignatureString(flywireDetails);
			String token = FlywireTokenEncryption.encryptString(signatureString, sharedSecret, algorithm);
			log.info("PaymentId: " + flywireDetails.getPaymentId() + " \nToken: " + token);
			return flywireDetails.getXFlywireDigest().equals(token);
		} catch (Exception e) {
			log.error("Error validating flyire digest request Token", e);
			throw new FlywireException("Error validating flyire digest request Token " + e.getMessage());
		}
	}

	@Override
	public boolean isCorrelationIdValid(String correlationId) throws FlywireException {
		try {
			if (correlationId.isBlank())
				throw new FlywireException("Blank correlationId");
			return flywireInformationRepository.isCorrelationIdValid(correlationId);
		} catch (Exception e) {
			log.error("Error reteriving correlation Id " + correlationId, e);
			throw new FlywireException("Error reteriving correlation Id " + correlationId + e.getMessage());
		}
	}

	@Override
	public void saveFundDetails(String correlationId, FundDetails fundDetails) throws FlywireException {
		try {
			flywireInformationRepository.saveFundDetails(correlationId, fundDetails);
			if (fundDetails.getFundDetailsDocs() != null) {
				fundDetails.getFundDetailsDocs().forEach(doc -> saveAttachment(correlationId, doc));
			}
		} catch (Exception e) {
			log.error("Error saving details ", e);
			throw new FlywireException("Error saving details " + e.getMessage());
		}
	}

	@Override
	public SelectedAccountResponse submitAccount(String correlationId, SelectedAccountRequest selectAccountRequest)
			throws FlywireException {
		try {
			boolean accountSelected = false;
			List<AccountDetails> accountDetails = flywireInformationRepository.getAccountDetails(correlationId);
			for (AccountDetails acc : accountDetails) {
				if (acc.getAccountNumber().replaceAll(NOT_MASK_LAST_4_DIGIT, MASK_CHAR)
						.equals(selectAccountRequest.getAccountNo())) {
					flywireInformationRepository.saveCustomerAccountDetails(correlationId, acc,
							Stage.CASA_COMPLETED.name());
					accountSelected = true;
					break;
				}
			}
			return SelectedAccountResponse.builder().accountSelected(accountSelected)
					.errorMsg(accountSelected ? null : "Account selected not in list").build();

		} catch (Exception e) {
			log.error("Error saving customer account details", e);
			throw new FlywireException("Error saving customer account details " + e.getMessage());
		}

	}

	@Override
	public ChecksumResponse buildChecksum(String correlationId, ChecksumRequest checksumRequest)
			throws FlywireException {
		String checksumStr = AppConstant.FLYWIRE + nbAuthTxnID + checksumRequest.getCustomerId() + correlationId
				+ base64ToString();
		CRC32 crc = new CRC32();
		crc.update(checksumStr.getBytes());
		return ChecksumResponse.builder().checksum(crc.getValue()).build();
	}

	private String base64ToString() {
		return new String(Base64.getDecoder().decode(nbAuthMasterKey.getBytes()));
	}

	@Override
	public void auditLog(String correlationId, Object request, ApiResponse response, String stage,
			String exceptionMessage) {
		try {
			FlywireAudit flywireAudit = FlywireAudit.builder().correlationId(correlationId).stage(stage)
					.request(null != request ? objectMapper.writeValueAsString(request) : null)
					.response(null != response ? objectMapper.writeValueAsString(response) : null)
					.remark((null != exceptionMessage && !exceptionMessage.isBlank()) ? exceptionMessage : null)
					.build();
			flywireAuditRepository.save(flywireAudit);
		} catch (Exception e) {
			log.error("Error saving audit log ", e);
			throw new FlywireException("Error saving audit log " + e.getMessage());
		}

	}

	@Override
	public void uiTerminated(String correlationId) throws FlywireException {
		try {
			flywireInformationRepository.updateUITerminationStage(correlationId);
		} catch (Exception e) {
			log.error("Error saving ui terminated ", e);
			throw new FlywireException("Error saving ui terminated " + e.getMessage());
		}

	}

	@Override
	public DigestResponse buildDigest(DigestRequest digestRequest) throws FlywireException {
		String signatureString = FlywireTokenEncryption.createSignatureString(digestRequest);
		String token = FlywireTokenEncryption.encryptString(signatureString, sharedSecret, algorithm);
		return DigestResponse.builder().digest(token).build();
	}

	@Override
	public void saveNBAuthStatus(String correlationId, NbAuthStatus nbAuthStatus) throws FlywireException {
		flywireInformationRepository.saveNBAuthStatus(correlationId, nbAuthStatus);

	}

	public void saveAttachment(String correlationId, FundDetailsDocs docs) throws FlywireException {
		try {

			byte[] bytes = docs.getContent().getBytes();
			String sql = AttachmentType.BANKSTMT.name().equals(docs.getType()) ? updateBankStatementDocQuery
					: updateEducationalDocQuery;

			MapSqlParameterSource parameters = new MapSqlParameterSource();
			parameters.addValue("ext", docs.getExtension());
			parameters.addValue("content",
					new SqlLobValue(new ByteArrayInputStream(bytes), bytes.length, new DefaultLobHandler()),
					OracleTypes.BLOB);
			parameters.addValue("correlation_id", correlationId);
			parameters.addValue("type", docs.getType());
			jdbcTemplate.update(sql, parameters);
		} catch (FlywireException e) {
			throw new FlywireException(e.getMessage());
		}
	}
	
	/*@Override
	public void fileUploadTest(String correlationId, FundDetailsDocs fundDetailsDocs) {
		log.info("correlationId -" + correlationId);
		try {
			String sql = "INSERT INTO FLYWIRE_DOCS (content, extension, correlation_id, type) VALUES (:content, :extension, :correlation_id, :type)";
			byte[] bytes = fundDetailsDocs.getContent().getBytes();
			MapSqlParameterSource parameters = new MapSqlParameterSource();
			parameters.addValue("extension", fundDetailsDocs.getExtension());
			parameters.addValue("content",
					new SqlLobValue(new ByteArrayInputStream(bytes), bytes.length, new DefaultLobHandler()),
					OracleTypes.BLOB);
			parameters.addValue("correlation_id", correlationId);
			parameters.addValue("stage", fundDetailsDocs.getType());
			jdbcTemplate.update(sql, parameters);
			log.info("record is inserted...");
		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
		}

	}

	@Value("${file.base.path.dealpro}")
	private String basePathLocation;

	@Override
	public void downloadImage(String id) throws FlywireException {
		SqlParameterSource parameterSource = new MapSqlParameterSource("id", id);
		jdbcTemplate.query("SELECT * FROM DOCS_TEST WHERE id=:id", parameterSource, (rs, rownum) -> {
			Blob content = rs.getBlob("CONTENT");
			String ext = rs.getString("EXTENSION");
			String blobFileLocation = basePathLocation + "test_" + id + ext;
			try (FileOutputStream fout = new FileOutputStream(blobFileLocation)) {
				byte[] barr = content.getBytes(1, (int) content.length());
				fout.write(Base64.getDecoder().decode(barr));
			} catch (Exception e) {
				log.error(e);
				throw new FlywireException(e.getMessage());
			}
			return null;

		});

	}*/

	

}
