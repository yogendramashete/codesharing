package com.hdfcbank.flywire.util.sftp;

import com.hdfcbank.flywire.config.SftpProperties;
import com.hdfcbank.flywire.exception.FlywireException;
import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;

import lombok.extern.log4j.Log4j2;

@Log4j2
public class FileTransferServiceUtil {

	private FileTransferServiceUtil() {
	}

	public static boolean uploadFile(String localFilePath, SftpProperties sftpProperties) throws FlywireException {
		ChannelSftp channelSftp = null;
		try {
			channelSftp = createChannelSftp(sftpProperties);
			channelSftp.put(localFilePath, sftpProperties.getRemotePath());
			return true;
		} catch (SftpException | FlywireException e) {
			log.error("Error upload file", e);
			throw new FlywireException(e.getMessage());
		} finally {
			disconnectChannelSftp(channelSftp);
		}
	}

	private static ChannelSftp createChannelSftp(SftpProperties sftpProperties) throws FlywireException {
		try {
			JSch jSch = new JSch();
			Session session = jSch.getSession(sftpProperties.getUsername(), sftpProperties.getHost(),
					sftpProperties.getPort());
			session.setPassword(sftpProperties.getPassword());
			session.setConfig("StrictHostKeyChecking", "no");
			session.connect(sftpProperties.getSessionTimeout());
			Channel channel = session.openChannel("sftp");
			channel.connect(sftpProperties.getChannelTimeout());
			return (ChannelSftp) channel;
		} catch (JSchException ex) {
			log.error("Create ChannelSftp error", ex);
			throw new FlywireException("Create ChannelSftp error");
		}
	}

	private static void disconnectChannelSftp(ChannelSftp channelSftp) {
		try {
			if (channelSftp == null)
				return;

			if (channelSftp.isConnected())
				channelSftp.disconnect();

			if (channelSftp.getSession() != null)
				channelSftp.getSession().disconnect();

		} catch (Exception ex) {
			log.error("SFTP disconnect error", ex);
		}
	}

}
