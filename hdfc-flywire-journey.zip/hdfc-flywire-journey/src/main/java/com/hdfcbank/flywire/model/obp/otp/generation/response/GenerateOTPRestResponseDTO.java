package com.hdfcbank.flywire.model.obp.otp.generation.response;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class GenerateOTPRestResponseDTO {
	@JsonProperty(required = true)
	private TransactionStatus status;
	@JsonProperty(required = false)
	private String maintenanceType;
	@JsonProperty(required = false)
	private String configVersionId;
	@JsonProperty(required = false)
	private ResponseString responseString;
}
