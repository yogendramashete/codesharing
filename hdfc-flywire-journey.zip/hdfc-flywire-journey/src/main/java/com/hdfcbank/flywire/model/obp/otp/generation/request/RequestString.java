package com.hdfcbank.flywire.model.obp.otp.generation.request;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
public class RequestString {

//	@JsonProperty(required = true)
//	private String passwordMask; //example: N $$
	@JsonProperty(required = true)
	private String instanceId; //example: 8888
	@JsonProperty(required = true)
	private String apiUser; //hdfc_fc Caller ID provided by E2FA
//	@JsonProperty(required = true)
//	private String expiryMin; //example: 3 $$
//	@JsonProperty(required = true)
//	private String maxAttempts;//example: 3 $$
	@JsonProperty(required = true)
	private String linkData;//example: 543243210987
//	@JsonProperty(required = true)
//	private String passwordCategory;//example: OTP $$
//	@JsonProperty(required = true)
//	private String authenticationAllowed;//example: 1 $$
	@JsonProperty(required = true)
	private String refNo; //example: e456trdfvbdfv - used in otp gen and verify
	@JsonProperty(required = true)
	private String messageHash; //example: dynamic:genpwdreq:12:fJil0XmTaHPKufHTz65S2kmg4uI=
//	@JsonProperty(required = true)
//	private String passwordLength;//example: 6 $$
//	@JsonProperty(required = false)
//	private String otpForceOverrideRefData;
//	@JsonProperty(required = false)
//	private String otpReferenceData;
//	@JsonProperty(required = false)
//	private String forceNew; 
//	@JsonProperty(required = false)
//	private String ornReferenceNumber;
}
