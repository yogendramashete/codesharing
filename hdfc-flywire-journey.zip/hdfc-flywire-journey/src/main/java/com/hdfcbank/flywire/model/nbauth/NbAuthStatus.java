package com.hdfcbank.flywire.model.nbauth;

import lombok.Data;

@Data
public class NbAuthStatus {

	private String custId;
	private String serviceId;
	private String txnRefNo;
	private String checksum;
	private String errorcode;
	private String errorMessage;
	private String retrunCode;

}
