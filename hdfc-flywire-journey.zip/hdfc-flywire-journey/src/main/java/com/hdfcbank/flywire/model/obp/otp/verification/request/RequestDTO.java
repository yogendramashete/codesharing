package com.hdfcbank.flywire.model.obp.otp.verification.request;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
public class RequestDTO {

	@JsonProperty(required = true)
	private SessionContext sessionContext;
	@JsonProperty(required = true, value = "VerifyOTPRestRequestDTO")
	private VerifyOTPRestRequestDTO verifyOTPRestRequestDTO;
}
