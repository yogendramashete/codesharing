package com.hdfcbank.flywire;

import java.util.List;

import org.apache.commons.lang3.StringUtils;

public class EmailRegxDemo {

	public static void main(String[] args) {
		String email="DUUMY@TEETDUMMY.IN";
		String maskedEmail = email.replaceAll("(?<=.{2}).(?=[^@]*?..@)", "*");
		
		System.out.println(maskedEmail);
		System.out.println(email.replaceAll("(?<=.).(?=[^@]\\*?@)", "*"));
		//System.out.println(email.replaceAll("(?<=[w]{1})[w-+%]*(?=[w]{1}[.])", "*"));
		System.out.println(email.replaceAll("(?<=.)[^@](?=[^@]*?@)|(?:(?<=..@..)|(?!^)\\G(?=[^@]*$)).(?=.*\\.)", "*"));
		//string pattern = @"(?<=[\w]{1})[\w-\._\+%]*(?=[\w]{1}@)"; // ---> mask before "@"
		//string p2 = @"(?<=[\w]{1})[\w-\+%]*(?=[\w]{1}[.])"; //
		
		System.out.println(email.replaceAll("(?<=..)[^@](?=[^@]*?..@)|(?:(?<=@..)|(?!^)\\G(?=[^@]*$)).(?=.*\\.)", "*"));
		
		
		System.out.println(StringUtils.isNotBlank(""));
	 List<String> t1= List.of("test");
	 t1.parallelStream().count();
	 String test=null;
	// System.out.println(String.);
	}
	
	
}
