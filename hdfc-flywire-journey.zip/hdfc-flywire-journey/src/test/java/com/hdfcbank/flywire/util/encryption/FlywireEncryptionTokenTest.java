package com.hdfcbank.flywire.util.encryption;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

import com.hdfcbank.flywire.model.flywire.FlywireDetails;

class FlywireEncryptionTokenTest {

	@Test
	void testCreateSignatureString() {
		String expectedString = "6903.50|100.0|2017-12-10T20:30:01+00:00|INR|USD|https://webhook.flywire.com/partner_name/notifications|123456789|123456789|US|Flywire University|https://api.flywire.com/callbacks/partner_name|USD";

		FlywireDetails flywireDetails = new FlywireDetails();
		flywireDetails.setAmountCollect("6903.50");
		flywireDetails.setAmountDisburse("100.0");
		flywireDetails.setCreatedAt("2017-12-10T20:30:01+00:00");
		flywireDetails.setCurrencyCollect("INR");
		flywireDetails.setCurrencyDisburse("USD");
		flywireDetails.setNotifyUrl("https://webhook.flywire.com/partner_name/notifications");
		flywireDetails.setPartnerId("123456789");
		flywireDetails.setPaymentId("123456789");
		flywireDetails.setRecipientCountry("US");
		flywireDetails.setRecipientName("Flywire University");
		flywireDetails.setReturnUrl("https://api.flywire.com/callbacks/partner_name");
		flywireDetails.setSettlementCurrency("USD");

		assertEquals(expectedString, FlywireTokenEncryption.createSignatureString(flywireDetails));
	}

	@Test
	void testEncryptString() {
		String signatureString = "6903.50|100.0|2017-12-10T20:30:01+00:00|INR|USD|https://webhook.flywire.com/partner_name/notifications|123456789|FLY123456789|Flywire University|https://api.flywire.com/callbacks/partner_name|USD";
		String sharedSecret = "xFLY445sfdfksd%sf";
		String algorithm = "HmacSHA256";
		String expectedEncryptedToken = "kENL/iwJ7aAmH+Wiyeo6xF+/SyWPcQWrXzpcKPz9Ky8=";
		assertEquals(expectedEncryptedToken,
				FlywireTokenEncryption.encryptString(signatureString, sharedSecret, algorithm));
	}
}
