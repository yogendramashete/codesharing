package com.hdfcbank.flywire.util.converter;

import static org.junit.jupiter.api.Assertions.*;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;

import org.junit.jupiter.api.Test;

class TimestampConverterTest {

	@Test
	void testGetCurrentTimeStamp() {
		String expectedCurrentTimestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Timestamp(System.currentTimeMillis()));
		assertEquals(expectedCurrentTimestamp, TimestampConverter.getCurrentTimeStamp());
	}

	@Test
	void testGetCurrentDate() {
		String expectedCurrentDate = new SimpleDateFormat("ddMMyy").format(new Timestamp(System.currentTimeMillis()));
		assertEquals(expectedCurrentDate, TimestampConverter.getCurrentDate());
	}

	@Test
	void testGetCurrentTime() {
		String expectedCurrentTime = new SimpleDateFormat("HHmmss").format(new Timestamp(System.currentTimeMillis()));
		assertEquals(expectedCurrentTime, TimestampConverter.getCurrentTime());
	}

	@Test
	void testGetDate() {
		long millis = System.currentTimeMillis();
		String expectedCurrentTime = new SimpleDateFormat("ddMMyy").format(new Timestamp(millis));
		assertEquals(expectedCurrentTime, TimestampConverter.getDate(millis));
	}

	@Test
	void testGetTime() {
		long millis = System.currentTimeMillis();
		String expectedCurrentTime = new SimpleDateFormat("HHmmss").format(new Timestamp(millis));
		assertEquals(expectedCurrentTime, TimestampConverter.getTime(millis));
	}

}
