package com.hdfcbank.flywire.util.hash;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class HashingUtilTest {
	
	@Test
	void testCalculateHash() {
		
		String expectedOutput = "2DQxffGmRsdQbkPTFfSOeUYCO1A=";
		String actualOutput = HashingUtil.calculateHash("8888","hdfc_flywire","5023313050233130500","4606052262883527","123456","M3V7A3B3Q6");
		assertEquals(expectedOutput, actualOutput);
	}
}
