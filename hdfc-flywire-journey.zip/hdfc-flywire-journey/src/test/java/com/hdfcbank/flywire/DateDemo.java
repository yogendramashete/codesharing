package com.hdfcbank.flywire;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;

import com.jayway.jsonpath.internal.function.numeric.Min;

public class DateDemo {

	public static void main(String[] args) throws ParseException {
		/*
		 * String date = "5/13/2022, 7:05:33 AM"; LocalDate date1 =
		 * LocalDate.parse("2018-05-05");
		 * 
		 * LocalDateTime now = LocalDateTime..with(LocalTime.MIN); DateTimeFormatter
		 * format = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss"); String
		 * formatDateTime = now.format(format);
		 * 
		 * 
		 * System.out.println(formatDateTime);
		 */

		/*DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/MM/yyyy");
		String date = "5/13/2022, 7:05:33 AM";
		String[] d1 = date.split(",");
		String date2 = "16/08/2016";

		// convert String to LocalDate
		LocalDate localDate = LocalDate.parse(date2, formatter);
		System.out.println(localDate.atTime(LocalTime.MIN));*/
		LocalDate localDateTime = LocalDate.parse("05/13/2022", DateTimeFormatter.ofPattern("MM/dd/yyyy"));
		 LocalDateTime localDateTime1 = localDateTime.atTime(LocalTime.MIN);
		System.out.println(localDateTime1);
		
		String startDateString = "081222";
	    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("ddMMyy");
	    DateTimeFormatter formatter2 = DateTimeFormatter.ofPattern("yyMMdd");
	    System.out.println(LocalDate.parse(startDateString, formatter).format(formatter2));

	}
}
