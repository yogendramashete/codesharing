package com.hdfcbank.flywire;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.hdfcbank.flywire.controller.FlywireController;

@SpringBootTest
class FlywireEngineApplicationTests {
	
	@Autowired
	private FlywireController flywireController;

	@Test
	void contextLoads() {
		assertNotNull(flywireController);
	}

}
