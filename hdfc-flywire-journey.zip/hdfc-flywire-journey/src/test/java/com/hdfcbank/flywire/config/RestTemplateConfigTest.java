package com.hdfcbank.flywire.config;



import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.web.client.RestTemplate;


@SpringBootTest
@ContextConfiguration(classes = { RestTemplateConfig.class, HttpClientConfig.class })
class RestTemplateConfigTest {

	@Autowired
	private RestTemplate restTemplate;

	//@Test
	void getRandomQuote() {
		final String uri = "https://goquotes-api.herokuapp.com/api/v1/random?count=1";
		String result = restTemplate.getForObject(uri, String.class);
		System.out.print(result);
		assertNotNull(result);
	}
}
