package com.hdfcbank.flywire.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hdfcbank.flywire.constant.AppConstant;
import com.hdfcbank.flywire.enums.StatusCode;
import com.hdfcbank.flywire.model.account.SelectedAccountRequest;
import com.hdfcbank.flywire.model.account.SelectedAccountResponse;
import com.hdfcbank.flywire.model.api.ApiResponse;
import com.hdfcbank.flywire.model.casa.CustomerCASA;
import com.hdfcbank.flywire.model.checksum.ChecksumRequest;
import com.hdfcbank.flywire.model.checksum.ChecksumResponse;
import com.hdfcbank.flywire.model.flywire.ConsentRequest;
import com.hdfcbank.flywire.model.flywire.FlywireDetails;
import com.hdfcbank.flywire.model.fund.FundDetails;
import com.hdfcbank.flywire.model.otp.OTPGenerationResponse;
import com.hdfcbank.flywire.model.otp.OTPVerificationRequest;
import com.hdfcbank.flywire.model.otp.OTPVerificationResponse;
import com.hdfcbank.flywire.model.sms.SMSPushRequest;
import com.hdfcbank.flywire.model.sms.SMSPushResponse;
import com.hdfcbank.flywire.model.uiterminated.UITerminatedRequest;
import com.hdfcbank.flywire.service.impl.FlywireServiceImpl;
import com.hdfcbank.flywire.service.impl.OBPServiceImpl;

@SpringBootTest
@AutoConfigureMockMvc
class FlywireControllerTest {

	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private FlywireServiceImpl flywireService;

	@MockBean
	private OBPServiceImpl obpService;

	@Autowired
	private ObjectMapper mapper;

	@Test
	void testSaveFlywireDetails() throws JsonProcessingException, Exception {
		when(flywireService.isRequestTokenValid(any(FlywireDetails.class))).thenReturn(true);
		doNothing().when(flywireService).storeFlywireDetails(anyString(), any(FlywireDetails.class));
		doNothing().when(flywireService).auditLog(anyString(), any(FlywireDetails.class), any(), anyString(),
				anyString());

		FlywireDetails flywireDetails = FlywireDetails.builder().xFlywireDigest("hello").currencyDisburse("USD")
				.createdAt("2022-10-10 12:12:12").amountCollect("1234").settlementCurrency("USD").currencyCollect("INR")
				.paymentId("1234").recipientName("Test").recipientCountry("US").partnerId("123").returnUrl("returnurl")
				.amountDisburse("2222").notifyUrl("notifyurl").build();

		this.mockMvc
				.perform(post("/saveFlywireDetails").contentType(MediaType.APPLICATION_JSON_VALUE)
						.content(mapper.writeValueAsString(flywireDetails)))
				.andDo(print()).andExpect(status().isOk())
				.andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
				.andExpect(jsonPath("$.status").value(0))
				.andExpect(jsonPath("$.message").value("Success - Customer data is saved successfully"))
				.andExpect(jsonPath("$.data.journeyId").isString()).andExpect(jsonPath("$.data.errorMsg").isEmpty())
				.andReturn();
	}

	@Test
	void testOtpGeneration() throws Exception {
		String otp = "123456";
		String refNo = "1234";
		String correlationId = "1234";
		String journeyId = correlationId;
		when(flywireService.isCorrelationIdValid(correlationId)).thenReturn(true);

		when(obpService.otpGeneration(anyString()))
				.thenReturn(OTPGenerationResponse.builder().passwordValue(otp).refNo(refNo).build());

		when(obpService.smsPushNotification(any(SMSPushRequest.class), anyString())).thenReturn(new SMSPushResponse());

		doNothing().when(flywireService).auditLog(anyString(), any(), any(), anyString(), anyString());

		this.mockMvc.perform(get("/otpGeneration/" + journeyId).header(AppConstant.CORRELATION_ID, correlationId))
				.andDo(print()).andExpect(status().isOk())
				.andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
				.andExpect(jsonPath("$.status").value(0))
				.andExpect(jsonPath("$.message").value("Success - Customer data is saved successfully"))
				.andExpect(jsonPath("$.data.refNo").value(correlationId)).andExpect(jsonPath("$.data.errMsg").isEmpty())
				.andReturn();
	}

	@Test
	void testOtpVerification() throws Exception {
		String otp = "123456";
		String refNo = "1234";
		String correlationId = "1234";
		String txnId = "098765543421";
		String journeyId = correlationId;
		when(flywireService.isCorrelationIdValid(correlationId)).thenReturn(true);

		when(obpService.otpVerification(any(OTPVerificationRequest.class), anyString()))
				.thenReturn(OTPVerificationResponse.builder().status(AppConstant.SUCCESS).build());

		doNothing().when(flywireService).auditLog(anyString(), any(OTPVerificationRequest.class), any(), anyString(),
				anyString());

		OTPVerificationRequest otpVerificationRequest = OTPVerificationRequest.builder().otp(otp).refNo(refNo)
				.txnId(txnId).build();

		this.mockMvc
				.perform(post("/otpVerification/" + journeyId).header(AppConstant.CORRELATION_ID, correlationId)
						.contentType(MediaType.APPLICATION_JSON_VALUE)
						.content(mapper.writeValueAsString(otpVerificationRequest)))

				.andDo(print()).andExpect(status().isOk())
				.andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
				.andExpect(jsonPath("$.status").value(0))
				.andExpect(jsonPath("$.message").value("Success - Customer data is saved successfully"))
				.andExpect(jsonPath("$.data.status").value(AppConstant.SUCCESS))
				.andExpect(jsonPath("$.data.errorMsg").isEmpty()).andReturn();
	}

	@Test
	void testGetCASADetails() throws JsonProcessingException, Exception {
		String correlationId = "1234";
		String mobileNo = "098765543421";
		String dob = "19801010";
		String journeyId = correlationId;
		when(flywireService.isCorrelationIdValid(correlationId)).thenReturn(true);

		ApiResponse apiResponse = ApiResponse.builder().status(StatusCode.SUCCESS.getKey())
				.message(StatusCode.SUCCESS.getValue()).build();
		when(obpService.getCASADetails(any(CustomerCASA.class), anyString())).thenReturn(apiResponse);

		CustomerCASA customerCASA = CustomerCASA.builder().mobileNumber(mobileNo).dateOfBirth(dob).build();

		this.mockMvc
				.perform(post("/getCASADetails/" + journeyId).header(AppConstant.CORRELATION_ID, correlationId)
						.contentType(MediaType.APPLICATION_JSON_VALUE).content(mapper.writeValueAsString(customerCASA)))

				.andDo(print()).andExpect(status().isOk())
				.andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
				.andExpect(jsonPath("$.status").value(0))
				.andExpect(jsonPath("$.message").value("Success - Customer successfully completed journey")).andReturn();
	}

	@Test
	void testFundDetails() throws JsonProcessingException, Exception {
		String correlationId = "1234";
		String journeyId = correlationId;
		when(flywireService.isCorrelationIdValid(correlationId)).thenReturn(true);

		doNothing().when(flywireService).saveFundDetails(anyString(), any(FundDetails.class));

		doNothing().when(flywireService).auditLog(anyString(), any(OTPVerificationRequest.class), any(), anyString(),
				anyString());

		FundDetails fundDetails = FundDetails.builder().relationshipWithStudent("father").countryOfUniversity("US")
				.bankCharges("NONE").sourceOfFund("OWN").additionalComments("This is a test").build();

		this.mockMvc
				.perform(post("/setFundDetails/" + journeyId).header(AppConstant.CORRELATION_ID, correlationId)
						.contentType(MediaType.APPLICATION_JSON_VALUE).content(mapper.writeValueAsString(fundDetails)))
				.andDo(print()).andExpect(status().isOk())
				.andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
				.andExpect(jsonPath("$.status").value(0))
				.andExpect(jsonPath("$.message").value("Success - Customer data is saved successfully")).andReturn();
	}

	@Test
	void testSaveConsent() throws JsonProcessingException, Exception {
		String correlationId = "1234";
		String journeyId = correlationId;
		when(flywireService.isCorrelationIdValid(correlationId)).thenReturn(true);

		doNothing().when(flywireService).storeConsent(anyString(), any(ConsentRequest.class));

		doNothing().when(flywireService).auditLog(anyString(), any(OTPVerificationRequest.class), any(), anyString(),
				anyString());

		ConsentRequest consentRequest = ConsentRequest.builder().isLRS(false).isTNC(true).build();

		this.mockMvc
				.perform(post("/setConsent/" + journeyId).header(AppConstant.CORRELATION_ID, correlationId)
						.contentType(MediaType.APPLICATION_JSON_VALUE)
						.content(mapper.writeValueAsString(consentRequest)))

				.andDo(print()).andExpect(status().isOk())
				.andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
				.andExpect(jsonPath("$.status").value(0))
				.andExpect(jsonPath("$.message").value("Success - Customer data is saved successfully")).andReturn();
	}

	@Test
	void testSendSmsConfirmation() throws JsonProcessingException, Exception {
		String correlationId = "1234";
		String refNo = "11223344";
		String otp = "123456";
		String journeyId = correlationId;
		when(flywireService.isCorrelationIdValid(correlationId)).thenReturn(true);

		when(obpService.smsPushNotification(any(SMSPushRequest.class), anyString()))
				.thenReturn(SMSPushResponse.builder().status(AppConstant.SUCCESS).responseString("APP-X").build());

		doNothing().when(flywireService).auditLog(anyString(), any(ChecksumRequest.class), any(), anyString(),
				anyString());

		SMSPushRequest smsPushRequest = SMSPushRequest.builder().refNo(refNo).smsMsgKeywordValue(otp).build();

		this.mockMvc
				.perform(post("/smsConfirmation/" + journeyId).header(AppConstant.CORRELATION_ID, correlationId)
						.contentType(MediaType.APPLICATION_JSON_VALUE)
						.content(mapper.writeValueAsString(smsPushRequest)))
				.andDo(print()).andExpect(status().isOk())
				.andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
				.andExpect(jsonPath("$.status").value(0))
				.andExpect(jsonPath("$.message").value("Success - Customer data is saved successfully"))
				.andExpect(jsonPath("$.data.status").value(AppConstant.SUCCESS))
				.andExpect(jsonPath("$.data.errorMsg").isEmpty())
				.andExpect(jsonPath("$.data.responseString").value("APP-X")).andReturn();
	}

	@Test
	void testGetCheckSum() throws JsonProcessingException, Exception {
		String correlationId = "1234";
		String customerId = "5001001";
		String journeyId = correlationId;
		when(flywireService.isCorrelationIdValid(correlationId)).thenReturn(true);

		when(flywireService.buildChecksum(anyString(), any(ChecksumRequest.class)))
				.thenReturn(ChecksumResponse.builder().checksum(11223344L).build());

		doNothing().when(flywireService).auditLog(anyString(), any(ChecksumRequest.class), any(), anyString(),
				anyString());

		ChecksumRequest checksumRequest = new ChecksumRequest(customerId);

		this.mockMvc
				.perform(post("/getCheckSum/" + journeyId).header(AppConstant.CORRELATION_ID, correlationId)
						.contentType(MediaType.APPLICATION_JSON_VALUE)
						.content(mapper.writeValueAsString(checksumRequest)))
				.andDo(print()).andExpect(status().isOk())
				.andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
				.andExpect(jsonPath("$.status").value(0))
				.andExpect(jsonPath("$.message").value("Success - Customer data is saved successfully"))
				.andExpect(jsonPath("$.data.checksum").isNumber()).andExpect(jsonPath("$.data.errorMsg").isEmpty())
				.andReturn();
	}

	@Test
	void testSubmitAccount() throws JsonProcessingException, Exception {
		String correlationId = "1234";
		String accountNo = "9099005001001";
		String journeyId = correlationId;
		when(flywireService.isCorrelationIdValid(correlationId)).thenReturn(true);

		when(flywireService.submitAccount(anyString(), any(SelectedAccountRequest.class)))
				.thenReturn(SelectedAccountResponse.builder().accountSelected(true).build());

		doNothing().when(flywireService).auditLog(anyString(), any(ChecksumRequest.class), any(), anyString(),
				anyString());

		SelectedAccountRequest selectedAccountRequest = new SelectedAccountRequest(accountNo);

		this.mockMvc
				.perform(post("/submitAccount/" + journeyId).header(AppConstant.CORRELATION_ID, correlationId)
						.contentType(MediaType.APPLICATION_JSON_VALUE)
						.content(mapper.writeValueAsString(selectedAccountRequest)))
				.andDo(print()).andExpect(status().isOk())
				.andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
				.andExpect(jsonPath("$.status").value(0))
				.andExpect(jsonPath("$.message").value("Success - Customer data is saved successfully"))
				.andExpect(jsonPath("$.data.accountSelected").value(true))
				.andExpect(jsonPath("$.data.errorMsg").isEmpty()).andReturn();
	}

	@Test
	void testUiTerminated() throws JsonProcessingException, Exception {
		String correlationId = "1234";
		String journeyId = correlationId;
		when(flywireService.isCorrelationIdValid(correlationId)).thenReturn(true);

		doNothing().when(flywireService).uiTerminated(anyString());

		doNothing().when(flywireService).auditLog(anyString(), any(UITerminatedRequest.class), any(), anyString(),
				anyString());

		UITerminatedRequest uiTerminatedRequest = UITerminatedRequest.builder().terminationReason("This is a test")
				.build();

		this.mockMvc
				.perform(post("/uiTerminated/" + journeyId).header(AppConstant.CORRELATION_ID, correlationId)
						.contentType(MediaType.APPLICATION_JSON_VALUE)
						.content(mapper.writeValueAsString(uiTerminatedRequest)))
				.andDo(print()).andExpect(status().isOk())
				.andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
				.andExpect(jsonPath("$.status").value(0))
				.andExpect(jsonPath("$.message").value("Success - Customer data is saved successfully")).andReturn();
	}

}
