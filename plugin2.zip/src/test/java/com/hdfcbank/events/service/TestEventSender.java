package com.hdfcbank.events.service;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;

import com.hdfcbank.events.model.EventModel;


class TestEventSender {

    
    String getXmldata(String fileName) throws IOException, URISyntaxException {

        URL resource = getClass().getClassLoader().
        getResource( fileName );
        return Files.readString(Paths.get(resource.toURI()));

    }

    @Test
    void sendDataEventToDataLake() throws Exception, IOException {

        String serviceType = "BRE";
        String productType = "Dial";
        Map < String, String > inputParam = Map.of("autocircleid", "1162", "mobileno", "9822650637",
            "operationtype", "BRE", "seqid", "5154", "status", "success", "tranrefnumber", "574693264809");
        EventSender obj = EventSenderImpl.getInstance();
       boolean result= obj.sendEventToDataLake(getXmldata("bre_request.xml"), serviceType,
            productType, inputParam);
       assertTrue(result);

    }

    @Test
    void sendReqResEventToDataLake() throws IOException, URISyntaxException {

        String serviceType = "BRE";
        String productType = "Dial";
        Map < String, String > inputParam = Map.of("autocircleid", "1162", "mobileno", "9822650637",
            "operationtype", "BRE", "seqid", "5154", "status", "success", "tranrefnumber", "574693264809");
        EventSender obj = EventSenderImpl.getInstance();
        obj.sendEventToDataLake(getXmldata("bre_request.xml"), getXmldata("bre_response.xml"), serviceType,
            productType, inputParam);
    }

    @Test
    void sendHunterEventToDataLake() throws IOException, URISyntaxException {

        String serviceType = "BRE";
        String productType = "Dial";
        Map < String, String > inputParam = 
        		Map.of("autocircleid", "1162", 
        				"mobileno", "9822650637",
        				"operationtype", "HunterAPI",
        				"seqid", "3755",
        				"status", "Failure", 
        				"tranrefnumber", "574693264809");
        EventSender obj = EventSenderImpl.getInstance();
        obj.sendEventToDataLake(getXmldata("hunter_request.xml"), 
        		getXmldata("hunter_request.xml"), serviceType,
            productType, inputParam);
    }


    @Test
    void sendBatchEventToDataLake() throws IOException, URISyntaxException {

        String serviceType = "BRE";
        String productType = "Dial";
        EventSender obj = EventSenderImpl.getInstance();
        List < EventModel > eventModelList = new ArrayList < EventModel > ();
        Map < String, String > inputParam = Map.of("autocircleid", "1162", "mobileno", "9822650637",
            "operationtype", "BRE", "seqid", "5154", "status", "success", "tranrefnumber", "574693264809");

        eventModelList.add(new EventModel(getXmldata("bre_request.xml"), getXmldata("bre_response.xml"), inputParam));
        eventModelList.add(new EventModel(getXmldata("bre_request1.xml"), getXmldata("bre_response1.xml"), inputParam));

        obj.sendBatchEventToDataLake(eventModelList, serviceType, productType);
    }


}