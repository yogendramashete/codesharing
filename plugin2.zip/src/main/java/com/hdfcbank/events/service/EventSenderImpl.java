package com.hdfcbank.events.service;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.UUID;
import java.util.stream.Stream;

import com.azure.messaging.eventhubs.EventData;
import com.azure.messaging.eventhubs.EventDataBatch;
import com.azure.messaging.eventhubs.EventHubClientBuilder;
import com.azure.messaging.eventhubs.EventHubProducerClient;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hdfcbank.events.exception.EventException;
import com.hdfcbank.events.model.EventModel;
import com.hdfcbank.events.model.EventModelDTO;
import com.hdfcbank.events.util.FilesData;


public class EventSenderImpl implements EventSender {

	static EventSenderImpl obj =new EventSenderImpl();
	private EventHubProducerClient producer;
	private Properties configProp = new Properties();

	private  String connectionString;
	//;EntityPath=ddi-dev-eventhub-hunter
	private static final String eventHubName = "ddi-dev-eventhub-hunter";

    private Map<String, String> topicMapper;
	private static final SimpleDateFormat timeStampFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
	private ObjectMapper objectMapper = new ObjectMapper();


	private EventSenderImpl()  {
try {		
	String data=FilesData.getdata("EventTopicMapper.json");
	topicMapper = objectMapper.readValue(data, Map.class);
	System.out.println("Json values"+topicMapper);
	configProp.load(EventSenderImpl.class.getClassLoader().getResourceAsStream("application.properties"));	
	connectionString=configProp.getProperty("EventHubConnection");
	producer = new EventHubClientBuilder()
			.connectionString(connectionString, eventHubName)
			.buildProducerClient();
}catch(Exception e) {
	e.printStackTrace();
}
	}
	public static EventSenderImpl getInstance() {
		return obj;
	}

	public boolean sendEventToDataLake(String request,String response, String serviceType, String productType,
			Map<String, String> inputParam)  {
		try {

			Timestamp timestamp = new Timestamp(System.currentTimeMillis());	
			String timetampStr= timeStampFormat.format(timestamp);
			String messageID=  UUID.randomUUID().toString();
			
			EventModelDTO 
			eventModel=  EventModelDTO.builder()
			.messageId(messageID)
			.request(request)
			.response(response)
			.timeStamp(timetampStr)
			.serviceType(serviceType)
			.productType(productType)
			.inputParam(inputParam).build();

			String jsonStr= objectMapper.writeValueAsString(eventModel);

			EventData payload = new EventData(jsonStr.getBytes());
			producer.send(List.of(payload));
			producer.close();

		} catch (JsonProcessingException e) {

			e.printStackTrace();
		}     
		return true;
	}


	@Override
	public boolean sendEventToDataLake(String data, String serviceType, String productType,
			Map<String, String> inputParam) {
		// TODO Auto-generated method stub
		try {

			Timestamp timestamp = new Timestamp(System.currentTimeMillis());	
			String timetampStr= timeStampFormat.format(timestamp);
			String messageID=  UUID.randomUUID().toString();
			EventModelDTO 
			eventModel=  EventModelDTO.builder()
			.messageId(messageID)
			.request(data)
			.response(null)
			.timeStamp(timetampStr)
			.serviceType(serviceType)
			.productType(productType)
			.inputParam(inputParam).build();

			String jsonStr= objectMapper.writeValueAsString(eventModel);

			EventData payload = new EventData(jsonStr.getBytes());
			producer.send(List.of(payload));
			producer.close();

		} catch (JsonProcessingException e) {

			e.printStackTrace();
		}
		return true;
	}


	@Override
	public boolean sendBatchEventToDataLake(List<EventModel> listData, String serviceType,
			String productType) {
		try {
			// TODO Auto-generated method stub
			EventHubProducerClient producer = new EventHubClientBuilder()
					.connectionString(connectionString, eventHubName)
					.buildProducerClient();

			List<EventData> batchdataList=new ArrayList<>();

			for (EventModel eventData : listData) {
				Timestamp timestamp = new Timestamp(System.currentTimeMillis());	
				String timetampStr= timeStampFormat.format(timestamp);
				String messageID=  UUID.randomUUID().toString();

				EventModelDTO 
				eventModel=  EventModelDTO.builder()
				.messageId(messageID)
				.request(eventData.getRequest())
				.response(eventData.getResponse())
				.timeStamp(timetampStr)
				.serviceType(serviceType)
				.productType(productType)
				.inputParam(eventData.getInputParam()).build();

				String jsonStr= objectMapper.writeValueAsString(eventModel);
				EventData payload = new EventData(jsonStr.getBytes());
				batchdataList.add(payload);

			}

			EventDataBatch eventDataBatch = producer.createBatch();

			for (EventData eventData : batchdataList) {

				if (!eventDataBatch.tryAdd(eventData)) {

					producer.send(eventDataBatch);
					eventDataBatch = producer.createBatch();
					if (!eventDataBatch.tryAdd(eventData)) {
						throw new EventException("Event is too large for an empty batch. Max size: "
								+ eventDataBatch.getMaxSizeInBytes());
					}
				}
			}
			if (eventDataBatch.getCount() > 0) {
				System.out.println("Send starts");
				producer.send(eventDataBatch);
				System.out.println("send Ends");
			}

			producer.close();
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}     



		return true;
	}



}
