package com.hdfcbank.events.service;





import java.util.List;

import java.util.Map;



import com.hdfcbank.events.model.EventModel;



public interface EventSender {

    

    /**

     * This API will be used to Push individual data

     * @param data - The data the needs to be pushed to Event Hub

     * @param serviceType - Type of data eg. BRE, HUNTER etc

     * @param productType- Type of product line - Dial, BL, CD

     * @param inputParam - input fields from xml File eg.-( "autocircleid->1162", "mobileno->9822650637",

            "operationtype->BRE", "seqid->5154", "status->success", "tranrefnumber->574693264809");



     * @return 

     */

    //enum for serviceType productType

    public boolean sendEventToDataLake(String data, String serviceType,

            String productType,Map<String,String> inputParam ); 

    

    /**

     * This API will be used to Push individual request and response to data lake

     * @param request

     * @param response

     * @param serviceType

     * @param productType

     * @param inputParam

     * @return

     */

    public boolean sendEventToDataLake(String request, String response, String serviceType,String productType,
            Map<String,String> inputParam); 


    /**

     *  This API will be used to Push data in batch model

     * @param data. 

     * @param serviceType

     * @param productType

     * @return

     */

    public boolean sendBatchEventToDataLake(List<EventModel> data, 

            String serviceType,String productType);

    

}