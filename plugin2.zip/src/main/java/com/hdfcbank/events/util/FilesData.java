package com.hdfcbank.events.util;

import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;

public class FilesData {
	
	 public  static String getdata(String fileName) throws IOException, URISyntaxException {

	        URL resource = FilesData.class.getClassLoader().getResource( fileName );
	        return Files.readString(Paths.get(resource.toURI()));

	    }


}
