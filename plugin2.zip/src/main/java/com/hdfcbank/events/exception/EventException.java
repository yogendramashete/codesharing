package com.hdfcbank.events.exception;

public class EventException extends RuntimeException {

	public EventException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public EventException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public EventException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public EventException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
	

}
