package com.hdfcbank.events.model;

import java.util.Map;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class EventModel {
	private String request;
	private String response;
	private Map<String,String> inputParam;
}
