package com.hdfcbank.events.model;

import java.util.Map;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class EventModelDTO {
	private String messageId;
	private String request;
	private String response;
	private String timeStamp;
	private String serviceType;
	private String productType;
	private Map<String,String> inputParam;
	

}
