import React, { useState } from 'react';
import { Plus, Search, Filter, Edit, Trash2, Database, Tag } from 'lucide-react';

const Fields: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [typeFilter, setTypeFilter] = useState('all');

  const fields = [
    { id: 1, name: 'customer_id', type: 'Integer', required: true, validation: 'Numeric', documents: 24, description: 'Unique customer identifier' },
    { id: 2, name: 'email_address', type: 'String', required: true, validation: 'Email Format', documents: 18, description: 'Customer email address' },
    { id: 3, name: 'phone_number', type: 'String', required: false, validation: 'Phone Format', documents: 15, description: 'Customer phone number' },
    { id: 4, name: 'created_date', type: 'DateTime', required: true, validation: 'Date Range', documents: 32, description: 'Record creation timestamp' },
    { id: 5, name: 'amount', type: 'Decimal', required: true, validation: 'Range Check', documents: 28, description: 'Transaction amount' },
    { id: 6, name: 'status', type: 'String', required: true, validation: 'Enum Values', documents: 21, description: 'Record status' },
  ];

  const filteredFields = fields.filter(field => {
    const matchesSearch = field.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         field.type.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         field.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = typeFilter === 'all' || field.type.toLowerCase() === typeFilter.toLowerCase();
    return matchesSearch && matchesType;
  });

  return (
    <div className="p-6 lg:p-8">
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Fields</h1>
          <p className="text-gray-600 mt-2">Manage data field definitions and validations</p>
        </div>
        <button className="mt-4 lg:mt-0 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors duration-200 flex items-center">
          <Plus size={20} className="mr-2" />
          Add Field
        </button>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100 mb-6">
        <div className="flex flex-col lg:flex-row gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
            <input
              type="text"
              placeholder="Search fields..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          <select
            value={typeFilter}
            onChange={(e) => setTypeFilter(e.target.value)}
            className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            <option value="all">All Types</option>
            <option value="string">String</option>
            <option value="integer">Integer</option>
            <option value="decimal">Decimal</option>
            <option value="datetime">DateTime</option>
            <option value="boolean">Boolean</option>
          </select>
        </div>
      </div>

      {/* Fields Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {filteredFields.map((field) => (
          <div key={field.id} className="bg-white rounded-xl shadow-sm p-6 border border-gray-100 hover:shadow-md transition-shadow duration-200">
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center">
                <div className="p-2 bg-purple-100 rounded-lg">
                  <Database className="h-6 w-6 text-purple-600" />
                </div>
                <div className="ml-3">
                  <h3 className="text-lg font-semibold text-gray-900">{field.name}</h3>
                  <div className="flex items-center mt-1">
                    <Tag className="h-4 w-4 text-gray-400 mr-1" />
                    <span className="text-sm text-gray-600">{field.type}</span>
                  </div>
                </div>
              </div>
              <div className="flex space-x-2">
                <button className="p-2 text-gray-400 hover:text-blue-600 transition-colors duration-200">
                  <Edit size={16} />
                </button>
                <button className="p-2 text-gray-400 hover:text-red-600 transition-colors duration-200">
                  <Trash2 size={16} />
                </button>
              </div>
            </div>

            <p className="text-sm text-gray-600 mb-4">{field.description}</p>

            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">Required</span>
                <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                  field.required ? 'bg-red-100 text-red-800' : 'bg-gray-100 text-gray-800'
                }`}>
                  {field.required ? 'Yes' : 'No'}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">Validation</span>
                <span className="px-2 py-1 bg-blue-100 text-blue-800 rounded-full text-xs font-medium">
                  {field.validation}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">Used in Documents</span>
                <span className="text-sm font-medium text-gray-900">{field.documents}</span>
              </div>
            </div>

            <div className="mt-6 pt-4 border-t border-gray-100">
              <button className="w-full bg-blue-50 text-blue-700 px-4 py-2 rounded-lg hover:bg-blue-100 transition-colors duration-200 text-sm font-medium">
                View Field Details
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Fields;