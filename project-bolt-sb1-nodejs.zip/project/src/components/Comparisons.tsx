import React, { useState } from 'react';
import { Plus, Search, GitCompare, Calendar, TrendingUp, TrendingDown, Minus } from 'lucide-react';

const Comparisons: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');

  const comparisons = [
    { 
      id: 1, 
      name: 'Customer Data vs Backup', 
      source1: 'Production DB', 
      source2: 'Backup DB', 
      status: 'Completed', 
      matches: 98.5, 
      differences: 15, 
      lastRun: '2024-01-15 14:30',
      type: 'Database'
    },
    { 
      id: 2, 
      name: 'API Response Validation', 
      source1: 'Live API', 
      source2: 'Test API', 
      status: 'Running', 
      matches: 0, 
      differences: 0, 
      lastRun: '2024-01-15 15:45',
      type: 'API'
    },
    { 
      id: 3, 
      name: 'File Format Check', 
      source1: 'CSV Export', 
      source2: 'JSON Export', 
      status: 'Failed', 
      matches: 87.2, 
      differences: 89, 
      lastRun: '2024-01-15 12:15',
      type: 'File'
    },
    { 
      id: 4, 
      name: 'Schema Validation', 
      source1: 'Schema v2.1', 
      source2: 'Schema v2.0', 
      status: 'Completed', 
      matches: 95.8, 
      differences: 3, 
      lastRun: '2024-01-15 11:20',
      type: 'Schema'
    },
  ];

  const filteredComparisons = comparisons.filter(comparison =>
    comparison.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    comparison.source1.toLowerCase().includes(searchTerm.toLowerCase()) ||
    comparison.source2.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="p-6 lg:p-8">
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Comparisons</h1>
          <p className="text-gray-600 mt-2">Compare data sources and analyze differences</p>
        </div>
        <button className="mt-4 lg:mt-0 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors duration-200 flex items-center">
          <Plus size={20} className="mr-2" />
          New Comparison
        </button>
      </div>

      {/* Search */}
      <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100 mb-6">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
          <input
            type="text"
            placeholder="Search comparisons..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>
      </div>

      {/* Comparisons List */}
      <div className="space-y-6">
        {filteredComparisons.map((comparison) => (
          <div key={comparison.id} className="bg-white rounded-xl shadow-sm p-6 border border-gray-100 hover:shadow-md transition-shadow duration-200">
            <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between">
              <div className="flex items-start lg:items-center mb-4 lg:mb-0">
                <div className="p-3 bg-orange-100 rounded-lg mr-4">
                  <GitCompare className="h-6 w-6 text-orange-600" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-1">{comparison.name}</h3>
                  <div className="flex flex-col lg:flex-row lg:items-center lg:space-x-4 text-sm text-gray-600">
                    <span>{comparison.source1} ↔ {comparison.source2}</span>
                    <span className="flex items-center mt-1 lg:mt-0">
                      <Calendar className="h-4 w-4 mr-1" />
                      {comparison.lastRun}
                    </span>
                  </div>
                </div>
              </div>

              <div className="flex items-center space-x-6">
                <div className="text-center">
                  <div className="text-sm text-gray-600">Status</div>
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                    comparison.status === 'Completed' ? 'bg-emerald-100 text-emerald-800' :
                    comparison.status === 'Running' ? 'bg-blue-100 text-blue-800' :
                    'bg-red-100 text-red-800'
                  }`}>
                    {comparison.status}
                  </span>
                </div>

                {comparison.status === 'Completed' && (
                  <>
                    <div className="text-center">
                      <div className="text-sm text-gray-600">Match Rate</div>
                      <div className="flex items-center">
                        <TrendingUp className="h-4 w-4 text-emerald-500 mr-1" />
                        <span className="text-lg font-semibold text-gray-900">{comparison.matches}%</span>
                      </div>
                    </div>

                    <div className="text-center">
                      <div className="text-sm text-gray-600">Differences</div>
                      <div className="flex items-center">
                        <TrendingDown className="h-4 w-4 text-red-500 mr-1" />
                        <span className="text-lg font-semibold text-gray-900">{comparison.differences}</span>
                      </div>
                    </div>
                  </>
                )}

                {comparison.status === 'Running' && (
                  <div className="text-center">
                    <div className="text-sm text-gray-600">Progress</div>
                    <div className="flex items-center">
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-blue-600 mr-2"></div>
                      <span className="text-lg font-semibold text-gray-900">Running...</span>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {comparison.status === 'Completed' && (
              <div className="mt-4 pt-4 border-t border-gray-100">
                <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between">
                  <div className="mb-3 lg:mb-0">
                    <div className="text-sm text-gray-600 mb-2">Match Rate Progress</div>
                    <div className="w-full lg:w-64 bg-gray-200 rounded-full h-2">
                      <div
                        className={`h-2 rounded-full ${
                          comparison.matches >= 95 ? 'bg-emerald-500' :
                          comparison.matches >= 90 ? 'bg-yellow-500' : 'bg-red-500'
                        }`}
                        style={{ width: `${comparison.matches}%` }}
                      ></div>
                    </div>
                  </div>
                  <div className="flex space-x-3">
                    <button className="bg-blue-50 text-blue-700 px-4 py-2 rounded-lg hover:bg-blue-100 transition-colors duration-200">
                      View Details
                    </button>
                    <button className="bg-gray-50 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-100 transition-colors duration-200">
                      Re-run
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default Comparisons;