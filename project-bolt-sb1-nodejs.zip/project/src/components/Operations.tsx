import React, { useState } from 'react';
import { Plus, Search, Filter, Settings, Play, Pause, Square, Clock, CheckCircle, AlertTriangle } from 'lucide-react';

const Operations: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');

  const operations = [
    { 
      id: 1, 
      name: 'Data Import Process', 
      type: 'Import', 
      status: 'Running', 
      progress: 65, 
      startTime: '2024-01-15 14:30:00',
      duration: '00:12:45',
      source: 'External API',
      records: 15420
    },
    { 
      id: 2, 
      name: 'Field Validation Batch', 
      type: 'Validation', 
      status: 'Completed', 
      progress: 100, 
      startTime: '2024-01-15 13:15:00',
      duration: '00:08:32',
      source: 'Database Channel',
      records: 8934
    },
    { 
      id: 3, 
      name: 'Document Export', 
      type: 'Export', 
      status: 'Failed', 
      progress: 45, 
      startTime: '2024-01-15 12:00:00',
      duration: '00:04:12',
      source: 'File System',
      records: 2156
    },
    { 
      id: 4, 
      name: 'Comparison Analysis', 
      type: 'Comparison', 
      status: 'Pending', 
      progress: 0, 
      startTime: null,
      duration: null,
      source: 'Multiple Sources',
      records: 0
    },
    { 
      id: 5, 
      name: 'Data Transformation', 
      type: 'Transform', 
      status: 'Running', 
      progress: 23, 
      startTime: '2024-01-15 15:45:00',
      duration: '00:03:21',
      source: 'Message Queue',
      records: 4821
    },
  ];

  const filteredOperations = operations.filter(operation => {
    const matchesSearch = operation.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         operation.type.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         operation.source.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || operation.status.toLowerCase() === statusFilter.toLowerCase();
    return matchesSearch && matchesStatus;
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Running': return 'bg-blue-100 text-blue-800';
      case 'Completed': return 'bg-emerald-100 text-emerald-800';
      case 'Failed': return 'bg-red-100 text-red-800';
      case 'Pending': return 'bg-yellow-100 text-yellow-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'Running': return <Play className="h-4 w-4" />;
      case 'Completed': return <CheckCircle className="h-4 w-4" />;
      case 'Failed': return <AlertTriangle className="h-4 w-4" />;
      case 'Pending': return <Clock className="h-4 w-4" />;
      default: return <Settings className="h-4 w-4" />;
    }
  };

  return (
    <div className="p-6 lg:p-8">
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Operations</h1>
          <p className="text-gray-600 mt-2">Monitor and manage system operations</p>
        </div>
        <button className="mt-4 lg:mt-0 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors duration-200 flex items-center">
          <Plus size={20} className="mr-2" />
          New Operation
        </button>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100 mb-6">
        <div className="flex flex-col lg:flex-row gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
            <input
              type="text"
              placeholder="Search operations..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            <option value="all">All Status</option>
            <option value="running">Running</option>
            <option value="completed">Completed</option>
            <option value="failed">Failed</option>
            <option value="pending">Pending</option>
          </select>
        </div>
      </div>

      {/* Operations List */}
      <div className="space-y-4">
        {filteredOperations.map((operation) => (
          <div key={operation.id} className="bg-white rounded-xl shadow-sm p-6 border border-gray-100 hover:shadow-md transition-shadow duration-200">
            <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between mb-4">
              <div className="flex items-center mb-4 lg:mb-0">
                <div className="p-3 bg-gray-100 rounded-lg mr-4">
                  <Settings className="h-6 w-6 text-gray-600" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-gray-900">{operation.name}</h3>
                  <div className="flex items-center space-x-4 text-sm text-gray-600 mt-1">
                    <span className="bg-gray-100 px-2 py-1 rounded text-xs">{operation.type}</span>
                    <span>{operation.source}</span>
                  </div>
                </div>
              </div>

              <div className="flex items-center space-x-4">
                <div className="text-center">
                  <div className="text-sm text-gray-600">Status</div>
                  <span className={`px-2 py-1 rounded-full text-xs font-medium flex items-center ${getStatusColor(operation.status)}`}>
                    {getStatusIcon(operation.status)}
                    <span className="ml-1">{operation.status}</span>
                  </span>
                </div>

                {operation.status === 'Running' && (
                  <div className="text-center">
                    <div className="text-sm text-gray-600">Progress</div>
                    <div className="text-lg font-semibold text-gray-900">{operation.progress}%</div>
                  </div>
                )}

                {operation.records > 0 && (
                  <div className="text-center">
                    <div className="text-sm text-gray-600">Records</div>
                    <div className="text-lg font-semibold text-gray-900">{operation.records.toLocaleString()}</div>
                  </div>
                )}

                <div className="flex space-x-2">
                  {operation.status === 'Running' && (
                    <>
                      <button className="p-2 text-yellow-600 hover:bg-yellow-50 rounded-lg transition-colors duration-200">
                        <Pause size={16} />
                      </button>
                      <button className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors duration-200">
                        <Square size={16} />
                      </button>
                    </>
                  )}
                  {operation.status === 'Pending' && (
                    <button className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors duration-200">
                      <Play size={16} />
                    </button>
                  )}
                  {(operation.status === 'Failed' || operation.status === 'Completed') && (
                    <button className="p-2 text-gray-600 hover:bg-gray-50 rounded-lg transition-colors duration-200">
                      <Play size={16} />
                    </button>
                  )}
                </div>
              </div>
            </div>

            {/* Progress Bar for Running Operations */}
            {operation.status === 'Running' && (
              <div className="mb-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm text-gray-600">Progress</span>
                  <span className="text-sm font-medium text-gray-900">{operation.progress}%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div
                    className="bg-blue-500 h-2 rounded-full transition-all duration-300"
                    style={{ width: `${operation.progress}%` }}
                  ></div>
                </div>
              </div>
            )}

            {/* Operation Details */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 text-sm">
              {operation.startTime && (
                <div>
                  <span className="text-gray-600">Started:</span>
                  <div className="font-medium text-gray-900">{operation.startTime}</div>
                </div>
              )}
              {operation.duration && (
                <div>
                  <span className="text-gray-600">Duration:</span>
                  <div className="font-medium text-gray-900">{operation.duration}</div>
                </div>
              )}
              <div>
                <span className="text-gray-600">Type:</span>
                <div className="font-medium text-gray-900">{operation.type}</div>
              </div>
              <div>
                <span className="text-gray-600">Source:</span>
                <div className="font-medium text-gray-900">{operation.source}</div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Operations;