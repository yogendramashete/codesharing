import React, { useState } from 'react';
import { Plus, Search, Filter, Edit, Trash2, CheckCircle, AlertTriangle, Play } from 'lucide-react';

const Validations: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');

  const validations = [
    { id: 1, name: 'Email Format Validation', type: 'Format Check', status: 'Active', fields: 5, lastRun: '2 mins ago', successRate: 98 },
    { id: 2, name: 'Date Range Validation', type: 'Range Check', status: 'Active', fields: 8, lastRun: '5 mins ago', successRate: 95 },
    { id: 3, name: 'Required Field Check', type: 'Null Check', status: 'Active', fields: 12, lastRun: '1 min ago', successRate: 92 },
    { id: 4, name: 'Numeric Range Validation', type: 'Range Check', status: 'Inactive', fields: 3, lastRun: '1 hour ago', successRate: 89 },
    { id: 5, name: 'Custom Business Rule', type: 'Custom', status: 'Error', fields: 6, lastRun: '10 mins ago', successRate: 76 },
    { id: 6, name: 'Phone Number Format', type: 'Format Check', status: 'Active', fields: 2, lastRun: '3 mins ago', successRate: 94 },
  ];

  const filteredValidations = validations.filter(validation => {
    const matchesSearch = validation.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         validation.type.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || validation.status.toLowerCase() === statusFilter.toLowerCase();
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="p-6 lg:p-8">
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Validations</h1>
          <p className="text-gray-600 mt-2">Manage data validation rules and checks</p>
        </div>
        <button className="mt-4 lg:mt-0 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors duration-200 flex items-center">
          <Plus size={20} className="mr-2" />
          Add Validation
        </button>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100 mb-6">
        <div className="flex flex-col lg:flex-row gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
            <input
              type="text"
              placeholder="Search validations..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            <option value="all">All Status</option>
            <option value="active">Active</option>
            <option value="inactive">Inactive</option>
            <option value="error">Error</option>
          </select>
        </div>
      </div>

      {/* Validations Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
        {filteredValidations.map((validation) => (
          <div key={validation.id} className="bg-white rounded-xl shadow-sm p-6 border border-gray-100 hover:shadow-md transition-shadow duration-200">
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center">
                <div className="p-2 bg-emerald-100 rounded-lg">
                  <CheckCircle className="h-6 w-6 text-emerald-600" />
                </div>
                <div className="ml-3">
                  <h3 className="text-lg font-semibold text-gray-900">{validation.name}</h3>
                  <p className="text-sm text-gray-600">{validation.type}</p>
                </div>
              </div>
              <div className="flex space-x-2">
                <button className="p-2 text-gray-400 hover:text-blue-600 transition-colors duration-200">
                  <Edit size={16} />
                </button>
                <button className="p-2 text-gray-400 hover:text-red-600 transition-colors duration-200">
                  <Trash2 size={16} />
                </button>
              </div>
            </div>

            <div className="space-y-3 mb-4">
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">Status</span>
                <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                  validation.status === 'Active' ? 'bg-emerald-100 text-emerald-800' :
                  validation.status === 'Inactive' ? 'bg-gray-100 text-gray-800' :
                  'bg-red-100 text-red-800'
                }`}>
                  {validation.status}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">Applied to Fields</span>
                <span className="text-sm font-medium text-gray-900">{validation.fields}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">Last Run</span>
                <span className="text-sm font-medium text-gray-900">{validation.lastRun}</span>
              </div>
            </div>

            {/* Success Rate */}
            <div className="mb-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-gray-600">Success Rate</span>
                <span className="text-sm font-medium text-gray-900">{validation.successRate}%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div
                  className={`h-2 rounded-full ${
                    validation.successRate >= 95 ? 'bg-emerald-500' :
                    validation.successRate >= 90 ? 'bg-yellow-500' : 'bg-red-500'
                  }`}
                  style={{ width: `${validation.successRate}%` }}
                ></div>
              </div>
            </div>

            <div className="flex space-x-2">
              <button className="flex-1 bg-blue-50 text-blue-700 px-3 py-2 rounded-lg hover:bg-blue-100 transition-colors duration-200 flex items-center justify-center">
                <Play size={16} className="mr-2" />
                Run
              </button>
              <button className="flex-1 bg-gray-50 text-gray-700 px-3 py-2 rounded-lg hover:bg-gray-100 transition-colors duration-200">
                Configure
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Validations;