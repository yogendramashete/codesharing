import React, { useState } from 'react';
import Sidebar from './components/Sidebar';
import Dashboard from './components/Dashboard';
import Channels from './components/Channels';
import Documents from './components/Documents';
import Fields from './components/Fields';
import Validations from './components/Validations';
import Comparisons from './components/Comparisons';
import Operations from './components/Operations';

type ActiveView = 'dashboard' | 'channels' | 'documents' | 'fields' | 'validations' | 'comparisons' | 'operations';

function App() {
  const [activeView, setActiveView] = useState<ActiveView>('dashboard');

  const renderActiveView = () => {
    switch (activeView) {
      case 'dashboard':
        return <Dashboard />;
      case 'channels':
        return <Channels />;
      case 'documents':
        return <Documents />;
      case 'fields':
        return <Fields />;
      case 'validations':
        return <Validations />;
      case 'comparisons':
        return <Comparisons />;
      case 'operations':
        return <Operations />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <div className="flex h-screen bg-gray-50">
      <Sidebar activeView={activeView} setActiveView={setActiveView} />
      <main className="flex-1 overflow-auto">
        {renderActiveView()}
      </main>
    </div>
  );
}

export default App;