import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { FileText, Settings, List, Plus } from 'lucide-react';

interface LayoutProps {
  children: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  const location = useLocation();

  const isActive = (path: string) => location.pathname === path;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      <nav className="bg-white shadow-lg border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex items-center">
              <Link to="/" className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-blue-600 rounded-lg flex items-center justify-center">
                  <FileText className="w-5 h-5 text-white" />
                </div>
                <span className="text-xl font-bold text-gray-900">ConfigHub</span>
              </Link>
            </div>
            
            <div className="flex items-center space-x-1">
              <Link
                to="/documents"
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                  isActive('/documents') || location.pathname.startsWith('/documents')
                    ? 'bg-blue-100 text-blue-700'
                    : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                }`}
              >
                <div className="flex items-center space-x-2">
                  <List className="w-4 h-4" />
                  <span>Documents</span>
                </div>
              </Link>
              
              <Link
                to="/channels"
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                  isActive('/channels') || location.pathname.startsWith('/channels')
                    ? 'bg-blue-100 text-blue-700'
                    : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                }`}
              >
                <div className="flex items-center space-x-2">
                  <Settings className="w-4 h-4" />
                  <span>Channels</span>
                </div>
              </Link>
              
              <Link
                to="/documents/create"
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                  isActive('/documents/create')
                    ? 'bg-emerald-100 text-emerald-700'
                    : 'text-emerald-600 hover:text-emerald-700 hover:bg-emerald-50'
                }`}
              >
                <div className="flex items-center space-x-2">
                  <Plus className="w-4 h-4" />
                  <span>Add Document</span>
                </div>
              </Link>
              
              <Link
                to="/channels/create"
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                  isActive('/channels/create')
                    ? 'bg-amber-100 text-amber-700'
                    : 'text-amber-600 hover:text-amber-700 hover:bg-amber-50'
                }`}
              >
                <div className="flex items-center space-x-2">
                  <Plus className="w-4 h-4" />
                  <span>Add Channel</span>
                </div>
              </Link>
            </div>
          </div>
        </div>
      </nav>
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {children}
      </main>
    </div>
  );
};

export default Layout;