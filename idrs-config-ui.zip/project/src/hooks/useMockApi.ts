import { useState, useEffect } from 'react';

export const useMockApi = () => {
  const [useMockApi, setUseMockApi] = useState(() => {
    const saved = localStorage.getItem('useMockApi');
    return saved ? JSON.parse(saved) : true; // Default to mock API enabled
  });

  useEffect(() => {
    localStorage.setItem('useMockApi', JSON.stringify(useMockApi));
  }, [useMockApi]);

  const toggleMockApi = () => {
    setUseMockApi((prev: boolean) => !prev);
  };

  return {
    useMockApi,
    toggleMockApi,
    setUseMockApi
  };
};