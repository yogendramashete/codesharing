import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Layout from './components/Layout';
import Home from './pages/Home';
import DocumentList from './pages/DocumentList';
import DocumentDetail from './pages/DocumentDetail';
import DocumentCreate from './pages/DocumentCreate';
import DocumentEdit from './pages/DocumentEdit';
import ChannelList from './pages/ChannelList';
import ChannelDetail from './pages/ChannelDetail';
import ChannelCreate from './pages/ChannelCreate';
import ChannelEdit from './pages/ChannelEdit';

function App() {
  return (
    <Router>
      <Layout>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/documents" element={<DocumentList />} />
          <Route path="/documents/create" element={<DocumentCreate />} />
          <Route path="/documents/:documentName" element={<DocumentDetail />} />
          <Route path="/documents/:documentName/edit" element={<DocumentEdit />} />
          <Route path="/channels" element={<ChannelList />} />
          <Route path="/channels/create" element={<ChannelCreate />} />
          <Route path="/channels/:channelName" element={<ChannelDetail />} />
          <Route path="/channels/:channelName/edit" element={<ChannelEdit />} />
        </Routes>
      </Layout>
    </Router>
  );
}

export default App;