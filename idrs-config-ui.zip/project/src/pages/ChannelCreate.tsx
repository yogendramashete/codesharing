import React, { useState, useEffect } from 'react';
import { Settings, Plus, Save } from 'lucide-react';
import { channelApi, documentApi } from '../utils/api';
import type { SaveChannelRequest, DocumentResponse } from '../types/api';

const ChannelCreate: React.FC = () => {
  const [formData, setFormData] = useState({
    channel: '',
    neevAPIKey: '',
    preprocessing: false,
    postprocessing: false,
  });
  const [availableDocuments, setAvailableDocuments] = useState<DocumentResponse | null>(null);
  const [selectedDocuments, setSelectedDocuments] = useState<Record<string, any>>({});
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);

  useEffect(() => {
    const fetchDocuments = async () => {
      try {
        const data = await documentApi.getAllDocuments();
        setAvailableDocuments(data);
      } catch (error) {
        console.error('Error fetching documents:', error);
      }
    };

    fetchDocuments();
  }, []);

  const handleDocumentSelect = (documentName: string) => {
    if (selectedDocuments[documentName]) {
      const newSelected = { ...selectedDocuments };
      delete newSelected[documentName];
      setSelectedDocuments(newSelected);
    } else {
      setSelectedDocuments(prev => ({
        ...prev,
        [documentName]: {
          operations: {}
        }
      }));
    }
  };

  const handleOperationSelect = (documentName: string, operationType: string) => {
    setSelectedDocuments(prev => ({
      ...prev,
      [documentName]: {
        ...prev[documentName],
        operations: {
          ...prev[documentName].operations,
          [operationType]: prev[documentName].operations[operationType] 
            ? undefined 
            : { fields: {}, apis: [] }
        }
      }
    }));
  };

  const handleFieldSelect = (documentName: string, operationType: string, fieldName: string) => {
    setSelectedDocuments(prev => ({
      ...prev,
      [documentName]: {
        ...prev[documentName],
        operations: {
          ...prev[documentName].operations,
          [operationType]: {
            ...prev[documentName].operations[operationType],
            fields: {
              ...prev[documentName].operations[operationType].fields,
              [fieldName]: prev[documentName].operations[operationType].fields[fieldName]
                ? undefined
                : {
                    fieldValidation: [],
                    comparisonValidation: []
                  }
            }
          }
        }
      }
    }));
  };

  const handleValidationChange = (
    documentName: string,
    operationType: string,
    fieldName: string,
    validationType: 'fieldValidation' | 'comparisonValidation',
    value: string,
    checked: boolean
  ) => {
    setSelectedDocuments(prev => {
      const field = prev[documentName].operations[operationType].fields[fieldName];
      const currentValues = field[validationType] || [];
      
      const newValues = checked
        ? [...currentValues, value]
        : currentValues.filter((v: string) => v !== value);

      return {
        ...prev,
        [documentName]: {
          ...prev[documentName],
          operations: {
            ...prev[documentName].operations,
            [operationType]: {
              ...prev[documentName].operations[operationType],
              fields: {
                ...prev[documentName].operations[operationType].fields,
                [fieldName]: {
                  ...field,
                  [validationType]: newValues
                }
              }
            }
          }
        }
      };
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setSuccess(false);

    try {
      const requestData: SaveChannelRequest = {
        ...formData,
        documents: Object.fromEntries(
          Object.entries(selectedDocuments).filter(([_, doc]) => 
            Object.keys(doc.operations).length > 0
          )
        )
      };

      await channelApi.saveChannel(requestData);
      setSuccess(true);
      
      // Reset form
      setFormData({
        channel: '',
        neevAPIKey: '',
        preprocessing: false,
        postprocessing: false,
      });
      setSelectedDocuments({});
      
      setTimeout(() => setSuccess(false), 3000);
    } catch (error) {
      console.error('Error saving channel:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-6xl mx-auto">
      <div className="bg-white rounded-xl shadow-lg p-8">
        <div className="flex items-center space-x-3 mb-8">
          <div className="w-12 h-12 bg-gradient-to-br from-amber-500 to-amber-600 rounded-lg flex items-center justify-center">
            <Settings className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Create New Channel</h1>
            <p className="text-gray-600">Configure a new channel with document operations</p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label htmlFor="channel" className="block text-sm font-medium text-gray-700 mb-2">
                Channel Name
              </label>
              <input
                type="text"
                id="channel"
                value={formData.channel}
                onChange={(e) => setFormData(prev => ({ ...prev, channel: e.target.value }))}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500 transition-colors"
                placeholder="e.g., FTAGN"
                required
              />
            </div>

            <div>
              <label htmlFor="neevAPIKey" className="block text-sm font-medium text-gray-700 mb-2">
                Neev API Key
              </label>
              <input
                type="text"
                id="neevAPIKey"
                value={formData.neevAPIKey}
                onChange={(e) => setFormData(prev => ({ ...prev, neevAPIKey: e.target.value }))}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500 transition-colors"
                placeholder="sk-..."
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="flex items-center">
              <input
                type="checkbox"
                id="preprocessing"
                checked={formData.preprocessing}
                onChange={(e) => setFormData(prev => ({ ...prev, preprocessing: e.target.checked }))}
                className="h-4 w-4 text-amber-600 focus:ring-amber-500 border-gray-300 rounded"
              />
              <label htmlFor="preprocessing" className="ml-2 block text-sm text-gray-900">
                Enable Preprocessing
              </label>
            </div>

            <div className="flex items-center">
              <input
                type="checkbox"
                id="postprocessing"
                checked={formData.postprocessing}
                onChange={(e) => setFormData(prev => ({ ...prev, postprocessing: e.target.checked }))}
                className="h-4 w-4 text-amber-600 focus:ring-amber-500 border-gray-300 rounded"
              />
              <label htmlFor="postprocessing" className="ml-2 block text-sm text-gray-900">
                Enable Postprocessing
              </label>
            </div>
          </div>

          <div>
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Document Configuration</h2>
            
            {availableDocuments && (
              <div className="space-y-6">
                {Object.entries(availableDocuments.documents).map(([documentName, document]) => (
                  <div key={documentName} className="border border-gray-200 rounded-lg p-6">
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center space-x-3">
                        <input
                          type="checkbox"
                          id={documentName}
                          checked={!!selectedDocuments[documentName]}
                          onChange={() => handleDocumentSelect(documentName)}
                          className="h-4 w-4 text-amber-600 focus:ring-amber-500 border-gray-300 rounded"
                        />
                        <label htmlFor={documentName} className="text-lg font-medium text-gray-900">
                          {documentName}
                        </label>
                      </div>
                    </div>

                    {selectedDocuments[documentName] && (
                      <div className="pl-6 space-y-4">
                        <h3 className="text-md font-medium text-gray-800">Operations</h3>
                        
                        {Object.entries(document.operations).map(([operationType, operation]) => (
                          <div key={operationType} className="bg-gray-50 rounded-lg p-4">
                            <div className="flex items-center space-x-3 mb-3">
                              <input
                                type="checkbox"
                                id={`${documentName}-${operationType}`}
                                checked={!!selectedDocuments[documentName]?.operations[operationType]}
                                onChange={() => handleOperationSelect(documentName, operationType)}
                                className="h-4 w-4 text-amber-600 focus:ring-amber-500 border-gray-300 rounded"
                              />
                              <label htmlFor={`${documentName}-${operationType}`} className="font-medium text-gray-900">
                                {operationType}
                              </label>
                            </div>

                            {selectedDocuments[documentName]?.operations[operationType] && operation.fields && (
                              <div className="pl-6 space-y-3">
                                <h4 className="text-sm font-medium text-gray-700">Fields</h4>
                                
                                {Object.entries(operation.fields).map(([fieldName, field]) => (
                                  <div key={fieldName} className="bg-white rounded-lg p-3">
                                    <div className="flex items-center space-x-3 mb-2">
                                      <input
                                        type="checkbox"
                                        id={`${documentName}-${operationType}-${fieldName}`}
                                        checked={!!selectedDocuments[documentName]?.operations[operationType]?.fields[fieldName]}
                                        onChange={() => handleFieldSelect(documentName, operationType, fieldName)}
                                        className="h-4 w-4 text-amber-600 focus:ring-amber-500 border-gray-300 rounded"
                                      />
                                      <label htmlFor={`${documentName}-${operationType}-${fieldName}`} className="font-medium text-gray-800">
                                        {fieldName}
                                      </label>
                                    </div>

                                    {selectedDocuments[documentName]?.operations[operationType]?.fields[fieldName] && (
                                      <div className="pl-6 space-y-2">
                                        {field.fieldValidation && field.fieldValidation.length > 0 && (
                                          <div>
                                            <h5 className="text-xs font-medium text-gray-600 mb-1">Field Validation</h5>
                                            <div className="flex flex-wrap gap-2">
                                              {field.fieldValidation.map((validation, idx) => (
                                                <label key={idx} className="flex items-center text-xs">
                                                  <input
                                                    type="checkbox"
                                                    onChange={(e) => handleValidationChange(
                                                      documentName,
                                                      operationType,
                                                      fieldName,
                                                      'fieldValidation',
                                                      validation.key,
                                                      e.target.checked
                                                    )}
                                                    className="mr-1 h-3 w-3"
                                                  />
                                                  {validation.key}
                                                </label>
                                              ))}
                                            </div>
                                          </div>
                                        )}

                                        {field.comparisonValidation && field.comparisonValidation.length > 0 && (
                                          <div>
                                            <h5 className="text-xs font-medium text-gray-600 mb-1">Comparison Validation</h5>
                                            <div className="flex flex-wrap gap-2">
                                              {field.comparisonValidation.map((validation, idx) => (
                                                <label key={idx} className="flex items-center text-xs">
                                                  <input
                                                    type="checkbox"
                                                    onChange={(e) => handleValidationChange(
                                                      documentName,
                                                      operationType,
                                                      fieldName,
                                                      'comparisonValidation',
                                                      validation,
                                                      e.target.checked
                                                    )}
                                                    className="mr-1 h-3 w-3"
                                                  />
                                                  {validation}
                                                </label>
                                              ))}
                                            </div>
                                          </div>
                                        )}
                                      </div>
                                    )}
                                  </div>
                                ))}
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="flex justify-end space-x-4">
            <button
              type="submit"
              disabled={loading || !formData.channel || !formData.neevAPIKey}
              className="px-6 py-3 bg-amber-600 text-white rounded-lg font-medium hover:bg-amber-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors flex items-center space-x-2"
            >
              <Save className="w-4 h-4" />
              <span>{loading ? 'Saving...' : 'Save Channel'}</span>
            </button>
          </div>
        </form>

        {success && (
          <div className="mt-6 p-4 bg-green-50 border border-green-200 rounded-lg">
            <div className="flex items-center">
              <div className="w-5 h-5 bg-green-500 rounded-full flex items-center justify-center mr-3">
                <span className="text-white text-xs">✓</span>
              </div>
              <span className="text-green-800 font-medium">Channel saved successfully!</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ChannelCreate;