import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Settings, ArrowLeft, Key, FileText, Tag, Code, Edit } from 'lucide-react';
import { channelApi } from '../utils/api';
import type { Channel } from '../types/api';

const ChannelDetail: React.FC = () => {
  const { channelName } = useParams<{ channelName: string }>();
  const [channel, setChannel] = useState<Channel | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeDocument, setActiveDocument] = useState<string>('');

  useEffect(() => {
    const fetchChannel = async () => {
      if (!channelName) return;
      
      try {
        const data = await channelApi.getChannel(channelName);
        setChannel(data);
        // Set first document as active
        if (data.documents) {
          setActiveDocument(Object.keys(data.documents)[0]);
        }
      } catch (error) {
        console.error('Error fetching channel:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchChannel();
  }, [channelName]);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-4 border-amber-500 border-t-transparent"></div>
      </div>
    );
  }

  if (!channel) {
    return (
      <div className="text-center py-12">
        <h2 className="text-xl font-semibold text-gray-900 mb-2">Channel not found</h2>
        <Link to="/channels" className="text-amber-600 hover:text-amber-700">
          Back to Channels
        </Link>
      </div>
    );
  }

  const documents = Object.entries(channel.documents);

  return (
    <div className="max-w-6xl mx-auto">
      <div className="flex items-center justify-between mb-8">
        <div className="flex items-center space-x-4">
          <Link
            to="/channels"
            className="p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </Link>
          
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 bg-gradient-to-br from-amber-500 to-amber-600 rounded-lg flex items-center justify-center">
              <Settings className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">{channel.channel}</h1>
              <p className="text-gray-600">Channel configuration details</p>
            </div>
          </div>
        </div>

        <Link
          to={`/channels/${channelName}/edit`}
          className="px-4 py-2 bg-amber-600 text-white rounded-lg font-medium hover:bg-amber-700 transition-colors flex items-center space-x-2"
        >
          <Edit className="w-4 h-4" />
          <span>Edit Channel</span>
        </Link>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="bg-white rounded-xl shadow-lg p-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Channel Settings</h2>
          
          <div className="space-y-4">
            <div className="flex items-center space-x-3">
              <Key className="w-5 h-5 text-gray-400" />
              <div>
                <div className="text-sm font-medium text-gray-700">API Key</div>
                <div className="text-sm text-gray-600 truncate">{channel.neevAPIKey}</div>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-sm font-medium text-gray-700">Preprocessing</span>
              <div className={`w-6 h-6 rounded-full flex items-center justify-center ${
                channel.preprocessing ? 'bg-green-100 text-green-600' : 'bg-gray-100 text-gray-400'
              }`}>
                {channel.preprocessing ? '✓' : '✗'}
              </div>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-sm font-medium text-gray-700">Postprocessing</span>
              <div className={`w-6 h-6 rounded-full flex items-center justify-center ${
                channel.postprocessing ? 'bg-green-100 text-green-600' : 'bg-gray-100 text-gray-400'
              }`}>
                {channel.postprocessing ? '✓' : '✗'}
              </div>
            </div>
          </div>

          <div className="mt-6">
            <h3 className="text-md font-semibold text-gray-900 mb-3">Documents</h3>
            <div className="space-y-2">
              {documents.map(([docName]) => (
                <button
                  key={docName}
                  onClick={() => setActiveDocument(docName)}
                  className={`w-full px-3 py-2 text-left rounded-lg transition-colors ${
                    activeDocument === docName
                      ? 'bg-amber-100 text-amber-700'
                      : 'hover:bg-gray-50 text-gray-700'
                  }`}
                >
                  <div className="flex items-center space-x-2">
                    <FileText className="w-4 h-4" />
                    <span className="font-medium">{docName}</span>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="lg:col-span-2">
          {activeDocument && (
            <div className="bg-white rounded-xl shadow-lg p-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-6">{activeDocument} Operations</h2>
              
              <div className="space-y-6">
                {Object.entries(channel.documents[activeDocument].operations).map(([operationType, operation]) => (
                  <div key={operationType} className="border border-gray-200 rounded-lg p-4">
                    <h3 className="text-md font-semibold text-gray-800 mb-4 flex items-center">
                      <Code className="w-4 h-4 mr-2" />
                      {operationType}
                    </h3>

                    {operation.fields && Object.keys(operation.fields).length > 0 && (
                      <div className="mb-4">
                        <h4 className="text-sm font-medium text-gray-700 mb-2 flex items-center">
                          <Tag className="w-4 h-4 mr-1" />
                          Fields
                        </h4>
                        <div className="space-y-3">
                          {Object.entries(operation.fields).map(([fieldName, field]) => (
                            <div key={fieldName} className="bg-gray-50 rounded-lg p-3">
                              <div className="font-medium text-gray-800 mb-2">{fieldName}</div>
                              
                              {field.fieldValidation && field.fieldValidation.length > 0 && (
                                <div className="mb-2">
                                  <div className="text-xs font-medium text-gray-600 mb-1">Field Validation</div>
                                  <div className="flex flex-wrap gap-1">
                                    {field.fieldValidation.map((validation, idx) => (
                                      <span
                                        key={idx}
                                        className="px-2 py-1 bg-yellow-100 text-yellow-700 text-xs rounded"
                                      >
                                        {validation}
                                      </span>
                                    ))}
                                  </div>
                                </div>
                              )}
                              
                              {field.comparisonValidation && field.comparisonValidation.length > 0 && (
                                <div>
                                  <div className="text-xs font-medium text-gray-600 mb-1">Comparison Validation</div>
                                  <div className="flex flex-wrap gap-1">
                                    {field.comparisonValidation.map((validation, idx) => (
                                      <span
                                        key={idx}
                                        className="px-2 py-1 bg-green-100 text-green-700 text-xs rounded"
                                      >
                                        {validation}
                                      </span>
                                    ))}
                                  </div>
                                </div>
                              )}
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {operation.apis && operation.apis.length > 0 && (
                      <div>
                        <h4 className="text-sm font-medium text-gray-700 mb-2">APIs</h4>
                        <div className="flex flex-wrap gap-2">
                          {operation.apis.map((api, idx) => (
                            <span
                              key={idx}
                              className="px-2 py-1 bg-purple-100 text-purple-700 text-xs rounded-full"
                            >
                              {api}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ChannelDetail;