import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Settings, Eye, Search, Plus, Key, FileText } from 'lucide-react';
import { channelApi } from '../utils/api';
import type { Channel } from '../types/api';

const ChannelList: React.FC = () => {
  const [channels, setChannels] = useState<Channel[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    const fetchChannels = async () => {
      try {
        const data = await channelApi.getAllChannels();
        setChannels(data);
      } catch (error) {
        console.error('Error fetching channels:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchChannels();
  }, []);

  const filteredChannels = channels.filter(channel =>
    channel.channel.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-4 border-amber-500 border-t-transparent"></div>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto">
      <div className="flex items-center justify-between mb-8">
        <div className="flex items-center space-x-3">
          <div className="w-12 h-12 bg-gradient-to-br from-amber-500 to-amber-600 rounded-lg flex items-center justify-center">
            <Settings className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Channels</h1>
            <p className="text-gray-600">Manage your channel configurations</p>
          </div>
        </div>
        
        <Link
          to="/channels/create"
          className="px-4 py-2 bg-amber-600 text-white rounded-lg font-medium hover:bg-amber-700 transition-colors flex items-center space-x-2"
        >
          <Plus className="w-4 h-4" />
          <span>New Channel</span>
        </Link>
      </div>

      <div className="bg-white rounded-xl shadow-lg p-6">
        <div className="mb-6">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="text"
              placeholder="Search channels..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500 transition-colors"
            />
          </div>
        </div>

        {filteredChannels.length === 0 ? (
          <div className="text-center py-12">
            <Settings className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No channels found</h3>
            <p className="text-gray-600 mb-4">Get started by creating your first channel configuration</p>
            <Link
              to="/channels/create"
              className="inline-flex items-center px-4 py-2 bg-amber-600 text-white rounded-lg font-medium hover:bg-amber-700 transition-colors"
            >
              <Plus className="w-4 h-4 mr-2" />
              Create Channel
            </Link>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredChannels.map((channel) => (
              <div key={channel.channel} className="bg-gradient-to-br from-amber-50 to-amber-100 rounded-lg p-6 hover:shadow-md transition-shadow">
                <div className="flex items-center justify-between mb-4">
                  <div className="w-10 h-10 bg-amber-100 rounded-lg flex items-center justify-center">
                    <Settings className="w-5 h-5 text-amber-600" />
                  </div>
                  <Link
                    to={`/channels/${channel.channel}`}
                    className="text-amber-600 hover:text-amber-700 transition-colors"
                  >
                    <Eye className="w-5 h-5" />
                  </Link>
                </div>
                
                <h3 className="text-lg font-semibold text-gray-900 mb-2">{channel.channel}</h3>
                
                <div className="space-y-2">
                  <div className="flex items-center text-sm text-gray-600">
                    <Key className="w-4 h-4 mr-2" />
                    <span className="truncate">{channel.neevAPIKey}</span>
                  </div>
                  
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-600">Documents</span>
                    <span className="font-medium text-gray-900">
                      {Object.keys(channel.documents).length}
                    </span>
                  </div>
                  
                  <div className="flex items-center space-x-4 text-sm">
                    <div className="flex items-center">
                      <div className={`w-2 h-2 rounded-full mr-1 ${channel.preprocessing ? 'bg-green-500' : 'bg-gray-300'}`} />
                      <span className="text-gray-600">Pre</span>
                    </div>
                    <div className="flex items-center">
                      <div className={`w-2 h-2 rounded-full mr-1 ${channel.postprocessing ? 'bg-green-500' : 'bg-gray-300'}`} />
                      <span className="text-gray-600">Post</span>
                    </div>
                  </div>
                  
                  <div className="flex flex-wrap gap-1">
                    {Object.keys(channel.documents).map(docName => (
                      <span
                        key={docName}
                        className="px-2 py-1 bg-amber-100 text-amber-700 text-xs rounded-full"
                      >
                        {docName}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default ChannelList;