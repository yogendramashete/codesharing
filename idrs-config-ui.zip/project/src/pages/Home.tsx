import React from 'react';
import { Link } from 'react-router-dom';
import { FileText, Settings, Plus, ArrowRight } from 'lucide-react';

const Home: React.FC = () => {
  return (
    <div className="max-w-6xl mx-auto">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">
          Welcome to <span className="text-blue-600">ConfigHub</span>
        </h1>
        <p className="text-xl text-gray-600 max-w-2xl mx-auto">
          Manage your document configurations and channel settings with ease. 
          Create, configure, and monitor your document processing pipeline.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
        <div className="bg-white rounded-xl shadow-lg p-8 hover:shadow-xl transition-shadow">
          <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-blue-600 rounded-lg flex items-center justify-center mb-6">
            <FileText className="w-8 h-8 text-white" />
          </div>
          <h2 className="text-2xl font-bold text-gray-900 mb-3">Document Management</h2>
          <p className="text-gray-600 mb-6">
            Configure document types with operations, fields, and validation rules. 
            Define how your documents should be processed and validated.
          </p>
          <div className="flex space-x-4">
            <Link
              to="/documents"
              className="flex items-center text-blue-600 hover:text-blue-700 font-medium"
            >
              View Documents
              <ArrowRight className="w-4 h-4 ml-1" />
            </Link>
            <Link
              to="/documents/create"
              className="flex items-center text-emerald-600 hover:text-emerald-700 font-medium"
            >
              Create New
              <Plus className="w-4 h-4 ml-1" />
            </Link>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-lg p-8 hover:shadow-xl transition-shadow">
          <div className="w-16 h-16 bg-gradient-to-br from-amber-500 to-amber-600 rounded-lg flex items-center justify-center mb-6">
            <Settings className="w-8 h-8 text-white" />
          </div>
          <h2 className="text-2xl font-bold text-gray-900 mb-3">Channel Configuration</h2>
          <p className="text-gray-600 mb-6">
            Set up channels that use your document configurations. 
            Configure processing settings and API integrations.
          </p>
          <div className="flex space-x-4">
            <Link
              to="/channels"
              className="flex items-center text-amber-600 hover:text-amber-700 font-medium"
            >
              View Channels
              <ArrowRight className="w-4 h-4 ml-1" />
            </Link>
            <Link
              to="/channels/create"
              className="flex items-center text-emerald-600 hover:text-emerald-700 font-medium"
            >
              Create New
              <Plus className="w-4 h-4 ml-1" />
            </Link>
          </div>
        </div>
      </div>

      <div className="bg-gradient-to-r from-blue-50 to-amber-50 rounded-xl p-8 text-center">
        <h2 className="text-2xl font-bold text-gray-900 mb-4">Quick Actions</h2>
        <div className="flex justify-center space-x-4">
          <Link
            to="/documents/create"
            className="px-6 py-3 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 transition-colors flex items-center space-x-2"
          >
            <Plus className="w-5 h-5" />
            <span>Add Document</span>
          </Link>
          <Link
            to="/channels/create"
            className="px-6 py-3 bg-amber-600 text-white rounded-lg font-medium hover:bg-amber-700 transition-colors flex items-center space-x-2"
          >
            <Plus className="w-5 h-5" />
            <span>Add Channel</span>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default Home;