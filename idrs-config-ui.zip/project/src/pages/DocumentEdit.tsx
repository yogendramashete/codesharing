import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { FileText, Plus, Trash2, Save, ArrowLeft } from 'lucide-react';
import { documentApi } from '../utils/api';
import type { SaveDocumentRequest, Field, Operation } from '../types/api';

const DocumentEdit: React.FC = () => {
  const { documentName } = useParams<{ documentName: string }>();
  const navigate = useNavigate();
  const [operations, setOperations] = useState<Record<string, Operation>>({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [success, setSuccess] = useState(false);

  const operationTypes = ['CLASSIFICATION', 'VERIFICATION', 'SEARCH', 'EXTRACTION'];
  const dataTypes = ['STRING', 'INTEGER', 'DATE', 'BOOLEAN'];
  const validationTypes = ['REGEX', 'MIN_LENGTH', 'MAX_LENGTH', 'REQUIRED'];
  const comparisonTypes = ['EQUALS', 'NAME_MATCH', 'ADDRESS_MATCH'];

  useEffect(() => {
    const fetchDocument = async () => {
      if (!documentName) return;
      
      try {
        const data = await documentApi.getDocument(documentName);
        setOperations(data.documents[documentName].operations);
      } catch (error) {
        console.error('Error fetching document:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchDocument();
  }, [documentName]);

  const addOperation = (type: string) => {
    setOperations(prev => ({
      ...prev,
      [type]: {
        userPrompt: '',
        systemPrompt: '',
        fields: {},
        apis: []
      }
    }));
  };

  const removeOperation = (type: string) => {
    setOperations(prev => {
      const newOps = { ...prev };
      delete newOps[type];
      return newOps;
    });
  };

  const updateOperation = (type: string, field: keyof Operation, value: any) => {
    setOperations(prev => ({
      ...prev,
      [type]: {
        ...prev[type],
        [field]: value
      }
    }));
  };

  const addField = (operationType: string, fieldName: string) => {
    if (!fieldName) return;
    
    setOperations(prev => ({
      ...prev,
      [operationType]: {
        ...prev[operationType],
        fields: {
          ...prev[operationType].fields,
          [fieldName]: {
            name: fieldName,
            description: '',
            dataType: 'STRING',
            fieldValidation: [],
            comparisonValidation: []
          }
        }
      }
    }));
  };

  const removeField = (operationType: string, fieldName: string) => {
    setOperations(prev => ({
      ...prev,
      [operationType]: {
        ...prev[operationType],
        fields: Object.fromEntries(
          Object.entries(prev[operationType].fields || {}).filter(([key]) => key !== fieldName)
        )
      }
    }));
  };

  const updateField = (operationType: string, fieldName: string, field: keyof Field, value: any) => {
    setOperations(prev => ({
      ...prev,
      [operationType]: {
        ...prev[operationType],
        fields: {
          ...prev[operationType].fields,
          [fieldName]: {
            ...prev[operationType].fields![fieldName],
            [field]: value
          }
        }
      }
    }));
  };

  const addFieldValidation = (operationType: string, fieldName: string, key: string, value: string) => {
    setOperations(prev => ({
      ...prev,
      [operationType]: {
        ...prev[operationType],
        fields: {
          ...prev[operationType].fields,
          [fieldName]: {
            ...prev[operationType].fields![fieldName],
            fieldValidation: [
              ...(prev[operationType].fields![fieldName].fieldValidation || []),
              { key, value }
            ]
          }
        }
      }
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!documentName) return;
    
    setSaving(true);
    setSuccess(false);

    try {
      const requestData: SaveDocumentRequest = {
        documents: {
          [documentName]: {
            operations
          }
        }
      };

      await documentApi.saveDocument(requestData);
      setSuccess(true);
      
      setTimeout(() => {
        setSuccess(false);
        navigate(`/documents/${documentName}`);
      }, 2000);
    } catch (error) {
      console.error('Error saving document:', error);
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-4 border-blue-500 border-t-transparent"></div>
      </div>
    );
  }

  if (!documentName) {
    return (
      <div className="text-center py-12">
        <h2 className="text-xl font-semibold text-gray-900 mb-2">Document not found</h2>
        <button onClick={() => navigate('/documents')} className="text-blue-600 hover:text-blue-700">
          Back to Documents
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-white rounded-xl shadow-lg p-8">
        <div className="flex items-center space-x-4 mb-8">
          <button
            onClick={() => navigate(`/documents/${documentName}`)}
            className="p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-blue-600 rounded-lg flex items-center justify-center">
              <FileText className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Edit {documentName}</h1>
              <p className="text-gray-600">Modify document configuration and operations</p>
            </div>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-8">
          <div>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold text-gray-900">Operations</h2>
              <div className="flex space-x-2">
                {operationTypes.map(type => (
                  <button
                    key={type}
                    type="button"
                    onClick={() => addOperation(type)}
                    disabled={operations[type]}
                    className="px-3 py-1 text-xs font-medium text-blue-600 bg-blue-50 rounded-md hover:bg-blue-100 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                  >
                    <Plus className="w-3 h-3 inline mr-1" />
                    {type}
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-6">
              {Object.entries(operations).map(([operationType, operation]) => (
                <div key={operationType} className="border border-gray-200 rounded-lg p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-md font-semibold text-gray-800">{operationType}</h3>
                    <button
                      type="button"
                      onClick={() => removeOperation(operationType)}
                      className="text-red-500 hover:text-red-700 transition-colors"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>

                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        User Prompt
                      </label>
                      <textarea
                        value={operation.userPrompt}
                        onChange={(e) => updateOperation(operationType, 'userPrompt', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors"
                        rows={3}
                        placeholder="Enter user prompt..."
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        System Prompt
                      </label>
                      <textarea
                        value={operation.systemPrompt || ''}
                        onChange={(e) => updateOperation(operationType, 'systemPrompt', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors"
                        rows={3}
                        placeholder="Enter system prompt..."
                      />
                    </div>

                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <label className="block text-sm font-medium text-gray-700">Fields</label>
                        <button
                          type="button"
                          onClick={() => {
                            const fieldName = prompt('Enter field name:');
                            if (fieldName) addField(operationType, fieldName);
                          }}
                          className="text-sm text-blue-600 hover:text-blue-700 transition-colors"
                        >
                          <Plus className="w-4 h-4 inline mr-1" />
                          Add Field
                        </button>
                      </div>

                      {Object.entries(operation.fields || {}).map(([fieldName, field]) => (
                        <div key={fieldName} className="bg-gray-50 rounded-lg p-4 mb-3">
                          <div className="flex items-center justify-between mb-3">
                            <span className="font-medium text-gray-800">{fieldName}</span>
                            <button
                              type="button"
                              onClick={() => removeField(operationType, fieldName)}
                              className="text-red-500 hover:text-red-700 transition-colors"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>

                          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                            <div>
                              <label className="block text-xs font-medium text-gray-600 mb-1">
                                Description
                              </label>
                              <input
                                type="text"
                                value={field.description}
                                onChange={(e) => updateField(operationType, fieldName, 'description', e.target.value)}
                                className="w-full px-2 py-1 text-sm border border-gray-300 rounded focus:ring-1 focus:ring-blue-500 focus:border-blue-500 transition-colors"
                              />
                            </div>

                            <div>
                              <label className="block text-xs font-medium text-gray-600 mb-1">
                                Data Type
                              </label>
                              <select
                                value={field.dataType}
                                onChange={(e) => updateField(operationType, fieldName, 'dataType', e.target.value)}
                                className="w-full px-2 py-1 text-sm border border-gray-300 rounded focus:ring-1 focus:ring-blue-500 focus:border-blue-500 transition-colors"
                              >
                                {dataTypes.map(type => (
                                  <option key={type} value={type}>{type}</option>
                                ))}
                              </select>
                            </div>
                          </div>

                          <div className="mt-3">
                            <label className="block text-xs font-medium text-gray-600 mb-1">
                              Comparison Validation
                            </label>
                            <div className="flex flex-wrap gap-2">
                              {comparisonTypes.map(type => (
                                <label key={type} className="flex items-center text-xs">
                                  <input
                                    type="checkbox"
                                    checked={field.comparisonValidation?.includes(type) || false}
                                    onChange={(e) => {
                                      const current = field.comparisonValidation || [];
                                      const updated = e.target.checked
                                        ? [...current, type]
                                        : current.filter(t => t !== type);
                                      updateField(operationType, fieldName, 'comparisonValidation', updated);
                                    }}
                                    className="mr-1"
                                  />
                                  {type}
                                </label>
                              ))}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        APIs
                      </label>
                      <input
                        type="text"
                        value={operation.apis?.join(', ') || ''}
                        onChange={(e) => updateOperation(operationType, 'apis', e.target.value.split(', ').filter(Boolean))}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors"
                        placeholder="Enter APIs separated by commas"
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="flex justify-end space-x-4">
            <button
              type="button"
              onClick={() => navigate(`/documents/${documentName}`)}
              className="px-6 py-3 border border-gray-300 text-gray-700 rounded-lg font-medium hover:bg-gray-50 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={saving}
              className="px-6 py-3 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors flex items-center space-x-2"
            >
              <Save className="w-4 h-4" />
              <span>{saving ? 'Saving...' : 'Save Changes'}</span>
            </button>
          </div>
        </form>

        {success && (
          <div className="mt-6 p-4 bg-green-50 border border-green-200 rounded-lg">
            <div className="flex items-center">
              <div className="w-5 h-5 bg-green-500 rounded-full flex items-center justify-center mr-3">
                <span className="text-white text-xs">✓</span>
              </div>
              <span className="text-green-800 font-medium">Document updated successfully!</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default DocumentEdit;