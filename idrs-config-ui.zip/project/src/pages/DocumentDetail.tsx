import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { FileText, ArrowLeft, Code, Tag, Settings, Edit } from 'lucide-react';
import { documentApi } from '../utils/api';
import type { DocumentResponse } from '../types/api';

const DocumentDetail: React.FC = () => {
  const { documentName } = useParams<{ documentName: string }>();
  const [document, setDocument] = useState<DocumentResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<string>('');

  useEffect(() => {
    const fetchDocument = async () => {
      if (!documentName) return;
      
      try {
        const data = await documentApi.getDocument(documentName);
        setDocument(data);
        // Set first operation as active tab
        if (data.documents[documentName]?.operations) {
          setActiveTab(Object.keys(data.documents[documentName].operations)[0]);
        }
      } catch (error) {
        console.error('Error fetching document:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchDocument();
  }, [documentName]);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-4 border-blue-500 border-t-transparent"></div>
      </div>
    );
  }

  if (!document || !documentName) {
    return (
      <div className="text-center py-12">
        <h2 className="text-xl font-semibold text-gray-900 mb-2">Document not found</h2>
        <Link to="/documents" className="text-blue-600 hover:text-blue-700">
          Back to Documents
        </Link>
      </div>
    );
  }

  const documentData = document.documents[documentName];
  const operations = Object.entries(documentData.operations);

  return (
    <div className="max-w-6xl mx-auto">
      <div className="flex items-center justify-between mb-8">
        <div className="flex items-center space-x-4">
          <Link
            to="/documents"
            className="p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </Link>
          
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-blue-600 rounded-lg flex items-center justify-center">
              <FileText className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">{documentName}</h1>
              <p className="text-gray-600">Document configuration details</p>
            </div>
          </div>
        </div>

        <Link
          to={`/documents/${documentName}/edit`}
          className="px-4 py-2 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 transition-colors flex items-center space-x-2"
        >
          <Edit className="w-4 h-4" />
          <span>Edit Document</span>
        </Link>
      </div>

      <div className="bg-white rounded-xl shadow-lg overflow-hidden">
        <div className="border-b border-gray-200">
          <nav className="flex space-x-8 px-6">
            {operations.map(([operationType]) => (
              <button
                key={operationType}
                onClick={() => setActiveTab(operationType)}
                className={`py-4 px-2 border-b-2 font-medium text-sm transition-colors ${
                  activeTab === operationType
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                {operationType}
              </button>
            ))}
          </nav>
        </div>

        {activeTab && (
          <div className="p-6">
            {(() => {
              const operation = documentData.operations[activeTab];
              return (
                <div className="space-y-6">
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <div>
                      <h3 className="text-lg font-semibold text-gray-900 mb-3 flex items-center">
                        <Code className="w-5 h-5 mr-2" />
                        User Prompt
                      </h3>
                      <div className="bg-gray-50 rounded-lg p-4">
                        <pre className="text-sm text-gray-700 whitespace-pre-wrap">
                          {operation.userPrompt}
                        </pre>
                      </div>
                    </div>

                    {operation.systemPrompt && (
                      <div>
                        <h3 className="text-lg font-semibold text-gray-900 mb-3 flex items-center">
                          <Settings className="w-5 h-5 mr-2" />
                          System Prompt
                        </h3>
                        <div className="bg-gray-50 rounded-lg p-4">
                          <pre className="text-sm text-gray-700 whitespace-pre-wrap">
                            {operation.systemPrompt}
                          </pre>
                        </div>
                      </div>
                    )}
                  </div>

                  {operation.fields && Object.keys(operation.fields).length > 0 && (
                    <div>
                      <h3 className="text-lg font-semibold text-gray-900 mb-3 flex items-center">
                        <Tag className="w-5 h-5 mr-2" />
                        Fields
                      </h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {Object.entries(operation.fields).map(([fieldName, field]) => (
                          <div key={fieldName} className="bg-gray-50 rounded-lg p-4">
                            <div className="flex items-center justify-between mb-2">
                              <h4 className="font-medium text-gray-900">{fieldName}</h4>
                              <span className="px-2 py-1 bg-blue-100 text-blue-700 text-xs rounded-full">
                                {field.dataType}
                              </span>
                            </div>
                            
                            <p className="text-sm text-gray-600 mb-3">{field.description}</p>
                            
                            {field.fieldValidation && field.fieldValidation.length > 0 && (
                              <div className="mb-3">
                                <h5 className="text-xs font-medium text-gray-700 mb-1">Field Validation</h5>
                                <div className="flex flex-wrap gap-1">
                                  {field.fieldValidation.map((validation, idx) => (
                                    <span
                                      key={idx}
                                      className="px-2 py-1 bg-yellow-100 text-yellow-700 text-xs rounded"
                                    >
                                      {validation.key}: {validation.value}
                                    </span>
                                  ))}
                                </div>
                              </div>
                            )}
                            
                            {field.comparisonValidation && field.comparisonValidation.length > 0 && (
                              <div>
                                <h5 className="text-xs font-medium text-gray-700 mb-1">Comparison Validation</h5>
                                <div className="flex flex-wrap gap-1">
                                  {field.comparisonValidation.map((validation, idx) => (
                                    <span
                                      key={idx}
                                      className="px-2 py-1 bg-green-100 text-green-700 text-xs rounded"
                                    >
                                      {validation}
                                    </span>
                                  ))}
                                </div>
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {operation.apis && operation.apis.length > 0 && (
                    <div>
                      <h3 className="text-lg font-semibold text-gray-900 mb-3">APIs</h3>
                      <div className="flex flex-wrap gap-2">
                        {operation.apis.map((api, idx) => (
                          <span
                            key={idx}
                            className="px-3 py-1 bg-purple-100 text-purple-700 text-sm rounded-full"
                          >
                            {api}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              );
            })()}
          </div>
        )}
      </div>
    </div>
  );
};

export default DocumentDetail;