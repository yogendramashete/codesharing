export interface FieldValidation {
  key: string;
  value: string;
}

export interface Field {
  name: string;
  description: string;
  dataType: string;
  fieldValidation?: FieldValidation[];
  comparisonValidation?: string[];
}

export interface Operation {
  userPrompt: string;
  systemPrompt?: string;
  fields?: Record<string, Field>;
  apis?: string[];
}

export interface Document {
  operations: Record<string, Operation>;
}

export interface DocumentResponse {
  documents: Record<string, Document>;
}

export interface SaveDocumentRequest {
  documents: Record<string, Document>;
}

export interface ChannelField {
  fieldValidation?: string[];
  comparisonValidation?: string[];
}

export interface ChannelOperation {
  fields?: Record<string, ChannelField>;
  apis?: string[];
}

export interface ChannelDocument {
  operations: Record<string, ChannelOperation>;
}

export interface Channel {
  channel: string;
  neevAPIKey: string;
  preprocessing: boolean;
  postprocessing: boolean;
  documents: Record<string, ChannelDocument>;
}

export interface SaveChannelRequest {
  channel: string;
  neevAPIKey: string;
  preprocessing: boolean;
  postprocessing: boolean;
  documents: Record<string, ChannelDocument>;
}