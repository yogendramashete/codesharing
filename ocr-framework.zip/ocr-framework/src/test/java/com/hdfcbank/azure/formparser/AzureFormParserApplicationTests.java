package com.hdfcbank.azure.formparser;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.hdfcbank.azure.formparser.controller.ParserController;

@SpringBootTest
class AzureFormParserApplicationTests {
	
	@Autowired
	private ParserController parserController;

	@Test
	void contextLoads() {
		assertNotNull(parserController);
	}

}
