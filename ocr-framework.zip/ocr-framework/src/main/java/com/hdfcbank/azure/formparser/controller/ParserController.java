package com.hdfcbank.azure.formparser.controller;

import java.util.List;

import javax.validation.Valid;

import org.apache.commons.lang3.RandomStringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.hdfcbank.azure.formparser.constant.AppConstant;
import com.hdfcbank.azure.formparser.enums.Stage;
import com.hdfcbank.azure.formparser.enums.StatusCode;
import com.hdfcbank.azure.formparser.exception.OCRFrameworkException;
import com.hdfcbank.azure.formparser.model.api.ApiResponse;
import com.hdfcbank.azure.formparser.model.api.CustomDocRequest;
import com.hdfcbank.azure.formparser.model.api.DocumentKeywordsRequest;
import com.hdfcbank.azure.formparser.model.api.PrebuiltDocRequest;
import com.hdfcbank.azure.formparser.model.document.DocumentAnalysisResponse;
import com.hdfcbank.azure.formparser.model.document.DocumentDetail;
import com.hdfcbank.azure.formparser.model.document.DocumentDetailsUpdateRequest;
import com.hdfcbank.azure.formparser.model.document.DocumentResponse;
import com.hdfcbank.azure.formparser.service.AuditLogService;
import com.hdfcbank.azure.formparser.service.CustomModeAnalyzerService;
import com.hdfcbank.azure.formparser.service.DocumentService;
import com.hdfcbank.azure.formparser.service.PrebuiltModelAnalyzerService;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.info.Contact;
import io.swagger.v3.oas.annotations.info.Info;
import lombok.extern.log4j.Log4j2;

@Log4j2
@RestController
@OpenAPIDefinition(info = @Info(description = "OCR Framework APIs", version = "1.0", contact = @Contact(name = "HDFC Bank", email = "hdfc.suport@hdfcbank.com")))
public class ParserController {
	private static final int CORRELATION_ID_LENGTH = 10;

	@Autowired
	private DocumentService documentService;

	@Autowired
	private CustomModeAnalyzerService customModeAnalyzerService;

	@Autowired
	private PrebuiltModelAnalyzerService prebuiltModelAnalyzerService;

	@Autowired
	private AuditLogService auditLogService;

	@Operation(summary = "Analyze document with prebuilt model", description = "Upload files for document analysis with prebuilt model")
	@ResponseStatus(HttpStatus.OK)
	@PostMapping(value = "/prebuilt", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ApiResponse<DocumentResponse>> analyzeDocumentWithPrebuiltModel(
			@Valid @RequestBody PrebuiltDocRequest prebuiltDocRequest) {
		String correlationId = RandomStringUtils.randomAlphanumeric(CORRELATION_ID_LENGTH);
		log.info("ParserController :: analyzeDocumentWithPrebuiltModel : correlationId : " + correlationId);

		ApiResponse<DocumentResponse> resp = null;
		try {
			prebuiltModelAnalyzerService.parseDocument(correlationId, prebuiltDocRequest);
			resp = ApiResponse.<DocumentResponse>builder().status(StatusCode.API_SUCCESS.getKey())
					.message(StatusCode.API_SUCCESS.getValue())
					.data(DocumentResponse.builder().correlationId(correlationId).build()).build();
			auditLogService.auditLog(correlationId, prebuiltDocRequest, resp, Stage.PREBUILT_MODEL_ANALYSIS.name(),
					AppConstant.SUCCESS);
		} catch (OCRFrameworkException e) {
			log.error(e);
			resp = ApiResponse.<DocumentResponse>builder().status(StatusCode.API_ERROR.getKey())
					.message(StatusCode.API_ERROR.getValue())
					.data(DocumentResponse.builder().errorMsg(e.getMessage()).build()).build();
			auditLogService.auditLog(correlationId, prebuiltDocRequest, resp,
					Stage.PREBUILT_MODEL_ANALYSIS_ERROR.name(), e.getMessage());
		}
		return ResponseEntity.status(HttpStatus.OK).header(AppConstant.CORRELATION_ID, correlationId).body(resp);
	}

	@Operation(summary = "Analyze file with custom model", description = "Upload files for document analysis with custom model")
	@ResponseStatus(HttpStatus.OK)
	@PostMapping(value = "/custom", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ApiResponse<DocumentResponse>> analyzeDocumentWithCustomModel(
			@Valid @RequestBody CustomDocRequest customDocRequest) {
		String correlationId = RandomStringUtils.randomAlphanumeric(CORRELATION_ID_LENGTH);
		log.info("ParserController :: analyzeDocumentWithCustomModel : correlationId : " + correlationId);

		ApiResponse<DocumentResponse> resp = null;
		try {
			customModeAnalyzerService.parseDocument(correlationId, customDocRequest);
			resp = ApiResponse.<DocumentResponse>builder().status(StatusCode.API_SUCCESS.getKey())
					.message(StatusCode.API_SUCCESS.getValue())
					.data(DocumentResponse.builder().correlationId(correlationId).build()).build();
			auditLogService.auditLog(correlationId, customDocRequest, resp, Stage.CUSTOM_MODEL_ANALYSIS.name(),
					AppConstant.SUCCESS);
		} catch (OCRFrameworkException e) {
			log.error(e);
			resp = ApiResponse.<DocumentResponse>builder().status(StatusCode.API_ERROR.getKey())
					.message(StatusCode.API_ERROR.getValue())
					.data(DocumentResponse.builder().errorMsg(e.getMessage()).build()).build();
			auditLogService.auditLog(correlationId, customDocRequest, resp, Stage.CUSTOM_MODEL_ANALYSIS_ERROR.name(),
					e.getMessage());
		}
		return ResponseEntity.status(HttpStatus.OK).header(AppConstant.CORRELATION_ID, correlationId).body(resp);
	}

	@Operation(summary = "Get Document Analysis", description = "Get Document details for previously uploaded documents in REST call")
	@ResponseStatus(HttpStatus.OK)
	@GetMapping(value = "/document", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ApiResponse<DocumentAnalysisResponse>> getDocumentAnalysis(
			@RequestHeader(name = AppConstant.CORRELATION_ID, required = true) String correlationId) {
		log.info("ParserController :: getDocumentAnalysis : correlationId : " + correlationId);
		ApiResponse<DocumentAnalysisResponse> resp = null;
		try {
			List<DocumentDetail> documentDetailList = documentService.getDocumentAnalysis(correlationId);
			resp = ApiResponse.<DocumentAnalysisResponse>builder().status(StatusCode.API_SUCCESS.getKey())
					.message(StatusCode.API_SUCCESS.getValue())
					.data(DocumentAnalysisResponse.builder().documentDetailList(documentDetailList).build()).build();
			auditLogService.auditLog(correlationId, null, resp, Stage.ANALYSIS_RESULT.name(), AppConstant.SUCCESS);
		} catch (OCRFrameworkException e) {
			log.error(e);
			resp = ApiResponse.<DocumentAnalysisResponse>builder().status(StatusCode.API_ERROR.getKey())
					.message(StatusCode.API_ERROR.getValue())
					.data(DocumentAnalysisResponse.builder().errorMsg(e.getMessage()).build()).build();
			auditLogService.auditLog(correlationId, null, resp, Stage.ANALYSIS_RESULT_ERROR.name(), e.getMessage());
		}
		return ResponseEntity.status(HttpStatus.OK).header(AppConstant.CORRELATION_ID, correlationId).body(resp);
	}

	@Operation(summary = "Update Document Keywords", description = "Get Document details for previously uploaded documents in REST call")
	@ResponseStatus(HttpStatus.OK)
	@PostMapping(value = "/updateKeywords", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ApiResponse<Void>> updateDocumenKeywords(
			@Valid @RequestBody DocumentKeywordsRequest documentKeywordsRequest) {
		String correlationId = RandomStringUtils.randomAlphanumeric(CORRELATION_ID_LENGTH);
		log.info("ParserController :: updateDocumenKeywords : correlationId : " + correlationId);
		ApiResponse<Void> resp = null;
		try {
			documentService.updateDocumentKeywords(correlationId, documentKeywordsRequest);
			resp = ApiResponse.<Void>builder().status(StatusCode.API_SUCCESS.getKey())
					.message(StatusCode.API_SUCCESS.getValue()).build();
			auditLogService.auditLog(correlationId, documentKeywordsRequest, resp, Stage.UPDATE_KEYWORD.name(),
					AppConstant.SUCCESS);
		} catch (OCRFrameworkException e) {
			log.error(e);
			resp = ApiResponse.<Void>builder().status(StatusCode.API_ERROR.getKey())
					.message(StatusCode.API_ERROR.getValue()).build();
			auditLogService.auditLog(correlationId, documentKeywordsRequest, resp, Stage.UPDATE_KEYWORD_ERROR.name(),
					e.getMessage());
		}
		return ResponseEntity.status(HttpStatus.OK).header(AppConstant.CORRELATION_ID, correlationId).body(resp);
	}

	@Operation(summary = "Update document details", description = "Update latest document details in REST call")
	@ResponseStatus(HttpStatus.OK)
	@PostMapping(value = "/updateDocumentDetails", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ApiResponse<DocumentAnalysisResponse>> updateDocumentDetails(
			@RequestHeader(name = AppConstant.CORRELATION_ID, required = true) String correlationId,
			@RequestBody @Valid DocumentDetailsUpdateRequest documentDetailsUpdateRequest) {
		log.info("ParserController :: getDocumentAnalysis : correlationId : " + correlationId);
		ApiResponse<DocumentAnalysisResponse> resp = null;
		try {
			List<DocumentDetail> documentDetailList = documentService.getDocumentAnalysis(correlationId);
			resp = ApiResponse.<DocumentAnalysisResponse>builder().status(StatusCode.API_SUCCESS.getKey())
					.message(StatusCode.API_SUCCESS.getValue())
					.data(DocumentAnalysisResponse.builder().documentDetailList(documentDetailList).build()).build();
			auditLogService.auditLog(correlationId, null, resp, Stage.DOCUMENT_USER_UPDATE.name(), AppConstant.SUCCESS);
		} catch (OCRFrameworkException e) {
			log.error(e);
			resp = ApiResponse.<DocumentAnalysisResponse>builder().status(StatusCode.API_ERROR.getKey())
					.message(StatusCode.API_ERROR.getValue())
					.data(DocumentAnalysisResponse.builder().errorMsg(e.getMessage()).build()).build();
			auditLogService.auditLog(correlationId, null, resp, Stage.DOCUMENT_USER_UPDATE_ERROR.name(),
					e.getMessage());
		}
		return ResponseEntity.status(HttpStatus.OK).header(AppConstant.CORRELATION_ID, correlationId).body(resp);
	}
}
