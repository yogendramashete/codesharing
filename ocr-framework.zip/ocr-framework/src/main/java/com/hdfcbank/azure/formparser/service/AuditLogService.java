package com.hdfcbank.azure.formparser.service;

import com.hdfcbank.azure.formparser.model.api.ApiResponse;

public interface AuditLogService {

	public void auditLog(String correlationId, Object request, ApiResponse<?> response, String stage,
			String exceptionMessage);
}
