package com.hdfcbank.azure.formparser.constant;

public class AppConstant {
	
	private AppConstant() {}

	public static final String CORRELATION_ID = "correlationId";
	public static final String SUCCESS = "SUCCESS";
	public static final String FAILURE = "FAILURE";
}
