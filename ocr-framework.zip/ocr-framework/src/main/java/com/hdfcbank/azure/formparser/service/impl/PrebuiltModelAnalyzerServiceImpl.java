package com.hdfcbank.azure.formparser.service.impl;

import java.io.ByteArrayInputStream;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

import org.apache.commons.lang3.RandomStringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.azure.ai.formrecognizer.DocumentAnalysisAsyncClient;
import com.azure.ai.formrecognizer.DocumentAnalysisClientBuilder;
import com.azure.ai.formrecognizer.implementation.util.Utility;
import com.azure.core.credential.AzureKeyCredential;
import com.azure.core.util.polling.AsyncPollResponse;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hdfcbank.azure.formparser.exception.OCRFrameworkException;
import com.hdfcbank.azure.formparser.model.api.PrebuiltDocRequest;
import com.hdfcbank.azure.formparser.model.document.DocumentDetail;
import com.hdfcbank.azure.formparser.model.document.DocumentField;
import com.hdfcbank.azure.formparser.model.entity.OCRDocumentInformation;
import com.hdfcbank.azure.formparser.model.entity.OCRDocumentKeywords;
import com.hdfcbank.azure.formparser.repository.OCRDocumentInformationRepository;
import com.hdfcbank.azure.formparser.repository.OCRDocumentKeywordsRepository;
import com.hdfcbank.azure.formparser.service.PrebuiltModelAnalyzerService;

import lombok.extern.log4j.Log4j2;
import me.xdrop.fuzzywuzzy.FuzzySearch;
import reactor.core.publisher.Flux;

@Log4j2
@Service
public class PrebuiltModelAnalyzerServiceImpl implements PrebuiltModelAnalyzerService {
	private static final int DOCUMENT_ID_LENGTH = 15;

	@Value("${microsoft.parser.endpoint}")
	private String parserEndpoint;
	@Value("${microsoft.parser.key}")
	private String parserKey;
	@Value("${microsoft.parser.model.prebuiltModelId}")
	private String prebuiltModelId;

	@Autowired
	private ObjectMapper objectMapper;

	@Autowired
	private OCRDocumentInformationRepository ocrDocumentInformationRepository;

	@Autowired
	private OCRDocumentKeywordsRepository ocrDocumentKeywordsRepository;

	@Override
	public void parseDocument(String correlationId, PrebuiltDocRequest prebuiltDocRequest)
			throws OCRFrameworkException {
		try {
			DocumentAnalysisAsyncClient documentAnalysisAsyncClient = new DocumentAnalysisClientBuilder()
					.credential(new AzureKeyCredential(parserKey)).endpoint(parserEndpoint).buildAsyncClient();

			final CompletableFuture<DocumentDetail> documentDetail = CompletableFuture.supplyAsync(
					() -> getDocumentInfoPrebuilt(prebuiltModelId, prebuiltDocRequest, documentAnalysisAsyncClient));

			CompletableFuture.allOf(documentDetail).join();

			OCRDocumentInformation ocrDocumentInformation = OCRDocumentInformation.builder()
					.correlationId(correlationId).documentInfo(objectMapper.writeValueAsString(documentDetail)).build();
			ocrDocumentInformationRepository.save(ocrDocumentInformation);

		} catch (JsonProcessingException e) {
			log.error(e.getMessage());
			throw new OCRFrameworkException(e.getMessage());
		}

	}

	private DocumentDetail getDocumentInfoPrebuilt(String modelId, PrebuiltDocRequest prebuiltDocRequest,
			DocumentAnalysisAsyncClient documentAnalysisAsyncClient) {
		byte[] fileBytes = prebuiltDocRequest.getFileContents().getBytes();
		Flux<ByteBuffer> buffer = Utility.toFluxByteBuffer(new ByteArrayInputStream(fileBytes));

		var documentFieldList = new ArrayList<DocumentField>();
		documentAnalysisAsyncClient.beginAnalyzeDocument(modelId, buffer, fileBytes.length).last()
				.flatMap(AsyncPollResponse::getFinalResult).subscribe(
						analyzeResult -> analyzeResult.getDocuments().stream()
								.forEach(analyzedDocument -> analyzedDocument.getFields()
										.forEach((key, documentField) -> documentFieldList.add(DocumentField.builder()
												.key(key.toUpperCase()).value(documentField.getContent())
												.confidence(String.valueOf(documentField.getConfidence())).build()))));

		var filteredDocumentFieldList = filterKeywords(documentFieldList,
				getKeywordListForDocType(prebuiltDocRequest.getDocType()));

		return DocumentDetail.builder().docId(RandomStringUtils.randomAlphanumeric(DOCUMENT_ID_LENGTH))
				.fileName(prebuiltDocRequest.getFileName()).documentFieldList(filteredDocumentFieldList).build();
	}

	private List<DocumentField> filterKeywords(List<DocumentField> documentList, List<String> keywords) {
		var filteredList = new ArrayList<DocumentField>();
		var docListKeywords = documentList.stream().map(DocumentField::getKey).collect(Collectors.toList());

		for (String keyword : keywords) {
			String extractedKeyword = FuzzySearch.extractOne(keyword, docListKeywords).getString();

			Optional<DocumentField> extractedDocField = documentList.stream()
					.filter(t -> t.getKey().equals(extractedKeyword)).findFirst();
			filteredList.add(extractedDocField.isPresent() ? extractedDocField.get() : null);

		}

		return filteredList;
	}

	private List<String> getKeywordListForDocType(String docType) throws OCRFrameworkException {
		OCRDocumentKeywords documentKeywords = ocrDocumentKeywordsRepository.findByDocumentType(docType);
		try {
			return objectMapper.readValue(documentKeywords.getKeywords(), new TypeReference<List<String>>() {
			});
		} catch (JsonProcessingException e) {
			log.error(e.getMessage());
			throw new OCRFrameworkException(e.getMessage());
		}
	}
}
