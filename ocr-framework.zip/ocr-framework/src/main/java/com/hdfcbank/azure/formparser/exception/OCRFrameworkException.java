package com.hdfcbank.azure.formparser.exception;

public class OCRFrameworkException extends RuntimeException {
	
	/**
	 * 
	 */
	
	private static final long serialVersionUID = 1L;

	public OCRFrameworkException() {
		super();
	}

	public OCRFrameworkException(String message, Throwable cause) {
		super(message, cause);
	}

	public OCRFrameworkException(String message) {
		super(message);
	}

	public OCRFrameworkException(Throwable cause) {
		super(cause);
	}
}