package com.hdfcbank.azure.formparser.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.hdfcbank.azure.formparser.model.entity.OCRDocumentKeywords;

@Repository
public interface OCRDocumentKeywordsRepository extends JpaRepository<OCRDocumentKeywords, Long> {
	
	@Query("select o from OCRDocumentKeywords o where o.documentType = :documentType")
	OCRDocumentKeywords findByDocumentType(@Param("documentType") String documentType);

}
