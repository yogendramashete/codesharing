package com.hdfcbank.azure.formparser.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import lombok.Getter;
import lombok.Setter;

@ConfigurationProperties(prefix = "parser.microsoft")
@Configuration
@Getter
@Setter
public class ParserProperties {
	
	private String endpoint;
	private String apiKey;
}
