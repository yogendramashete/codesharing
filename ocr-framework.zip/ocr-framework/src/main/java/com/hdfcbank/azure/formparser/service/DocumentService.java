package com.hdfcbank.azure.formparser.service;

import java.util.List;

import com.hdfcbank.azure.formparser.exception.OCRFrameworkException;
import com.hdfcbank.azure.formparser.model.api.DocumentKeywordsRequest;
import com.hdfcbank.azure.formparser.model.document.DocumentDetail;

public interface DocumentService {

	public List<DocumentDetail> getDocumentAnalysis(String correlationId) throws OCRFrameworkException;

	public void updateDocumentDetails(String correlationId, List<DocumentDetail> documentDetailList)
			throws OCRFrameworkException;
	
	public void updateDocumentKeywords(String correlationId, DocumentKeywordsRequest documentKeywordsRequest) throws OCRFrameworkException;
}
