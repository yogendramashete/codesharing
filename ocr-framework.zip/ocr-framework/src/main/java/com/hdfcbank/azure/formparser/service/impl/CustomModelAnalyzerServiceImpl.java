package com.hdfcbank.azure.formparser.service.impl;

import java.io.ByteArrayInputStream;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.concurrent.CompletableFuture;

import org.apache.commons.lang3.RandomStringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.azure.ai.formrecognizer.DocumentAnalysisAsyncClient;
import com.azure.ai.formrecognizer.DocumentAnalysisClientBuilder;
import com.azure.ai.formrecognizer.implementation.util.Utility;
import com.azure.core.credential.AzureKeyCredential;
import com.azure.core.util.polling.AsyncPollResponse;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hdfcbank.azure.formparser.exception.OCRFrameworkException;
import com.hdfcbank.azure.formparser.model.api.CustomDocRequest;
import com.hdfcbank.azure.formparser.model.document.DocumentDetail;
import com.hdfcbank.azure.formparser.model.document.DocumentField;
import com.hdfcbank.azure.formparser.model.entity.OCRDocumentInformation;
import com.hdfcbank.azure.formparser.repository.OCRDocumentInformationRepository;
import com.hdfcbank.azure.formparser.service.CustomModeAnalyzerService;

import lombok.extern.log4j.Log4j2;
import reactor.core.publisher.Flux;

@Log4j2
@Service
public class CustomModelAnalyzerServiceImpl implements CustomModeAnalyzerService {

	private static final int DOCUMENT_ID_LENGTH = 15;

	@Value("${microsoft.parser.endpoint}")
	private String parserEndpoint;
	@Value("${microsoft.parser.key}")
	private String parserKey;

	@Autowired
	private ObjectMapper objectMapper;

	@Autowired
	private OCRDocumentInformationRepository ocrDocumentInformationRepository;

	@Override
	public void parseDocument(String correlationId, CustomDocRequest customDocRequest) throws OCRFrameworkException {
		try {
			DocumentAnalysisAsyncClient documentAnalysisAsyncClient = new DocumentAnalysisClientBuilder()
					.credential(new AzureKeyCredential(parserKey)).endpoint(parserEndpoint).buildAsyncClient();

			final CompletableFuture<DocumentDetail> documentDetail = CompletableFuture.supplyAsync(() -> {
				String fileName = customDocRequest.getFileName();
				return getDocumentInfo(customDocRequest.getModelId(),
						new ByteArrayInputStream(customDocRequest.getFileContents().getBytes()).readAllBytes(), fileName,
						documentAnalysisAsyncClient);

			});

			CompletableFuture.allOf(documentDetail).join();

			OCRDocumentInformation ocrDocumentInformation = OCRDocumentInformation.builder()
					.correlationId(correlationId).documentInfo(objectMapper.writeValueAsString(documentDetail)).build();
			ocrDocumentInformationRepository.save(ocrDocumentInformation);

		} catch (JsonProcessingException e) {
			log.error(e.getMessage());
			throw new OCRFrameworkException(e.getMessage());
		}

	}

	private DocumentDetail getDocumentInfo(String modelId, byte[] fileByteArray, String fileName,
			DocumentAnalysisAsyncClient documentAnalysisAsyncClient) {
		Flux<ByteBuffer> buffer = Utility.toFluxByteBuffer(new ByteArrayInputStream(fileByteArray));

		var documentFieldList = new ArrayList<DocumentField>();
		documentAnalysisAsyncClient.beginAnalyzeDocument(modelId, buffer, fileByteArray.length).last()
				.flatMap(AsyncPollResponse::getFinalResult).subscribe(
						analyzeResult -> analyzeResult.getDocuments().stream()
								.forEach(analyzedDocument -> analyzedDocument.getFields()
										.forEach((key, documentField) -> documentFieldList.add(DocumentField.builder()
												.key(key.toUpperCase()).value(documentField.getContent())
												.confidence(String.valueOf(documentField.getConfidence())).build())

										)));

		return DocumentDetail.builder().docId(RandomStringUtils.randomAlphanumeric(DOCUMENT_ID_LENGTH))
				.fileName(fileName).documentFieldList(documentFieldList).build();
	}

}
