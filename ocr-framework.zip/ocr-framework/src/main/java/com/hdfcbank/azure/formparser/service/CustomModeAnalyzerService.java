package com.hdfcbank.azure.formparser.service;

import com.hdfcbank.azure.formparser.exception.OCRFrameworkException;
import com.hdfcbank.azure.formparser.model.api.CustomDocRequest;

public interface CustomModeAnalyzerService {
	public void parseDocument(String correlationId, CustomDocRequest customDocRequest)
			throws OCRFrameworkException;
}
