package com.hdfcbank.azure.formparser.model.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicUpdate;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Table(name = "OCR_AUDIT")
@Entity
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@DynamicUpdate
public class OCRAudit {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID")
	private Long id;
	@Column(name = "CORRELATION_ID")
	private String correlationId;
	@Column(name = "API_CALL")
	private String apiCall;
	@Column(name = "REQUEST"/*, columnDefinition = "text"*/)
	@Lob
	private String request;
	@Column(name = "RESPONSE"/*, columnDefinition = "text"*/)
	@Lob
	private String response;
	@Column(name = "REMARK")
	private String remark;
	@Column(name = "CREATED_AT")
	private String createdAt;
}
