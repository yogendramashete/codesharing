package com.hdfcbank.azure.formparser.config;

import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;

import com.hdfcbank.azure.formparser.filter.Slf4jMDCFilter;

//@Configuration
public class FilterRegistrationConfig {

	public static final String DEFAULT_RESPONSE_TOKEN_HEADER = "Response_Token";
	public static final String DEFAULT_MDC_UUID_TOKEN_KEY = "Slf4jMDCFilter.UUID";
	
	private String responseHeader = DEFAULT_RESPONSE_TOKEN_HEADER;
	private String mdcTokenKey = DEFAULT_MDC_UUID_TOKEN_KEY;
	private String requestHeader = null;
	
	@Bean
	public FilterRegistrationBean<Slf4jMDCFilter> servletRegistrationBean() {
		FilterRegistrationBean<Slf4jMDCFilter> registrationBean = new FilterRegistrationBean<>();

		registrationBean.setFilter(new Slf4jMDCFilter(responseHeader, mdcTokenKey, requestHeader));
		registrationBean.addUrlPatterns("/*");
		registrationBean.setOrder(2);

		return registrationBean;
	}
}