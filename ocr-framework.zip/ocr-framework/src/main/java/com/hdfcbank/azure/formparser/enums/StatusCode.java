package com.hdfcbank.azure.formparser.enums;

public enum StatusCode {
	
	API_SUCCESS(200,"Success - Sucessfully submitted"),
	API_ERROR(00, "Failed - Internal Server Error");

	private final int key;
	private final String value;

	StatusCode(int key, String value) {
		this.key = key;
		this.value = value;
	}

	public int getKey() {
		return key;
	}

	public String getValue() {
		return value;
	}
}
