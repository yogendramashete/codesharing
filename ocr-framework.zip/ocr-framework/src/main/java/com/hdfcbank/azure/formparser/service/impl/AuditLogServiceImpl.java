package com.hdfcbank.azure.formparser.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hdfcbank.azure.formparser.exception.OCRFrameworkException;
import com.hdfcbank.azure.formparser.model.api.ApiResponse;
import com.hdfcbank.azure.formparser.model.entity.OCRAudit;
import com.hdfcbank.azure.formparser.repository.OCRAuditRepository;
import com.hdfcbank.azure.formparser.service.AuditLogService;

import lombok.extern.log4j.Log4j2;

@Service
@Log4j2
public class AuditLogServiceImpl implements AuditLogService {

	@Autowired
	private ObjectMapper objectMapper;

	@Autowired
	private OCRAuditRepository ocrAuditRepository;

	@Override
	public void auditLog(String correlationId, Object request, ApiResponse<?> response, String apiCall,
			String exceptionMessage) {
		try {
			OCRAudit ocrAudit = OCRAudit.builder().correlationId(correlationId).apiCall(apiCall)
					.request(null != request ? objectMapper.writeValueAsString(request) : null)
					.response(null != response ? objectMapper.writeValueAsString(response) : null)
					.remark((null != exceptionMessage && !exceptionMessage.isBlank()) ? exceptionMessage : null)
					.build();
			ocrAuditRepository.save(ocrAudit);
		} catch (Exception e) {
			log.error("Error saving audit log ", e);
			throw new OCRFrameworkException("Error saving audit log " + e.getMessage());
		}

	}
	
}
