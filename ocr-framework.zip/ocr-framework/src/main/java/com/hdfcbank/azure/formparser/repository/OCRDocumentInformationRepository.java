package com.hdfcbank.azure.formparser.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.hdfcbank.azure.formparser.model.entity.OCRDocumentInformation;

public interface OCRDocumentInformationRepository extends JpaRepository<OCRDocumentInformation, Long> {

	@Query("select o from OCRDocumentInformation o where o.correlationId = :correlationId and o.userModified = :userModified")
	OCRDocumentInformation findByCorrelationIdAndUserModified(@Param("correlationId") String correlationId,
			@Param("userModified") boolean userModified);

	@Modifying(clearAutomatically = true)
	@Query("update OCRDocumentInformation o set o.documentInfo =:documentInfo , o.userModified = true where o.correlationId =:correlationId")
	void updateDocumentInfoByUser(@Param("documentInfo") String documentInfo,
			@Param("correlationId") String correlationId);

}
