package com.hdfcbank.azure.formparser.service.impl;

import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hdfcbank.azure.formparser.exception.OCRFrameworkException;
import com.hdfcbank.azure.formparser.model.api.DocumentKeywordsRequest;
import com.hdfcbank.azure.formparser.model.document.DocumentDetail;
import com.hdfcbank.azure.formparser.model.entity.OCRDocumentInformation;
import com.hdfcbank.azure.formparser.model.entity.OCRDocumentKeywords;
import com.hdfcbank.azure.formparser.repository.OCRDocumentInformationRepository;
import com.hdfcbank.azure.formparser.repository.OCRDocumentKeywordsRepository;
import com.hdfcbank.azure.formparser.service.DocumentService;

import lombok.extern.log4j.Log4j2;

@Log4j2
@Service
public class DocumentServiceImpl implements DocumentService {

	@Value("${microsoft.parser.endpoint}")
	private String parserEndpoint;
	@Value("${microsoft.parser.key}")
	private String parserKey;
	@Value("${microsoft.parser.model.prebuiltModelId}")
	private String prebuiltModelId;

	@Autowired
	private ObjectMapper objectMapper;

	@Autowired
	private OCRDocumentInformationRepository ocrDocumentInformationRepository;

	@Autowired
	private OCRDocumentKeywordsRepository ocrDocumentKeywordsRepository;

	@Override
	public void updateDocumentKeywords(String correlationId, DocumentKeywordsRequest documentKeywordsRequest)
			throws OCRFrameworkException {
		try {

			OCRDocumentKeywords dbOcrDocumentKeywords = ocrDocumentKeywordsRepository
					.findByDocumentType(documentKeywordsRequest.getDocType());
			if (null != dbOcrDocumentKeywords) {
				dbOcrDocumentKeywords.setKeywords(documentKeywordsRequest.getKeywords());
				ocrDocumentKeywordsRepository.save(dbOcrDocumentKeywords);

			} else {
				OCRDocumentKeywords documentKeywords = OCRDocumentKeywords.builder()
						.documentType(documentKeywordsRequest.getDocType())
						.keywords(documentKeywordsRequest.getKeywords()).build();
				ocrDocumentKeywordsRepository.save(documentKeywords);
			}

		} catch (Exception e) {
			log.error(e.getMessage());
			throw new OCRFrameworkException(e.getMessage());
		}
	}

	@Override
	public List<DocumentDetail> getDocumentAnalysis(String correlationId) throws OCRFrameworkException {
		try {
			OCRDocumentInformation ocrDocumentInformation = ocrDocumentInformationRepository
					.findByCorrelationIdAndUserModified(correlationId, true);
			if (null == ocrDocumentInformation)
				ocrDocumentInformation = ocrDocumentInformationRepository
						.findByCorrelationIdAndUserModified(correlationId, false);
			if (null == ocrDocumentInformation)
				throw new OCRFrameworkException("Unable to get data for the mentioned correlationId: " + correlationId);
			return objectMapper.readValue(ocrDocumentInformation.getDocumentInfo(),
					new TypeReference<List<DocumentDetail>>() {
					});
		} catch (Exception e) {
			log.error(e.getMessage());
			throw new OCRFrameworkException(e.getMessage());
		}
	}

	@Override
	public void updateDocumentDetails(String correlationId, List<DocumentDetail> documentDetailList)
			throws OCRFrameworkException {
		try {
			if (null == documentDetailList || documentDetailList.isEmpty())
				throw new OCRFrameworkException("No data provided for correlationId: " + correlationId);
			List<DocumentDetail> dbDocumentDetailList = getDocumentAnalysis(correlationId);
			if (null == dbDocumentDetailList || dbDocumentDetailList.isEmpty())
				throw new OCRFrameworkException("No found in db for correlationId: " + correlationId);

			dbDocumentDetailList.forEach(dbDocDetail -> documentDetailList.stream()
					.filter(docDetail -> Objects.equals(docDetail.getDocId(), dbDocDetail.getDocId())).findAny()
					.ifPresent(docDetail -> dbDocDetail.setDocumentFieldList(docDetail.getDocumentFieldList())));

			ocrDocumentInformationRepository
					.updateDocumentInfoByUser(objectMapper.writeValueAsString(dbDocumentDetailList), correlationId);
		} catch (Exception e) {
			log.error(e.getMessage());
			throw new OCRFrameworkException(e.getMessage());
		}
	}
}
