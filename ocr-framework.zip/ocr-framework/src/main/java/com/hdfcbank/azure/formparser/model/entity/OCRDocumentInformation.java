package com.hdfcbank.azure.formparser.model.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicUpdate;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Table(name = "OCR_DOCUMENT_INFORMATION")
@Entity
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@DynamicUpdate
public class OCRDocumentInformation extends DateAudit{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID")
	private Long id;
	@Column(name = "CORRELATION_ID")
	private String correlationId;
	@Column(name = "DOCUMENT_INFO"/*, columnDefinition = "text"*/)
	@Lob
	private String documentInfo;
	@Column(name = "USER_MODIFIED")
	private Boolean userModified;
}
