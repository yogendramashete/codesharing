package com.hdfcbank.azure.formparser.model.document;

import java.util.List;

import javax.validation.constraints.NotBlank;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DocumentDetail {
	@NotBlank
	private String docId;
	private String fileName;
	private List<DocumentField> documentFieldList;

}
