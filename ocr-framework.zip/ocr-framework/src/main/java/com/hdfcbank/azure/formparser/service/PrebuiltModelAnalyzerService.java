package com.hdfcbank.azure.formparser.service;

import com.hdfcbank.azure.formparser.exception.OCRFrameworkException;
import com.hdfcbank.azure.formparser.model.api.PrebuiltDocRequest;

public interface PrebuiltModelAnalyzerService {

	public void parseDocument(String correlationId, PrebuiltDocRequest prebuiltDocRequest)
			throws OCRFrameworkException;
}
