# ocr-framework
OCR framework which will call model based on where its deployed
