package poc.yogendra.azure.formparser.util;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class FileUtils {

	private FileUtils() {
	}

	public static void writeFile(String fileName, String contents) throws IOException {
		try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName, true))) {
			writer.append('\n');
			writer.write(contents);
			writer.flush();
		}
	}

	public static List<String> getFileNames(String basePath, String filenamePart, String extension) throws IOException {
		try(Stream<Path> stream = Files
				.find(Paths.get(basePath), Integer.MAX_VALUE,
						(filePath,
								fileAttr) -> fileAttr.isRegularFile()
								&& filePath.getFileName().toString().contains(filenamePart)
								&& filePath.getFileName().toString().endsWith(extension))){
			return stream.map(Path::toString).sorted().collect(Collectors.toList());
		}catch(IOException e) {
			e.printStackTrace();
		}
		return null;

	}
	
	public static List<String> getFileNamesInFolder(String folderBasePath, String filenamePart, String extension){
		File f = new File(folderBasePath);
		File[] matchingFiles = f.listFiles((dir, name) -> name.contains(filenamePart) && name.endsWith(extension));
		return Stream.of(matchingFiles).map(File::getPath).collect(Collectors.toList());
	}

	public static List<String> getFoldersInFolder(String folderBasePath){
		try(Stream<Path> stream = Files
				.find(Paths.get(folderBasePath), Integer.MAX_VALUE,
						(filePath,
								fileAttr) -> fileAttr.isDirectory())){
			return stream.map(Path::toString).sorted().collect(Collectors.toList());
		}catch(IOException e) {
			e.printStackTrace();
		}
		return null;
	}
}
