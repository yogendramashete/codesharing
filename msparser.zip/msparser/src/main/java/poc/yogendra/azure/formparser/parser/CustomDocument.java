package poc.yogendra.azure.formparser.parser;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.Map;
import java.util.Map.Entry;

import com.azure.ai.formrecognizer.DocumentAnalysisClient;
import com.azure.ai.formrecognizer.DocumentAnalysisClientBuilder;
import com.azure.ai.formrecognizer.models.AnalyzeResult;
import com.azure.ai.formrecognizer.models.AnalyzedDocument;
import com.azure.ai.formrecognizer.models.DocumentField;
import com.azure.ai.formrecognizer.models.DocumentOperationResult;
import com.azure.core.credential.AzureKeyCredential;
import com.azure.core.util.polling.SyncPoller;

import lombok.extern.log4j.Log4j2;
import poc.yogendra.azure.formparser.model.DocValueConfidence;
import poc.yogendra.azure.formparser.util.FileUtils;

@Log4j2
public class CustomDocument {
	private CustomDocument() {}
//
//	private static final String endpoint = "https://formparserindia.cognitiveservices.azure.com/";
//	private static final String key = "f0ba8169b0ad46c493cd3d75dc85a880";
//
//	public static void main(String[] args) throws IOException {
//		// variable
//		DocumentAnalysisClient client = new DocumentAnalysisClientBuilder().credential(new AzureKeyCredential(key))
//				.endpoint(endpoint).buildClient();
//
//		// sample document
//		String documentUrl = "/Users/y3875/OneDrive - HDFCBANK/documents/projects/poc_on_ocr/DOCS/PAN copies/testing/pan_aparna.jpg";
//		File ipFile = new File(documentUrl);
//		String modelId = "pan_retrain";
//		byte[] readAllBytes = Files.readAllBytes(ipFile.toPath());
//		SyncPoller<DocumentOperationResult, AnalyzeResult> recognizeFormPoller = client.beginAnalyzeDocument(modelId,
//				new ByteArrayInputStream(readAllBytes), readAllBytes.length);
//
//		AnalyzeResult analyzeResult = recognizeFormPoller.getFinalResult();
//
//		for (AnalyzedDocument analyzedDocument : analyzeResult.getDocuments()) {
//			var fields = analyzedDocument.getFields();
//			for (Entry<String, DocumentField> entry : fields.entrySet())
//				log.info(entry.getKey().toUpperCase() + "|" + entry.getValue().getContent() + "|"
//						+ entry.getValue().getConfidence());
//		}
//	}

	public static void getDocumentInfoByFile(String modelId, String filePath,
			DocumentAnalysisClient documentAnalysisClient, String outputFilePath) throws IOException {
		File document = new File(filePath);

		byte[] readAllBytes = Files.readAllBytes(document.toPath());
		SyncPoller<DocumentOperationResult, AnalyzeResult> recognizeFormPoller = documentAnalysisClient
				.beginAnalyzeDocument(modelId, new ByteArrayInputStream(readAllBytes), readAllBytes.length);

		StringBuilder sb = new StringBuilder();
		AnalyzeResult analyzeResult = recognizeFormPoller.getFinalResult();
		if (null != analyzeResult) {
			analyzeResult.getDocuments().stream()
					.forEach(analyzedDocument -> analyzedDocument.getFields()
							.forEach((key, documentField) -> sb.append("\n" + key.toUpperCase() + "|"
									+ documentField.getContent() + "|" + documentField.getConfidence())));
			FileUtils.writeFile(outputFilePath, "\n------" + filePath + "-------" + sb.toString());
		} else {
			System.out.println("analyzeResult is null");
		}
	}
	
	public static void getDocumentInfoByFolder(String modelId, String filePath,
			DocumentAnalysisClient documentAnalysisClient, Map<String, DocValueConfidence> valMap) throws IOException {
		File document = new File(filePath);

		byte[] readAllBytes = Files.readAllBytes(document.toPath());
		SyncPoller<DocumentOperationResult, AnalyzeResult> recognizeFormPoller = documentAnalysisClient
				.beginAnalyzeDocument(modelId, new ByteArrayInputStream(readAllBytes), readAllBytes.length);

		AnalyzeResult analyzeResult = recognizeFormPoller.getFinalResult();

		if (null != analyzeResult) {
			analyzeResult.getDocuments().stream()
					.forEach(analyzedDocument -> analyzedDocument.getFields().forEach((key, documentField) -> {

						DocValueConfidence docVal = valMap.putIfAbsent(key.toUpperCase(),
								DocValueConfidence.builder().key(key.toUpperCase()).value(documentField.getContent())
										.confidence(documentField.getConfidence()).build());

						if (null != docVal && docVal.getConfidence() < documentField.getConfidence()) {
							DocValueConfidence value = DocValueConfidence.builder().key(key.toUpperCase())
									.value(documentField.getContent()).confidence(documentField.getConfidence())
									.build();
							valMap.put(key.toUpperCase(), value);
						}

					}));
		} else {
			System.out.println("analyzeResult is null");
		}
//		return valMap;

	}
}
