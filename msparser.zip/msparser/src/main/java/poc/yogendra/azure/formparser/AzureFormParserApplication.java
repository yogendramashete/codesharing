package poc.yogendra.azure.formparser;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AzureFormParserApplication {

	public static void main(String[] args) {
		SpringApplication.run(AzureFormParserApplication.class, args);
	}

}
