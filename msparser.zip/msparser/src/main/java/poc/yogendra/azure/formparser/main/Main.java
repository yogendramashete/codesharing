package poc.yogendra.azure.formparser.main;

import java.io.IOException;

import poc.yogendra.azure.formparser.process.ProcessFiles;

public class Main {
	public static void main(String[] args) throws IOException {
		processFile("boe");
		processFile("coe");
		processFile("crl");
		processFile("transport");
		processFile("invoice");
		processFile("rl");
	}

	private static final String BASE_PATH = "/Users/y3875/OneDrive - HDFCBANK/documents/projects/poc_on_ocr/tradeflow/abhay_palav/TF_DOCS/";
//	private static final String BASE_PATH = "/Users/y3875/OneDrive - HDFCBANK/documents/projects/poc_on_ocr/tradeflow/abhay_palav/drop1/";
	private static final String EXTENSION = ".tif";

	static void processFile(String doctype) throws IOException {
		String filenameSubstring = null;
		String modelId = null;
		String outputFilePath = "/tmp/";
		if (doctype.equalsIgnoreCase("crl")) {
			filenameSubstring = "CUSTOMER_LETTER";
			modelId = "crl_poc";
		} else if (doctype.equalsIgnoreCase("coe")) {
			filenameSubstring = "CERTIFICATE_OF_ORIGIN";
			modelId = "coe_poc";
		} else if (doctype.equalsIgnoreCase("transport")) {
			filenameSubstring = "TRANSPORT_DOCUMENT";
			modelId = "transport_poc";
		} else if (doctype.equalsIgnoreCase("boe")) {
			filenameSubstring = "BILL_OF_EXCHANGE";
			modelId = "boe_poc";
		} else if (doctype.equalsIgnoreCase("invoice")) {
			filenameSubstring = "COMMERCIAL_INVOICE";
			modelId = "invoice_neural_test";
		} else if (doctype.equalsIgnoreCase("rl")) {
			filenameSubstring = "REMITANCE_LETTER";
			modelId = "rl_poc";
		} else if (doctype.equalsIgnoreCase("a2")) {
			filenameSubstring = "A2";
			modelId = "a2_poc";
		} else if (doctype.equalsIgnoreCase("ca15")) {
			filenameSubstring = "CA15";
			modelId = "ca15_poc";
		} else if (doctype.equalsIgnoreCase("cb15")) {
			filenameSubstring = "CB15";
			modelId = "cb15_poc";
		}
		outputFilePath += filenameSubstring + ".txt";
		ProcessFiles.processFilesAsync(BASE_PATH, filenameSubstring, EXTENSION, modelId, outputFilePath);
		
//		ProcessFiles.processFilesAsPerFolderAsync(BASE_PATH, filenameSubstring, EXTENSION, modelId, outputFilePath);
		
//		ProcessFiles.processFilesSync(BASE_PATH, filenameSubstring, EXTENSION, modelId, outputFilePath);
		
//		ProcessFiles.processFilesAsPerFolderSync(BASE_PATH, filenameSubstring, EXTENSION, modelId, outputFilePath);
		
	}
}
