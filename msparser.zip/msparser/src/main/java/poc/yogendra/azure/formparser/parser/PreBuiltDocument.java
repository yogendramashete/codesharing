package poc.yogendra.azure.formparser.parser;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.List;

import com.azure.ai.formrecognizer.DocumentAnalysisClient;
import com.azure.ai.formrecognizer.DocumentAnalysisClientBuilder;
import com.azure.ai.formrecognizer.models.AnalyzeResult;
import com.azure.ai.formrecognizer.models.DocumentOperationResult;
import com.azure.ai.formrecognizer.models.DocumentTable;
import com.azure.core.credential.AzureKeyCredential;
import com.azure.core.util.polling.SyncPoller;

import lombok.extern.log4j.Log4j2;

@Log4j2
public class PreBuiltDocument {

	// set `<your-endpoint>` and `<your-key>` variables with the values from the
	// Azure portal
	private static final String endpoint = "https://formparserindia.cognitiveservices.azure.com/";
	private static final String key = "f0ba8169b0ad46c493cd3d75dc85a880";

	public static void main(String[] args) throws IOException {

		// create your `DocumentAnalysisClient` instance and `AzureKeyCredential`
		// variable
		DocumentAnalysisClient client = new DocumentAnalysisClientBuilder().credential(new AzureKeyCredential(key))
				.endpoint(endpoint).buildClient();

		// sample document
		String documentUrl = "/Users/y3875/OneDrive - HDFCBANK/documents/projects/poc_on_ocr/DOCS/PAN copies/testing/pan_aparna.jpg";
		File ipFile = new File(documentUrl);
		String modelId = "prebuilt-document";
		byte[] readAllBytes = Files.readAllBytes(ipFile.toPath());
		SyncPoller<DocumentOperationResult, AnalyzeResult> analyzeDocumentPoller = client
				.beginAnalyzeDocument(modelId, new ByteArrayInputStream(readAllBytes), readAllBytes.length);

		AnalyzeResult analyzeResult = analyzeDocumentPoller.getFinalResult();

		// pages
		analyzeResult.getPages().forEach(documentPage -> {
			log.info("Page has width: " + documentPage.getWidth() + " and height: " + documentPage.getHeight()
					+ ", measured with unit: " + documentPage.getUnit());

			// lines
			documentPage.getLines().forEach(documentLine -> log.info("Line " + documentLine.getContent()
					+ "is within a bounding box " + documentLine.getBoundingBox().toString()));

			// words
			documentPage.getWords().forEach(documentWord -> log.info("Word " + documentWord.getContent()
					+ " has a confidence score of " + documentWord.getConfidence()));
		});

		// tables
		List<DocumentTable> tables = analyzeResult.getTables();
		for (int i = 0; i < tables.size(); i++) {
			DocumentTable documentTable = tables.get(i);
			log.info("Table " + i + " has " + documentTable.getRowCount() + " rows and "
					+ documentTable.getColumnCount() + " columns");
			documentTable.getCells().forEach(documentTableCell -> {
				log.info("Cell " + documentTableCell.getContent() + ", has row index " + documentTableCell.getRowIndex()
						+ " and column index " + documentTableCell.getColumnIndex());
			});
		}

		// Entities
		analyzeResult.getEntities().forEach(documentEntity -> {
			log.info("Entity category : "+documentEntity.getCategory()+", sub-category "+ 	documentEntity.getSubCategory());
			log.info("Entity content:  "+ documentEntity.getContent());
			log.info("Entity confidence: "+ documentEntity.getConfidence());
		});

		// Key-value pairs
		analyzeResult.getKeyValuePairs().forEach(documentKeyValuePair -> {
			log.info("Key content: "+ documentKeyValuePair.getKey().getContent());
			log.info("Key content bounding region: "+
					documentKeyValuePair.getKey().getBoundingRegions().toString());

			if (documentKeyValuePair.getValue() != null) {
				log.info("Value content: "+ documentKeyValuePair.getValue().getContent());
				log.info("Value content bounding region: "+
						documentKeyValuePair.getValue().getBoundingRegions().toString());
			}
		});
	}
}