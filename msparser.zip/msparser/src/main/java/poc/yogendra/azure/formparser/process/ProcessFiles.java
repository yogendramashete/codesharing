package poc.yogendra.azure.formparser.process;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import com.azure.ai.formrecognizer.DocumentAnalysisAsyncClient;
import com.azure.ai.formrecognizer.DocumentAnalysisClient;
import com.azure.ai.formrecognizer.DocumentAnalysisClientBuilder;
import com.azure.core.credential.AzureKeyCredential;

import poc.yogendra.azure.formparser.model.DocValueConfidence;
import poc.yogendra.azure.formparser.parser.CustomDocument;
import poc.yogendra.azure.formparser.parser.CustomDocumentAsync;
import poc.yogendra.azure.formparser.util.FileUtils;

public class ProcessFiles {
	private ProcessFiles() {
	}

	private static final String ENDPOINT = "https://formparserindia.cognitiveservices.azure.com/";
	private static final String KEY = "f0ba8169b0ad46c493cd3d75dc85a880";

	public static void processFilesSync(String basePath, String fileNameSubstring, String extension, String modelId,
			String outputFilePath) throws IOException {
		DocumentAnalysisClient documentAnalysisClient = new DocumentAnalysisClientBuilder()
				.credential(new AzureKeyCredential(KEY)).endpoint(ENDPOINT).buildClient();

		List<String> filePathList = FileUtils.getFileNames(basePath, fileNameSubstring, extension);

		ExecutorService executorService = Executors.newFixedThreadPool(10);

		for (String filePath : filePathList) {
			executorService.execute(() -> {
				try {
					CustomDocument.getDocumentInfoByFile(modelId, filePath, documentAnalysisClient, outputFilePath);
				} catch (IOException e) {
					e.printStackTrace();
				}
			});
		}

		executorService.shutdown();

	}

	public static void processFilesAsPerFolderSync(String basePath, String fileNameSubstring, String extension,
			String modelId, String outputFilePath) {
		DocumentAnalysisClient documentAnalysisClient = new DocumentAnalysisClientBuilder()
				.credential(new AzureKeyCredential(KEY)).endpoint(ENDPOINT).buildClient();

		ExecutorService executorService = Executors.newFixedThreadPool(10);
		List<String> folderPathList = FileUtils.getFoldersInFolder(basePath);
		for (String folder : folderPathList) {
			List<String> filesPathList = FileUtils.getFileNamesInFolder(folder, fileNameSubstring, extension);

			executorService.execute(() -> {
				Map<String, DocValueConfidence> valMap = new ConcurrentHashMap<>();

				for (String filePath : filesPathList) {
					try {
						CustomDocument.getDocumentInfoByFolder(modelId, filePath, documentAnalysisClient, valMap);
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
				try {
					writeToFile(outputFilePath, folder, valMap);
				} catch (IOException e) {
					e.printStackTrace();
				}
			});

		}
		executorService.shutdown();

	}

	public static void processFilesAsync(String basePath, String fileNameSubstring, String extension, final String modelId,
			final String outputFilePath) throws IOException {
		final DocumentAnalysisAsyncClient documentAnalysisAsyncClient = new DocumentAnalysisClientBuilder()
				.credential(new AzureKeyCredential(KEY)).endpoint(ENDPOINT).buildAsyncClient();

		List<String> filePathList = FileUtils.getFileNames(basePath, fileNameSubstring, extension);

		ExecutorService executorService = Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors() * 2);

		for (String filePath : filePathList) {
			executorService.execute(() -> {
				
				try {
					CustomDocumentAsync.getDocumentInfo(modelId, filePath, documentAnalysisAsyncClient, outputFilePath);
				} catch (IOException e) {
					e.printStackTrace();
				}
			});
		}

//		while(executorService.isShutdown()) {}
//		executorService.shutdown();
		
	}

	public static void processFilesAsPerFolderAsync(String basePath, String fileNameSubstring, String extension,
			String modelId, String outputFilePath) {
		DocumentAnalysisAsyncClient documentAnalysisAsyncClient = new DocumentAnalysisClientBuilder()
				.credential(new AzureKeyCredential(KEY)).endpoint(ENDPOINT).buildAsyncClient();

		ExecutorService executorService = Executors.newFixedThreadPool(10);
		List<String> folderPathList = FileUtils.getFoldersInFolder(basePath);
		for (String folder : folderPathList) {
			List<String> filesPathList = FileUtils.getFileNamesInFolder(folder, fileNameSubstring, extension);

			executorService.execute(() -> {
				Map<String, DocValueConfidence> valMap = new ConcurrentHashMap<>();

				for (String filePath : filesPathList) {
					try {
						CustomDocumentAsync.getDocumentInfo2(modelId, filePath, documentAnalysisAsyncClient, valMap);
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
				try {
					writeToFile(outputFilePath, folder, valMap);
				} catch (IOException e) {
					e.printStackTrace();
				}
			});

		}
		executorService.shutdown();
	}

	private static void writeToFile(String outputFilePath, String folder, Map<String, DocValueConfidence> valMap)
			throws IOException {
		List<String> keys = new ArrayList<>(valMap.keySet());
		Collections.sort(keys);

		if (!keys.isEmpty()) {
			StringBuilder sb = new StringBuilder("\n------Case folder:" + folder + "-------");
			keys.forEach(k -> {
				DocValueConfidence docVal = valMap.get(k);
				sb.append(
						"\n" + docVal.getKey().toUpperCase() + "|" + docVal.getValue() + "|" + docVal.getConfidence());
			});

			FileUtils.writeFile(outputFilePath, sb.toString());
		}
	}

}
