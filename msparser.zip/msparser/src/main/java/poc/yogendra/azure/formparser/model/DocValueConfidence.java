package poc.yogendra.azure.formparser.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class DocValueConfidence {

	private String key;
	private String value;
	private Float confidence;
}
