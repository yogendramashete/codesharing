package poc.yogendra.azure.formparser.parser;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.file.Files;
import java.time.Duration;
import java.time.Instant;
import java.util.Map;
import java.util.function.Predicate;

import com.azure.ai.formrecognizer.DocumentAnalysisAsyncClient;
import com.azure.ai.formrecognizer.implementation.util.Utility;
import com.azure.ai.formrecognizer.models.AnalyzeResult;
import com.azure.ai.formrecognizer.models.DocumentOperationResult;
import com.azure.core.util.polling.AsyncPollResponse;
import com.azure.core.util.polling.LongRunningOperationStatus;
import com.azure.core.util.polling.PollerFlux;

import poc.yogendra.azure.formparser.model.DocValueConfidence;
import poc.yogendra.azure.formparser.util.FileUtils;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public class CustomDocumentAsync {

	private CustomDocumentAsync() {
	}

	public static void getDocumentInfo(String modelId, String filePath,
			DocumentAnalysisAsyncClient documentAnalysisAsyncClient, String outputFilePath) throws IOException {
		Instant startTime = Instant.now();
		File document = new File(filePath);

		// Utility method to convert input stream to Byte buffer
		Flux<ByteBuffer> buffer = Utility
				.toFluxByteBuffer(new ByteArrayInputStream(Files.readAllBytes(document.toPath())));

		final Predicate<? super AsyncPollResponse<DocumentOperationResult, AnalyzeResult>> isComplete = response -> response
				.getStatus() != LongRunningOperationStatus.IN_PROGRESS
				&& response.getStatus() != LongRunningOperationStatus.NOT_STARTED;

		StringBuilder sb = new StringBuilder();
		PollerFlux<DocumentOperationResult, AnalyzeResult> pollerFlux = documentAnalysisAsyncClient
				.beginAnalyzeDocument(modelId, buffer, document.length());

		AnalyzeResult analyzeResult = pollerFlux.takeUntil(isComplete).last()
				// if polling operation completed, retrieve the final result.
				.flatMap(asyncPollResponse -> {
					if (asyncPollResponse.getStatus() == LongRunningOperationStatus.SUCCESSFULLY_COMPLETED) {
						// operation completed successfully, retrieving final result.
						return asyncPollResponse.getFinalResult();
					} else {
						return Mono.error(new RuntimeException(
								"polling completed unsuccessfully with status:" + asyncPollResponse.getStatus()));
					}
				}).block();

		if (null != analyzeResult) {
			analyzeResult.getDocuments().stream()
					.forEach(analyzedDocument -> analyzedDocument.getFields()
							.forEach((key, documentField) -> sb.append("\n" + key.toUpperCase() + "|"
									+ documentField.getContent() + "|" + documentField.getConfidence())));
			Instant finish = Instant.now(); 
			long timeElapsed = Duration.between(startTime, finish).toMillis();
			FileUtils.writeFile(outputFilePath, "\n##"+timeElapsed +"##------" + filePath + "-------" + sb.toString());
		} else {
			System.out.println("analyzeResult is null");
		}
	}

	public static void getDocumentInfo2(String modelId, String filePath,
			DocumentAnalysisAsyncClient documentAnalysisAsyncClient, Map<String, DocValueConfidence> valMap)
			throws IOException {
		File document = new File(filePath);

		// Utility method to convert input stream to Byte buffer
		Flux<ByteBuffer> buffer = Utility
				.toFluxByteBuffer(new ByteArrayInputStream(Files.readAllBytes(document.toPath())));

		final Predicate<? super AsyncPollResponse<DocumentOperationResult, AnalyzeResult>> isComplete = response -> response
				.getStatus() != LongRunningOperationStatus.IN_PROGRESS
				&& response.getStatus() != LongRunningOperationStatus.NOT_STARTED;

		PollerFlux<DocumentOperationResult, AnalyzeResult> pollerFlux = documentAnalysisAsyncClient
				.beginAnalyzeDocument(modelId, buffer, document.length());

		AnalyzeResult analyzeResult = pollerFlux.takeUntil(isComplete).last()
				// if polling operation completed, retrieve the final result.
				.flatMap(asyncPollResponse -> {
					if (asyncPollResponse.getStatus() == LongRunningOperationStatus.SUCCESSFULLY_COMPLETED) {
						// operation completed successfully, retrieving final result.
						return asyncPollResponse.getFinalResult();
					} else {
						return Mono.error(new RuntimeException(
								"polling completed unsuccessfully with status:" + asyncPollResponse.getStatus()));
					}
				}).block();

		if (null != analyzeResult) {
			analyzeResult.getDocuments().stream()
					.forEach(analyzedDocument -> analyzedDocument.getFields().forEach((key, documentField) -> {

						DocValueConfidence docVal = valMap.putIfAbsent(key.toUpperCase(),
								DocValueConfidence.builder().key(key.toUpperCase()).value(documentField.getContent())
										.confidence(documentField.getConfidence()).build());
						
						if (null != docVal && docVal.getConfidence() < documentField.getConfidence()) {
							DocValueConfidence value = DocValueConfidence.builder().key(key.toUpperCase())
									.value(documentField.getContent()).confidence(documentField.getConfidence())
									.build();
							valMap.put(key.toUpperCase(), value);
						}

					}));
		} else {
			System.out.println("analyzeResult is null");
		}
//		return valMap;
	}

}
