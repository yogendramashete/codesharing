## Apache Olingo

This module contains articles about Apache Olingo

### Relevant articles:

- [OData Protocol Guide](https://www.baeldung.com/odata)
- [Intro to OData with Olingo](https://www.baeldung.com/olingo)
