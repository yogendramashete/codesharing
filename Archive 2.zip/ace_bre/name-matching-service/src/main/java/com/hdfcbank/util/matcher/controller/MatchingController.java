package com.hdfcbank.util.matcher.controller;

import com.hdfcbank.util.matcher.exception.MatcherException;
import com.hdfcbank.util.matcher.model.api.ApiResponse;
import com.hdfcbank.util.matcher.model.name.Request;
import com.hdfcbank.util.matcher.model.name.Response;
import com.hdfcbank.util.matcher.service.MatchingService;
import io.quarkus.logging.Log;
import io.quarkus.runtime.util.StringUtil;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.validation.Valid;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;

@Path("/match")
public class MatchingController {
    @Inject
    private MatchingService matchingServiceImpl;

    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public ApiResponse<Response> getMatchRatio(@Valid Request request) {
        try {
            if (null != request && !StringUtil.isNullOrEmpty(request.getFirstString())
                    && !StringUtil.isNullOrEmpty(request.getSecondString())) {
                String firstString = request.getFirstString();
                String secondString = request.getSecondString();
                int ratio = matchingServiceImpl.getMatchRatio(firstString, secondString);
                Response response = new Response(firstString, secondString,String.valueOf(ratio));
                return ApiResponse.Builder.<Response>anApiResponse().status(200).message("SUCCESS").data(response).build();
            } else {
                return ApiResponse.Builder.<Response>anApiResponse().status(200).message("FAILURE").build();
            }
        } catch (MatcherException matcherException) {
            Log.error(matcherException.getMessage());
            return ApiResponse.Builder.<Response>anApiResponse().status(500).message("EXCEPTION").build();
        }
    }

}
