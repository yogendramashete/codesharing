package com.hdfcbank.util.matcher.service;

import com.hdfcbank.util.matcher.exception.MatcherException;

import javax.enterprise.context.ApplicationScoped;

public interface MatchingService {
    public int getMatchRatio(String str1, String str2) throws MatcherException;
}
