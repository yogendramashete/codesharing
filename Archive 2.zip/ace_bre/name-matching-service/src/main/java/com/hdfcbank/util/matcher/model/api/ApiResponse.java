package com.hdfcbank.util.matcher.model.api;


public class ApiResponse<T> {

	private int status;
	private String message;
	private T data;

	public int getStatus() {
		return status;
	}

	public String getMessage() {
		return message;
	}

	public T getData() {
		return data;
	}

	@Override
	public String toString() {
		return "ApiResponse{" +
				"status=" + status +
				", message='" + message + '\'' +
				", data=" + data +
				'}';
	}


	public static final class Builder<T extends Object> {
		private int status;
		private String message;
		private T data;

		private Builder() {
		}

		public static Builder anApiResponse() {
			return new Builder();
		}

		public Builder status(int status) {
			this.status = status;
			return this;
		}

		public Builder message(String message) {
			this.message = message;
			return this;
		}

		public Builder data(T data) {
			this.data = data;
			return this;
		}

		public ApiResponse build() {
			ApiResponse apiResponse = new ApiResponse();
			apiResponse.status = this.status;
			apiResponse.message = this.message;
			apiResponse.data = this.data;
			return apiResponse;
		}
	}
}
