package com.hdfcbank.util.matcher.util;

import javax.inject.Singleton;
import java.util.Arrays;

@Singleton
public class LevenshteinDistanceUtil {
    private static final String ALPHANUMERIC_REGEX = "[^A-Za-z0-9 ]";
    private static final String MULTIPLESPACE_REGEX = "[ ]{2,}";

    private int computeLevenshteinDistance(String str1, String str2) {
        int[][] dp = new int[str1.length() + 1][str2.length() + 1];
        for (int i = 0; i <= str1.length(); i++) {
            for (int j = 0; j <= str2.length(); j++) {
                if (i == 0) {
                    dp[i][j] = j;
                } else if (j == 0) {
                    dp[i][j] = i;
                } else {
                    dp[i][j] = minm_edits(dp[i - 1][j - 1]
                                    + NumOfReplacement(str1.charAt(i - 1), str2.charAt(j - 1)), // replace
                            dp[i - 1][j] + 1, // delete
                            dp[i][j - 1] + 1); // insert
                }
            }
        }
       return dp[str1.length()][str2.length()];
    }

    private int NumOfReplacement(char c1, char c2) {
        return c1 == c2 ? 0 : 1;
    }

    private int minm_edits(int... nums) {
        return Arrays.stream(nums).min().orElse(Integer.MAX_VALUE);
    }

    public int getRatio(String string1, String string2) {
        String str1 = removeRegex(string1);
        String str2 = removeRegex(string2);
        int maxLength = Math.max(str1.length(), str2.length());
        int levenshteinDistance = computeLevenshteinDistance(str1, str2);
        return 100 * (maxLength - levenshteinDistance) / maxLength;
    }

    private String removeRegex(String str) {
        return str.trim().replaceAll(ALPHANUMERIC_REGEX, "")
                .replaceAll(MULTIPLESPACE_REGEX, " ");
    }

}
