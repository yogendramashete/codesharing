package com.hdfcbank.util.matcher.model.name;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Response {
    private String firstString;
    private String secondString;
    private String matchRatio;

}
