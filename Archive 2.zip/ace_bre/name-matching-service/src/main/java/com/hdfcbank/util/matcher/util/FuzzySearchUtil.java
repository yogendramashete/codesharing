package com.hdfcbank.util.matcher.util;

import javax.inject.Singleton;
import me.xdrop.fuzzywuzzy.*;
@Singleton
public class FuzzySearchUtil {

    private static final String ALPHANUMERIC_REGEX = "[^A-Za-z0-9 ]";
    private static final String MULTIPLESPACE_REGEX = "[ ]{2,}";

    private String removeRegex(String str) {
        return str.trim().replaceAll(ALPHANUMERIC_REGEX, "")
                .replaceAll(MULTIPLESPACE_REGEX, " ");
    }

    public int getRatio(String string1, String string2) {
        return FuzzySearch.tokenSortRatio(string1, string2);
    }
}
