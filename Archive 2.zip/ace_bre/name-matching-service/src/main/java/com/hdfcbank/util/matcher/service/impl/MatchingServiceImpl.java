package com.hdfcbank.util.matcher.service.impl;

import com.hdfcbank.util.matcher.exception.MatcherException;
import com.hdfcbank.util.matcher.service.MatchingService;
import com.hdfcbank.util.matcher.util.FuzzySearchUtil;
import com.hdfcbank.util.matcher.util.LevenshteinDistanceUtil;
import io.quarkus.logging.Log;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;

@ApplicationScoped
public class MatchingServiceImpl implements MatchingService {
    @Inject
    private LevenshteinDistanceUtil levenshteinDistanceUtil;

    @Inject
    private FuzzySearchUtil fuzzySearchUtil;

    @Override
    public int getMatchRatio(String str1, String str2) throws MatcherException {
        try {
//            return levenshteinDistanceUtil.getRatio(str1, str2);
            return fuzzySearchUtil.getRatio(str1, str2);
        }catch(Exception exception){
            Log.error(exception);
            throw new MatcherException(exception.getMessage());
        }
    }
}
