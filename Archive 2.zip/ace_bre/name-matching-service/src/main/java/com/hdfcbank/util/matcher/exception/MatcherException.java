package com.hdfcbank.util.matcher.exception;

public class MatcherException extends RuntimeException {

	/**
	 *
	 */

	private static final long serialVersionUID = 1L;

	public MatcherException() {
		super();
	}

	public MatcherException(String message, Throwable cause) {
		super(message, cause);
	}

	public MatcherException(String message) {
		super(message);
	}

	public MatcherException(Throwable cause) {
		super(cause);
	}
}