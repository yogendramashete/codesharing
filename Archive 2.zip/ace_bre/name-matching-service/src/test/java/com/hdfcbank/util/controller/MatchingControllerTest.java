package com.hdfcbank.util.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hdfcbank.util.matcher.model.api.ApiResponse;
import com.hdfcbank.util.matcher.model.name.Request;
import com.hdfcbank.util.matcher.model.name.Response;
import io.quarkus.test.junit.QuarkusTest;
import org.hamcrest.MatcherAssert;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.Test;

import java.util.List;

import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.is;

@QuarkusTest
public class MatchingControllerTest {

    @Test
    public void testMatchEndpointLoop() throws JsonProcessingException {
        List<String> stringList1 = List.of("SEEMA  RANI","CHITRA  BAI","NAND LAL KUMAWAT","MAHIPALSINH GIRWANSINH RANA","RASHID  KALLUKHAN","KRISHNA  BURAGOHAIN","RASHEEDA  KHATOON","VERVENEST TECHNOLOGIES PRIVATE LIMITED","SANYOGA  DEVI","JAYESH  JAWADE","V SURESH KUMAR","SANTOSINI  GOUDA","MANISHA RAMESH VAGHADE","ANJANNA GANGARAM GEDAM","SARASWATI  SAHU","BANITA  GOUDA","BABY DATTATRAY VYANKATWAR","KAUSHALYA WAMAN JUNGHARE","PUNSHI DEVRAJ SANKHRA","PAVITHRAN ELAMBILAN","DANISTA  PARAJIN","S PREM RUBAN","PRAKHYA  VENKATRAM","CHELLADURAI  R","CHUMUKI  PRADHAN","DINESH LALITPRASAD YADAV","KOKANI  GAUDA","ATMARAM APPA PAWASKAR","NAMSU NARAYAN SERVAI","SACHIN ASHOK JADHAV","ACUTRO TECHNOLOGIES PRIVATE LIMITED","JANAKI  J","SARIKA VISHAL AAVLE","RINSIYA MARVA AP","CHOTKI  DEVI","KANCHAN  DEVI","ROHAN DEEPAK DHUMAL","JITENDRA K ISRANI","MINA  HEMBROM","MOZIBAR  ALI","RAJU  B","SHREEYA ENTERPRISES","MOHAMMAD  HAFIJ","BALRAM SANTHOSH","MOHAMMAD NASIR MOHAMMADAASIF","GEMBALI MANI ESWARARAO","K  NANDEESH","RAMBAI  RAWAT","PATANI SURAJBEN RAMABHAI","NARAIN LAL AGARWAL","VARALAKSHMI K S","SHARADA  R","ROKTIM RAHUL THENGAL","RATHNAMMA  S","GOWRAMMA  B","VISHNU  VP","BEBI  BHAGWAN","PRITI  SIKRODYA","AMOL NARAYAN KADAM","ANITA  NIRANJAN","ARAM  BAI","KUNTALA  DEI","TANIYA SATISH MODI","DINESH  YADAV","BABITA  SANJAY","LILA  BAI","SUBAIDA  K","CHARANJEET  KAUR","DEVENDRA  KUMAR","AMAN  SAHOTA","AARTI  RANI","MAMTA  BAI","J  ATHMANATHAN","SANTRO  RAMKUMAR","AMIT  BALRAM","GITA  KARAN","MAMTA  MAHENDER","AMANDEEP  KAUR","JAMEELA  K","LEO NELSON XAVIER","SYED  USMAN","GONESH  BORDOLOI","FASEELA  PARVEZ","BIBI AYISHA MULLA","SASIRAM  S","KAMAL  KAUR","MITHLESH  PAL","SATBIR  KAUR","NISHA  DEVI","ARTI JAY GOVIND","MAYA  DEVI","GOHIL KIRITSINH BHARATSINH","GIRJA  BIKAOO","RAVINDRA  SHARMA","MD  IQUBAL","HARIS  K","ALIAS  PANICKER","VIJUBAI DNYANESHRWAR PATIL","MADHURI JAGDISH JAMBHURE","SANJEEV  SURESH");
        List<String> stringList2 = List.of("SEEMA  RANI","CHITRA  BAI","NAND LAL KUMAWAT","MAHIPALSINH GIRWANSINH RANA SINGH","RASHID  K","KRISHNA  ","R  KHATOON","VERVENEST TECH PVT LTD","SANYOGA  DEVI","JAWADE JAYESH  ","V SURESH KUMAR","SANTOSH  GOUDA","MANISHA RAMESH","ANJANNA GEDAM","SARASWATI  S","BANITA  GOUDA","BABY DATTATRAY VYANKATWAR","KAUSHALYA WAMAN JUNGHARE","PUNSHI DEVRAJ SANKHRA","E PAVITHRAN","DANISTA  PARAJIN","PREM RUBAN","PRAKHYA  VENKATRAM","CHELLADURAI  R","CHUMUKI  PRADHAN","DINESH LALITPRASAD YDV","GOWDA K","ATMARAM APPA PAWASKAR","NAMSU NARAYAN SERVAI","SACHIN ASHOK JADHAV","ACUTRO TECHNOLOGIES PRIVATE LIMITED","JANAKI  J","SARIKA VISHAL AAVLE","RINSIYA MARVA AP","CHOTKI  DEVI PARMAR","KANCHAN  DEVI SHETY","ROHAN DEEPAK DHUMAL","DR. JITENDRA K ISRANI","MINA  HEMBROM","MD MOZIBAR  ","RAJU  BHATT","SHREEYA ENTERPRISES","MOHAMMAD  HAFIJ","B  SANTHOSH","MOHAMMAD NASIR","GEMBALI MANI ESWARARAO","K  NANDEESH","RAMBI  ROWAT","PATANI SURAJBEN RAMABHAI","NARAIN LAL AGARWAL","VARALAKSHMI K S","RAMESH SHARADA ","ROKTIM RAHUL THENGAL","RATHNAMMA  S","GOWRAMMA  B","VISHNU  VIJAYA","BEBI  BHAGWAN","PRITI  PRASAD","ANIL NARAYAN KADAM","ANITA  NIRANJAN","ARAM  BANNO","SAVITRI KUNTALA  DEI","TANYA MODI","DINESH  YADAV","BABITA  SANJAY","LILA  BAI","SUBAIDA  K","CHARANJIT  KAUR","DEVENDRA  KR SINGH","AMAN  SAHOTA","AARTI  RANI","MAMTA  BAI","JAGAT  ATHMANATHAN","SANTRO  RAMKUMAR","AMIT  BALRAM","GITA  KARAN","MAMTA  MAHENDER","AMANDEEP  KAUR","JAMEELA  K","LEO NELSON XAVIER","SYED  USMAN","GONESH  BORDOLOI","FASEELA  P","BIBI AYISHA MULLA","SASIRAM ","KAMALJIT  KAUR","MITHILA  PAL","SATBIR  KAUR","NISHA  DEVI","ARTI JAY GOVIND","MAYA  DEVI","GOHIL KIRITSINH BHARATSINH","GIRJA  BIKAOO","RAVINDRA  SHARMA","MD  IQUBAL","HARIS  K","ALIAS  PANICKER","VIJUBAI D PATIL","MADHURI JAGDISH JAMBHURE","SANJEEV  RAMESH");

        if (stringList1.size() != stringList2.size()) {
            System.out.println("Size not equal");
            return;
        }
        for (int i = 0; i < stringList1.size(); i++) {
            Request request = Request.builder().firstString(stringList1.get(i)).secondString(stringList2.get(i)).build();
            ApiResponse<Response> actualResponse = new ObjectMapper().readValue((given()
                    .body(request).header("Content-Type", "application/json").when().post("/match")
                    .then()
                    .statusCode(200).extract().response().getBody().asString()), new TypeReference<ApiResponse<Response>>() {
            });
        }
    }

    @Test
    public void testMatchEndpoint() throws JsonProcessingException {
        Request request = Request.builder().firstString("test").secondString("test2").build();
        Response response = Response.builder().firstString("test").secondString("test2").matchRatio(String.valueOf(89)).build();
        ApiResponse<Response> responseApiResponse = ApiResponse.Builder.anApiResponse().data(response).status(200).message("SUCCESS").build();
        ApiResponse<Response> actualResponse = new ObjectMapper().readValue((given()
                .body(request).header("Content-Type", "application/json").when().post("/match")
                .then()
                .statusCode(200).extract().response().getBody().print()), new TypeReference<ApiResponse<Response>>() {
        });

        MatcherAssert.assertThat(actualResponse, is(Matchers.samePropertyValuesAs(responseApiResponse)));
    }

}