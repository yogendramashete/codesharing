# Face Match Service

## Summary:

Utilizes Azure Face Match API to compare between two face images provided and response if the images are identical and its ratio

## REST API:
`POST http://<baseUrl>/compare`


### Sample Request:

`{`

`&nbsp;&nbsp;"sourceImage":"<base64 String>",`

`&nbsp;&nbsp;"destinationImage":"<base64 String>",`

`&nbsp;&nbsp;"sourceImageSystem":"Selfie",`

`&nbsp;&nbsp;"destinationImageSystem":"Aadhaar",`

`&nbsp;&nbsp;"destinationImageSystem":"Channel",`

`&nbsp;&nbsp;"externalReferenceNumber":"extRef1234"`

`}`

### Sample Response:

#### Success Response Sample:
`{`

`&nbsp;&nbsp;"status": 200,`

`&nbsp;&nbsp;"message": "Success - Successfully submitted",`

`&nbsp;&nbsp;"data": {`

`&nbsp;&nbsp;&nbsp;&nbsp;"correlationId": "8hR6s8cZam",`

`&nbsp;&nbsp;&nbsp;&nbsp;"isIdentical": false,`

`&nbsp;&nbsp;&nbsp;&nbsp;"ratioMatch": 9.445,`

`&nbsp;&nbsp;&nbsp;&nbsp;"errorMsg": null`,

`&nbsp;&nbsp;&nbsp;&nbsp;"externalReferenceNumber": "extRef1234"`

`&nbsp;&nbsp;}`

`}`

#### Error Response Sample:
`{`

`&nbsp;&nbsp;"status": 500,`

`&nbsp;&nbsp;"message": "Failed - Internal Server Error",`

`&nbsp;&nbsp;"data": {`

`&nbsp;&nbsp;&nbsp;&nbsp;"correlationId": "vLTkjcV4qd",`

`&nbsp;&nbsp;&nbsp;&nbsp;"isIdentical": null,`

`&nbsp;&nbsp;&nbsp;&nbsp;"ratioMatch": null,`

`&nbsp;&nbsp;&nbsp;&nbsp;"errorMsg": "hdfc-face-match.cognitiveservices.azure.com: nodename nor servname provided, or not known"`

`&nbsp;&nbsp;&nbsp;&nbsp;"externalReferenceNumber": "extRef1234"`

`&nbsp;&nbsp;}`

`}`