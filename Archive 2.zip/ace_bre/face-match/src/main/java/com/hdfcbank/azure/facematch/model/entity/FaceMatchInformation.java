package com.hdfcbank.azure.facematch.model.entity;

import lombok.*;
import org.hibernate.annotations.DynamicUpdate;

import javax.persistence.*;

@Table(name = "FACEMATCH_INFORMATION")
@Entity
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@DynamicUpdate
public class FaceMatchInformation extends DateAudit {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID")
	private Long id;
	@Column(name = "CORRELATION_ID",length = 50)
	private String correlationId;
	@Column(name = "CHANNEL",length = 50)
	private String channel;
	@Column(name = "SOURCE_FILENAME_SYSTEM",length = 100)
	private String sourceImageSystem;
	@Column(name = "DESTINATION_FILENAME_SYSTEM",length = 100)
	private String destinationImageSystem;
	@Column(name = "IS_IDENTICAL")
	private Boolean isIdentical;
	@Column(name = "MATCH_RATIO")
	private Double matchRatio;
	@Column(name = "EXTERNAL_REFERENCE_NUMBER",length = 50)
	private String externalReferenceNumber;
}
