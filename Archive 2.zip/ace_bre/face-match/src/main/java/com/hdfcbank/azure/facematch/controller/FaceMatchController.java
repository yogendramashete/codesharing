package com.hdfcbank.azure.facematch.controller;

import com.hdfcbank.azure.facematch.constant.AppConstant;
import com.hdfcbank.azure.facematch.enums.Stage;
import com.hdfcbank.azure.facematch.enums.StatusCode;
import com.hdfcbank.azure.facematch.exception.FaceMatchException;
import com.hdfcbank.azure.facematch.model.api.ApiResponse;
import com.hdfcbank.azure.facematch.model.facematch.FaceMatchRequest;
import com.hdfcbank.azure.facematch.model.facematch.FaceMatchResponse;
import com.hdfcbank.azure.facematch.model.log.LogMessage;
import com.hdfcbank.azure.facematch.service.AuditLogService;
import com.hdfcbank.azure.facematch.service.FaceMatchService;
import com.hdfcbank.azure.facematch.service.LoggerService;
import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.info.Contact;
import io.swagger.v3.oas.annotations.info.Info;
import lombok.extern.log4j.Log4j2;
import org.apache.commons.lang3.RandomStringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.util.logging.Level;
import java.util.logging.Logger;

@RestController
@OpenAPIDefinition(info = @Info(title = "Face API",description = "Face Match Service APIs", version = "1.0", contact = @Contact(name = "HDFC Bank", email = "hdfc.suport@hdfcbank.com")))
public class FaceMatchController {
    private static final int CORRELATION_ID_LENGTH = 10;
    private static final Logger LOGGER = Logger.getLogger(FaceMatchController.class.getName());
    @Autowired
    private AuditLogService auditLogService;
    @Autowired
    private FaceMatchService faceMatchService;

    @Autowired
    private LoggerService loggerServiceImpl;

    @Operation(summary = "Face Match", description = "Face match based on Azure Cognitive translation API")
    @ResponseStatus(HttpStatus.OK)
    @PostMapping(value = "/compare", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ApiResponse<FaceMatchResponse>> compare(
            @Valid @RequestBody FaceMatchRequest faceMatchRequest) {
        String correlationId = RandomStringUtils.randomAlphanumeric(CORRELATION_ID_LENGTH);
        LogMessage logMessage = LogMessage.builder().methodName("compare").correlationId(correlationId).externalReferenceNumber(faceMatchRequest.getExternalReferenceNumber()).build();
        loggerServiceImpl.log(logMessage, LOGGER, Level.INFO);
        ApiResponse<FaceMatchResponse> resp = null;

        try {
            FaceMatchResponse faceMatchResponse = faceMatchService.compare(correlationId, faceMatchRequest);

            resp = ApiResponse.<FaceMatchResponse>builder().status(StatusCode.API_SUCCESS.getKey())
                    .message(StatusCode.API_SUCCESS.getValue())
                    .data(faceMatchResponse)
                    .build();
            auditLogService.auditLog(correlationId, faceMatchRequest, resp, Stage.FACE_MATCH_API_SUCCESS.name(),
                    AppConstant.SUCCESS);
        } catch (FaceMatchException e) {
            logMessage.setException(e);
            loggerServiceImpl.log(logMessage, LOGGER, Level.INFO);
            resp = ApiResponse.<FaceMatchResponse>builder().status(StatusCode.API_ERROR.getKey())
                    .message(StatusCode.API_ERROR.getValue())
                    .data(FaceMatchResponse.builder().correlationId(correlationId).externalReferenceNumber(faceMatchRequest.getExternalReferenceNumber()).errorMsg(e.getMessage()).build()).build();
            auditLogService.auditLog(correlationId, faceMatchRequest, resp, Stage.FACE_MATCH_API_FAILURE.name(),
                    e.getMessage());
        }
        return ResponseEntity.status(HttpStatus.OK).header(AppConstant.CORRELATION_ID, correlationId).body(resp);

    }
}
