package com.hdfcbank.azure.facematch.filter;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hdfcbank.azure.facematch.model.facematch.FaceMatchRequest;
import com.hdfcbank.azure.facematch.model.log.LogMessage;
import com.hdfcbank.azure.facematch.service.LoggerService;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StreamUtils;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.InputStream;
import java.util.logging.Level;
import java.util.logging.Logger;

import static com.hdfcbank.azure.facematch.constant.AppConstant.EXTERNAL_REFERENCE_NUMBER;

@AllArgsConstructor
public class MasterFilter extends OncePerRequestFilter {
	private static final Logger LOGGER = Logger.getLogger(MasterFilter.class.getName());
	@Autowired
	private LoggerService loggerServiceImpl;
	private final ObjectMapper objectMapper = new ObjectMapper();

	@Override
	protected void doFilterInternal(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, FilterChain filterChain) throws ServletException, IOException{
		LogMessage logMessage = LogMessage.builder().methodName("doFilterInternal").build();
		try {
			CachedBodyHttpServletRequest cachedBodyHttpServletRequest = new CachedBodyHttpServletRequest(httpServletRequest);
			cachedBodyHttpServletRequest.getInputStream();
			InputStream inputStream = cachedBodyHttpServletRequest.getInputStream();
			byte[] body = StreamUtils.copyToByteArray(inputStream);
			FaceMatchRequest request = objectMapper.readValue(new String(body), FaceMatchRequest.class);
			String externalReferenceNumber = request.getExternalReferenceNumber();
			cachedBodyHttpServletRequest.setAttribute(EXTERNAL_REFERENCE_NUMBER, externalReferenceNumber);
			logMessage.setExternalReferenceNumber(externalReferenceNumber);
			loggerServiceImpl.log(logMessage, LOGGER, Level.INFO);
			filterChain.doFilter(cachedBodyHttpServletRequest, httpServletResponse);
		}catch(Exception e){
			loggerServiceImpl.log(logMessage, LOGGER, Level.INFO);
			throw e;
		}
	}

}
