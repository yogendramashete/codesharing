package com.hdfcbank.azure.facematch.enums;

public enum Stage {
	FACE_MATCH_API_SUCCESS, FACE_MATCH_API_FAILURE
}
