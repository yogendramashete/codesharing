package com.hdfcbank.azure.facematch.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.hdfcbank.azure.facematch.model.entity.FaceMatchAudit;

@Repository
public interface FaceMatchAuditRepository extends JpaRepository<FaceMatchAudit, Long> {

}
