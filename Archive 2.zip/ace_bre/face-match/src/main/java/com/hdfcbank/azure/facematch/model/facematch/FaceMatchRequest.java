package com.hdfcbank.azure.facematch.model.facematch;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.*;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class FaceMatchRequest {

	@JsonProperty(required = true)
	@NotEmpty(message = "sourceImage cannot be empty")
	private byte[] sourceImage;
	@JsonProperty(required = true)
	@NotEmpty(message = "destinationImage cannot be empty")
	private byte[] destinationImage;
	@JsonProperty(required = true)
	@NotBlank(message = "channel cannot be blank")
	private String channel;
	@JsonProperty(required = true)
	@NotBlank(message = "sourceImageSystem cannot be blank")
	private String sourceImageSystem;
	@JsonProperty(required = true)
	@NotBlank(message = "destinationImageSystem cannot be blank")
	private String destinationImageSystem;
	@JsonProperty(required = true)
	@NotBlank(message = "externalReferenceNumber cannot be blank")
	private String externalReferenceNumber;
}
