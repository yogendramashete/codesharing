package com.hdfcbank.azure.facematch.model.log;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import java.lang.reflect.Field;

@Getter
@Setter
@Builder
public class LogMessage {
    private String correlationId;
    private String externalReferenceNumber;
    private String className;
    private String methodName;
    private String message;
    private Exception exception;

    @Override
    public String toString() {
        Field[] fields = LogMessage.class.getDeclaredFields();
        String res = " ";
        for (Field field : fields) {
            try {
                res += (field.get(this)) != null
                        && ((field.getType() == String.class && !(field.get(this)).toString().isBlank()) || field.getType() != String.class)
                        ? field.getName() + " : " + (field.get(this).toString()) + " , " : "";
            } catch (Exception ex) {

            }
        }
        return res.substring(0, res.length() - 1).trim();
    }
}
