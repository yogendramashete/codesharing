package com.hdfcbank.azure.facematch.model.entity;

import lombok.*;
import org.hibernate.annotations.DynamicUpdate;

import javax.persistence.*;

@Table(name = "FACEMATCH_AUDIT")
@Entity
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@DynamicUpdate
public class FaceMatchAudit extends DateAudit {

    private static final long serialVersionUID = -4880627509533388806L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID", nullable = false)
    private Long id;
    @Column(name = "CORRELATION_ID", length = 50, nullable = false)
    private String correlationId;
    @Column(name = "API_CALL", length = 50, nullable = false)
    private String apiCall;
    @Column(name = "REQUEST"/*, columnDefinition = "text"*/)
    @Lob
    private String request;
    @Column(name = "RESPONSE"/*, columnDefinition = "text"*/)
    @Lob
    private String response;
    @Column(name = "REMARK", length = 3000)
    private String remark;
}
