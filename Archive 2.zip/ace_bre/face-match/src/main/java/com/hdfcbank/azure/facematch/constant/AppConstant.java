package com.hdfcbank.azure.facematch.constant;

public class AppConstant {
	
	private AppConstant() {}

	public static final String CORRELATION_ID = "correlationId";
	public static final String SUCCESS = "SUCCESS";
	public static final String FAILURE = "FAILURE";
	public static final String OCTET_MEDIA_TYPE = "application/octet-stream";
	public static final String JSON_MEDIA_TYPE = "application/json";
	public static final String FACE_MATCH_KEY_HEADER = "Ocp-Apim-Subscription-Key";
	public static final String CONTENT_TYPE_HEADER ="Content-Type";
	public static final String EXTERNAL_REFERENCE_NUMBER ="externalReferenceNumber";
	public static final String FACE_NOT_DETECTED ="faceNotDetected";
}
