package com.hdfcbank.azure.facematch.service.impl;

import com.hdfcbank.azure.facematch.exception.FaceMatchException;
import com.hdfcbank.azure.facematch.model.log.LogMessage;
import com.hdfcbank.azure.facematch.service.LoggerService;
import org.springframework.stereotype.Service;

import java.util.logging.Level;
import java.util.logging.Logger;

@Service
public class LoggerServiceImpl implements LoggerService {
    private static final Logger LOGGER = Logger.getLogger(LoggerServiceImpl.class.getName());
    @Override
    public void log(LogMessage logMessage, Logger logger, Level level) throws FaceMatchException {
        try {
            logger.log(level, logMessage.toString());
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Error while logging");
        }
    }

}
