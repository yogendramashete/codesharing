package com.hdfcbank.azure.facematch.model.facematch;

import lombok.*;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class FaceMatchResponse {

	private String correlationId;
	private Boolean isIdentical;
	private Float ratioMatch;
	private String errorMsg;
	private String externalReferenceNumber;
}
