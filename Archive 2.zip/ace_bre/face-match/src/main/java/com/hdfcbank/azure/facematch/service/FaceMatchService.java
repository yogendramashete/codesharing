package com.hdfcbank.azure.facematch.service;

import com.hdfcbank.azure.facematch.exception.FaceMatchException;
import com.hdfcbank.azure.facematch.model.facematch.FaceMatchRequest;
import com.hdfcbank.azure.facematch.model.facematch.FaceMatchResponse;

import java.util.List;

public interface FaceMatchService {

	public FaceMatchResponse compare(String correlationId, FaceMatchRequest faceMatchRequest) throws FaceMatchException;
	public List<String> getFaceIds(String correlationId, byte[] face1, byte[] face2);
}
