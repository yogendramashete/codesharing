package com.hdfcbank.azure.facematch.model.azure.detect.response;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class FaceRectangle {
    int top;
    int left;
    int width;
    int height;
}

