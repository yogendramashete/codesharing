package com.hdfcbank.azure.facematch.repository;

import com.hdfcbank.azure.facematch.model.entity.FaceMatchInformation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface FaceMatchInformationRepository extends JpaRepository<FaceMatchInformation, Long> {
    FaceMatchInformation findByCorrelationId(String correlationId);
}
