package com.hdfcbank.azure.facematch.exception;

public class FaceMatchException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public FaceMatchException() {
		super();
	}

	public FaceMatchException(String message, Throwable cause) {
		super(message, cause);
	}

	public FaceMatchException(String message) {
		super(message);
	}

	public FaceMatchException(Throwable cause) {
		super(cause);
	}
}