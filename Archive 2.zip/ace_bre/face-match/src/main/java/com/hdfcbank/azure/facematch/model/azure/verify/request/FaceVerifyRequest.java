package com.hdfcbank.azure.facematch.model.azure.verify.request;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class FaceVerifyRequest {
    private String faceId1;
    private String faceId2;
}
