package com.hdfcbank.azure.facematch.service.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hdfcbank.azure.facematch.exception.FaceMatchException;
import com.hdfcbank.azure.facematch.model.api.ApiResponse;
import com.hdfcbank.azure.facematch.model.entity.FaceMatchAudit;
import com.hdfcbank.azure.facematch.model.log.LogMessage;
import com.hdfcbank.azure.facematch.repository.FaceMatchAuditRepository;
import com.hdfcbank.azure.facematch.service.AuditLogService;
import com.hdfcbank.azure.facematch.service.LoggerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.logging.Level;
import java.util.logging.Logger;

@Service
public class AuditLogServiceImpl implements AuditLogService {
	private static final Logger LOGGER = Logger.getLogger(AuditLogServiceImpl.class.getName());

	@Autowired
	private ObjectMapper objectMapper;

	@Autowired
	private FaceMatchAuditRepository faceMatchAuditRepository;

	@Autowired
	private LoggerService loggerServiceImpl;

	@Override
	public void auditLog(String correlationId, Object request, ApiResponse<?> response, String apiCall,
			String exceptionMessage) {
		LogMessage logMessage = LogMessage.builder().correlationId(correlationId)
				.methodName("auditLog").className(FaceMatchServiceImpl.class.getName()).build();

		try {
			FaceMatchAudit faceMatchAudit = FaceMatchAudit.builder().correlationId(correlationId).apiCall(apiCall)
					.request(null != request ? objectMapper.writeValueAsString(request) : null)
					.response(null != response ? objectMapper.writeValueAsString(response) : null)
					.remark((null != exceptionMessage && !exceptionMessage.isBlank()) ? exceptionMessage : null)
					.build();
			faceMatchAuditRepository.save(faceMatchAudit);
		} catch (Exception e) {
			logMessage.setException(e);
			logMessage.setMessage("Error saving audit log");
			loggerServiceImpl.log(logMessage, LOGGER, Level.SEVERE);
			throw new FaceMatchException("Error saving audit log " + e.getMessage());
		}

	}
	
}
