package com.hdfcbank.azure.facematch.service;

import com.hdfcbank.azure.facematch.model.api.ApiResponse;

public interface AuditLogService {

	public void auditLog(String correlationId, Object request, ApiResponse<?> response, String stage,
			String exceptionMessage);
}
