package com.hdfcbank.azure.facematch.config;

import com.hdfcbank.azure.facematch.filter.MasterFilter;
import com.hdfcbank.azure.facematch.service.LoggerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.Ordered;

@Configuration
public class FilterRegistrationConfiguration {

	@Bean
	public FilterRegistrationBean<MasterFilter> correlationIdVerificationFilter(@Autowired LoggerService loggerServiceImpl) {
		FilterRegistrationBean<MasterFilter> registrationBean = new FilterRegistrationBean<>();

		registrationBean.setFilter(new MasterFilter(loggerServiceImpl));
		registrationBean.addUrlPatterns("/compare/*");
		registrationBean.setOrder(Ordered.HIGHEST_PRECEDENCE);

		return registrationBean;
	}
}