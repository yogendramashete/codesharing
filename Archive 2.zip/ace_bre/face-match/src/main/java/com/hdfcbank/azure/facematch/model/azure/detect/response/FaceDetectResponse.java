package com.hdfcbank.azure.facematch.model.azure.detect.response;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class FaceDetectResponse {

    private String faceId;
    private FaceRectangle faceRectangle;
    private String recognitionModel;
}
