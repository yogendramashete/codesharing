package com.hdfcbank.azure.facematch.controller;

import com.hdfcbank.azure.facematch.constant.AppConstant;
import com.hdfcbank.azure.facematch.model.api.ApiResponse;
import com.hdfcbank.azure.facematch.model.facematch.FaceMatchResponse;
import com.hdfcbank.azure.facematch.model.log.LogMessage;
import com.hdfcbank.azure.facematch.service.AuditLogService;
import com.hdfcbank.azure.facematch.service.LoggerService;
import org.apache.commons.lang3.RandomStringUtils;
import org.springframework.beans.ConversionNotSupportedException;
import org.springframework.beans.TypeMismatchException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.http.converter.HttpMessageNotWritableException;
import org.springframework.validation.BindException;
import org.springframework.validation.FieldError;
import org.springframework.web.HttpMediaTypeNotAcceptableException;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingPathVariableException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.ServletRequestBindingException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.context.request.async.AsyncRequestTimeoutException;
import org.springframework.web.multipart.support.MissingServletRequestPartException;
import org.springframework.web.servlet.NoHandlerFoundException;

import java.util.Arrays;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;

@ControllerAdvice
public class ExceptionHandlerController {
    private static final int CORRELATION_ID_LENGTH = 10;
    private static final Logger LOGGER = Logger.getLogger(ExceptionHandlerController.class.getName());
    @Autowired
    private LoggerService loggerServiceImpl;

    @Autowired
    private AuditLogService auditLogService;

    @ExceptionHandler( MethodArgumentNotValidException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ResponseBody
    public ResponseEntity<ApiResponse<FaceMatchResponse>> showCustomBadRequestMessage(MethodArgumentNotValidException ex,  WebRequest request) {
        String errorMsg = ex.getBindingResult().getFieldErrors().stream().map(FieldError::getDefaultMessage).collect(Collectors.joining(", "));

        return getResponse("showCustomBadRequestMessage", errorMsg, HttpStatus.BAD_REQUEST, request);
    }

    @ExceptionHandler(MissingServletRequestParameterException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ResponseBody
    public ResponseEntity<ApiResponse<FaceMatchResponse>> showCustomBadRequestMessage(MissingServletRequestParameterException ex,  WebRequest request) {
        String errorMsg = ex.getMessage();
        return getResponse("showCustomBadRequestMessage", errorMsg, HttpStatus.BAD_REQUEST, request);
    }

    @ExceptionHandler( ServletRequestBindingException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ResponseBody
    public ResponseEntity<ApiResponse<FaceMatchResponse>> showCustomBadRequestMessage(ServletRequestBindingException ex,  WebRequest request) {
        String errorMsg = ex.getMessage();
        return getResponse("showCustomBadRequestMessage", errorMsg, HttpStatus.BAD_REQUEST, request);
    }

    @ExceptionHandler(TypeMismatchException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ResponseBody
    public ResponseEntity<ApiResponse<FaceMatchResponse>> showCustomBadRequestMessage(TypeMismatchException ex,  WebRequest request) {
        String errorMsg = ex.getMessage();
        return getResponse("showCustomBadRequestMessage", errorMsg, HttpStatus.BAD_REQUEST, request);
    }

    @ExceptionHandler(HttpMessageNotReadableException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ResponseBody
    public ResponseEntity<ApiResponse<FaceMatchResponse>> showCustomBadRequestMessage(HttpMessageNotReadableException ex,  WebRequest request) {
        String errorMsg = ex.getMessage();
        return getResponse("showCustomBadRequestMessage", errorMsg, HttpStatus.BAD_REQUEST, request);
    }

    @ExceptionHandler( MissingServletRequestPartException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ResponseBody
    public ResponseEntity<ApiResponse<FaceMatchResponse>> showCustomBadRequestMessage(MissingServletRequestPartException ex,  WebRequest request) {
        String errorMsg = ex.getMessage();
        return getResponse("showCustomBadRequestMessage", errorMsg, HttpStatus.BAD_REQUEST, request);
    }

    @ExceptionHandler(BindException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ResponseBody
    public ResponseEntity<ApiResponse<FaceMatchResponse>> showCustomBadRequestMessage(BindException ex,  WebRequest request) {
        String errorMsg = ex.getMessage();
        return getResponse("showCustomBadRequestMessage", errorMsg, HttpStatus.BAD_REQUEST, request);
    }

    @ExceptionHandler(MissingPathVariableException.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    @ResponseBody
    public ResponseEntity<ApiResponse<FaceMatchResponse>> showCustomInternalServerErrorMessage(MissingPathVariableException ex, WebRequest request) {
        String errMsg = "Internal Server Error - Please try after sometime";
        return getResponse("showCustomInternalServerErrorMessage", errMsg, HttpStatus.INTERNAL_SERVER_ERROR, request);
    }

    @ExceptionHandler(ConversionNotSupportedException.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    @ResponseBody
    public ResponseEntity<ApiResponse<FaceMatchResponse>> showCustomInternalServerErrorMessage(ConversionNotSupportedException ex, WebRequest request) {
        String errMsg = "Internal Server Error - Please try after sometime";
        return getResponse("showCustomInternalServerErrorMessage", errMsg, HttpStatus.INTERNAL_SERVER_ERROR, request);
    }

    @ExceptionHandler(HttpMessageNotWritableException.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    @ResponseBody
    public ResponseEntity<ApiResponse<FaceMatchResponse>> showCustomInternalServerErrorMessage(HttpMessageNotWritableException ex, WebRequest request) {
        String errMsg = "Internal Server Error - Please try after sometime";
        return getResponse("showCustomInternalServerErrorMessage", errMsg, HttpStatus.INTERNAL_SERVER_ERROR, request);
    }

    @ExceptionHandler(AsyncRequestTimeoutException.class)
    @ResponseStatus(HttpStatus.SERVICE_UNAVAILABLE)
    @ResponseBody
    public ResponseEntity<ApiResponse<FaceMatchResponse>> showCustomServiceUnavailableMessage(AsyncRequestTimeoutException e, WebRequest request) {
        return getResponse("showCustomServiceUnavailableMessage", "Service Unavailable", HttpStatus.SERVICE_UNAVAILABLE, request);
    }

    @ExceptionHandler(HttpMediaTypeNotAcceptableException.class)
    @ResponseStatus(HttpStatus.NOT_ACCEPTABLE)
    @ResponseBody
    public ResponseEntity<ApiResponse<FaceMatchResponse>> showCustomNotAcceptableMessage(HttpMediaTypeNotAcceptableException e, WebRequest request) {
        return getResponse("showCustomNotAcceptableMessage", "Not Acceptable", HttpStatus.NOT_ACCEPTABLE, request);
    }

    @ExceptionHandler(HttpMediaTypeNotSupportedException.class)
    @ResponseStatus(HttpStatus.UNSUPPORTED_MEDIA_TYPE)
    @ResponseBody
    public ResponseEntity<ApiResponse<FaceMatchResponse>> showCustomUnsupportedMediaTypeMessage(HttpMediaTypeNotSupportedException e, WebRequest request) {
        return getResponse("showCustomUnsupportedMediaTypeMessage", "Unsupported Media Type", HttpStatus.UNSUPPORTED_MEDIA_TYPE, request);
    }

    @ExceptionHandler(HttpRequestMethodNotSupportedException.class)
    @ResponseStatus(HttpStatus.METHOD_NOT_ALLOWED)
    @ResponseBody
    public ResponseEntity<ApiResponse<FaceMatchResponse>> showCustomMethodNotAllowedMessage(HttpRequestMethodNotSupportedException e, WebRequest request) {
        return getResponse("showCustomMethodNotAllowedMessage", "Method Not Allowed", HttpStatus.METHOD_NOT_ALLOWED, request);

    }

    @ExceptionHandler(NoHandlerFoundException.class)
    @ResponseStatus(HttpStatus.NOT_FOUND)
    @ResponseBody
    public ResponseEntity<ApiResponse<FaceMatchResponse>> showCustomNotFoundMessage(NoHandlerFoundException e, WebRequest request) {
        return getResponse("showCustomNotFoundMessage", "Not Found", HttpStatus.NOT_FOUND, request);
    }

    private ResponseEntity<ApiResponse<FaceMatchResponse>> getResponse(String methodName, String errorMsg, HttpStatus status, WebRequest request) {
        String correlationId = RandomStringUtils.randomAlphanumeric(CORRELATION_ID_LENGTH);
        String externalReferenceNumber = (String) request.getAttribute(AppConstant.EXTERNAL_REFERENCE_NUMBER, 0);
        LogMessage logMessage = LogMessage.builder().methodName(methodName).correlationId(correlationId).externalReferenceNumber(externalReferenceNumber).build();
        logMessage.setMessage(errorMsg);
        loggerServiceImpl.log(logMessage, LOGGER, Level.INFO);

        ApiResponse<FaceMatchResponse> resp = ApiResponse.<FaceMatchResponse>builder().status(status.value())
                .message(status.getReasonPhrase())
                .data(FaceMatchResponse.builder().correlationId(correlationId).externalReferenceNumber(externalReferenceNumber).errorMsg(errorMsg).build()).build();
        auditLogService.auditLog(correlationId, null, resp, status.name(),
                errorMsg);

        return ResponseEntity.status(status).body(resp);
    }
}