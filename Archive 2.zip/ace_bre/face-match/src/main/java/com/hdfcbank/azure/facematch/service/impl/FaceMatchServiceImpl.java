package com.hdfcbank.azure.facematch.service.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hdfcbank.azure.facematch.constant.AppConstant;
import com.hdfcbank.azure.facematch.exception.FaceMatchException;
import com.hdfcbank.azure.facematch.model.azure.detect.response.FaceDetectResponse;
import com.hdfcbank.azure.facematch.model.azure.verify.request.FaceVerifyRequest;
import com.hdfcbank.azure.facematch.model.azure.verify.response.FaceVerifyResponse;
import com.hdfcbank.azure.facematch.model.entity.FaceMatchInformation;
import com.hdfcbank.azure.facematch.model.facematch.FaceMatchRequest;
import com.hdfcbank.azure.facematch.model.facematch.FaceMatchResponse;
import com.hdfcbank.azure.facematch.model.log.LogMessage;
import com.hdfcbank.azure.facematch.repository.FaceMatchInformationRepository;
import com.hdfcbank.azure.facematch.service.FaceMatchService;
import com.hdfcbank.azure.facematch.service.LoggerService;
import com.squareup.okhttp.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

@Service
public class FaceMatchServiceImpl implements FaceMatchService {
    private static final Logger LOGGER = Logger.getLogger(FaceMatchServiceImpl.class.getName());

    @Value("${microsoft.facematch.detect.url}")
    private String faceMatchDetectUrl;

    @Value("${microsoft.facematch.verify.url}")
    private String faceMatchVerifyUrl;

    @Value("${microsoft.facematch.key}")
    private String faceMatchKey;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private LoggerService loggerServiceImpl;

    @Autowired
    private FaceMatchInformationRepository faceMatchInformationRepository;

    @Override
    public FaceMatchResponse compare(String correlationId, FaceMatchRequest faceMatchRequest)
            throws FaceMatchException {
        LogMessage logMessage = LogMessage.builder().correlationId(correlationId).externalReferenceNumber(faceMatchRequest.getExternalReferenceNumber())
                .methodName("compare").className(FaceMatchServiceImpl.class.getName()).build();
        try {
            saveFaceMatchRequest(correlationId, faceMatchRequest);
            List<String> faceIdList = getFaceIds(correlationId, faceMatchRequest.getSourceImage(), faceMatchRequest.getDestinationImage());
            String externalReferenceNumber = faceMatchRequest.getExternalReferenceNumber();
            if (faceIdList.contains(AppConstant.FACE_NOT_DETECTED)) {
                FaceMatchResponse faceMatchResponse =  FaceMatchResponse.builder().ratioMatch(0f).isIdentical(false).correlationId(correlationId).externalReferenceNumber(externalReferenceNumber).build();
                saveFaceMatchResult(correlationId, faceMatchResponse.getRatioMatch(), faceMatchResponse.getIsIdentical());
                return faceMatchResponse;
            } else {
                OkHttpClient client = new OkHttpClient();
                MediaType mediaTypeJson = MediaType.parse("application/json");
                FaceVerifyRequest faceVerifyRequest = FaceVerifyRequest.builder().faceId1(faceIdList.get(0)).faceId2(faceIdList.get(1)).build();
                RequestBody body = RequestBody.create(mediaTypeJson, objectMapper.writeValueAsString(faceVerifyRequest));
                Request request = new Request.Builder().url(faceMatchVerifyUrl).post(body)
                        .addHeader(AppConstant.FACE_MATCH_KEY_HEADER, faceMatchKey)
                        .addHeader(AppConstant.CONTENT_TYPE_HEADER, AppConstant.JSON_MEDIA_TYPE).build();
                Response response = client.newCall(request).execute();
                if (!response.isSuccessful())
                    throw new FaceMatchException("Error from Face Match Verify API");

                FaceVerifyResponse faceVerifyResponse = objectMapper.readValue(response.body().string(), FaceVerifyResponse.class);
                FaceMatchResponse faceMatchResponse = FaceMatchResponse.builder().ratioMatch(faceVerifyResponse.getConfidence() * 100f).isIdentical(faceVerifyResponse.getIsIdentical()).correlationId(correlationId).externalReferenceNumber(externalReferenceNumber).build();
                saveFaceMatchResult(correlationId, faceMatchResponse.getRatioMatch(), faceMatchResponse.getIsIdentical());
                logMessage.setMessage("Face compared detected");
                loggerServiceImpl.log(logMessage, LOGGER, Level.INFO);
                return faceMatchResponse;
            }
        } catch (Exception e) {
            logMessage.setException(e);
            loggerServiceImpl.log(logMessage, LOGGER, Level.SEVERE);
            throw new FaceMatchException(e.getMessage());
        }
    }

    @Override
    public List<String> getFaceIds(String correlationId, byte[] faceImage1, byte[] faceImage2) {
        return List.of(getFaceId(correlationId, faceImage1), getFaceId(correlationId, faceImage2));
    }

    private String getFaceId(String correlationId, byte[] faceImage) {
        LogMessage logMessage = LogMessage.builder().correlationId(correlationId)
                .methodName("getFaceId").className(FaceMatchServiceImpl.class.getName()).build();
        MediaType mediaType = MediaType.parse(AppConstant.OCTET_MEDIA_TYPE);
        RequestBody body = RequestBody.create(mediaType, faceImage);

        OkHttpClient client = new OkHttpClient();

        Request request = new Request.Builder().url(faceMatchDetectUrl).post(body)
                .addHeader(AppConstant.FACE_MATCH_KEY_HEADER, faceMatchKey)
                .addHeader(AppConstant.CONTENT_TYPE_HEADER, AppConstant.OCTET_MEDIA_TYPE).build();
        try {
            Response response = client.newCall(request).execute();
            String json = response.body().string();
            FaceDetectResponse[] faceResponse = new ObjectMapper().readValue(json, FaceDetectResponse[].class);
            if (faceResponse.length == 0)
                throw new FaceMatchException("No face detected");

            logMessage.setMessage("Face detected");
            loggerServiceImpl.log(logMessage, LOGGER, Level.INFO);
            return faceResponse[0].getFaceId();
        } catch (Exception e) {
            logMessage.setException(e);
            logMessage.setMessage("Error while calling face detect API");
            loggerServiceImpl.log(logMessage, LOGGER, Level.SEVERE);
            return AppConstant.FACE_NOT_DETECTED;
        }
    }

    @Transactional
    private void saveFaceMatchRequest(String correlationId, FaceMatchRequest faceMatchRequest) throws FaceMatchException {
        LogMessage logMessage = LogMessage.builder().correlationId(correlationId)
                .methodName("getFaceId").className(FaceMatchServiceImpl.class.getName()).build();
        try {
            FaceMatchInformation faceMatchInformation = FaceMatchInformation.builder()
                    .correlationId(correlationId).destinationImageSystem(faceMatchRequest.getDestinationImageSystem())
                    .sourceImageSystem(faceMatchRequest.getSourceImageSystem()).externalReferenceNumber(faceMatchRequest.getExternalReferenceNumber())
                    .channel(faceMatchRequest.getChannel()).build();
            faceMatchInformationRepository.save(faceMatchInformation);
            logMessage.setMessage("Face match request saved");
            loggerServiceImpl.log(logMessage, LOGGER, Level.INFO);
        } catch (Exception e) {
            logMessage.setException(e);
            logMessage.setMessage("Error while calling face detect API");
            loggerServiceImpl.log(logMessage, LOGGER, Level.SEVERE);
            throw new FaceMatchException(e.getMessage());
        }
    }

    @Transactional
    private void saveFaceMatchResult(String correlationId, double matchRatio, boolean isIdentical) throws FaceMatchException {
        LogMessage logMessage = LogMessage.builder().correlationId(correlationId)
                .methodName("saveFaceMatchResult").className(FaceMatchServiceImpl.class.getName()).build();
        try {
            FaceMatchInformation faceMatchInformation = faceMatchInformationRepository.findByCorrelationId(correlationId);
            faceMatchInformation.setMatchRatio(matchRatio);
            faceMatchInformation.setIsIdentical(isIdentical);
            faceMatchInformationRepository.save(faceMatchInformation);
            logMessage.setMessage("Face match result saved");
            loggerServiceImpl.log(logMessage, LOGGER, Level.INFO);
        } catch (Exception e) {
            logMessage.setException(e);
            logMessage.setMessage("Error while calling face detect API");
            loggerServiceImpl.log(logMessage, LOGGER, Level.SEVERE);
            throw new FaceMatchException(e.getMessage());
        }
    }
}
