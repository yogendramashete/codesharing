package com.hdfcbank.azure.facematch.service;

import com.hdfcbank.azure.facematch.exception.FaceMatchException;
import com.hdfcbank.azure.facematch.model.log.LogMessage;

import java.util.logging.Level;
import java.util.logging.Logger;

public interface LoggerService {
    public void log(LogMessage logMessage, Logger logger, Level level) throws FaceMatchException;
}
