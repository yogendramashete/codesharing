package com.hdfcbank.azure.facematch.model.azure.verify.response;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class FaceVerifyResponse {
    private Boolean isIdentical;
    private Float confidence;
}
