package com.hdfcbank.azure.facematch.util.passenc;

import org.jasypt.encryption.pbe.PooledPBEStringEncryptor;
import org.jasypt.encryption.pbe.config.SimpleStringPBEConfig;

public class CreateEncPassword {
	public static void main(String[] args) {//MNtZVY1HjGU8zQy6UbBlAz36L
		try {
			encryptKey("faceMatchService","da8532695f8f469ab9097af635cba2a5");
			encryptKey("faceMatchService","sa");
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
		//decryptKey("hdfcFlywirePr0d","Uva27BUinMx9MtaL7F/PpdKV2DEJF//2NgrB9390ES99nkSVqU24jw=");
	}

	// encrypt the plain text
	private static void encryptKey(final String password, final String plainKey) {
		final SimpleStringPBEConfig pbeConfig = new SimpleStringPBEConfig();
		pbeConfig.setPassword(password);
		pbeConfig.setPoolSize(1);

		final PooledPBEStringEncryptor pbeStringEncryptor = new PooledPBEStringEncryptor();
		pbeStringEncryptor.setConfig(pbeConfig);

		System.out.println("Encrypted key = " + pbeStringEncryptor.encrypt(plainKey));
	}

	// decrypt the encrypted text
	private static void decryptKey(final String password,final String encryptedKey) {
		final SimpleStringPBEConfig pbeConfig = new SimpleStringPBEConfig();
		pbeConfig.setPassword(password);
		pbeConfig.setPoolSize(1);

		final PooledPBEStringEncryptor pbeStringEncryptor = new PooledPBEStringEncryptor();
		pbeStringEncryptor.setConfig(pbeConfig);

		System.out.println("Decrypted key = " + pbeStringEncryptor.decrypt(encryptedKey));
	}

}
