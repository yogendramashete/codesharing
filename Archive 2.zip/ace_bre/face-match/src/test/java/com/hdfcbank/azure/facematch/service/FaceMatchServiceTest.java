package com.hdfcbank.azure.facematch.service;


import com.hdfcbank.azure.facematch.model.facematch.FaceMatchRequest;
import com.hdfcbank.azure.facematch.model.facematch.FaceMatchResponse;
import org.hamcrest.CoreMatchers;
import org.hamcrest.MatcherAssert;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Random;
import java.util.UUID;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;

@RunWith(SpringRunner.class)
class FaceMatchServiceTest {


    @Test
    void testCompareFaces() throws Exception {

        byte[] face1 = Files.readAllBytes(Paths.get("src", "test", "resources", "images", "mark1.jpeg"));
        byte[] face2 = Files.readAllBytes(Paths.get("src", "test", "resources", "images", "mark2.jpeg"));

        String correlationId = UUID.randomUUID().toString();
        String externalReferenceNumber = String.valueOf(new Random().nextInt());
        FaceMatchResponse mockFaceMatchResponse = FaceMatchResponse.builder().isIdentical(true).ratioMatch(90f).correlationId(correlationId).build();
        FaceMatchService faceMatchServiceImpl = Mockito.mock(FaceMatchService.class);

        FaceMatchRequest faceMatchRequest = FaceMatchRequest.builder().sourceImage(face1).destinationImage(face2)
                .sourceImageSystem("Selfie").destinationImageSystem("aadhaar")
                .externalReferenceNumber(externalReferenceNumber).build();
        Mockito.when(faceMatchServiceImpl.compare(anyString(),any(FaceMatchRequest.class))).thenReturn(mockFaceMatchResponse);
        FaceMatchResponse faceMatchResponse = faceMatchServiceImpl.compare(correlationId, faceMatchRequest);

        Assertions.assertTrue(faceMatchResponse.getIsIdentical());
        MatcherAssert.assertThat(faceMatchResponse.getRatioMatch(), CoreMatchers.is(Matchers.greaterThanOrEqualTo(90f)));
    }
}
