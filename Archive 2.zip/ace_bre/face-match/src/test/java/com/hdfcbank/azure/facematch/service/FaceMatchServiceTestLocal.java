package com.hdfcbank.azure.facematch.service;

import com.hdfcbank.azure.facematch.model.facematch.FaceMatchRequest;
import com.hdfcbank.azure.facematch.model.facematch.FaceMatchResponse;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.Random;
import java.util.UUID;

//@SpringBootTest
public class FaceMatchServiceTestLocal {

    @Autowired
    private FaceMatchService faceMatchServiceImpl;

    //@Test
    void testCompareFaces() throws Exception {
        String basePath = "/Users/y3875/Library/CloudStorage/OneDrive-HDFCBANK/documents/projects/Face Match service/data/Photos";
        File[] listOfFiles = new File(basePath).listFiles();
        String outputFile = "/Users/y3875/Library/CloudStorage/OneDrive-HDFCBANK/documents/projects/Face Match service/data/output.csv";
        String content = "FileName 1, Filename1 face detected, filename2, filename2 face detected, faces identical, facematch ratio";
        Files.write(Paths.get(outputFile),content.getBytes(), StandardOpenOption.WRITE);

        for (int i = 0; i < listOfFiles.length; i++) {
            for (int j = i + 1; j < listOfFiles.length; j++) {
                try {
                    callAPI(listOfFiles[i], listOfFiles[j], outputFile);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private void callAPI(File faceF1, File faceF2, String fileName) throws IOException {
        byte[] face1 = Files.readAllBytes(Paths.get(faceF1.getAbsolutePath()));
        byte[] face2 = Files.readAllBytes(Paths.get(faceF2.getAbsolutePath()));

        String correlationId = UUID.randomUUID().toString();
        FaceMatchRequest faceMatchRequest = FaceMatchRequest.builder().sourceImage(face1).destinationImage(face2)
                .sourceImageSystem("Selfie").destinationImageSystem("aadhaar")
                .externalReferenceNumber(String.valueOf(new Random().nextInt(0,99999))).build();
        FaceMatchResponse faceMatchResponse = faceMatchServiceImpl.compare(correlationId, faceMatchRequest);
        String contentToAppend = faceF1.getName() + "," + faceF2.getName() + "," + faceMatchResponse.getIsIdentical() + "," + faceMatchResponse.getRatioMatch();
        Files.write(Paths.get(fileName),contentToAppend.getBytes(), StandardOpenOption.APPEND);
        //System.out.println(faceF1.getName() + "," + faceF2.getName() + "," + faceMatchResponse.getIsIdentical() + "," + faceMatchResponse.getRatioMatch());
    }
}
