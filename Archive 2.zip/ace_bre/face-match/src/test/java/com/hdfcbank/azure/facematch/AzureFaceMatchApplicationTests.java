package com.hdfcbank.azure.facematch;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.hdfcbank.azure.facematch.controller.FaceMatchController;

@SpringBootTest
class AzureFaceMatchApplicationTests {
	
	@Autowired
	private FaceMatchController faceMatchController;

	@Test
	void contextLoads() {
		assertNotNull(faceMatchController);
	}

}
