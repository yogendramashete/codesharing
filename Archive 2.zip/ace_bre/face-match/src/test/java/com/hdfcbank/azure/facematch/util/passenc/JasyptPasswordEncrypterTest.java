package com.hdfcbank.azure.facematch.util.passenc;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JasyptPasswordEncrypterTest {

	@Value("${microsoft.facematch.key}")
	private String faceMatchKey;

	@Test
	void whenDecryptedPasswordNeeded_GetFromService() {
		assertEquals("da8532695f8f469ab9097af635cba2a5", faceMatchKey);
	}

}
