package com.hdfcbank.elengine.domain.enums;

import com.hdfcbank.elengine.constant.AppConstants;

public enum PerfiosVendorId {
	SEB(AppConstants.SME_VENDOR_ID), SEP(AppConstants.SME_VENDOR_ID), SD(AppConstants.VENDOR_ID);

	private final String code;

	private PerfiosVendorId(String code) {
		this.code = code;
	}

	public String toInt() {
		return code;
	}

	public String toString() {
		return String.valueOf(code);
	}
}
