package com.hdfcbank.elengine.domain.enums;

public enum BreServiceType {
	blapp, ftnr, bl_bre1b, blbre2a, blbre2b, blbre2c,GetBureauOffer,GetIncomeBasedOffer,GetSTPNonSTPDecision
}
