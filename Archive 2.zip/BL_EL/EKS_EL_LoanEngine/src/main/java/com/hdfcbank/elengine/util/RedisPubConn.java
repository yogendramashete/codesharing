package com.hdfcbank.elengine.util;

import java.math.BigInteger;
import java.util.HashSet;
import java.util.Set;

import org.apache.commons.pool2.impl.GenericObjectPoolConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import redis.clients.jedis.HostAndPort;
import redis.clients.jedis.JedisCluster;

@Service
public class RedisPubConn {

	private static Logger logger = LoggerFactory.getLogger(RedisPubConn.class);
	private String redisUrl = "sony-kbc-redis-clu.uunfd0.clustercfg.use1.cache.amazonaws.com";

	private int redisPort = 6379;

	protected static final int DEFAULT_TIMEOUT = 1500;
	protected static final int DEFAULT_MAX_REDIRECTIONS = 3;
	private static int jedisClusterCount = 0;
	public static long SECONDS_IN_DAY = 86400;
	public static long SECONDS_IN_WEEK = 604800;
	private static final int MAXSIZE = 5;
	int mb = 1024 * 1024;
	private boolean redisInit = false;
	Set<HostAndPort> jedisClusterNodes = new HashSet<>();
	GenericObjectPoolConfig config = null;

	private GenericObjectPoolConfig initPoolConfiguration() {
		GenericObjectPoolConfig config = new GenericObjectPoolConfig();

		config.setLifo(true);
		config.setTestOnBorrow(true);
		config.setTestOnReturn(false);
		config.setBlockWhenExhausted(false);
		config.setMinIdle(1); // keep 10% hot always
		config.setMaxIdle(5);
		config.setMaxTotal(MAXSIZE);
		config.setTestWhileIdle(false);
		config.setSoftMinEvictableIdleTimeMillis(3000L);
		config.setNumTestsPerEvictionRun(5);
		config.setTimeBetweenEvictionRunsMillis(5000L);
		config.setJmxEnabled(false);

		return config;
	}

	// NEW-REDISCLUSTER CONNECTION - FIX -02May2019
	static JedisCluster jedisCluster = null;

	public JedisCluster openConnection(String redisURL, int redisPort) {
		logger.info("createInstanceJedisCluster");
		// NEW-REDISCLUSTER CONNECTION - FIX -02May2019
		// JedisCluster jedisCluster = null;
		try {
			if (redisInit == false) {
				HostAndPort hostAndPort = new HostAndPort(redisURL, redisPort);
				jedisClusterNodes.add(hostAndPort);
				config = initPoolConfiguration();
				redisInit = true;
			}

			long before = System.currentTimeMillis();
			// NEW-REDISCLUSTER CONNECTION - FIX -02May2019
			if (null == jedisCluster) {
				jedisCluster = new JedisCluster(jedisClusterNodes, DEFAULT_TIMEOUT, DEFAULT_MAX_REDIRECTIONS, config);

			}

			long after = System.currentTimeMillis();

			// Map<String, JedisPool> nodes =jedisCluster.getClusterNodes();
			// System.out.println("jedisClusterCoun nodes: " + nodes);
			Runtime runtime = Runtime.getRuntime();
			logger.info("jedisClusterCount_Time_Taken: " + (after - before) + " :Count: " + jedisClusterCount++
					+ " Used_Memory:" + (runtime.totalMemory() - runtime.freeMemory()) / mb);

		} catch (Exception e) {
			e.printStackTrace();
			logger.error("createInstanceJedisCluster==" + e + " jedisClusterCount:" + jedisClusterCount + "--> "
					+ e.getMessage());
		}
		return jedisCluster;
	}

	private JedisCluster openConnection() {
		// System.out.println("createInstanceJedisCluster");
		// NEW-REDISCLUSTER CONNECTION - FIX -02May2019
		// JedisCluster jedisCluster = null;
		try {
			if (redisInit == false) {
				logger.info("openConnection_redisInit");
				HostAndPort hostAndPort = new HostAndPort(redisUrl, 6379);
				jedisClusterNodes.add(hostAndPort);
				config = initPoolConfiguration();
				redisInit = true;
			}

			long before = System.currentTimeMillis();
			// NEW-REDISCLUSTER CONNECTION - FIX -02May2019
			if (null == jedisCluster) {
				System.out.println("RedisCluster:null == jedisCluster: ");
				jedisCluster = new JedisCluster(jedisClusterNodes, DEFAULT_TIMEOUT, DEFAULT_MAX_REDIRECTIONS, config);

			}

			long after = System.currentTimeMillis();

			// Map<String, JedisPool> nodes =jedisCluster.getClusterNodes();
			// System.out.println("jedisClusterCoun nodes: " + nodes);
			Runtime runtime = Runtime.getRuntime();
			System.out.println("jedisClusterCount_Time_Taken: " + (after - before) + " :Count: " + jedisClusterCount++
					+ " Used_Memory:" + (runtime.totalMemory() - runtime.freeMemory()) / mb);

		} catch (Exception e) {
			e.printStackTrace();
			System.err.println("createInstanceJedisCluster==" + e + " jedisClusterCount:" + jedisClusterCount + "---> "
					+ e.getMessage());
		}
		return jedisCluster;
	}

	/*
	 * private void closeConnection(JedisCluster jedis) { //
	 * System.out.println("closeConnection: " + redisPool.getNumActive()); if (null
	 * == jedis) { return; } try { jedis.close(); } catch (IOException e) {
	 * System.err.println("closeConnection exp : ", e); }finally { //jedis = null; }
	 * }
	 */
	public Long getNextUserProfileId() {
		// System.out.println("getNextUserProfileId Start");
		JedisCluster jedis = openConnection();
		long ret = 0;
		if (null != jedis) {
			ret = jedis.incr("UserProfileID");
			//// closeConnection(jedis);
		}
		// System.out.println("getNextUserProfileId End " + ret);
		//// jedis = null;
		return ret;
	}

	public Long getNextDeviceInfoID() {
		// System.out.println("getNextDeviceInfoID");
		JedisCluster jedis = openConnection();
		long ret = 0;
		if (null != jedis) {
			ret = jedis.incr("DeviceInfoID");
			// closeConnection(jedis);
		}
		// System.out.println("getNextDeviceInfoID End");
		// jedis = null;
		return ret;
	}

	public Long incrSocialLoginCounts(String key) {
		// System.out.println("incrSocialLoginCounts Start:" + key);
		JedisCluster jedis = openConnection();
		long ret = 0;
		if (null != jedis) {
			ret = jedis.incr(key);
			// closeConnection(jedis);
		}
		// jedis = null;
		// System.out.println("incrSocialLoginCounts End:" + ret);
		return ret;
	}

	public Long del(String key) {
		// System.out.println("del Start:" + key);
		JedisCluster jedis = openConnection();
		Long redisKeyId = null;
		if (null != jedis) {
			redisKeyId = jedis.del(key);
			// closeConnection(jedis);
		}
		// jedis = null;
		// System.out.println("del End");
		return redisKeyId;
	}

	public String setStrings(String key, String value) {
		// System.out.println("setStrings key:" + key + " " + value);
		JedisCluster jedis = openConnection();
		String redisKeyId = null;
		if (null != jedis) {
			redisKeyId = jedis.set(key, value);
			// closeConnection(jedis);
		}
		// System.out.println("setStrings End");
		// jedis = null;
		return redisKeyId;
	}

	public void setexpire(String redisKeyId, int seconds) {
		// System.out.println("setexpire Start:" + redisKeyId + " " + seconds);
		JedisCluster jedis = openConnection();
		if (null != jedis) {
			jedis.expire(redisKeyId, seconds);
			// closeConnection(jedis);
		}
		// System.out.println("setexpire End");
		// jedis = null;
	}

	public Long incrUserDataEntryCounts(String key) {
		// System.out.println("incrUserDataEntryCounts Start:" + key);
		JedisCluster jedis = openConnection();
		long ret = 0;
		if (null != jedis) {
			ret = jedis.incr(key);
			// closeConnection(jedis);
		}
		// System.out.println("incrUserDataEntryCounts End:" + ret);
		// jedis = null;
		return ret;
	}

	public Double incrUserRewardPoints(String key, long value, int userProfileId) {
		// System.out.println("incrUserRewardPoints Start:" + key + " " + value + " " +
		// userProfileId);
		JedisCluster jedis = openConnection();
		Double ret = (double) 0;
		if (null != jedis) {
			ret = jedis.zincrby(key, (double) value, String.valueOf(userProfileId));
			// closeConnection(jedis);
			if (null == ret) {
				ret = (double) 0;
			}
		}
		// System.out.println("incrUserRewardPoints End:" + ret);
		// jedis = null;
		return ret;
	}

	public Long getUserRank(String key, BigInteger userProfileId) {
		// System.out.println("getUserRank:Start" + key + " " + userProfileId);
		Long ret = 0l;
		JedisCluster jedis = openConnection();
		try {
			if (null != jedis) {
				ret = jedis.zrevrank(key, String.valueOf(userProfileId));
			}
		} catch (Exception e) {
			System.err.println("Exception:getUserRank:" + key + " :" + userProfileId + " -- >" + e.getMessage());
			ret = 0l;
		} finally {
			// closeConnection(jedis);
			// jedis = null;
		}
		if (ret == null) {
			ret = 0l;
		}
		// System.out.println("getUserRank:End:" + ret);
		return ret + 1; // as redis rank start with 0
	}

	public Long getUserScore(String key, BigInteger userProfileId) {
		// System.out.println("getUserScore:key "+ key +" userProfileId:" +
		// userProfileId);
		Long ret = 0l;
		JedisCluster jedis = openConnection();
		try {
			if (null != jedis) {
				Double score = jedis.zscore(key, userProfileId + "");
				if (null != score)
					ret = score.longValue();
			}
		} catch (Exception e) {
			System.err.println("Exception:getUserScore:" + key + ":userid:" + userProfileId + "-->" + e.getMessage());
			ret = 0l;
		} finally {
			// closeConnection(jedis);
			// jedis = null;
		}
		if (ret == null) {
			ret = 0l;
		}
		return ret;
	}

	public Set<String> zrevrange(String key, long maxRange) {
		// System.out.println("zrevrange:Start:" + key + ":" + maxRange);
		Set<String> keys = null;
		JedisCluster jedis = openConnection();
		try {
			if (null != jedis) {
				keys = jedis.zrevrange(key, 0, maxRange); // descending
			}
		} catch (Exception e) {
			System.err.println("Exception:zrevrange:" + key + ":" + maxRange + "-->" + e.getMessage());
			keys = null;
		} finally {
			// closeConnection(jedis);
			// jedis = null;
		}
		// System.out.println("zrevrangeEnd:"+ keys);
		return keys;
	}

	public Set<String> zrevrange(String key, long startRange, long maxRange) {
		// System.out.println("zrevrange:" + key + " Start "+ startRange + " maxRange
		// "+maxRange);
		Set<String> keys = null;
		JedisCluster jedis = openConnection();
		try {
			if (null != jedis) {
				keys = jedis.zrevrange(key, startRange, maxRange); // descending
			}
		} catch (Exception e) {
			System.err.println("Exception:zrevrange:" + key + " Start:" + startRange + " maxRange:" + maxRange + "-->"
					+ e.getMessage());
			keys = null;
		} finally {
			// closeConnection(jedis);
			// jedis = null;
		}
		// System.out.println("zrevrange:End:" + keys);
		return keys;
	}

	public String getUserInfo(String key) {
		// System.out.println("getUserInfo:Start:" + key);
		String userInfo = null;
		JedisCluster jedis = openConnection();
		try {
			if (null != jedis) {
				userInfo = jedis.get(key);
			}
		} catch (Exception e) {
			System.err.println("Exception:getUserInfo:" + key + "-->" + e.getMessage());
			userInfo = null;
		} finally {
			// closeConnection(jedis);
			// jedis = null;
		}
		// System.out.println("getUserInfo:End:"+userInfo);
		return userInfo;
	}

	public void sAddData(String key, String value) {
		// System.out.println("sAddData:Start:" + key + ":" + value);
		JedisCluster jedis = openConnection();
		try {
			if (null != jedis) {
				jedis.sadd(key, value);
			}
		} catch (Exception e) {
			System.err.println("Exception:sAddData:" + key + ":" + value + "-->" + e.getMessage());
		} finally {
			// closeConnection(jedis);
			// jedis = null;
		}
		// System.out.println("sAddData:End");
	}

	public Set<String> sMembersData(String key) {
		// System.out.println("sMembersData:Start:" + key);
		Set<String> data = null;
		JedisCluster jedis = openConnection();
		try {
			if (null != jedis) {
				data = jedis.smembers(key);
			}
		} catch (Exception e) {
			System.err.println("Exception:sMembersData:" + e.getMessage());
			data = null;
		} finally {
			// closeConnection(jedis);
			// jedis = null;
		}
		// System.out.println("sMembersData:End:" + data);
		return data;
	}

	public String getProgramInfo(String string) {
		// System.out.println("getProgramInfo:" + string);
		String programInfo = null;
		JedisCluster jedis = openConnection();
		try {
			if (null != jedis) {
				programInfo = jedis.get(string);
			}
		} catch (Exception e) {
			System.err.println("Exception:getProgramInfo:" + string + "" + e.getMessage());
		} finally {
			// closeConnection(jedis);
			// jedis = null;
		}
		// System.out.println("getProgramInfo:" + programInfo);
		return programInfo;
	}

	/*
	 * public Set<String> getAllKeysByPattren(String pattren) { //
	 * System.out.println("getAllKeysByPattren:" + pattren); JedisCluster jedis =
	 * openConnection(); Set<String> keys = null; try { if (null != jedis) { keys =
	 * jedis.keys(pattren);
	 * 
	 * } } catch (Exception e) { System.err.println("Exception:getAllKeysByPattren:"
	 * + pattren, e); }finally { closeConnection(jedis); } //
	 * System.out.println("getAllKeysByPattren:End" + keys); return keys; }
	 */

	public String getRedisValue(String key) {
		// System.out.println("getRedisValue:" + key);
		String userInfo = null;
		JedisCluster jedis = openConnection();
		try {
			if (null != jedis) {
				return jedis.get(key);
			}
		} catch (Exception e) {
			System.err.println("Exception:getRedisValue:" + key + "--> " + e.getMessage());
		} finally {
			// closeConnection(jedis);
			// jedis = null;
		}
		// System.out.println("getRedisValue:End:" + userInfo);
		return userInfo;
	}

	/*
	 * public Set<String> getKeys(String pattern) { // System.out.println("getKeys:"
	 * + pattern); Set<String> keys = null; JedisCluster jedis = openConnection();
	 * try { if (null != jedis) { return jedis.keys(pattern); } }catch (Exception e)
	 * { System.err.println("Exception :getKeys:" + pattern, e); }finally {
	 * //closeConnection(jedis); } // System.out.println("getKeys:" + keys); return
	 * keys; }
	 */

	public String readRedisHash(String key, String hash) {
		// System.out.println("readRedisHash:" + key + " " + hash);
		String value = null;
		JedisCluster jedis = openConnection();
		try {
			if (null != jedis) {
				value = jedis.hget(key, hash);
			}
		} catch (Exception e) {
			System.err.println("Exception :readRedisHash:" + key + " :" + hash + "---> " + e.getMessage());
		} finally {
			// closeConnection(jedis);
			// jedis = null;
		}
		return value;
	}

//	public static void main(String args[]) {
//		/*
//		 * String message =
//		 * "{\"companion_ads_height\":false,\"sponsor_questions\":{\"user_fields\":[\"age\",\"location\",\"mobile\",\"gender\"],\"width\":\"100\",\"url\":\"https://docs.google.com/forms/u/0/\",\"height\":\"300\"},\"channel\":\"sony.kbc\",\"companion_ads_width\":false,\"type\":\"waiting\",\"ads_unit_path\":null,\"companion_ads_require\":0,\"urls\":{\"image\":null,\"sponsor_questions\":null},\"media_type\":\"sponsor_questions\",\"width\":null,\"vast_tag_url\":null,\"footer_ads\":\"true\",\"height\":null,\"video_id\":null}";
//		 * try{ JSONParser parser = new JSONParser(); JSONObject json = (JSONObject)
//		 * parser.parse(message); System.out.println("json :" + json);
//		 * Map<String,String> urlsmap = (Map<String,String>)json.get("urls");
//		 * System.out.println("urlsmap :" + urlsmap); Map<String,String>
//		 * sponsorQuestionsMap = (Map<String,String>)json.get("sponsor_questions");
//		 * if(json != null){ if(json.containsKey("urls")){ json.remove("urls");
//		 * json.putAll(urlsmap); } if(json.containsKey("sponsor_questions")){
//		 * json.remove("sponsor_questions"); json.putAll(sponsorQuestionsMap); } message
//		 * = json.toJSONString(); } System.out.println("message --->"+message);
//		 * ObjectMapper mapper = new ObjectMapper(); HashMap<String, Object> datamap =
//		 * mapper.readValue(message, new TypeReference<HashMap<String, Object>>() {});
//		 * System.out.println("Map Message "+datamap);
//		 * 
//		 * System.out.println("Calendar Week "+Calendar.getInstance().get(Calendar.
//		 * WEEK_OF_YEAR));
//		 * System.out.println("Calendar Year "+Calendar.getInstance().get(Calendar.YEAR)
//		 * );
//		 * 
//		 * Date date = new Date(); SimpleDateFormat formatter = new
//		 * SimpleDateFormat("MM-dd-yyyy"); String strDate = formatter.format(date);
//		 * System.out.println("Date "+strDate); }catch(Exception ex){
//		 * ex.printStackTrace(); }
//		 */
//		RedisPubTest utilPubTest = new RedisPubTest();
//		JedisCluster jedis = null;
//		jedis = utilPubTest.openConnection("sony-dev-cluster-new.uunfd0.clustercfg.use1.cache.amazonaws.com", 6379);
//		if (args[0].equals("get")) {
//			System.out.println("Object  Return " + jedis.get(args[1]));
//		} else if (args[0].equals("del")) {
//			System.out.println("Object  Return " + jedis.del(args[1]));
//		} else if (args[0].equals("set")) {
//			System.out.println("Object  Return " + jedis.set(args[1], args[2]));
//		}
//
//	}

}
