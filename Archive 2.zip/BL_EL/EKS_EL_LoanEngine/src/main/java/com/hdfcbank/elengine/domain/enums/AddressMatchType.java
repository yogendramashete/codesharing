package com.hdfcbank.elengine.domain.enums;

public enum AddressMatchType {
       perfios,multibureau
}
