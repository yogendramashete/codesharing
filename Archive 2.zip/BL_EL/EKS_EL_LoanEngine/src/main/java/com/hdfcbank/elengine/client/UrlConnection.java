package com.hdfcbank.elengine.client;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.ProtocolException;
import java.net.URL;
import java.nio.charset.StandardCharsets;

import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class UrlConnection {

	public String perfiosCall(String payload, String apiUrl) throws IOException {
		StringBuilder response = new StringBuilder();
		BufferedReader in = null;
		try {
			byte[] postData = payload.getBytes(StandardCharsets.UTF_8);

			URL url = new URL(apiUrl);
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setDoOutput(true);
			conn.setInstanceFollowRedirects(false);
			conn.setRequestMethod("POST");
			conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
			conn.setUseCaches(false);
			try (DataOutputStream wr = new DataOutputStream(conn.getOutputStream())) {
				try {
					wr.write(postData);
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			int responseCode = conn.getResponseCode();
			String jsonString = conn.getResponseMessage();

			log.info("response code from server {}", responseCode);
			log.info("response message code from server {}", jsonString);

			if (responseCode == 200) {
				in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
				String inputLine;
				while ((inputLine = in.readLine()) != null) {
					response.append(inputLine);
				}
				in.close();
			} else {
				in = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
				String inputLine;
				while ((inputLine = in.readLine()) != null) {
					response.append(inputLine);
				}
				in.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return response.toString();
	}

	public String initiateCallBack(String payload, String apiUrl) throws IOException {
		StringBuilder response = new StringBuilder();
		BufferedReader in = null;
		try {
			byte[] postData = payload.getBytes(StandardCharsets.UTF_8);

			URL url = new URL(apiUrl);
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setDoOutput(true);
			conn.setInstanceFollowRedirects(false);
			conn.setRequestMethod("POST");
			conn.setRequestProperty("Content-Type", "application/json");
			conn.setUseCaches(false);
			try (DataOutputStream wr = new DataOutputStream(conn.getOutputStream())) {
				try {
					wr.write(postData);
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			int responseCode = conn.getResponseCode();
			String jsonString = conn.getResponseMessage();

			log.info("bre callback response code from server {}", responseCode);
			log.info("bre callback response message from server {}", jsonString);

			if (responseCode == 200) {
				in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
				String inputLine;

				while ((inputLine = in.readLine()) != null) {
					response.append(inputLine);
				}
				in.close();
			} else {
				response.append("error");
			}
		} catch (ProtocolException e) {
			e.printStackTrace();
		}
		return response.toString();
	}
}
