package com.hdfcbank.elengine.domain.enums;

public enum MBServiceType {
	MBINPUT,EQUIFAX,MBEOT,MERGED_SCORE,HIGHMARK,EXPERIAN,CIBIL
}
