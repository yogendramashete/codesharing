package com.hdfcbank.elengine.domain.enums;

public enum HunterType {
	Hunter
}
