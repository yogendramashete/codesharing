package com.hdfcbank.elengine.exception;

public class CallBackException extends RuntimeException {
	private static final long serialVersionUID = 1L;

	public CallBackException() {
		super();
	}

	public CallBackException(String message) {
		super(message);
	}

}
