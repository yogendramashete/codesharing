package com.hdfcbank.elengine.constant;

import lombok.Getter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Getter
@Component
public class PosidexConstants {

    @Value("${POSIDEX_IN_SOAP_XMLNS_ENVELOP}")
    public String POSIDEX_IN_SOAP_XMLNS_ENVELOP;

    @Value("${IS_EMPTY}")
    public String IS_EMPTY = "";

    @Value("${POSIDEX_IN_SOAP_XSD}")
    public String POSIDEX_IN_SOAP_XSD;
    @Value("${POSIDEX_IN_SOA_PRODUCT_ID_C}")
    public String POSIDEX_IN_SOA_PRODUCT_ID_C;
    @Value("${POSIDEX_IN_SOA_BORROWER_FLAG_C}")
    public String POSIDEX_IN_SOA_BORROWER_FLAG_C;
    @Value("${POSIDEX_IN_SOA_LOAN_AMT_N}")
    public String POSIDEX_IN_SOA_LOAN_AMT_N;
    @Value("${POSIDEX_IN_SOA_BRANCHID_N}")
    public String POSIDEX_IN_SOA_BRANCHID_N;
    @Value("${POSIDEX_IN_SOA_EMPLOYER_NAME_C}")
    public String POSIDEX_IN_SOA_EMPLOYER_NAME_C;
    @Value("${POSIDEX_IN_SOA_IND_CORP_FLAG_C}")
    public String POSIDEX_IN_SOA_IND_CORP_FLAG_C;
    @Value("${POSIDEX_IN_SOA_SET_TARGET_DB}")
    public String POSIDEX_IN_SOA_SET_TARGET_DB;
    @Value("${POSIDEX_IN_SOA_SET_CREDIT_BUREAUS}")
    public String POSIDEX_IN_SOA_SET_CREDIT_BUREAUS;
    @Value("${POSIDEX_IN_SOA_SOURCE_ID}")
    public String POSIDEX_IN_SOA_SOURCE_ID;
    @Value("${POSIDEX_IN_FILLER_13}")
    public String POSIDEX_IN_FILLER_13;
    @Value("${POSIDEX_IN_FILLER_16}")
    public String POSIDEX_IN_FILLER_16;
    @Value("${POSIDEX_IN_FILLER_17}")
    public String POSIDEX_IN_FILLER_17;
    @Value("${POSIDEX_IN_FILLER_21}")
    public String POSIDEX_IN_FILLER_21;
    @Value("${POSIDEX_IN_FILLER_22}")
    public String POSIDEX_IN_FILLER_22;
    @Value("${POSIDEX_IN_FILLER_23}")
    public String POSIDEX_IN_FILLER_23;
    @Value("${POS_PUB_OPERATIONTYPE}")
    public String POS_PUB_OPERATIONTYPE;
    @Value("${POS_OUT_OPERATIONTYPE}")
    public String POS_OUT_OPERATIONTYPE;
    ;;
}
