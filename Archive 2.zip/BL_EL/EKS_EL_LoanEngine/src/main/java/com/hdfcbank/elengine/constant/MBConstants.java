package com.hdfcbank.elengine.constant;

import lombok.Getter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Getter
@Component
public class MBConstants {

    @Value("${INITIATE_MB_AGGREGATOR_ID}")
    private String INITIATE_MB_AGGREGATOR_ID;
    @Value("${INITIATE_MB_INSTITUTION_ID}")
    public String INITIATE_MB_INSTITUTION_ID;
    @Value("${INITIATE_MB_MEMBER_ID}")
    public String INITIATE_MB_MEMBER_ID ;
    @Value("${INITIATE_MB_PASSWORD}")
    public String INITIATE_MB_PASSWORD;
    @Value("${INITIATE_MB_REQUEST_TYPE}")
    public String INITIATE_MB_REQUEST_TYPE;
    @Value("${INITIATE_MB_SOURCE_SYSTEM}")
    public String INITIATE_MB_SOURCE_SYSTEM ;
    @Value("${INITIATE_MB_PRIORITY}")
    public String INITIATE_MB_PRIORITY;
    @Value("${INITIATE_MB_PRODUCT_TYPE}")
    public String INITIATE_MB_PRODUCT_TYPE;
    @Value("${INITIATE_MB_LOAN_TYPE}")
    public String INITIATE_MB_LOAN_TYPE ;
    @Value("${INITIATE_MB_LOAN_AMOUNT}")
    public String INITIATE_MB_LOAN_AMOUNT ;
    @Value("${INITIATE_MB_JOINT_IND}")
    public String INITIATE_MB_JOINT_IND ;
    @Value("${INITIATE_MB_SOURCE_SYSTEM_NAME}")
    public String INITIATE_MB_SOURCE_SYSTEM_NAME;
    @Value("${INITIATE_MB_BUREAU_REGION}")
    public String INITIATE_MB_BUREAU_REGION ;
    @Value("${INITIATE_MB_INQUIRY_STAGE}")
    public String INITIATE_MB_INQUIRY_STAGE ;
    @Value("${INITIATE_MB_INDIVIDUAL_CORPORATE_FLAG}")
    public String INITIATE_MB_INDIVIDUAL_CORPORATE_FLAG;
    @Value("${INITIATE_MB_CONSTITUTION}")
    public String INITIATE_MB_CONSTITUTION;
    @Value("${INITIATE_MB_ADDRESS_TYPE}")
    public String INITIATE_MB_ADDRESS_TYPE;
    @Value("${INITIATE_MB_ADDRESS_RESIDENCE_CODE}")
    public String INITIATE_MB_ADDRESS_RESIDENCE_CODE;
    @Value("${INITIATE_MB_TENURE}")
    public String INITIATE_MB_TENURE;
    @Value("${INITIATE_MB_RESPONSE_FORMAT}")
    public String INITIATE_MB_RESPONSE_FORMAT;

    @Value("${INITIATE_MB_SOAP_XMLNS_ENVELOP}")
    public String INITIATE_MB_SOAP_XMLNS_ENVELOP;
    @Value("${INITIATE_MB_SOAP_XSD}")
    public String INITIATE_MB_SOAP_XSD;
    @Value("${INITIATE_MB_SOAP_XML_XSD}")
    public String INITIATE_MB_SOAP_XML_XSD;
    @Value("${INITIATE_MB_SOAP_XML_XSI}")
    public String INITIATE_MB_SOAP_XML_XSI;

}
