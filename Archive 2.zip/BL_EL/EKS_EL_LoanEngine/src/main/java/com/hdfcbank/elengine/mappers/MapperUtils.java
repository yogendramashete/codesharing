package com.hdfcbank.elengine.mappers;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.hdfcbank.elengine.domain.request.GstArnLevel;
import com.hdfcbank.elengine.domain.response.bre.blbre1b.Bre1bFailedReason;
import com.hdfcbank.elengine.domain.response.bre.blbre1b.Bre1bIrr;
import com.hdfcbank.elengine.domain.response.bre.blbre1b.Bre1bOfferAmount;
import com.hdfcbank.elengine.domain.response.bre.blbre1b.Bre1bProcfeeper;
import com.hdfcbank.elengine.domain.response.bre.blbre1b.Bre1bWorkflowStatus;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class MapperUtils {

	public static String defaultSetToNull(String string) {
		try {
			return StringUtils.isBlank(string) == true ? "null" : string;
		} catch (Exception e) {
			// TODO: handle exception
		}
		return "null";
	}

	public static String defaultSetToDate(String string) {
		try {
			return StringUtils.isBlank(string) == true ? "01/01/1900 00:00:00" : string;
		} catch (Exception e) {
			// TODO: handle exception
		}
		return "01/01/1900 00:00:00";
	}

	public static Integer defaultSetToZero(Integer integer) {
		try {
			return integer == null ? 0 : integer;
		} catch (Exception e) {
			// TODO: handle exception
		}
		return 0;
	}

	public static Double defaultSetToDouble(Integer double1) {
		try {
			return double1 == null ? 0 : double1.doubleValue();
		} catch (Exception e) {
			// TODO: handle exception
		}
		return (double) 0;
	}

	public static Float defaultSetToFloat(Float float1) {
		try {
			return float1 == null ? (float) 0 : float1.floatValue();
		} catch (Exception e) {
			// TODO: handle exception
		}
		return (float) 0;
	}
	
	public static Double defaultSetToDouble1(Double double1) {
		try {
			return double1 == null ? 0 : double1.doubleValue();
		} catch (Exception e) {
			// TODO: handle exception
		}
		return (double) 0;
	}

	public static String defaultSetToLong(Long long1) {
		try {
			return long1 == null ? "null" : String.valueOf(long1);
		} catch (Exception e) {
			// TODO: handle exception
		}
		return "null";
	}

	public static String defaultSetToInt(Integer integer) {
		try {
			return integer == null ? "null" : String.valueOf(integer);
		} catch (Exception e) {
			// TODO: handle exception
		}
		return "null";
	}

	public static Integer defaultSetToInteger(String integer) {
		try {
			return integer == null ? 0 : Integer.valueOf(integer);
		} catch (Exception e) {
			// TODO: handle exception
		}
		return 0;
	}

	public static String defaultDoubletoStr(Double double1) {
		try {

			return double1 == null ? "null" : String.valueOf(double1);

		} catch (Exception e) {
			// TODO: handle exception
		}
		return "null";
	}

	public static List<Bre1bWorkflowStatus> getBre1bWorkflowStatus(List<Bre1bWorkflowStatus> bre1bWorkflowStatus) {
		if (Objects.isNull(bre1bWorkflowStatus)) {
			bre1bWorkflowStatus = new ArrayList<Bre1bWorkflowStatus>();
			Bre1bWorkflowStatus bre1bWorkflowStatus2 = new Bre1bWorkflowStatus();
			bre1bWorkflowStatus2.setHardreject(null);
			bre1bWorkflowStatus2.setOfferType(null);
			bre1bWorkflowStatus2.setStpNonstp(null);
			bre1bWorkflowStatus.add(bre1bWorkflowStatus2);
		}
		return bre1bWorkflowStatus;
	}

	public static List<Bre1bOfferAmount> getBre1bOfferAmount(List<Bre1bOfferAmount> bre1bOfferAmounts) {
		if (Objects.isNull(bre1bOfferAmounts)) {
			bre1bOfferAmounts = new ArrayList<Bre1bOfferAmount>();
			Bre1bOfferAmount bre1bOfferAmount = new Bre1bOfferAmount();
			bre1bOfferAmount.setOfferAmount(0);
			bre1bOfferAmount.setTenure(0);
			bre1bOfferAmounts.add(bre1bOfferAmount);
		}
		return bre1bOfferAmounts;
	}

	public static List<Bre1bIrr> getBre1bIrr(List<Bre1bIrr> bre1bIrrs) {
		if (Objects.isNull(bre1bIrrs)) {
			bre1bIrrs = new ArrayList<Bre1bIrr>();
			Bre1bIrr bre1bIrr = new Bre1bIrr();
			bre1bIrr.setIrr(0.0f);
			bre1bIrr.setTenure(0);
			bre1bIrrs.add(bre1bIrr);
		}
		return bre1bIrrs;
	}

	public static List<Bre1bProcfeeper> getBre1bProcfeeper(List<Bre1bProcfeeper> bre1bProcfeepers) {
		if (Objects.isNull(bre1bProcfeepers)) {
			bre1bProcfeepers = new ArrayList<Bre1bProcfeeper>();
			Bre1bProcfeeper bre1bProcfeeper = new Bre1bProcfeeper();
			bre1bProcfeeper.setProcfeeper(0.0f);
			bre1bProcfeeper.setTenure(0);
			bre1bProcfeepers.add(bre1bProcfeeper);
		}
		return bre1bProcfeepers;
	}

	public static List<Bre1bFailedReason> getBre1bFailedReason(List<Bre1bFailedReason> bre1bFailedReasons) {
		if (Objects.isNull(bre1bFailedReasons)) {
			bre1bFailedReasons = new ArrayList<Bre1bFailedReason>();
			Bre1bFailedReason bre1bFailedReason = new Bre1bFailedReason();
			bre1bFailedReason.setReason1("null");
			bre1bFailedReason.setReason2("null");
			bre1bFailedReason.setReason3("null");
			bre1bFailedReasons.add(bre1bFailedReason);
		}
		return bre1bFailedReasons;
	}

	public static Double getFtnrProbValue(Double ftnrProbValue) {
		BigDecimal bd = new BigDecimal(ftnrProbValue).setScale(2, RoundingMode.HALF_UP);
		double newInput = bd.doubleValue();
		return newInput;
	}
	
	
	public static  List<GstArnLevel> modifyGstArnLevel(List<GstArnLevel> arnLevels){
		List<GstArnLevel> arnLevels2   = new ArrayList<>();
		for (GstArnLevel gstArnLevel : arnLevels) {
			gstArnLevel.setArn(StringUtils.isBlank(gstArnLevel.getArn()) == true?"null":gstArnLevel.getArn());
			gstArnLevel.setMof(StringUtils.isBlank(gstArnLevel.getMof()) == true?"null":gstArnLevel.getMof());
			gstArnLevel.setValid(StringUtils.isBlank(gstArnLevel.getValid()) == true?"null":gstArnLevel.getValid());
			arnLevels2.add(gstArnLevel);	
		}
		return arnLevels2;
	}
	
}
