package com.hdfcbank.elengine.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.hdfcbank.elengine.domain.entity.MBEntity;
@Repository
public interface FetchConfigMapRepository extends JpaRepository<MBEntity, Integer>{

}
