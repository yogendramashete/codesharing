package com.hdfcbank.elengine.openAPI;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

//import junit.framework.TestCase;

public class TestXMLDigitalSignature /* extends TestCase */ {
	private static final String REQUEST_XML_PATH = "D:/workspace/SOASampleCode/src/com/hdfcbank/openAPI/test/request_1.xml";
	private static final String SIGNATURE_XML_PATH = "D:/workspace/SOASampleCode/src/com/hdfcbank/openAPI/test/xml_signature_1.xml";
	private static final String CLIENT_KEYSTORE_PATH = "D:/workspace/SOASampleCode/src/com/hdfcbank/openAPI/test/client";
	private static final String CLIENT_KEYSTORE_PWD = "test1234";
	private static final String CLIENT_KEYSTORE_ALIAS = "Client";
	public final static Logger logger = LoggerFactory.getLogger(DigitalSignature.class);

//	public void testSign() throws Exception {
//		byte[] fileContent = Files.readAllBytes(Paths.get(REQUEST_XML_PATH));
//		String xmlRequest = new String(fileContent);	
//		XMLDigitalSignature xmlDigitalSignature = new XMLDigitalSignature();
//		String signedXML = xmlDigitalSignature.sign(xmlRequest, CLIENT_KEYSTORE_PATH, CLIENT_KEYSTORE_PWD, CLIENT_KEYSTORE_ALIAS);
//		logger.info(signedXML);
//	}
//	
//	public void testValidate() throws Exception {
//		byte[] fileContent = Files.readAllBytes(Paths.get(REQUEST_XML_PATH));
//		String xmlRequest = new String(fileContent);
//		
//		XMLDigitalSignature xmlDigitalSignature = new XMLDigitalSignature();
//		String signedXML = xmlDigitalSignature.sign(xmlRequest, CLIENT_KEYSTORE_PATH, CLIENT_KEYSTORE_PWD, CLIENT_KEYSTORE_ALIAS);
//		logger.info(signedXML);
//		
//	}
	
}
