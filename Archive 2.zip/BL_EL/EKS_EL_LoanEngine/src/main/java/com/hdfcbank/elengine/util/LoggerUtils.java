package com.hdfcbank.elengine.util;

import org.jboss.logging.MDC;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class LoggerUtils {
	public static final String MDC_HTTP_STATUS_CODE = "httpStatusCode";
	public static final String MDC_PAYLOAD_STATUS ="payloadStatus";
	public static final String MDC_REQUEST_URI = "requestUri";
	public void setHttpStatusCode(int httpStatusCode) {
		MDC.put(MDC_HTTP_STATUS_CODE, "" + httpStatusCode);
		String requestURI = MDC.get(MDC_REQUEST_URI) ==  null?"blank":MDC.get(MDC_REQUEST_URI).toString();
		log.info(requestURI+"_statuscode","");
		MDC.remove(MDC_HTTP_STATUS_CODE);
	}

	public void setPayloadStatus(String status) {
		MDC.put(MDC_PAYLOAD_STATUS, status);
		String requestURI = MDC.get(MDC_REQUEST_URI) ==  null?"blank":MDC.get(MDC_REQUEST_URI).toString();
		log.info(requestURI+"_payloadStatus","");
		MDC.remove(MDC_PAYLOAD_STATUS);
	}

}
