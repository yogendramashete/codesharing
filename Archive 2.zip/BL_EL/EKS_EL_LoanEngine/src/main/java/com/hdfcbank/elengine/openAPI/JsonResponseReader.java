package com.hdfcbank.elengine.openAPI;

import com.google.gson.Gson;

/**
 * Get Json Response object from String json response
 * 
 * @author Madhura Oak
 *
 */
public class JsonResponseReader {
	private Gson gson = new Gson();

	/**
	 * Get json response
	 * 
	 * @param jsonResponse
	 * @return
	 */
	public JsonResponse read(String jsonResponse) {
		JsonResponse response = gson.fromJson(jsonResponse, JsonResponse.class);
		return response;
	}

	/**
	 * Get json response
	 * 
	 * @param jsonResponse
	 * @return
	 */
	public CrmJsonResponse crmread(String jsonResponse) {
		CrmJsonResponse response = gson.fromJson(jsonResponse, CrmJsonResponse.class);
		return response;
	}

	public LeadStatusJsonResponse leadRead(String jsonResponse) {
		LeadStatusJsonResponse response = gson.fromJson(jsonResponse, LeadStatusJsonResponse.class);
		return response;
	}

	/**
	 * Get json response
	 * 
	 * @param jsonResponse
	 * @return
	 */
	public JsonResponse2 billdeskread(String jsonResponse) {
		JsonResponse2 response = gson.fromJson(jsonResponse, JsonResponse2.class);
		return response;
	}

	public PanValidationJsonResponse panRead(String jsonResponse) {
		PanValidationJsonResponse response = gson.fromJson(jsonResponse, PanValidationJsonResponse.class);
		return response;
	}

	public AadharKYCValidationJsonResponse aadharKYCRead(String jsonResponse) {
		AadharKYCValidationJsonResponse response = gson.fromJson(jsonResponse, AadharKYCValidationJsonResponse.class);
		return response;
	}
	public VcipJsonRequest vcipRequestRead(String jsonResponse) {
		VcipJsonRequest request = gson.fromJson(jsonResponse, VcipJsonRequest.class);
		return request;
	}
	
	public MedEncryptJsonResponse medJsonRead(String jsonResponse) {
		MedEncryptJsonResponse response = gson.fromJson(jsonResponse, MedEncryptJsonResponse.class);
		return response;
	}
}
