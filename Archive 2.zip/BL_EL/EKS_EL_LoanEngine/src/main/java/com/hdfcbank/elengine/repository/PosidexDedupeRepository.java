package com.hdfcbank.elengine.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.hdfcbank.elengine.domain.entity.PosidexDedupeEntity;
import com.hdfcbank.elengine.domain.enums.PosidexDedupeServiceType;

@Repository
public interface PosidexDedupeRepository extends JpaRepository<PosidexDedupeEntity, Integer>{
	Optional<PosidexDedupeEntity> findByoperationtype(PosidexDedupeServiceType posidexDedupeServiceType);
}
