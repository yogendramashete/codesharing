package com.hdfcbank.elengine.config;

import lombok.extern.slf4j.Slf4j;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.HashSet;
import java.util.Set;

@Component
@Order(1)
@Slf4j
public class SsrfFilter implements Filter {
    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        log.info("Initializing filter :{}", this);

    }

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {

        HttpServletRequest httpServletRequest = (HttpServletRequest) servletRequest;
        HttpServletResponse httpServletResponse = (HttpServletResponse) servletResponse;
        Set<String> whiteListedUrl = new HashSet<>();
        whiteListedUrl.add("http://localhost:9099/ElOrchestrator/services/initbre");
        log.info("inside filter");

        if (httpServletRequest.getParameterMap().containsKey("url")) {
            String url = httpServletRequest.getParameter("url");
            if (url.startsWith("http:") && !url.startsWith("//")) {
                httpServletResponse.sendRedirect(url);
            } else {
                httpServletResponse.sendRedirect("/");
            }
        }
    }

    @Override
    public void destroy() {
        log.warn("Destructing filter :{}", this);
    }
}
