package com.hdfcbank.elengine.util;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.net.HttpURLConnection;
import java.net.ProtocolException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.security.KeyPair;
import java.security.MessageDigest;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Security;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;

import javax.crypto.Cipher;

import org.apache.commons.lang3.StringUtils;
import org.bouncycastle.openssl.PEMReader;
import org.bouncycastle.util.encoders.Hex;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hdfcbank.elengine.constant.AppConstants;
import com.hdfcbank.elengine.constant.PerfiosPrivateKey;
import com.hdfcbank.elengine.domain.enums.EmploymentType;
import com.hdfcbank.elengine.openAPI.AESUtils;

import lombok.extern.slf4j.Slf4j;
 
@Component
@Slf4j
public class PerfiosUtil {
 	@Autowired
	AESUtils	aesUtils;
	@Autowired
	RedisUtils redisUtils;

	public String genericCreateHTML(String payload, String operation) {

		String signature = getSignature(AppConstants.ENCRYPTION_ALGO, AppConstants.DIGEST_ALGO,
				buildPrivateKey(PerfiosPrivateKey.PERFIOS_PRIVAYE_KEY), payload);
		StringBuilder htmlBuilder = new StringBuilder();
		htmlBuilder.append("<html>");
		htmlBuilder.append("<body onload='document.autoform.submit();'>");
		/*
		 * htmlBuilder.append("<form name='autoform' method='post' action='https://" +
		 * AppConstants.SERVER + "/KuberaVault/insights/" + operation + "'>");
		 */

//		htmlBuilder.append("<form name='autoform' method='post' action='" + PERFIOS_START_PROCESS_API_URL + "'>");

		htmlBuilder.append("<input type='hidden' name='payload' value='" + payload + "'>");
		htmlBuilder.append("<input type='hidden' name='signature' value='" + signature + "'>");
		htmlBuilder.append("</form>");
		htmlBuilder.append("</body>");
		htmlBuilder.append("</html>");
		return htmlBuilder.toString();
	}

	public String postHTML(String perfiosUrlPost) {

		StringBuilder htmlBuilder = new StringBuilder();
		/*
		 * htmlBuilder.append("<html>");
		 * htmlBuilder.append("<body onload='document.autoform.submit();'>");
		 * htmlBuilder.append("<form name='autoform' method='get' action='" +
		 * perfiosUrlPost + "'>"); htmlBuilder.append("</form>");
		 * htmlBuilder.append("</body>"); htmlBuilder.append("</html>");
		 */

		htmlBuilder.append("<html>");
		// htmlBuilder.append("<body onload='document.autoform.submit();'>");
		htmlBuilder.append("<body>");
		htmlBuilder.append("<form name='autoform' method='get' action='" + perfiosUrlPost + "'>");
		htmlBuilder.append("</form>");
		htmlBuilder.append("<script>setTimeout(function(){document.forms[0].submit()},1000)</script>");
		htmlBuilder.append("</body>");
		htmlBuilder.append("</html>");
		return htmlBuilder.toString();
	}

	public static String getSignature(String encryptAlgo, String digestAlgo, Key k, String xml) {
		String dig = makeDigest(xml, digestAlgo);
		return encrypt(dig, encryptAlgo, k);
	}

	public static String getSignature(String encryptAlgo, String digestAlgo, String xml,String employmentType) {
		Key k = null;
		if(employmentType.equalsIgnoreCase(EmploymentType.SEB.toString())) {
			k = buildPrivateKey(PerfiosPrivateKey.PERFIOS_SME_PRIVAYE_KEY);			
		}else {
			k = buildPrivateKey(PerfiosPrivateKey.PERFIOS_PRIVAYE_KEY);
		}
		return getSignature(encryptAlgo, digestAlgo, k, xml);
	}

	public static String makeDigest(String payload, String digestAlgo) {
		String strDigest = "";
		try {
			MessageDigest md = MessageDigest.getInstance(digestAlgo);
			md.update(payload.getBytes("UTF-8"));
			byte[] digest = md.digest();
			byte[] encoded = Hex.encode(digest);
			strDigest = new String(encoded);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return strDigest;
	}

	public static String encrypt(String raw, String encryptAlgo, Key k) {
		String strEncrypted = "";
		try {
			Cipher cipher = Cipher.getInstance(encryptAlgo);
			cipher.init(Cipher.ENCRYPT_MODE, k);
			byte[] encrypted = cipher.doFinal(raw.getBytes("UTF-8"));
			byte[] encoded = Hex.encode(encrypted);
			strEncrypted = new String(encoded);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return strEncrypted;
	}

	private static PublicKey buildPublicKey(String privateKeySerialized) {
		StringReader reader = new StringReader(privateKeySerialized);
		PublicKey pKey = null;
		try {
			Security.addProvider(new org.bouncycastle.jce.provider.BouncyCastleProvider());
			PEMReader pemReader = new PEMReader(reader);
			KeyPair keyPair = (KeyPair) pemReader.readObject();
			pKey = keyPair.getPublic();
			pemReader.close();
		} catch (IOException i) {
			i.printStackTrace();
		}
		return pKey;
	}

	private static PrivateKey buildPrivateKey(String privateKeySerialized) {
		StringReader reader = new StringReader(privateKeySerialized);
		PrivateKey pKey = null;
		try {
			Security.addProvider(new org.bouncycastle.jce.provider.BouncyCastleProvider());
			PEMReader pemReader = new PEMReader(reader);
			KeyPair keyPair = (KeyPair) pemReader.readObject();
			pKey = keyPair.getPrivate();
			pemReader.close();
		} catch (IOException i) {
			i.printStackTrace();
		}
		return pKey;
	}

	public String getNetbankingPayload(String referenceNumber, String employerName, String emailId,
			String destination) {
		// String emailEncrypted = encrypt(emailId, AppConstants.ENCRYPTION_ALGO,
		// PerfiosUtil.buildPublicKey(PerfiosPrivateKey.PERFIOS_PRIVAYE_KEY));
		LocalDate date = LocalDate.now();
		String currentDate = date.toString();

		String yearMonthTo = "", yearMonthFrom = "";
		date = date.minusMonths(AppConstants.PERFIOS_START_MINUS);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM");
		try {
			yearMonthTo = sdf2.format(sdf.parse(date.toString()));
			date = date.minusMonths(AppConstants.PERFIOS_END_MINUS);
			yearMonthFrom = sdf2.format(sdf.parse(date.toString()));
		} catch (ParseException e) {
			e.printStackTrace();
		}

		if(StringUtils.isBlank(employerName)) {
			employerName = "Not Available";
		}

		StringBuilder payloadBuilder = new StringBuilder();

		payloadBuilder.append("<payload>");
		payloadBuilder.append("<vendorId>" + AppConstants.VENDOR_ID + "</vendorId>");
		payloadBuilder.append("<apiVersion>" + AppConstants.API_VERSION + "</apiVersion>");
		payloadBuilder.append("<txnId>" + referenceNumber + "</txnId>");
		payloadBuilder.append("<destination>" + destination + "</destination>");
		payloadBuilder.append("<referenceNumber>" + referenceNumber + "</referenceNumber>");
		payloadBuilder.append("<employerName>"+ employerName +"</employerName>");
		payloadBuilder.append("<applicantType>RETAIL</applicantType>");
		payloadBuilder.append("<productType>AL</productType>");
		payloadBuilder.append("<dateOfApplication>" + currentDate + "</dateOfApplication>");
		payloadBuilder.append("<sourceSystem>LoanAssist</sourceSystem>");
		payloadBuilder.append("<loanDuration>12</loanDuration>");
		payloadBuilder.append("<loanAmount>100000</loanAmount>");
		payloadBuilder.append("<loanType>Personal</loanType>");
		payloadBuilder.append("<yearMonthFrom>" + yearMonthFrom + "</yearMonthFrom>");
		payloadBuilder.append("<yearMonthTo>" + yearMonthTo + "</yearMonthTo>");
//		payloadBuilder.append("<acceptancePolicy>" + PERFIOS_TRANSACTION_RANGE + "</acceptancePolicy>");
//		payloadBuilder.append("<returnUrl>" + PERFIOS_START_PROC_RETURN_URL + referenceNumber + "</returnUrl>");
		payloadBuilder.append("</payload>");
		return payloadBuilder.toString();
	}

	public String getETBNetbankingPayload(String referenceNumber, String employerName, String emailId,
			String destination) {
		// String emailEncrypted = encrypt(emailId, AppConstants.ENCRYPTION_ALGO,
		// PerfiosUtil.buildPublicKey(PerfiosPrivateKey.PERFIOS_PRIVAYE_KEY));
		LocalDate date = LocalDate.now();
		String currentDate = date.toString();

		String yearMonthTo = "", yearMonthFrom = "";
		date = date.minusMonths(AppConstants.PERFIOS_START_MINUS);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM");
		try {
			yearMonthTo = sdf2.format(sdf.parse(date.toString()));
			date = date.minusMonths(AppConstants.PERFIOS_END_MINUS);
			yearMonthFrom = sdf2.format(sdf.parse(date.toString()));
		} catch (ParseException e) {
			e.printStackTrace();
		}

		StringBuilder payloadBuilder = new StringBuilder();

		payloadBuilder.append("<payload>");
		payloadBuilder.append("<vendorId>" + AppConstants.VENDOR_ID + "</vendorId>");
		payloadBuilder.append("<apiVersion>" + AppConstants.API_VERSION + "</apiVersion>");
		payloadBuilder.append("<txnId>" + referenceNumber + "</txnId>");
		payloadBuilder.append("<destination>" + destination + "</destination>");
		payloadBuilder.append("<referenceNumber>" + referenceNumber + "</referenceNumber>");
		payloadBuilder.append("<employerName>Not Available</employerName>");
		payloadBuilder.append("<applicantType>RETAIL</applicantType>");
		payloadBuilder.append("<productType>AL</productType>");
		payloadBuilder.append("<dateOfApplication>" + currentDate + "</dateOfApplication>");
		payloadBuilder.append("<sourceSystem>LoanAssist</sourceSystem>");
		payloadBuilder.append("<loanDuration>12</loanDuration>");
		payloadBuilder.append("<loanAmount>100000</loanAmount>");
		payloadBuilder.append("<loanType>Personal</loanType>");
		payloadBuilder.append("<yearMonthFrom>" + yearMonthFrom + "</yearMonthFrom>");
		payloadBuilder.append("<yearMonthTo>" + yearMonthTo + "</yearMonthTo>");
//		payloadBuilder.append("<acceptancePolicy>" + PERFIOS_TRANSACTION_RANGE + "</acceptancePolicy>");
//		payloadBuilder.append("<returnUrl>" + ETB_PERFIOS_START_PROC_RETURN_URL + referenceNumber + "</returnUrl>");
		payloadBuilder.append("</payload>");
		return payloadBuilder.toString();
	}

	public String getDocNetbankingPayload(String referenceNumber, String employerName, String emailId,
			String destination) {
		// String emailEncrypted = encrypt(emailId, AppConstants.ENCRYPTION_ALGO,
		// PerfiosUtil.buildPublicKey(PerfiosPrivateKey.PERFIOS_PRIVAYE_KEY));
		LocalDate date = LocalDate.now();
		String currentDate = date.toString();

		String yearMonthTo = "", yearMonthFrom = "";
		date = date.minusMonths(AppConstants.PERFIOS_START_MINUS);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM");
		try {
			yearMonthTo = sdf2.format(sdf.parse(date.toString()));
			date = date.minusMonths(AppConstants.PERFIOS_END_MINUS);
			yearMonthFrom = sdf2.format(sdf.parse(date.toString()));
		} catch (ParseException e) {
			e.printStackTrace();
		}

		if(StringUtils.isBlank(employerName)) {
			employerName = "Not Available";
		}
		StringBuilder payloadBuilder = new StringBuilder();

		payloadBuilder.append("<payload>");
		payloadBuilder.append("<vendorId>" + AppConstants.VENDOR_ID + "</vendorId>");
		payloadBuilder.append("<apiVersion>" + AppConstants.API_VERSION + "</apiVersion>");
		payloadBuilder.append("<txnId>" + referenceNumber + "</txnId>");
		payloadBuilder.append("<destination>" + destination + "</destination>");
		payloadBuilder.append("<referenceNumber>" + referenceNumber + "</referenceNumber>");
		payloadBuilder.append("<employerName>"+ employerName +"</employerName>");
		payloadBuilder.append("<applicantType>RETAIL</applicantType>");
		payloadBuilder.append("<productType>AL</productType>");
		payloadBuilder.append("<dateOfApplication>" + currentDate + "</dateOfApplication>");
		payloadBuilder.append("<sourceSystem>LoanAssist</sourceSystem>");
		payloadBuilder.append("<loanDuration>12</loanDuration>");
		payloadBuilder.append("<loanAmount>100000</loanAmount>");
		payloadBuilder.append("<loanType>Personal</loanType>");
		payloadBuilder.append("<yearMonthFrom>" + yearMonthFrom + "</yearMonthFrom>");
		payloadBuilder.append("<yearMonthTo>" + yearMonthTo + "</yearMonthTo>");
//		payloadBuilder.append("<acceptancePolicy>" + PERFIOS_TRANSACTION_RANGE + "</acceptancePolicy>");
//		payloadBuilder.append("<returnUrl>" + DOC_PERFIOS_START_PROC_RETURN_URL + referenceNumber + "</returnUrl>");
		payloadBuilder.append("</payload>");
		return payloadBuilder.toString();
	}

	public String getStatementPayload(String referenceNumber, String employerName, String emailId, String destination) {
		StringBuilder payloadBuilder = new StringBuilder();
		String emailEncrypted = PerfiosUtil.encrypt(emailId, AppConstants.ENCRYPTION_ALGO,
				PerfiosUtil.buildPublicKey(PerfiosPrivateKey.PERFIOS_PRIVAYE_KEY));

		payloadBuilder.append("<payload>");
		payloadBuilder.append("<apiVersion>" + AppConstants.API_VERSION + "</apiVersion>");
		payloadBuilder.append("<vendorId>" + AppConstants.VENDOR_ID + "</vendorId>");
		payloadBuilder.append("<referenceNumber>" + referenceNumber + "</referenceNumber>");
		payloadBuilder.append("<employerName>" + employerName + "</employerName>");
		payloadBuilder.append("<applicantType>" + AppConstants.APPLICANT_TYPE + "</applicantType>");
		payloadBuilder.append("<productType>" + AppConstants.PRODUCT_TYPE + "</productType>");
		payloadBuilder.append("<dateOfApplication>" + CommonUtility.getDate(AppConstants.DATE_FMT_yyyy_MM_dd)
		+ "</dateOfApplication>");
		payloadBuilder.append("<sourceSystem>" + AppConstants.SOURCE_SYSTEM + "</sourceSystem>");
		payloadBuilder.append("<txnId>" + referenceNumber + "</txnId>");
		payloadBuilder.append("<emailId>" + emailEncrypted + "</emailId>");
		payloadBuilder.append("<destination>" + destination + "</destination>");
//		payloadBuilder.append("<returnUrl>" + PERFIOS_START_PROC_RETURN_URL + "</returnUrl>");
		payloadBuilder.append("</payload>");
		return payloadBuilder.toString();
	}

	public String getTxnStatusPayload(String referenceNumber) {
		StringBuilder payloadBuilder = new StringBuilder();
		payloadBuilder.append("<payload>");
		payloadBuilder.append("<apiVersion>" + AppConstants.API_VERSION + "</apiVersion>");
		payloadBuilder.append("<txnId>" + referenceNumber + "</txnId>");
		payloadBuilder.append("<vendorId>" + AppConstants.VENDOR_ID + "</vendorId>");
		payloadBuilder.append("</payload>");
		return payloadBuilder.toString();
	}

	public String getRetrievePayload(String referenceNumber, String perfiosTransactionId) {
		StringBuilder payloadBuilder = new StringBuilder();
		payloadBuilder.append("<payload>");
		payloadBuilder.append("<apiVersion>" + AppConstants.API_VERSION + "</apiVersion>");
		payloadBuilder.append("<txnId>" + referenceNumber + "</txnId>");
		payloadBuilder.append("<vendorId>" + AppConstants.VENDOR_ID + "</vendorId>");
		payloadBuilder.append("<perfiosTransactionId>" + perfiosTransactionId + "</perfiosTransactionId>");
		payloadBuilder.append("<reportType>" + AppConstants.REPORT_TYPE + "</reportType>");
		payloadBuilder.append("</payload>");
		return payloadBuilder.toString();
	}

	public String perfiosCall(String payload, String apiUrl) throws IOException {
		StringBuilder response = new StringBuilder();
		BufferedReader in = null;

		try {
			byte[] postData = payload.getBytes(StandardCharsets.UTF_8);

			URL url = new URL(apiUrl);
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setDoOutput(true);
			conn.setInstanceFollowRedirects(false);
			conn.setRequestMethod("POST");
			conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
			conn.setUseCaches(false);
			try (DataOutputStream wr = new DataOutputStream(conn.getOutputStream())) {
				try {
					wr.write(postData);
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			int responseCode = conn.getResponseCode();
			String jsonString = conn.getResponseMessage();

			log.info("response code from server {}" , responseCode);
			log.info("response message code from server {}" , jsonString);

			if (responseCode == 200) {
				in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
				String inputLine;

				while ((inputLine = in.readLine()) != null) {
					response.append(inputLine);
				}
				in.close();
				// logger.info("response :: " + response);
			} else {
				response.append("error");
			}
		} catch (ProtocolException e) {
			e.printStackTrace();
		}
		// return response.toString();
		return response.toString();
	}
	 
	public String getTansactionStatusPayload(String txnId) {
		StringBuilder payload = new StringBuilder();
		payload.append("<payload>");
		payload.append("<apiVersion>" + AppConstants.API_VERSION + "</apiVersion>");
		payload.append("<txnId>" + txnId + "</txnId>");
		payload.append("<vendorId>" + AppConstants.VENDOR_ID + "</vendorId>");
		payload.append("</payload>");
		return payload.toString();
	}
}
