package com.hdfcbank.elengine.domain.enums;

public enum ApiResponseType {
	success, failure, initiated
}
