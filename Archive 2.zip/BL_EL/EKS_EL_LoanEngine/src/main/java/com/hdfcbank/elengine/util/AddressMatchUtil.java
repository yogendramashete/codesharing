package com.hdfcbank.elengine.util;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.text.similarity.JaroWinklerDistance;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.hdfcbank.elengine.client.OpenBankApiConnector;
import com.hdfcbank.elengine.constant.AppConstants;
import com.hdfcbank.elengine.constant.RedisConstants;
import com.hdfcbank.elengine.domain.enums.AddressMatchType;
import com.hdfcbank.elengine.domain.enums.MBServiceType;
import com.hdfcbank.elengine.domain.request.Bre3AppData;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class AddressMatchUtil {

	@Autowired
	RedisUtils redisUtils;

	@Autowired
	XMLtoJsonParser jsonParser;

	@Autowired
	OpenBankApiConnector openBankapiConnector;

	@Value("${POSIDEXNAMEADDMATCH_URL}")
	private String POSIDEXNAMEADDMATCH_URL;

	@Value("${NAMEMATCHSCOPE}")
	private String NAMEMATCHSCOPE;

	public static int getAddressMatchScore(String a1, String a2) {
		String percentage = "";
		try {
			double d = new JaroWinklerDistance().apply(a1, a2);
			percentage = String.valueOf(d);
			int score = Integer.valueOf(percentage.substring(percentage.indexOf(".") + 1));
			log.info("getAddressMatchScore {}:: {} :: {} ", a1, a2, score);
			if (score == 0) {
				score = 100;
				
			}
			return score;

		} catch (Exception e) {
			log.info("percentage {}", percentage);
		}
		return 100;
	}

	public String createAddrRedisValue(String operatonType, String addrType, String addrScore) {
		String addrRedisValue = "";
		switch (1) {
		case 1:
			if (operatonType.contains("perfios")) {

				if (operatonType.contains(AppConstants.ADD_RESI)) {
					addrRedisValue = AppConstants.PERFIOS + AppConstants.ADD_RESI + RedisConstants.US + addrScore;
				} else {
					addrRedisValue = AppConstants.PERFIOS + AppConstants.ADD_OFF + RedisConstants.US + addrScore;
				}

				break;
			}

		case 2:
			if (operatonType.contains("posidex")) {

				if (operatonType.contains(AppConstants.ADD_RESI)) {
					addrRedisValue = AppConstants.POSIDEX + AppConstants.ADD_RESI + RedisConstants.US + addrScore;
				} else {
					addrRedisValue = AppConstants.POSIDEX + AppConstants.ADD_OFF + RedisConstants.US + addrScore;
				}

				break;
			}

		case 3:
			if (operatonType.contains("merged")) {

				if (operatonType.contains(AppConstants.ADD_RESI)) {
					addrRedisValue = AppConstants.MERGED + AppConstants.ADD_RESI + RedisConstants.US + addrScore;
				} else {
					addrRedisValue = AppConstants.MERGED + AppConstants.ADD_OFF + RedisConstants.US + addrScore;
				}

				break;
			}

		case 4:
			if (operatonType.contains("kyc")) {

				if (operatonType.contains(AppConstants.ADD_RESI)) {
					addrRedisValue = AppConstants.EKYC + AppConstants.ADD_RESI + RedisConstants.US + addrScore;
				} else {
					addrRedisValue = AppConstants.EKYC + AppConstants.ADD_OFF + RedisConstants.US + addrScore;
				}

				break;
			}

		case 5:
			if (operatonType.contains("karza")) {

				if (operatonType.contains(AppConstants.ADD_RESI)) {
					addrRedisValue = AppConstants.KARZA + AppConstants.ADD_RESI + RedisConstants.US + addrScore;
				} else {
					addrRedisValue = AppConstants.KARZA + AppConstants.ADD_OFF + RedisConstants.US + addrScore;
				}

				break;
			}

		}
		return addrRedisValue;
	}

	public Bre3AppData blAddressMatch(String mobileNumber, String referenceNumber, String offAdd1, String offAdd2,
			String offAdd3, String offState, String offCity, String offPin, String resiAdd1, String resiAdd2,
			String resiAdd3, String resiState, String resiCity, String resiPin)
			throws JsonMappingException, JsonProcessingException {
		Bre3AppData appData = new Bre3AppData();
		HashMap<String, String> filterFinalAddObj = new HashMap<String, String>();
		HashMap<String, Integer> filterResiScoreObj = new HashMap<String, Integer>();
		HashMap<String, Integer> filterOffScoreObj = new HashMap<String, Integer>();
		HashMap<String, String> filerResiAddObj = new HashMap<String, String>();
		HashMap<String, String> filterOffAddObj = new HashMap<String, String>();
		String resiAdd = resiAdd1 + " " + resiAdd2 + " " + resiAdd3 + " " + resiCity + " " + resiPin + " " + resiState;
		String offAdd = offAdd1 + " " + offAdd2 + " " + offAdd3 + " " + offCity + " " + offPin + " " + offState;
 
			String perfiosResponse = redisUtils
					.get(RedisConstants.PERFIOS_RETRIVE_DATA + mobileNumber + RedisConstants.US + referenceNumber);
			appData.setCustomerOfficeAddress(offAdd);
            appData.setCustomerResidenceAddress(resiAdd);
			if (StringUtils.isNotBlank(perfiosResponse)) {
				String employemntType = redisUtils
						.get(RedisConstants.EMPLOYMENT_TYPE + mobileNumber + RedisConstants.US + referenceNumber);
				String perfiosResiAdd = jsonParser.parsePerfiosAddressResponse(perfiosResponse, employemntType);
				String perfiosResiPin = CommonUtility.fetchPinCodeFromAddress(perfiosResiAdd);
				int perfiosResiAddScore = 0;
				if (perfiosResiPin.equals(resiPin)) {
					perfiosResiAddScore = getAddressMatchScore(resiAdd, perfiosResiAdd);
				}
				appData.setAppresiPerfiosMatchPerc(Float.valueOf(perfiosResiAddScore));
				appData.setAddressPerfios(perfiosResiAdd);
				int perfiosOffAddScore = 0;
				if (perfiosResiPin.equals(offPin)) {
					perfiosOffAddScore = getAddressMatchScore(offAdd, perfiosResiAdd);
				}
				appData.setAppofficePerfiosMatchPerc(Float.valueOf(perfiosOffAddScore));
 			}
			int i;
			String mergedScoreResponse = redisUtils.get(MBServiceType.MERGED_SCORE.toString() + mobileNumber + RedisConstants.US + referenceNumber);
			if(StringUtils.isNotBlank(mergedScoreResponse)) {
				ArrayList<String> mergedAddlist = jsonParser.parseMergedAddressResponse(mergedScoreResponse);
				i = 0;
				for (String mergedResiAdd : mergedAddlist) {

					String mergedResiPin = CommonUtility.fetchPinCodeFromAddress(mergedResiAdd);
					int mergedResiAddScore = 0;
					if (mergedResiPin.equals(resiPin)) {
						mergedResiAddScore = getAddressMatchScore(resiAdd, mergedResiAdd);
					}
					int mergedOffAddScore = 0;
					if (mergedResiPin.equals(offPin)) {
						mergedOffAddScore = getAddressMatchScore(offAdd, mergedResiAdd);
					}
					filterResiScoreObj.put("mergedResiAddScore" + i, mergedResiAddScore);
					filterOffScoreObj.put("mergedOffAddScore" + i, mergedOffAddScore);
					filerResiAddObj.put("mergedResiAddScore" + i, mergedResiAdd);
					filterOffAddObj.put("mergedOffAddScore" + i, mergedResiAdd);
					i++;
				}


				filterResiScoreObj = filterResiScoreObj.entrySet().stream()
						.sorted(Collections.reverseOrder(Map.Entry.comparingByValue())).collect(Collectors
								.toMap(Map.Entry::getKey, Map.Entry::getValue, (e1, e2) -> e2, LinkedHashMap::new));
				log.info("filterResiScoreObj :: after sorting :: " + filterResiScoreObj);

				filterOffScoreObj = filterOffScoreObj.entrySet().stream()
						.sorted(Collections.reverseOrder(Map.Entry.comparingByValue())).collect(Collectors
								.toMap(Map.Entry::getKey, Map.Entry::getValue, (e1, e2) -> e2, LinkedHashMap::new));
				log.info("filterOffScoreObj :: after sorting :: " + filterOffScoreObj);
				// set final object for top 3 score
				int top3count = 0;
				for (Map.Entry<String, Integer> entry : filterResiScoreObj.entrySet()) {
					log.info("Key = " + entry.getKey() + ", Value = " + entry.getValue());
					top3count++;
					if (top3count <= AppConstants.FILTER_BL_ADD_COUNT) {
						appData.setAddressFromBureauOff(filerResiAddObj.get(entry.getKey()));
						appData.setAppresiBureauMatchPerc(Float.valueOf(entry.getValue() == null?0:entry.getValue()));
					} else {
						break;
					}
				}

				top3count = 0;
				for (Map.Entry<String, Integer> entry : filterOffScoreObj.entrySet()) {
					log.info("Key = " + entry.getKey() + ", Value = " + entry.getValue());
					top3count++;
					if (top3count <= AppConstants.FILTER_BL_ADD_COUNT) {
						appData.setAddressFromBureauResi(filterOffAddObj.get(entry.getKey()));
						appData.setAppresiBureauMatchPerc(Float.valueOf(entry.getValue() == null?0:entry.getValue()));
					} else {
						break;
					}
				}
				appData.setNameFromBureau(jsonParser.parseMergedNameResponse(mergedScoreResponse));
			}
			
 
		return appData;
	}

	public ArrayList<String> filerAddress(String mobileNumber, String referenceNumber, String offAdd1, String offAdd2,
			String offAdd3, String offState, String offCity, String offPin, String resiAdd1, String resiAdd2,
			String resiAdd3, String resiState, String resiCity, String resiPin)
			throws JsonMappingException, JsonProcessingException {
		HashMap<String, String> filterFinalAddObj = new HashMap<String, String>();
		HashMap<String, Integer> filterResiScoreObj = new HashMap<String, Integer>();
		HashMap<String, Integer> filterOffScoreObj = new HashMap<String, Integer>();
		HashMap<String, String> filerResiAddObj = new HashMap<String, String>();
		HashMap<String, String> filterOffAddObj = new HashMap<String, String>();
		String resiAdd = resiAdd1 + " " + resiAdd2 + " " + resiAdd3 + " " + resiCity + " " + resiPin + " " + resiState;
		String offAdd = offAdd1 + " " + offAdd2 + " " + offAdd3 + " " + offCity + " " + offPin + " " + offState;
// perfios addreess match score
		String perfiosResponse = redisUtils
				.get(RedisConstants.PERFIOS_RETRIVE_DATA + mobileNumber + RedisConstants.US + referenceNumber);
		String employemntType = redisUtils
				.get(RedisConstants.EMPLOYMENT_TYPE + mobileNumber + RedisConstants.US + referenceNumber);
		String perfiosResiAdd = jsonParser.parsePerfiosAddressResponse(perfiosResponse, employemntType);
		String perfiosResiPin = CommonUtility.fetchPinCodeFromAddress(perfiosResiAdd);
		int perfiosResiAddScore = 0;
		if (perfiosResiPin.equals(resiPin)) {
			perfiosResiAddScore = getAddressMatchScore(resiAdd, perfiosResiAdd);
		}

		int perfiosOffAddScore = 0;
		if (perfiosResiPin.equals(offPin)) {
			perfiosOffAddScore = getAddressMatchScore(offAdd, perfiosResiAdd);
		}

		filterResiScoreObj.put("perfiosResiAddScore", perfiosResiAddScore);
		filterOffScoreObj.put("perfiosOffAddScore", perfiosOffAddScore);
		filerResiAddObj.put("perfiosResiAddScore", perfiosResiAdd);
		filterOffAddObj.put("perfiosOffAddScore", perfiosResiAdd);
		// posidex address match score

		String posidexResponse = redisUtils
				.get(RedisConstants.NTB_DEDUPE_OUTPUT + mobileNumber + RedisConstants.US + referenceNumber);
		HashMap<String, ArrayList<String>> hashMap = jsonParser.parsePosidexAddressResponse(posidexResponse);
		if (null != hashMap) {
			ArrayList<String> resiAddrList = hashMap.get("posidexResiAdd");
			ArrayList<String> officeAddrList = hashMap.get("posidexoffAdd");
			int i = 0;
			for (String posidexOffAdd : officeAddrList) {
				String posidexOffPin = CommonUtility.fetchPinCodeFromAddress(posidexOffAdd);
				int posidexOffAddScore = 0;
				if (posidexOffPin.equals(offPin)) {
					posidexOffAddScore = getAddressMatchScore(offAdd, posidexOffAdd);
				}
				filterOffScoreObj.put("posidexOffAddScore" + i, posidexOffAddScore);
				filterOffAddObj.put("posidexOffAddScore" + i, posidexOffAdd);
				i++;
			}
			i = 0;
			for (String posidexResiAdd : resiAddrList) {
				String posidexResiPin = CommonUtility.fetchPinCodeFromAddress(posidexResiAdd);
				int posidexResiAddScore = 0;
				if (posidexResiPin.equals(resiPin)) {
					posidexResiAddScore = getAddressMatchScore(resiAdd, posidexResiAdd);
				}
				filterResiScoreObj.put("posidexResiAddScore" + i, posidexResiAddScore);
				filerResiAddObj.put("posidexResiAddScore" + i, posidexResiAdd);
				i++;
			}
// medged score address match.
			String mergedScoreResponse = redisUtils
					.get(MBServiceType.MERGED_SCORE.toString() + mobileNumber + RedisConstants.US + referenceNumber);
			ArrayList<String> mergedAddlist = jsonParser.parseMergedAddressResponse(mergedScoreResponse);
			i = 0;
			for (String mergedResiAdd : mergedAddlist) {

				String mergedResiPin = CommonUtility.fetchPinCodeFromAddress(mergedResiAdd);
				int mergedResiAddScore = 0;
				if (mergedResiPin.equals(resiPin)) {
					mergedResiAddScore = getAddressMatchScore(resiAdd, mergedResiAdd);
				}
				int mergedOffAddScore = 0;
				if (mergedResiPin.equals(offPin)) {
					mergedOffAddScore = getAddressMatchScore(offAdd, mergedResiAdd);
				}
				filterResiScoreObj.put("mergedResiAddScore" + i, mergedResiAddScore);
				filterOffScoreObj.put("mergedOffAddScore" + i, mergedOffAddScore);
				filerResiAddObj.put("mergedResiAddScore" + i, mergedResiAdd);
				filterOffAddObj.put("mergedOffAddScore" + i, mergedResiAdd);
				i++;
			}

			filterResiScoreObj = filterResiScoreObj.entrySet().stream()
					.sorted(Collections.reverseOrder(Map.Entry.comparingByValue())).collect(Collectors
							.toMap(Map.Entry::getKey, Map.Entry::getValue, (e1, e2) -> e2, LinkedHashMap::new));
			log.info("filterResiScoreObj :: after sorting :: " + filterResiScoreObj);

			filterOffScoreObj = filterOffScoreObj.entrySet().stream()
					.sorted(Collections.reverseOrder(Map.Entry.comparingByValue())).collect(Collectors
							.toMap(Map.Entry::getKey, Map.Entry::getValue, (e1, e2) -> e2, LinkedHashMap::new));
			log.info("filterOffScoreObj :: after sorting :: " + filterOffScoreObj);
			// set final object for top 3 score
			int top3count = 0;
			for (Map.Entry<String, Integer> entry : filterResiScoreObj.entrySet()) {
				log.info("Key = " + entry.getKey() + ", Value = " + entry.getValue());
				top3count++;
				if (top3count <= AppConstants.FILTER_ADD_COUNT) {
					filterFinalAddObj.put(entry.getKey(), filerResiAddObj.get(entry.getKey()));
				} else {
					break;
				}
			}

			top3count = 0;
			for (Map.Entry<String, Integer> entry : filterOffScoreObj.entrySet()) {
				log.info("Key = " + entry.getKey() + ", Value = " + entry.getValue());
				top3count++;
				if (top3count <= AppConstants.FILTER_ADD_COUNT) {
					filterFinalAddObj.put(entry.getKey(), filterOffAddObj.get(entry.getKey()));
				} else {
					break;
				}
			}
			return callAddressMatch(filterFinalAddObj, resiAdd, offAdd, referenceNumber, mobileNumber);
		}
		return null;
	}

	public ArrayList<String> callAddressMatch(HashMap<String, String> filerFinalAddObj, String resiAdd, String offAdd,
			String referenceNumber, String mobileNumber) {
		log.info("callAddressMatch :: ");
		ArrayList<String> addrRedisValueLst = new ArrayList<String>();
		String creationTime = "";
		String updationTime = "";
		String operationtype = "PosidexAddrMatch";
		String addressMatchRequest = "";
		JSONObject addrMatchRespObj = new JSONObject();
		String status = "";
		try {

			String objectKey = "";
			String addrRedisValue = "";
			String sourceAddress = "";
			String targetAddress = "";
			String addrType = "";
			int addrApiLoopCount = 0;
			log.info("filerFinalAddObj :: " + filerFinalAddObj);
			for (Map.Entry<String, String> entry : filerFinalAddObj.entrySet()) {
				addrApiLoopCount++;
				log.info("Key = " + entry.getKey() + ", Value = " + entry.getValue());
				objectKey = entry.getKey();
				log.info("objectKey :: " + objectKey);
				if (objectKey.contains(AppConstants.ADD_RESI)) {
					sourceAddress = resiAdd;
					addrType = AppConstants.ADD_RESI;
				} else {
					sourceAddress = offAdd;
					addrType = AppConstants.ADD_OFF;
				}
				targetAddress = filerFinalAddObj.get(objectKey);
				log.info(referenceNumber + " targetAddress :: " + targetAddress);
				creationTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").format(Calendar.getInstance().getTime());
				addressMatchRequest = getAddressMatchReq(referenceNumber, sourceAddress, targetAddress);
				log.info(referenceNumber + " addressMatchRequest :: " + addressMatchRequest);
				addrMatchRespObj = openBankapiConnector.processPosidexAddressMatchApiRequest(addressMatchRequest,
						POSIDEXNAMEADDMATCH_URL, NAMEMATCHSCOPE, mobileNumber, referenceNumber);
				log.info(referenceNumber + " addrMatchRespObj :: " + addrMatchRespObj);
				updationTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").format(Calendar.getInstance().getTime());
				if (!addrMatchRespObj.isEmpty()) {
					status = "success";
				} else {
					status = "failed";
				}
				String addressPercentage = addrMatchRespObj.get("addressPercentage") == null ? "0"
						: addrMatchRespObj.get("addressPercentage").toString();
				addrRedisValue = createAddrRedisValue(objectKey, addrType, addressPercentage);
				addrRedisValueLst.add(addrRedisValue);
				return addrRedisValueLst;
			}
		} catch (Exception exe) {
			log.error("exception {}", exe);
		} finally {

		}
		return addrRedisValueLst;
	}

	public String getAddressMatchReq(String tranRefNo, String sourceAddress, String targetAddress) {
		StringBuilder reqBuilder = new StringBuilder();
		reqBuilder.append(
				"<soapenv:Envelope xmlns:con=\"http://context.app.fc.ofss.com\" xmlns:dat=\"http://datatype.fc.ofss.com\" xmlns:dom=\"http://domain.framework.fc.ofss.com\" xmlns:dto=\"http://dto.common.domain.framework.fc.ofss.com\" xmlns:exc=\"http://exception.infra.fc.ofss.com\" xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:tran=\"http://transaction.service.posidex.appx.cz.fc.ofss.com/\">");
		reqBuilder.append("<soapenv:Header/>");
		reqBuilder.append("<soapenv:Body>");
		reqBuilder.append("<tran:doAddressMatchPercentage>");
		reqBuilder.append("<arg0>");
		reqBuilder.append("<con:bankCode>08</con:bankCode>");
		reqBuilder.append("<con:channel>APIGW</con:channel>");
		reqBuilder.append("<con:externalReferenceNo>" + tranRefNo + "</con:externalReferenceNo>");
		reqBuilder.append("<con:transactionBranch>089999</con:transactionBranch>");
		reqBuilder.append("<con:userId>DevUser01</con:userId>");
		reqBuilder.append("<con:transactingPartyCode>50000045</con:transactingPartyCode>");
		reqBuilder.append("</arg0>");
		reqBuilder.append("<arg1>");
		reqBuilder.append("<srcName></srcName>");
		reqBuilder.append("<trgName></trgName>");
		reqBuilder.append("<srcAddress>" + sourceAddress + "</srcAddress>");
		reqBuilder.append("<trgAddress>" + targetAddress + "</trgAddress>");
		reqBuilder.append("<srcEquality></srcEquality>");
		reqBuilder.append("<trgEquality></trgEquality>");
		reqBuilder.append("<srcPhone></srcPhone>");
		reqBuilder.append("<trgPhone></trgPhone>");
		reqBuilder.append("</arg1>");
		reqBuilder.append("</tran:doAddressMatchPercentage>");
		reqBuilder.append("</soapenv:Body>");
		reqBuilder.append("</soapenv:Envelope>");
		return reqBuilder.toString();
	}

}
