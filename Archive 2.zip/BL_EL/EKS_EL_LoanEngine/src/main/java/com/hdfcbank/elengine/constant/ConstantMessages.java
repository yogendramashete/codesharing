package com.hdfcbank.elengine.constant;

import org.springframework.beans.factory.annotation.Value;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public abstract class ConstantMessages {

	public static final String BRE_RES_PARAMS = "FINAL_ELIG|STP_WFLW|BUREU_ELIG|BUREU_INC|PERF_INC|FILLER5|FILLER2|IRR|PROCFEEPER";
	public static final String BRE_REFORMAT_PARAMS = "FINAL_ELIG|IRR|PROCFEEPER";

	public static final String SUCCESS = "00";
	
	public static String IS_EMPTY = "";
	
	
	public static String INITIATE_MB_SOAP_XMLNS_ENVELOP = "http://schemas.xmlsoap.org/soap/envelope/";
	public static String INITIATE_MB_SOAP_XSD = "multibureau.xsd.hdfcbank.com";
	

	public static String INITIATE_MB_SOAP_XML_XSD = "http://www.w3.org/2001/XMLSchema";
	public static String INITIATE_MB_SOAP_XML_XSI = "http://www.w3.org/2001/XMLSchema-instance";
	
	public static String INITIATE_MB_AGGREGATOR_ID = "545";
	public static String INITIATE_MB_INSTITUTION_ID = "4010";
	public static String INITIATE_MB_MEMBER_ID = "cpu_loanengine@hdfcbank.com";
	public static String INITIATE_MB_PASSWORD = "UnkyQWg/I0c=";
	public static String INITIATE_MB_REQUEST_TYPE = "REQUEST";
	public static String INITIATE_MB_SOURCE_SYSTEM = "LOANENGINE";
	public static String INITIATE_MB_PRIORITY = "HIGH_PRIORITY";
	public static String INITIATE_MB_PRODUCT_TYPE = "CIR";
	public static String INITIATE_MB_LOAN_TYPE = "B";
	public static String INITIATE_MB_LOAN_AMOUNT = "100000";
	public static String INITIATE_MB_JOINT_IND = "INDV";
	public static String INITIATE_MB_SOURCE_SYSTEM_NAME = "LOANENGINE";
	public static String INITIATE_MB_BUREAU_REGION = "QA/UAT";
	public static String INITIATE_MB_INQUIRY_STAGE = "Pre-Screen";
	public static String INITIATE_MB_INDIVIDUAL_CORPORATE_FLAG = "I";
	public static String INITIATE_MB_CONSTITUTION = "15";
	public static String INITIATE_MB_ADDRESS_TYPE = "CURRES";
	public static String INITIATE_MB_ADDRESS_RESIDENCE_CODE = "01";
	public static String INITIATE_MB_TENURE = "60";
	public static String INITIATE_MB_RESPONSE_FORMAT = "04";
	
	
	public static String POSIDEX_IN_SOAP_XMLNS_ENVELOP = "http://schemas.xmlsoap.org/soap/envelope/";
	public static String POSIDEX_IN_SOAP_XSD = "soaserver.xsd.hdfcbank.com";
	
	
	public static String POSIDEX_IN_SOA_PRODUCT_ID_C = "B";
	public static String POSIDEX_IN_SOA_BORROWER_FLAG_C = "C";
	public static String POSIDEX_IN_SOA_LOAN_AMT_N = "100000";
	public static String POSIDEX_IN_SOA_BRANCHID_N = "3";
	public static String POSIDEX_IN_SOA_EMPLOYER_NAME_C = "posidex";
	public static String POSIDEX_IN_SOA_IND_CORP_FLAG_C = "I";
	public static String POSIDEX_IN_SOA_SET_TARGET_DB = "LOANENGINE";
	public static String POSIDEX_IN_SOA_SET_CREDIT_BUREAUS = "CIBIL";
	public static String POSIDEX_IN_SOA_SOURCE_ID = "LOANENGINE";
	public static String POSIDEX_IN_FILLER_13 = "3";
	public static String POSIDEX_IN_FILLER_16 = "3";
	public static String POSIDEX_IN_FILLER_17 = "3";
	public static String POSIDEX_IN_FILLER_21 = "100";
	public static String POSIDEX_IN_FILLER_22 = "3";
	public static String POSIDEX_IN_FILLER_23 = "14";

	public static String POS_PUB_OPERATIONTYPE = "posidexPublishService";
	public static String POS_OUT_OPERATIONTYPE = "posidexOutputService";
	
	
	public static String HUNTER_SOAP_XMLNS_ENVELOP = "http://schemas.xmlsoap.org/soap/envelope/";
	public static String HUNTER_IN_SOAP_XSD = "http://www.mclsoftware.co.uk/HunterII/WebServices";
	

	public static String HUNTER_CUSTOMER_ID = "5";
	public static String HUNTER_CUSTOMER_NAME = "HDFCBANK";
	public static String HUNTER_SUBMISSION_LOAD = "1";
	public static String HUNTER_SCHEME_ID_28 = "28";
	public static String HUNTER_SCHEME_ID_20 = "20";
	public static String HUNTER_SCHEME_ID_21 = "21";
	public static String HUNTER_SCHEME_ID_22 = "22";
	public static String HUNTER_SCHEME_ID_23 = "23";
	public static String HUNTER_SCHEME_ID_24 = "24";
	public static String HUNTER_SCHEME_ID_25 = "25";
	public static String HUNTER_SCHEME_ID_26 = "26";
	public static String HUNTER_SCHEME_ID_27 = "27";
	public static String HUNTER_SCHEME_ID_56 = "56";
	public static String HUNTER_SCHEME_ID_58 = "58";
	public static String HUNTER_SCHEME_ID_78 = "78";
	public static String HUNTER_SCHEME_ID_93 = "93";
	public static String HUNTER_SCHEME_ID_94 = "94";
	public static String HUNTER_PERSIST_MATCHES = "1";
	public static String HUNTER_WORKLIST_INSERT = "1";
	public static String HUNTER_RSLT_CODE = "1";
	public static String HUNTER_COUNT = "1";
	public static String HUNTER_ORIGINATOR = "HDFCBANK";
	public static String HUNTER_CLASSIFICATION = "REFER";
	public static String HUNTER_STATUS_CLEAR = "Clear";
	public static String HUNTER_URN = "urn:mclsoftware.co.uk:hunterII";
	
	@Value("${HUNTER_USERNAME}")
	public static String HUNTER_USERNAME;

	@Value("${HUNTER_PASSWORD}")
	public static String HUNTER_PASSWORD;

	public static String BLAPP_LAPPTYPE="I";
	public static String BLAPP_PROMOTION_SCHEME="BKGSUR_35L";
}
