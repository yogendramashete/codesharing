package com.hdfcbank.elengine.domain.enums;

public enum LappProductId {

	SEB("B"), SEP("SEP"), SD("SEP");

	private final String code;

	private LappProductId(String code) {
		this.code = code;
	}

	public String toInt() {
		return code;
	}

	public String toString() {
		return String.valueOf(code);
	}
}
