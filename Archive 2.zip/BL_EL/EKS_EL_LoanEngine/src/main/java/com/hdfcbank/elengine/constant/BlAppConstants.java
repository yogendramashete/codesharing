package com.hdfcbank.elengine.constant;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Getter
@Component
public class BlAppConstants {
    @Value("${BLAPP_PROMOTION_SCHEME}")
    public String BLAPP_PROMOTION_SCHEME;

    @Value("${BLAPP_LAPPTYPE}")
    public String BLAPP_LAPPTYPE;

    @Value("${SUCCESS}")
    public String SUCCESS = "";



}
