package com.hdfcbank.elengine.mappers;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.hdfcbank.elengine.domain.request.bre.ftnr.FtnrApplication;
import com.hdfcbank.elengine.domain.request.bre.ftnr.LosCibAccdetailSrop;
import com.hdfcbank.elengine.domain.request.bre.ftnr.LosEqAccdetailsSrop;
import com.hdfcbank.elengine.domain.request.bre.ftnr.LosHmBasePriAcctypeSrop;
import com.hdfcbank.elengine.domain.request.bre.ftnr.LosInputFromsa;
import com.hdfcbank.elengine.domain.request.bre.ftnr.LosMbReqStatus;
import com.hdfcbank.elengine.domain.request.bre.ftnr.LosMergedPastenqSrop;
import com.hdfcbank.elengine.domain.request.bre.ftnr.LosMergedPaymenthistSrop;
import com.hdfcbank.elengine.domain.request.bre.ftnr.LosMergedTradelinesSrop;
import com.hdfcbank.elengine.domain.request.common.InBreServices;
import com.hdfcbank.elengine.domain.response.mb.callback.cibil.CibilSropDomainList;
import com.hdfcbank.elengine.domain.response.mb.callback.crfhighmark.ChmBaseSropDomainList1;
import com.hdfcbank.elengine.domain.response.mb.callback.eot.MultiBureauEoTRequest;
import com.hdfcbank.elengine.domain.response.mb.callback.eot.success.MBEoTRequestType;
import com.hdfcbank.elengine.domain.response.mb.callback.equifax.EquifaxSropDomain;
import com.hdfcbank.elengine.domain.response.mb.callback.mergedscore.MergedSropDomain;
import com.hdfcbank.elengine.domain.response.posidexdedupe.PosidexOutData;

@Mapper
public interface FtnrAutoMapper {

	FtnrAutoMapper INSTANCE =  Mappers.getMapper(FtnrAutoMapper.class);
 
	 @Mapping(target  = "lsiAppIdC",expression  = "java(com.hdfcbank.elengine.util.CommonUtility.defaultSetToNull(posidexOutData.SOA_APP_ID_C))")
     @Mapping(target  = "lsiCustIdN",expression  = "java(com.hdfcbank.elengine.util.CommonUtility.defaultSetToNull(posidexOutData.SOA_CUST_ID_N))")
     @Mapping(target  = "lsiStatusC",expression  = "java(com.hdfcbank.elengine.util.CommonUtility.defaultSetToNull(posidexOutData.SOA_STATUS_C))")
     @Mapping(target  = "lsiCustTypeC",expression  = "java(com.hdfcbank.elengine.util.CommonUtility.defaultSetToNull(posidexOutData.SOA_CUST_TYPE_C))")
     @Mapping(target  = "lsiCustExposureN",expression = "java(Double.parseDouble(org.springframework.util.StringUtils.isEmpty(posidexOutData.SOA_CUST_EXPOSURE_N) ? \"0\" : posidexOutData.SOA_CUST_EXPOSURE_N))")
     @Mapping(target  = "lsiDedupeDate", expression = "java(com.hdfcbank.elengine.util.CommonUtility.changeDateFormat(posidexOutData.SOA_DEDUPE_DATE,\"yyyy-MM-dd HH:mm:ss.SSS\", \"dd/MM/yyyy HH:mm:ss\"))")
     @Mapping(target  = "lsiBorrowerF",expression  = "java(com.hdfcbank.elengine.util.CommonUtility.defaultSetToNull(posidexOutData.SOA_BORROWER_F))")
     @Mapping(target  = "lsiMatchAppidC",expression  = "java(com.hdfcbank.elengine.util.CommonUtility.defaultSetToNull(posidexOutData.SOA_MATCH_APPID_C))")
     @Mapping(target  = "lsiProductcodeC",expression  = "java(com.hdfcbank.elengine.util.CommonUtility.defaultSetToNull(posidexOutData.SOA_PRODUCT_CODE_C))")
     @Mapping(target  = "lsiSourceC",expression  = "java(com.hdfcbank.elengine.util.CommonUtility.defaultSetToNull(posidexOutData.SOA_SOURCE_C))")
     @Mapping(target  = "lsiFnameC",expression  = "java(com.hdfcbank.elengine.util.CommonUtility.defaultSetToNull(posidexOutData.SOA_FNAME_C))")
     @Mapping(target  = "lsiMnameC",expression  = "java(com.hdfcbank.elengine.util.CommonUtility.defaultSetToNull(posidexOutData.SOA_MNAME_C))")
     @Mapping(target  = "lsiLnameC",expression  = "java(com.hdfcbank.elengine.util.CommonUtility.defaultSetToNull(posidexOutData.SOA_LNAME_C))")
     @Mapping(target  = "lsiFileNameC",expression  = "java(com.hdfcbank.elengine.util.CommonUtility.defaultSetToNull(posidexOutData.SOA_FILE_NAME_C))")
     @Mapping(target  = "lsiSasUpdateStatus",expression  = "java(com.hdfcbank.elengine.util.CommonUtility.defaultSetToNull(posidexOutData.SOA_SAS_UPDATE_STATUS))")
     @Mapping(target  = "lsiSasUpdateDate",expression = "java(com.hdfcbank.elengine.util.CommonUtility.changeDateFormat(posidexOutData.SOA_SAS_UPDATE_DATE,\"yyyy-MM-dd HH:mm:ss.SSS\", \"dd/MM/yyyy HH:mm:ss\"))")
     @Mapping(target  = "lsiLosReadFlag",expression  = "java(com.hdfcbank.elengine.util.CommonUtility.defaultSetToNull(posidexOutData.SOA_READ_FLAG))")
     @Mapping(target  = "lsiLosReadDate",expression = "java(com.hdfcbank.elengine.util.CommonUtility.changeDateFormat(posidexOutData.SOA_READ_DATE,\"yyyy-MM-dd HH:mm:ss.SSS\", \"dd/MM/yyyy HH:mm:ss\"))")
     @Mapping(target  = "lsiCreditcardnoC",expression  = "java(com.hdfcbank.elengine.util.CommonUtility.defaultSetToNull(posidexOutData.FILLER_8))")
     @Mapping(target  = "lsiCurrentOutstandingN",expression = "java(Double.parseDouble(org.springframework.util.StringUtils.isEmpty(posidexOutData.FILLER_51) ? \"0\" : posidexOutData.FILLER_51))")
     @Mapping(target  = "lsiCustomerTypeC",expression  = "java(com.hdfcbank.elengine.util.CommonUtility.defaultSetToNull(posidexOutData.SOA_CUST_TYPE_C))")
     @Mapping(target  = "lsiDobD",expression = "java(com.hdfcbank.elengine.util.CommonUtility.changeDateFormat(posidexOutData.FILLER_4,\"yyyy-MM-dd HH:mm:ss.SSS\", \"dd/MM/yyyy HH:mm:ss\"))")
     @Mapping(target  = "lsiDaysOverlineCurrentN",expression = "java(Integer.parseInt(org.springframework.util.StringUtils.isEmpty(posidexOutData.FILLER_54) ? \"0\" : posidexOutData.FILLER_54))")
     @Mapping(target  = "lsiDaysOverlineYtdN",expression = "java(Integer.parseInt(org.springframework.util.StringUtils.isEmpty(posidexOutData.FILLER_55) ? \"0\" : posidexOutData.FILLER_55))")
     @Mapping(target  = "lsiDaysPastDueN",expression = "java(Integer.parseInt(org.springframework.util.StringUtils.isEmpty(posidexOutData.FILLER_30) ? \"0\" : posidexOutData.FILLER_30))")
     @Mapping(target  = "lsiDedupeCategoryC",expression  = "java(com.hdfcbank.elengine.util.CommonUtility.defaultSetToNull(posidexOutData.FILLER_60))")
     @Mapping(target  = "lsiDelinquencyStringC",expression  = "java(com.hdfcbank.elengine.util.CommonUtility.defaultSetToNull(posidexOutData.FILLER_4))")
     @Mapping(target  = "lsiDisbursementDateD",expression = "java(com.hdfcbank.elengine.util.CommonUtility.changeDateFormat(posidexOutData.FILLER_16,\"yyyy-MM-dd HH:mm:ss.SSS\", \"dd/MM/yyyy HH:mm:ss\"))")
     @Mapping(target  = "lsiDrivinglicnoC",expression  = "java(com.hdfcbank.elengine.util.CommonUtility.defaultSetToNull(posidexOutData.FILLER_38))")
     @Mapping(target  = "lsiEmployerNameC",expression  = "java(com.hdfcbank.elengine.util.CommonUtility.defaultSetToNull(posidexOutData.FILLER_3))")
     @Mapping(target  = "lsiFwAccountNumberC",expression  = "java(com.hdfcbank.elengine.util.CommonUtility.defaultSetToNull(posidexOutData.FILLER_46))")
     @Mapping(target  = "lsiFwCustomeridN",expression  = "java(com.hdfcbank.elengine.util.CommonUtility.defaultSetToNull(posidexOutData.FILLER_7))")
     @Mapping(target  = "lsiLoanAmtN",expression = "java(Double.parseDouble(org.springframework.util.StringUtils.isEmpty(posidexOutData.FILLER_15) ? \"0\" : posidexOutData.FILLER_15))")
     @Mapping(target  = "lsiLoanStatusC",expression  = "java(com.hdfcbank.elengine.util.CommonUtility.defaultSetToNull(posidexOutData.FILLER_48))")
     @Mapping(target  = "lsiMobilenoC",expression  = "java(com.hdfcbank.elengine.util.CommonUtility.defaultSetToNull(posidexOutData.FILLER_40))")
     @Mapping(target  = "lsiNpaStageIdC",expression  = "java(com.hdfcbank.elengine.util.CommonUtility.defaultSetToNull(posidexOutData.FILLER_58))")
     @Mapping(target  = "lsiObcCardC",expression  = "java(com.hdfcbank.elengine.util.CommonUtility.defaultSetToNull(posidexOutData.FILLER_39))")
     @Mapping(target  = "lsiOffAddressC",expression  = "java(com.hdfcbank.elengine.util.CommonUtility.defaultSetToNull(posidexOutData.FILLER_42))")
     @Mapping(target  = "lsiOffCityC",expression  = "java(com.hdfcbank.elengine.util.CommonUtility.defaultSetToNull(posidexOutData.FILLER_43))")
     @Mapping(target  = "lsiOffPhone1C",expression  = "java(com.hdfcbank.elengine.util.CommonUtility.defaultSetToNull(posidexOutData.FILLER_34))")
     @Mapping(target  = "lsiOffZipC",expression  = "java(com.hdfcbank.elengine.util.CommonUtility.defaultSetToNull(posidexOutData.FILLER_12))")
     @Mapping(target  = "lsiOverdraftCollateralDtlC",expression  = "java(com.hdfcbank.elengine.util.CommonUtility.defaultSetToNull(posidexOutData.FILLER_56))")
     @Mapping(target  = "lsiOverdraftLimitNoC",expression  = "java(com.hdfcbank.elengine.util.CommonUtility.defaultSetToNull(posidexOutData.FILLER_57))")
     @Mapping(target  = "lsiPanC",expression  = "java(com.hdfcbank.elengine.util.CommonUtility.defaultSetToNull(posidexOutData.FILLER_35))")
     @Mapping(target  = "lsiPassportnoC",expression  = "java(com.hdfcbank.elengine.util.CommonUtility.defaultSetToNull(posidexOutData.FILLER_37))")
     @Mapping(target  = "lsiRemarksC",expression  = "java(com.hdfcbank.elengine.util.CommonUtility.defaultSetToNull(posidexOutData.FILLER_33))")
     @Mapping(target  = "lsiResAddressC",expression  = "java(com.hdfcbank.elengine.util.CommonUtility.defaultSetToNull(posidexOutData.FILLER_11))")
     @Mapping(target  = "lsiResCityC",expression  = "java(com.hdfcbank.elengine.util.CommonUtility.defaultSetToNull(posidexOutData.FILLER_2))")
     @Mapping(target  = "lsiResPhone1C",expression  = "java(com.hdfcbank.elengine.util.CommonUtility.defaultSetToNull(posidexOutData.FILLER_34))")
     @Mapping(target  = "lsiResZipC",expression  = "java(com.hdfcbank.elengine.util.CommonUtility.defaultSetToNull(posidexOutData.FILLER_12))")
     @Mapping(target  = "lsiSasIdN",expression  = "java(com.hdfcbank.elengine.util.CommonUtility.defaultSetToNull(posidexOutData.FILLER_59))")
     @Mapping(target  = "lsiStateC",expression  = "java(com.hdfcbank.elengine.util.CommonUtility.defaultSetToNull(posidexOutData.FILLER_22))")
     @Mapping(target  = "lsiTotalExposureN",expression = "java(Double.parseDouble(org.springframework.util.StringUtils.isEmpty(posidexOutData.FILLER_21) ? \"0\" : posidexOutData.FILLER_21))")
     @Mapping(target  = "lsiVoterIdC",expression  = "java(com.hdfcbank.elengine.util.CommonUtility.defaultSetToNull(posidexOutData.FILLER_36))")
     @Mapping(target  = "lsiFinnSrcReadC",constant = "0")
     @Mapping(target  = "lsiFinnSrcPrcsdC", constant = "0")
     @Mapping(target  = "matchcriterianum",expression  = "java(com.hdfcbank.elengine.util.CommonUtility.defaultSetToNull(posidexOutData.FILLER_31))")
     @Mapping(target  = "forcechangeuser",expression  = "java(com.hdfcbank.elengine.util.CommonUtility.defaultSetToNull(posidexOutData.FILLER_32))")
     @Mapping(target  = "location",expression  = "java(com.hdfcbank.elengine.util.CommonUtility.defaultSetToNull(posidexOutData.FILLER_41))")
     @Mapping(target  = "tenure",expression  = "java(com.hdfcbank.elengine.util.CommonUtility.defaultSetToNull(posidexOutData.FILLER_47))")
     @Mapping(target  = "noofmonthsdefault",expression  = "java(com.hdfcbank.elengine.util.CommonUtility.defaultSetToNull(posidexOutData.FILLER_49))")
     @Mapping(target  = "delqamount",expression  = "java(com.hdfcbank.elengine.util.CommonUtility.defaultSetToNull(posidexOutData.FILLER_50))")
     @Mapping(target  = "balavail",expression  = "java(com.hdfcbank.elengine.util.CommonUtility.defaultSetToNull(posidexOutData.FILLER_51))")
     @Mapping(target  = "emi",expression  = "java(com.hdfcbank.elengine.util.CommonUtility.defaultSetToNull(posidexOutData.FILLER_52))")
	 public LosInputFromsa mapPosidexOutBodytoLosInputFromsa(PosidexOutData posidexOutData);
	
	 
	 @Mapping(target  = "accountTypeTl",expression  = "java(com.hdfcbank.elengine.util.CommonUtility.defaultSetToNull(cibilSropDomainList.accountTypeTl))")
	 @Mapping(target  = "dateOpenedDisbursedTl",expression = "java(com.hdfcbank.elengine.util.CommonUtility.changeDateFormat(cibilSropDomainList.dateOpenedDisbursedTl,\"yyyy-MM-dd HH:mm:ss.SSS\", \"dd/MM/yyyy HH:mm:ss\"))")
	 @Mapping(target  = "highCreditSanctionedAmount",expression = "java(Double.parseDouble(org.springframework.util.StringUtils.isEmpty(cibilSropDomainList.highCreditSanctionedAmount) ? \"0\" : cibilSropDomainList.highCreditSanctionedAmount))")
	 @Mapping(target  = "wofTotAmountTl", expression = "java(Double.parseDouble(org.springframework.util.StringUtils.isEmpty(cibilSropDomainList.wofTotAmountTl) ? \"0\" : cibilSropDomainList.wofTotAmountTl))")
     public LosCibAccdetailSrop mapMbCibiltoLosCibAccdetailSrop(CibilSropDomainList cibilSropDomainList);
	 
	 
	 @Mapping(target  = "accounttypeRsAc",expression  = "java(com.hdfcbank.elengine.util.CommonUtility.defaultSetToNull(equifaxSropDomain.accounttypeRsAc))")
	 @Mapping(target  = "dateopenedRsAc",expression = "java(com.hdfcbank.elengine.util.CommonUtility.formatDate(equifaxSropDomain.dateopenedRsAc))")
	 @Mapping(target  = "sactionamtRsAc",source = "equifaxSropDomain.sactionamtRsAc",defaultValue = "0")
	 @Mapping(target  = "writeoffamtRsAc",expression = "java(Double.parseDouble(org.springframework.util.StringUtils.isEmpty(equifaxSropDomain.writeoffamtRsAc) ? \"0\" : equifaxSropDomain.writeoffamtRsAc))")
	 public LosEqAccdetailsSrop mapMbEquitoLosEqAccdetailsSrop(EquifaxSropDomain equifaxSropDomain);
	 
	 @Mapping(target  = "acctType",expression  = "java(com.hdfcbank.elengine.util.CommonUtility.defaultSetToNull(chmBaseSropDomainList1.acctType))")
	 @Mapping(target  = "disbursedDt",expression = "java(com.hdfcbank.elengine.util.CommonUtility.formatDate(chmBaseSropDomainList1.disbursedDt,\"dd-MM-yyyy HH:mm:ss\"))")
	 @Mapping(target  = "disbursedAmt",expression = "java(Double.parseDouble(org.springframework.util.StringUtils.isEmpty(chmBaseSropDomainList1.disbursedAmt) ? \"0\" : chmBaseSropDomainList1.disbursedAmt))")
	 @Mapping(target  = "writeOffAmt",source = "chmBaseSropDomainList1.writeOffAmt",defaultValue = "0")
	 public LosHmBasePriAcctypeSrop mapMBHmtoLosHmBasePriAcctypeSrop(ChmBaseSropDomainList1 chmBaseSropDomainList1);
	 
	 @Mapping(target  = "appId",expression  = "java(com.hdfcbank.elengine.util.CommonUtility.defaultSetToNull(String.valueOf(mbEoTRequestType.header.applicationId.content)))")
	 @Mapping(target  = "cbStatus",constant="null")
	 @Mapping(target  = "custId",expression  = "java(com.hdfcbank.elengine.util.CommonUtility.defaultSetToNull(String.valueOf(mbEoTRequestType.header.custId.content)))")
	 @Mapping(target  = "eotApplicationScoreDesc",expression  = "java(com.hdfcbank.elengine.util.CommonUtility.replaceSpecialChars(mbEoTRequestType.soaFillers.filler5.content))")
	 @Mapping(target  = "eotApplicationScoreStatus",expression  = "java(com.hdfcbank.elengine.util.CommonUtility.defaultSetToNull(mbEoTRequestType.soaFillers.filler4.content))")
	 @Mapping(target  = "eotApplicationScoreValue",expression  = "java(com.hdfcbank.elengine.util.CommonUtility.defaultSetToNull(mbEoTRequestType.soaFillers.filler3.content))")
	 @Mapping(target  = "fileName",constant="null") // need to check with team
	 public LosMbReqStatus mapLosMbReqStatus(MBEoTRequestType mbEoTRequestType);
	 
	 
	 @Mapping(target  = "appId",expression  = "java(com.hdfcbank.elengine.util.CommonUtility.defaultSetToNull(String.valueOf(mbEoTRequestType.header.applicationId)))")
	 @Mapping(target  = "cbStatus",constant="null")
	 @Mapping(target  = "custId",expression  = "java(com.hdfcbank.elengine.util.CommonUtility.defaultSetToNull(String.valueOf(mbEoTRequestType.header.custId)))")
	 @Mapping(target  = "eotApplicationScoreDesc",constant="null")
	 @Mapping(target  = "eotApplicationScoreStatus",constant="null")
	 @Mapping(target  = "eotApplicationScoreValue",constant="null")
	 @Mapping(target  = "fileName",constant="null") // need to check with team
	 public LosMbReqStatus mapLosMbReqFailureStatus(MultiBureauEoTRequest mbEoTRequestType);
	 
	 @Mapping(target  = "appId",source="ackId")
	 @Mapping(target  = "cbStatus",constant="null")
	 @Mapping(target  = "custId",constant="null")
	 @Mapping(target  = "eotApplicationScoreDesc",constant="null")
	 @Mapping(target  = "eotApplicationScoreStatus",constant="null")
	 @Mapping(target  = "eotApplicationScoreValue",constant="null")
	 @Mapping(target  = "fileName",constant="null") // need to check with team
	 public LosMbReqStatus mapLosMbReqEmptyStatus(String ackId);
	 
	 
	 @Mapping(target  = "pastEnqAmount",source="mergedSropDomain.pastEnqAmount",defaultValue = "0")
	 @Mapping(target  = "pastEnqDate",expression = "java(com.hdfcbank.elengine.util.CommonUtility.formatDate(mergedSropDomain.pastEnqDate,\"ddMMyyyy HH:mm:ss\"))")
	 @Mapping(target  = "pastEnqDoneBy",expression  = "java(com.hdfcbank.elengine.util.CommonUtility.defaultSetToNull(mergedSropDomain.pastEnqDoneBy))")
	 @Mapping(target  = "pastEnqReason",expression  = "java(com.hdfcbank.elengine.util.CommonUtility.defaultSetToNull(mergedSropDomain.pastEnqReason))")
	 @Mapping(target  = "pastEnqReportedBureaus",expression  = "java(com.hdfcbank.elengine.util.CommonUtility.defaultSetToNull(mergedSropDomain.pastEnqReportedBureaus))")
	 public LosMergedPastenqSrop mapLosMergedPastenqSrop(MergedSropDomain mergedSropDomain);
	 
	 @Mapping(target  = "tlAcctHistKey",expression  = "java(com.hdfcbank.elengine.util.CommonUtility.defaultSetToNull(mergedSropDomain.tlAcctHistKey))")
	 @Mapping(target  = "memberReferenceNumber",expression  = "java(com.hdfcbank.elengine.util.CommonUtility.defaultSetToNull(mergedSropDomain.memberReferenceNumber))")
	 @Mapping(target  = "tlAcctNumber",expression  = "java(com.hdfcbank.elengine.util.CommonUtility.defaultSetToNull(mergedSropDomain.tlAcctNumber))")
	 @Mapping(target  = "splitTime2",constant = "null")
	 @Mapping(target  = "tlCreditInst2",expression  = "java(com.hdfcbank.elengine.util.CommonUtility.defaultSetToNull(mergedSropDomain.tlCreditInst))")
	 @Mapping(target  = "tlAcctHistPaymentStatus",expression  = "java(com.hdfcbank.elengine.util.CommonUtility.defaultSetToNull(mergedSropDomain.tlAcctHistPaymentStatus))")
	 @Mapping(target  = "tlAcctHistAssetClass",expression  = "java(com.hdfcbank.elengine.util.CommonUtility.defaultSetToNull(mergedSropDomain.tlAcctHistAssetClass))")
	 @Mapping(target  = "tlAcctHistSuitFiledStatus",expression  = "java(com.hdfcbank.elengine.util.CommonUtility.defaultSetToNull(mergedSropDomain.tlAcctHistSuitFiledStatus))")
	 public LosMergedPaymenthistSrop mapLosMergedPaymenthistSrop(MergedSropDomain mergedSropDomain);
	 
	 
	 @Mapping(target  = "memberReferenceNumber2",expression  = "java(com.hdfcbank.elengine.util.CommonUtility.defaultSetToNull(mergedSropDomain.memberReferenceNumber))")
     @Mapping(target  = "splitTime",constant = "null")
	 @Mapping(target  = "tlAcctNumber2",expression  = "java(com.hdfcbank.elengine.util.CommonUtility.defaultSetToNull(mergedSropDomain.tlAcctNumber))")
	 @Mapping(target  = "tlAcctOpenDate",expression = "java(com.hdfcbank.elengine.util.CommonUtility.formatDate(mergedSropDomain.tlAcctOpenDate,\"ddMMyyyy HH:mm:ss\"))")
	 @Mapping(target  = "tlAcctType",expression  = "java(com.hdfcbank.elengine.util.CommonUtility.defaultSetToNull(mergedSropDomain.tlAcctType))")
	 @Mapping(target  = "tlBureauName",expression  = "java(com.hdfcbank.elengine.util.CommonUtility.defaultSetToNull(mergedSropDomain.tlBureauName))")
	 @Mapping(target  = "tlCreditInst",expression  = "java(com.hdfcbank.elengine.util.CommonUtility.defaultSetToNull(mergedSropDomain.tlCreditInst))")
	 @Mapping(target  = "tlCurrentBalance",source = "mergedSropDomain.tlCurrentBalance",defaultValue = "0")
	 @Mapping(target  = "tlDisbursedAmt",source="mergedSropDomain.tlDisbursedAmt",defaultValue = "0")
	 @Mapping(target  = "tlOverdueAmount",source="mergedSropDomain.tlOverdueAmount",defaultValue = "0")
	 @Mapping(target  = "tlOwnership",expression  = "java(com.hdfcbank.elengine.util.CommonUtility.defaultSetToNull(mergedSropDomain.tlOwnership))")
	 @Mapping(target  = "tlReportedBureaus",expression  = "java(com.hdfcbank.elengine.util.CommonUtility.defaultSetToNull(mergedSropDomain.tlReportedBureaus))")
	 @Mapping(target  = "tlSanctionedAmt",source="mergedSropDomain.tlSanctionedAmt",defaultValue = "0")
	 @Mapping(target  = "tlWriteoffStatus",expression  = "java(com.hdfcbank.elengine.util.CommonUtility.defaultSetToNull(mergedSropDomain.tlWriteoffStatus))")
	 @Mapping(target  = "tlClosedDate",expression = "java(com.hdfcbank.elengine.util.CommonUtility.formatDate(mergedSropDomain.tlClosedDate,\"ddMMyyyy HH:mm:ss\"))")
	 @Mapping(target  = "tlCollateral",expression  = "java(com.hdfcbank.elengine.util.CommonUtility.defaultSetToNull(mergedSropDomain.tlCollateral))")
	 @Mapping(target  = "tlInstallAmt",expression  = "java(com.hdfcbank.elengine.util.CommonUtility.defaultSetToNull(mergedSropDomain.tlInstallAmt))")
	 @Mapping(target  = "tlInterestRate",expression  = "java(com.hdfcbank.elengine.util.CommonUtility.defaultSetToNull(mergedSropDomain.tlInterestRate))")
	 @Mapping(target  = "tlLastPaymentAmt",expression  = "java(com.hdfcbank.elengine.util.CommonUtility.defaultSetToNull(mergedSropDomain.tlLastPaymentAmt))")
	 @Mapping(target  = "tlLastPaymentDate",expression = "java(com.hdfcbank.elengine.util.CommonUtility.formatDate(mergedSropDomain.tlLastPaymentDate,\"ddMMyyyy HH:mm:ss\"))")
	 @Mapping(target  = "tlPaymentRating",expression  = "java(com.hdfcbank.elengine.util.CommonUtility.defaultSetToNull(mergedSropDomain.tlPaymentRating))")
	 @Mapping(target  = "tlReportedDate",expression = "java(com.hdfcbank.elengine.util.CommonUtility.formatDate(mergedSropDomain.tlReportedDate,\"ddMMyyyy HH:mm:ss\"))")
	 @Mapping(target  = "tlSecured",expression  = "java(com.hdfcbank.elengine.util.CommonUtility.defaultSetToNull(mergedSropDomain.tlSecured))")
	 @Mapping(target  = "tlTenure",expression  = "java(com.hdfcbank.elengine.util.CommonUtility.defaultSetToNull(mergedSropDomain.tlTenure))")
	 public LosMergedTradelinesSrop mapLosMergedTradelinesSrop(MergedSropDomain mergedSropDomain);
	 
	 
	 @Mapping(target  = "appIdC",expression  = "java(com.hdfcbank.elengine.util.CommonUtility.defaultSetToNull(inBreServices.ackid))")
	 @Mapping(target  = "custIdN",expression  = "java(com.hdfcbank.elengine.util.CommonUtility.defaultSetToNull(inBreServices.ackid))")
	 @Mapping(target  = "laaAppTypeC",constant = "I")
	 @Mapping(target  = "apiFtnrFiller1",constant ="0")
	 @Mapping(target  = "apiFtnrFiller2",constant = "0")
	 @Mapping(target  = "apiFtnrFiller3",constant = "0")
	 @Mapping(target  = "apiFtnrFiller4",constant = "0")
	 @Mapping(target  = "apiFtnrFiller5",constant = "0")
	 @Mapping(target  = "apiFtnrFiller6",constant = "0")
	 @Mapping(target  = "apiFtnrFiller7",constant = "0")
	 @Mapping(target  = "apiFtnrFiller8",constant = "0")
	 @Mapping(target  = "apiFtnrFiller9",constant = "0")
	 @Mapping(target  = "apiFtnrFiller10",constant = "0")
	 @Mapping(target  = "apiFtnrFiller11",constant = "0")
	 @Mapping(target  = "apiFtnrFiller12",constant = "0")
	 @Mapping(target  = "apiFtnrFiller13",constant = "0")
	 @Mapping(target  = "apiFtnrFiller14",constant = "0")
	 @Mapping(target  = "apiFtnrFiller15",constant = "0")
	 @Mapping(target  = "apiFtnrFiller16",constant = "0")
	 @Mapping(target  = "apiFtnrFiller17",constant = "0")
	 @Mapping(target  = "apiFtnrFiller18",constant = "null")
	 @Mapping(target  = "apiFtnrFiller19",constant = "null")
	 @Mapping(target  = "apiFtnrFiller20",constant = "null")
	 @Mapping(target  = "apiFtnrFiller21",constant = "null")
	 @Mapping(target  = "apiFtnrFiller22",constant = "null")
	 @Mapping(target  = "apiFtnrFiller23",constant = "null")
	 @Mapping(target  = "apiFtnrFiller24",constant = "null")
	 @Mapping(target  = "apiFtnrFiller25",constant = "null")
	 @Mapping(target  = "apiFtnrFiller26",constant = "null")
	 @Mapping(target  = "apiFtnrFiller27",constant = "null")
	 @Mapping(target  = "apiFtnrFiller28",constant = "null")
	 @Mapping(target  = "apiFtnrFiller29",constant = "null")
	 @Mapping(target  = "apiFtnrFiller30",constant = "null")
	 @Mapping(target  = "apiFtnrFiller31",constant = "null")
	 @Mapping(target  = "apiFtnrFiller32",constant = "null")
	 @Mapping(target  = "apiFtnrFiller33",constant = "null")
	 @Mapping(target  = "apiFtnrFiller34",constant = "null")
	 @Mapping(target  = "apiFtnrFiller35",constant = "null")
	 @Mapping(target  = "apiFtnrFiller36",constant = "null")
	 @Mapping(target  = "apiFtnrFiller37",constant = "null")
	 @Mapping(target  = "apiFtnrFiller38",constant = "null")
	 @Mapping(target  = "apiFtnrFiller39",constant = "null")
	 @Mapping(target  = "apiFtnrFiller40",constant = "null")
	 @Mapping(target  = "apiFtnrFiller41",constant = "null")
	 @Mapping(target  = "apiFtnrFiller42",constant = "null")
	 @Mapping(target  = "apiFtnrFiller43",constant = "null")
	 @Mapping(target  = "apiFtnrFiller44",constant = "null")
	 @Mapping(target  = "apiFtnrFiller45",constant = "null")
	 @Mapping(target  = "apiFtnrFiller46",constant = "null")
	 @Mapping(target  = "apiFtnrFiller47",constant = "null")
	 @Mapping(target  = "apiFtnrFiller48",constant = "null")
	 @Mapping(target  = "apiFtnrFiller49",constant = "null")
	 @Mapping(target  = "apiFtnrFiller50",constant = "null")
	 @Mapping(target  = "apiFtnrFiller51",constant = "null")
	 @Mapping(target  = "apiFtnrFiller52",constant = "null")
	 @Mapping(target  = "apiFtnrFiller53",constant = "null")
	 @Mapping(target  = "apiFtnrFiller54",constant = "null")
	 @Mapping(target  = "apiFtnrFiller55",constant = "null")
	 @Mapping(target  = "apiFtnrFiller56",constant = "null")
	 @Mapping(target  = "apiFtnrFiller57",constant = "null")
	 @Mapping(target  = "apiFtnrFiller58",constant = "null")
	 @Mapping(target  = "apiFtnrFiller59",constant = "01/01/1900 00:00:00")
	 @Mapping(target  = "apiFtnrFiller60",constant = "01/01/1900 00:00:00")
	 @Mapping(target  = "apiFtnrFiller61",constant = "01/01/1900 00:00:00")
	 @Mapping(target  = "apiFtnrFiller62",constant = "01/01/1900 00:00:00")
	 @Mapping(target  = "apiFtnrFiller63",constant = "01/01/1900 00:00:00")
	 @Mapping(target  = "apiFtnrFiller64",constant = "01/01/1900 00:00:00")
	 @Mapping(target  = "apiFtnrFiller65",constant = "01/01/1900 00:00:00")
	 @Mapping(target  = "ftnrProbValue",constant = "0")
	public FtnrApplication mapFtnrApplication(InBreServices inBreServices);


}
