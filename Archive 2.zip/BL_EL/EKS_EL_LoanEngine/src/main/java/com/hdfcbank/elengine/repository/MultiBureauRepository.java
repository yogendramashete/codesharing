package com.hdfcbank.elengine.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.hdfcbank.elengine.domain.entity.MBEntity;
import com.hdfcbank.elengine.domain.enums.MBServiceType;

@Repository
public interface MultiBureauRepository extends JpaRepository<MBEntity, Integer>{

	Optional<MBEntity> findByoperationtype(MBServiceType cibil);
}
