package com.hdfcbank.elengine.constant;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public abstract class RegexConstants {

	public static final String PHONE_NUMBER = "(91)\\d{10}";
}
