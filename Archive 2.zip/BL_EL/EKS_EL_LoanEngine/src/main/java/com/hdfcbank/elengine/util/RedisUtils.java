package com.hdfcbank.elengine.util;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;
import redis.clients.jedis.JedisCluster;

@Component
@Slf4j
public class RedisUtils {


	@Autowired
	RedisPubConn redisPub;

	@Value("${cache.redis.cluster.host}")
	String REDIS_HOST_ADDRESS;

	@Value("${cache.redis.cluster.port}")
	String REDIS_PORT;

	JedisCluster cluster = null;

	public void set(String key, String value) {

		try {

			if (cluster == null) {
				cluster = redisPub.openConnection(REDIS_HOST_ADDRESS, Integer.valueOf(REDIS_PORT));
				log.info("redis cluster object 337:: " + cluster);
			}
			cluster.set(key, value);

		} catch (Exception exe) {
			exe.printStackTrace();
		}
	}

	public String get(String key) {
		String value = "";
		try {
			if (cluster == null) {
				cluster = redisPub.openConnection(REDIS_HOST_ADDRESS, Integer.valueOf(REDIS_PORT));
				log.info("redis cluster object 337:" , cluster);
			}

			value = cluster.get(key) == null ? "" : cluster.get(key);
			 log.debug("cluster get :: " ,cluster.get(key));
		} catch (Exception exe) {
//			exe.printStackTrace();
		}
		return value;
	}

	public void sadd(String key, String value) {

		try {
			if (cluster == null) {
				cluster = redisPub.openConnection(REDIS_HOST_ADDRESS, Integer.valueOf(REDIS_PORT));
				log.info("redis cluster object 337:" + cluster);
			}

			cluster.sadd(key, value);
			// logger.info("cluster smembers :: " + cluster.smembers(key));
		} catch (Exception exe) {
			exe.printStackTrace();
		}
	}

	public void sadd(String key, Set<String> value) {

		try {
			String[] valueArr = Arrays.copyOf(value.toArray(), value.size(), String[].class);
			if (cluster == null) {
				cluster = redisPub.openConnection(REDIS_HOST_ADDRESS, Integer.valueOf(REDIS_PORT));
				log.info("redis cluster object 337:" + cluster);
			}

			cluster.sadd(key, valueArr);
			// logger.info("cluster smembers :: " + cluster.smembers(key));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public Set<String> smembers(String key) {
		Set<String> smembers = new HashSet<String>();
		try {
			if (cluster == null) {
				cluster = redisPub.openConnection(REDIS_HOST_ADDRESS, Integer.valueOf(REDIS_PORT));
				log.info("redis cluster object 337:" + cluster);
			}

			smembers = cluster.smembers(key);
			// logger.info("cluster smembers :: " + cluster.smembers(key));
		} catch (Exception exe) {
			exe.printStackTrace();
		}
		return smembers;

	}

	public long scard(String key) {
		long membersCount = 0;
		try {
			if (cluster == null) {
				cluster = redisPub.openConnection(REDIS_HOST_ADDRESS, Integer.valueOf(REDIS_PORT));
				log.info("redis cluster object 337:" + cluster);
			}

			membersCount = cluster.scard(key);
			// logger.info("cluster smembers :: " + cluster.smembers(key));
		} catch (Exception exe) {
			exe.printStackTrace();
		}
		return membersCount;

	}

	public long del(String key) {
		long delCount = 0;
		try {
			if (cluster == null) {
				cluster = redisPub.openConnection(REDIS_HOST_ADDRESS, Integer.valueOf(REDIS_PORT));
			}

			delCount = cluster.del(key);
		} catch (Exception exe) {
			exe.printStackTrace();
		}
		return delCount;
	}

	public long incr(String key) {
		long value = 0;
		try {
			if (cluster == null) {
				cluster = redisPub.openConnection(REDIS_HOST_ADDRESS, Integer.valueOf(REDIS_PORT));
			}

			value = cluster.incr(key);
		} catch (Exception exe) {
			exe.printStackTrace();
		}
		return value;
	}

	public void expire(String key, int time) {

		try {
			if (cluster == null) {
				cluster = redisPub.openConnection(REDIS_HOST_ADDRESS, Integer.valueOf(REDIS_PORT));
			}

			cluster.expire(key, time);
		} catch (Exception exe) {
			exe.printStackTrace();
		}
	}

	public boolean exists(String key) {
		boolean isExists = false;
		try {
			if (cluster == null) {
				cluster = redisPub.openConnection(REDIS_HOST_ADDRESS, Integer.valueOf(REDIS_PORT));
			}

			isExists = cluster.exists(key);
		} catch (Exception exe) {
			exe.printStackTrace();
		}
		return isExists;
	}

}
