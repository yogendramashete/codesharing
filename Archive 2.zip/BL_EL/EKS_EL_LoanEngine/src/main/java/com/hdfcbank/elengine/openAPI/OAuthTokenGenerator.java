package com.hdfcbank.elengine.openAPI;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.MalformedURLException;
import java.net.URL;
import java.security.KeyStore;
import java.security.SecureRandom;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.KeyManager;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;

//import org.omg.CORBA.DataOutputStream;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

/**
 * Call HDFC Bank Oauth Service to generate OAuth Token. Service URL is configured in Config.properties file. 
 * @author Madhura Oak
 *
 */
@Service
public class OAuthTokenGenerator {
	public final static Logger logger = LoggerFactory.getLogger(DigitalSignature.class);

	@Value("${OAUTH_TOKEN_SERVICE_URL}")
	 String OAUTH_TOKEN_SERVICE_URL;
	
	@Value("${AUTHORIZATION}")
	 String AUTHORIZATION ;
	
	@Value("${BASIC}")
	String BASIC;
	
	@Value("${USERNAME}")
	String USERNAME ;
	
	@Value("${PASSWORD}")
	String PASSWORD;
	
	@Value("${BLEL_OAUTH_TOKEN_SERVICE_URL}")
	String BLEL_OAUTH_TOKEN_SERVICE_URL;

	@Value("${openbankapiconnector.blelpfxpath}")
	String BLELpfxPath;

	@Value("${openbankapiconnector.blelpfxpassword}")
	String BLELpfxPassword;

	@Value("${openbankapiconnector.blelkeystorepath}")
	String BLELkeyStorePath;

	@Value("${openbankapiconnector.blelkeystorepassword}")
	String BLELkeyStorePassword;

	@Value("${openbankapiconnector.bleltruststorepath}")
	String BLELtrustStorePath;

	@Value("${openbankapiconnector.bleltruststorepassword}")
	String BLELtrustStorePassword;

	@Value("${openbankapiconnector.blelclientscope}")
	String BLELclientScope;

	
	private static final String COLON = ":";
	
	@Value("${POST}")
	String POST ;
	
	@Value("${CONTENT_TYPE}")
	String CONTENT_TYPE ;
	
	@Value("${CONTENT_LENGTH}")
	String CONTENT_LENGTH ;
	@Value("${FORM_URL_ENCODED}")
	String FORM_URL_ENCODED ;
	@Value("${GRANT_TYPE}")
	String GRANT_TYPE ;
	@Value("${CLIENT_CREDENTIALS}")
	String CLIENT_CREDENTIALS ;
	@Value("${SCOPE}")
	String SCOPE ;
	
	private static final String EQUALTO = "=";
	
	private static final String AND = "&";

	private static final String CLIENT_KEYSTORE_TYPE = "PKCS12";
	
	@Value("${ACCESS_TOKEN}")
	String ACCESS_TOKEN ;
	
	/**
	 * Call HDFC bank Oauth Service to get Oauth token. 
	 * @param clientId
	 * @param clientSecret
	 * @param scope 
	 * @return Oauth token
	 * @throws IOException
	 */
	public String getOAuthToken(String clientId, String clientSecret, String scope) throws IOException {
		String oauthToken = null;
		HttpsURLConnection conn = null;
		try {
			logger.info("client Id :" + clientId);
			logger.info("client Secret :" + clientSecret);
			String oauthTokenServiceURL = OAUTH_TOKEN_SERVICE_URL;
			URL url = new URL(oauthTokenServiceURL);
			conn = (HttpsURLConnection) url.openConnection();
			Base64EncoderDecoder encoder = new Base64EncoderDecoder();
			String encoded = encoder.encodeToString(clientId + COLON + clientSecret);
			conn.setRequestProperty(AUTHORIZATION, BASIC + encoded);
			conn.setRequestMethod(POST);
			conn.setRequestProperty(CONTENT_TYPE, FORM_URL_ENCODED);
			StringBuilder builder = new StringBuilder();
			
			builder.append(GRANT_TYPE).append(EQUALTO).append(CLIENT_CREDENTIALS).append(AND).append(SCOPE)
					.append(EQUALTO).append(scope);
			logger.info(builder.toString());
			conn.setRequestProperty(CONTENT_LENGTH, String.valueOf(builder.length()));
			conn.setConnectTimeout(10000);
			conn.setUseCaches(false);
			conn.setDoInput(true);
			conn.setDoOutput(true);
			PrintWriter writer = new PrintWriter(conn.getOutputStream());
			writer.write(builder.toString());
			writer.close();
			BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
			builder.delete(0, builder.length());
			String line = null;
			while ((line = reader.readLine()) != null) {
				builder.append(line);
			}
			JsonParser parser = new JsonParser();
			JsonObject jsonObject = (JsonObject) parser.parse(builder.toString());
			oauthToken = jsonObject.get(ACCESS_TOKEN).getAsString();
		} catch (MalformedURLException exp) {
			exp.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
			if (conn != null) {
				try (BufferedReader in = new BufferedReader(new InputStreamReader(conn.getErrorStream()))) {
					String inputLine;
					StringBuffer buffResp = new StringBuffer();

					while ((inputLine = in.readLine()) != null) {
						buffResp.append(inputLine);
					}
					logger.info("error stream :" + buffResp.toString());
					in.close();
				} catch (Exception e2) {
					e2.printStackTrace();
				}
			}
		}
		return oauthToken;
	}
	
	public String getOAuthTokenBLEL(String clientId, String clientSecret, String scope) throws IOException {
		String oauthToken = "";

		HttpsURLConnection conn = null;
		try {
			logger.info("client Id :" + clientId);
			logger.info("client Secret :" + clientSecret);

			String oauthTokenServiceURL =BLEL_OAUTH_TOKEN_SERVICE_URL;
//					"https://api-uat.hdfcbank.com/auth/oauth/v2/token?scope=blel&grant_type=client_credentials";    // BLEL_OAUTH_TOKEN_SERVICE_URL;
			logger.info("OAUTH_TOKEN_SERVICE_URL :" + oauthTokenServiceURL);
			logger.info("scope :" + scope);

			KeyStore clientStore = KeyStore.getInstance("PKCS12");
			clientStore.load(new FileInputStream(BLELpfxPath), BLELpfxPassword.toCharArray());
			KeyManagerFactory kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
			kmf.init(clientStore, BLELpfxPassword.toCharArray());

			KeyManager[] kms = kmf.getKeyManagers();
			SSLContext sslContext = null;
			sslContext = SSLContext.getInstance("TLSv1.2");
			// sslContext.init(kms, null , null);
			// conn = (HttpsURLConnection) url.openConnection();

			sslContext.init(kmf.getKeyManagers(), null, null);

			URL url = new URL(oauthTokenServiceURL);
			conn = (HttpsURLConnection) url.openConnection();
			Base64EncoderDecoder encoder = new Base64EncoderDecoder();
			String encoded = encoder.encodeToString(clientId + COLON + clientSecret);

			conn.setRequestProperty(AUTHORIZATION, BASIC + encoded);
			conn.setRequestMethod(POST);
			conn.setRequestProperty(CONTENT_TYPE, FORM_URL_ENCODED);
			conn.setSSLSocketFactory(sslContext.getSocketFactory());

			StringBuilder builder = new StringBuilder();

			//builder.append("scope").append(EQUALTO).append(scope).append(AND).append(GRANT_TYPE).append(EQUALTO)
				//	.append(CLIENT_CREDENTIALS);

			logger.info(builder.toString());
			conn.setRequestProperty(CONTENT_LENGTH, "0");
			conn.setConnectTimeout(10000);
			conn.setUseCaches(false);
			conn.setDoInput(true);
			conn.setDoOutput(true);

			PrintWriter writer = new PrintWriter(conn.getOutputStream());
			writer.write(builder.toString());
			writer.close();

			BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
			builder.delete(0, builder.length());
			String line = null;

			while ((line = reader.readLine()) != null) {
				builder.append(line);
			}

			JsonParser parser = new JsonParser();
			JsonObject jsonObject = (JsonObject) parser.parse(builder.toString());
			oauthToken = jsonObject.get(ACCESS_TOKEN).getAsString();
			logger.info("oauthToken"+oauthToken );
		} catch (MalformedURLException exp) {
			exp.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
			if (conn != null) {
				try (BufferedReader in = new BufferedReader(new InputStreamReader(conn.getErrorStream()))) {
					String inputLine;
					StringBuffer buffResp = new StringBuffer();

					while ((inputLine = in.readLine()) != null) {
						buffResp.append(inputLine);
					}
					logger.info("error stream :" + buffResp.toString());
					in.close();
				} catch (Exception e2) {
					e2.printStackTrace();
				}
			}
		}
		return oauthToken;
	}

	private static SSLContext getSSLSocketFactory(String PFX_location, String PFX_Password) throws Exception {

		SSLContext context = null;
		File pKeyFile = new File(PFX_location);
		KeyManagerFactory keyManagerFactory = KeyManagerFactory.getInstance("SunX509");
		KeyStore keyStore = KeyStore.getInstance(CLIENT_KEYSTORE_TYPE);
		InputStream keyInput = new FileInputStream(pKeyFile);
		keyStore.load(keyInput, PFX_Password.toCharArray());
		keyInput.close();
		keyManagerFactory.init(keyStore, PFX_Password.toCharArray());
		context = SSLContext.getInstance("SSLv3");
		context.init(keyManagerFactory.getKeyManagers(), null, new SecureRandom());
		return context;
	}

}
	