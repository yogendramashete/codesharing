package com.hdfcbank.elengine.domain.enums;

public enum ExpBreTagType {


	EMPTYSTRING(""),STRING("Z"), DECIMAL("-9999"), INT("-9999"),DATE("1900-01-01"),PERFIOSDATE("1900-01-01");

	private final String code;

	private ExpBreTagType(String code) {
		this.code = code;
	}

	public String toInt() {
		return code;
	}

	public String toString() {
		return String.valueOf(code);
	}

}
