package com.hdfcbank.elengine.exception;

import java.util.stream.Collectors;

import org.hibernate.exception.SQLGrammarException;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.server.ResponseStatusException;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.hdfcbank.elengine.util.ApiResponse;
import com.hdfcbank.elengine.util.ErrorResponse;

import lombok.extern.slf4j.Slf4j;

@RestControllerAdvice
@Slf4j
public class RestExceptionHandler {

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ApiResponse<ErrorResponse> handleMethodArgumentNotValidException(MethodArgumentNotValidException e) {
        log.error("Invalid request parameters", e);
        return ApiResponse.error(new ErrorResponse(HttpStatus.BAD_REQUEST.value(),
                "Invalid Parameters", e.getBindingResult().getFieldErrors().stream()
                .map(fieldError -> fieldError.getField() + " " + fieldError.getDefaultMessage())
                .collect(Collectors.toList())));
    }

    @ExceptionHandler(value = ResponseStatusException.class)
    public final ApiResponse<ErrorResponse> handleResponseStatusException(ResponseStatusException e) {
        log.error("ResponseStatusException occurred", e);
        return ApiResponse.error(new ErrorResponse(e.getStatus().value(), e.getReason()));
    }

    @ExceptionHandler(JsonProcessingException.class)
    public ApiResponse<ErrorResponse> handleJsonProcessingException(JsonProcessingException e) {
        log.error("Exception occurred while processing json data", e);
        return ApiResponse.error(new ErrorResponse(HttpStatus.INTERNAL_SERVER_ERROR.value(), e.getMessage()));
    }
    
    @ExceptionHandler(SQLGrammarException.class)
    public ApiResponse<ErrorResponse> handleSQLDataException(SQLGrammarException e) {
        log.error("Exception occurred while accessing sql data", e);
        return ApiResponse.error(new ErrorResponse(e.getErrorCode(), e.getMessage()));
    }
        
//    @ExceptionHandler(Exception.class)
    public ApiResponse<ErrorResponse> handleAllException(Exception e) {
        log.error("Exception occurred", e);
        return ApiResponse.error(new ErrorResponse(HttpStatus.INTERNAL_SERVER_ERROR.value(),
                e.getMessage().isEmpty() ? "Internal Server Error" : e.getMessage()));
    }

}
