
package com.hdfcbank.elengine.domain.request;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@NoArgsConstructor
@AllArgsConstructor
@Data
public class InitiateBlBrebApp {
	@JsonProperty("productCode")
	public String productCode;
	@JsonProperty("ackId")
	public String ackId;
	@JsonProperty("mobileNo")
	public String mobileNo;
	@JsonProperty("gstn_uin")
	public String gstnUin;
	@JsonProperty("legal_name")
	public String legalName;
	@JsonProperty("state_jurisdiction")
	public String stateJurisdiction;
	@JsonProperty("center_jurisdiction")
	public String centerJurisdiction;
	@JsonProperty("date_of_registration")
	public String dateOfRegistration;
	@JsonProperty("consitution_of_business")
	public String consitutionOfBusiness;
	@JsonProperty("tax_payer_type")
	public String taxPayerType;
	@JsonProperty("nature_of_business_activity")
	public String natureOfBusinessActivity;
	@JsonProperty("gstn_uin_status")
	public String gstnUinStatus;
	@JsonProperty("date_of_cancellation")
	public String dateOfCancellation;
	@JsonProperty("last_updated_date")
	public String lastUpdatedDate;
	@JsonProperty("state_jurisdiction_code")
	public String stateJurisdictionCode;
	@JsonProperty("centre_jurisdiction_code")
	public String centreJurisdictionCode;
	@JsonProperty("registration_trade_name")
	public String registrationTradeName;
	@JsonProperty("principal_place_of_business")
	public String principalPlaceOfBusiness;
	@JsonProperty("additional_palce_of_business")
	public String additionalPalceOfBusiness;
	@JsonProperty("pan_number")
	public String panNumber;
	@JsonProperty("total")
	public Integer total;
	@JsonProperty("business_address")
	public String businessAddress;
	@JsonProperty("company_name")
	public String companyName;
	@JsonProperty("registration_date")
	public String registrationDate;
	@JsonProperty("registration_status")
	public String registrationStatus;
	@JsonProperty("business_constitution")
	public String businessConstitution;
	@JsonProperty("cancellation_date")
	public String cancellationDate;
	@JsonProperty("grc_1_score")
	public Integer grc1Score;
	@JsonProperty("grc_3b_score")
	public Integer grc3bScore;
	@JsonProperty("type")
	public String type;
	@JsonProperty("financial_year")
	public String financialYear;
	@JsonProperty("gst_arn_level")
	public List<GstArnLevel> gstArnLevel = null;
	@JsonProperty("statename")
	public String statename;
	@JsonProperty("busines_segment")
	public String businesSegment;
	@JsonProperty("mobile_number")
	public String mobileNumber;
	@JsonProperty("pan")
	public String pan;
	@JsonProperty("enter_otp_1_mobile_validation")
	public Integer enterOtp1MobileValidation;
	@JsonProperty("first_name")
	public String firstName;
	@JsonProperty("middle_name")
	public String middleName;
	@JsonProperty("last_name")
	public String lastName;
	@JsonProperty("gender")
	public String gender;
	@JsonProperty("dob")
	public String dob;
	@JsonProperty("employment_type")
	public String employmentType;
	@JsonProperty("curr_resi_add_bureu_or_bank_records")
	public String currResiAddBureuOrBankRecords;
	@JsonProperty("curr_resi_add_manual")
	public String currResiAddManual;
	@JsonProperty("curr_resi_add_line1")
	public String currResiAddLine1;
	@JsonProperty("curr_resi_add_line2")
	public String currResiAddLine2;
	@JsonProperty("curr_resi_add_line3")
	public String currResiAddLine3;
	@JsonProperty("curr_resi_add_pincode")
	public String currResiAddPincode;
	@JsonProperty("curr_resi_add_city")
	public String currResiAddCity;
	@JsonProperty("curr_resi_add_state")
	public String currResiAddState;
	@JsonProperty("gstin")
	public String gstin;
	@JsonProperty("helped_by_hdfc_employee")
	public String helpedByHdfcEmployee;
	@JsonProperty("channel_name")
	public String channelName;
	@JsonProperty("branch_code")
	public String branchCode;
	@JsonProperty("dsa_code")
	public String dsaCode;
	@JsonProperty("sm_code")
	public String smCode;
	@JsonProperty("se_code")
	public String seCode;
	@JsonProperty("lc_code")
	public String lcCode;
	@JsonProperty("lg_code")
	public String lgCode;
	@JsonProperty("crm_promo_code")
	public String crmPromoCode;
	@JsonProperty("loan_amount_bre1")
	public Integer loanAmountBre1;
	@JsonProperty("tenure_bre1")
	public Integer tenureBre1;
	@JsonProperty("agreement_key_facts_charges_bre1")
	public String agreementKeyFactsChargesBre1;
	@JsonProperty("e_verification_options")
	public String eVerificationOptions;
	@JsonProperty("perfios_tnc")
	public String perfiosTnc;
	@JsonProperty("select_your_existing_bank")
	public String selectYourExistingBank;
	@JsonProperty("net_banking_id_of_bank")
	public String netBankingIdOfBank;
	@JsonProperty("net_banking_password")
	public String netBankingPassword;
	@JsonProperty("document_type")
	public String documentType;
	@JsonProperty("loan_amount")
	public Integer loanAmount;
	@JsonProperty("tenure_bre")
	public Integer tenureBre;
	@JsonProperty("agreement_key_facts_charges_bre2")
	public String agreementKeyFactsChargesBre2;
	@JsonProperty("loan_amount_bre2")
	public String loanAmountBre2;
	@JsonProperty("tenure_bre2")
	public String tenureBre2;
	@JsonProperty("turnover_of_business")
	public String turnoverOfBusiness;
	@JsonProperty("profit_after_tax")
	public String profitAfterTax;
	@JsonProperty("depreciation")
	public String depreciation;
	@JsonProperty("monthly_obligations_if_any")
	public String monthlyObligationsIfAny;
	@JsonProperty("net_take_home_salary")
	public String netTakeHomeSalary;
	@JsonProperty("loan_amount_ipa_offer")
	public Integer loanAmountIpaOffer;
	@JsonProperty("tenure_ipa_offer")
	public Integer tenureIpaOffer;
	@JsonProperty("agreement_key_facts_charges_bre3")
	public String agreementKeyFactsChargesBre3;
	@JsonProperty("preferred_langauge")
	public String preferredLangauge;
	@JsonProperty("aadhar_consent")
	public String aadharConsent;
	@JsonProperty("vkyc_consent")
	public String vkycConsent;
	@JsonProperty("aadhar_options")
	public String aadharOptions;
	@JsonProperty("ekyc_option_1")
	public String ekycOption1;
	@JsonProperty("ekyc_option_2")
	public String ekycOption2;
	@JsonProperty("enter_otp_2")
	public Integer enterOtp2;
	@JsonProperty("document_selection")
	public String documentSelection;
	@JsonProperty("document_number")
	public String documentNumber;
	@JsonProperty("date_of_expiry_of_the_document")
	public String dateOfExpiryOfTheDocument;
	@JsonProperty("confirm_address_type")
	public String confirmAddressType;
	@JsonProperty("is_this_your_permanent_address")
	public String isThisYourPermanentAddress;
	@JsonProperty("permanent_add_line_1")
	public String permanentAddLine1;
	@JsonProperty("permanent_add_line_2")
	public String permanentAddLine2;
	@JsonProperty("permanent_add_line_3")
	public String permanentAddLine3;
	@JsonProperty("permanent_add_pincode")
	public String permanentAddPincode;
	@JsonProperty("permanent_add_city")
	public String permanentAddCity;
	@JsonProperty("permanent_add_state")
	public String permanentAddState;
	@JsonProperty("office_add_same_as_current")
	public String officeAddSameAsCurrent;
	@JsonProperty("office_add_line_1")
	public String officeAddLine1;
	@JsonProperty("office_add_line_2")
	public String officeAddLine2;
	@JsonProperty("office_add_line_3")
	public String officeAddLine3;
	@JsonProperty("office_add_pincode")
	public String officeAddPincode;
	@JsonProperty("office_add_city")
	public String officeAddCity;
	@JsonProperty("office_add_state")
	public String officeAddState;
	@JsonProperty("office_number")
	public String officeNumber;
	@JsonProperty("preferred_contact_location")
	public String preferredContactLocation;
	@JsonProperty("personal_email_id")
	public String personalEmailId;
	@JsonProperty("enter_otp_3")
	public Integer enterOtp3;
	@JsonProperty("name_of_business")
	public String nameOfBusiness;
	@JsonProperty("name_of_employer")
	public String nameOfEmployer;
	@JsonProperty("nature_of_business_profile")
	public String natureOfBusinessProfile;
	@JsonProperty("occupation")
	public String occupation;
	@JsonProperty("purpose_of_loan")
	public String purposeOfLoan;
	@JsonProperty("name_of_medical_council")
	public String nameOfMedicalCouncil;
	@JsonProperty("registration_of_medical_council")
	public String registrationOfMedicalCouncil;
	@JsonProperty("year_of_registration_with_medical_council")
	public String yearOfRegistrationWithMedicalCouncil;
	@JsonProperty("icai_membership_number")
	public String icaiMembershipNumber;
	@JsonProperty("name_of_electricity_board")
	public String nameOfElectricityBoard;
	@JsonProperty("unique_customer_id")
	public String uniqueCustomerId;
	@JsonProperty("relationship_with_connection_owner")
	public String relationshipWithConnectionOwner;
	@JsonProperty("referencees_name")
	public String referenceesName;
	@JsonProperty("referencees_contact_number")
	public String referenceesContactNumber;
	@JsonProperty("maritial_status")
	public String maritialStatus;
	@JsonProperty("religion")
	public String religion;
	@JsonProperty("bank_name")
	public String bankName;
	@JsonProperty("bank_ac_number")
	public String bankAcNumber;
	@JsonProperty("desired_credit_sales_promo")
	public String desiredCreditSalesPromo;
	@JsonProperty("ucic_id")
	public String ucicId;
	@JsonProperty("laa_app_signed_date_d")
	public String laaAppSignedDateD;
	@JsonProperty("partnerJourneyId")
	public String  partnerJourneyId;
}
