package com.hdfcbank.elengine.domain.enums;

public enum LappTermIn {

	SEB(36), SEP(60), SD(60);

	private final int code;

	private LappTermIn(int code) {
		this.code = code;
	}

	public int toInt() {
		return code;
	}

	public String toString() {
		return String.valueOf(code);
	}
}
