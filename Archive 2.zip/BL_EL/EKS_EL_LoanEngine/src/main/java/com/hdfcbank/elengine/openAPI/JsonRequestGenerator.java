package com.hdfcbank.elengine.openAPI;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.security.PublicKey;
import java.security.UnrecoverableEntryException;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.xml.sax.SAXException;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

/**
 * Generate Json request
 * 
 * @author Madhura Oak
 *
 */
@Service
public class JsonRequestGenerator {
	private static final String X509 = "X.509";
	private static final String CONFIG = "Config";
	public final static Logger logger = LoggerFactory.getLogger(DigitalSignature.class);

	@Value("${clientKeyStoreFilePath}")
	String clientKeyStoreFilePath;

	@Value("${clientKeyStorePassword}")
	String clientKeyStorePassword;

	@Value("${clientKeyAlias}")
	String clientKeyAlias;

	@Value("${bankCertificateFilePath}")
	String bankCertificateFilePath;
	
	@Value("${apibankCertificateFilePath}")
	String apibankCertificateFilePath;

	@Value("${clientId}")
	String clientId;

	@Value("${clientSecret}")
	String clientSecret;

	@Value("${clientScope}")
	String clientScope;


	@Autowired
	OAuthTokenGenerator authTokenGenerator;

	@Value("${dapcertificatepath}")
	String dapcertificatepath;

	 
	@Value("${jsonrequestgenerator.blelclientid}")
	String BLELclientId;

	@Value("${jsonrequestgenerator.blelclientsecret}")
	String BLELclientSecret;

	@Value("${jsonrequestgenerator.blelclientscope}")
	String BLELclientScope;
	

	
	
	/**
	 * Load public key from the bank's public certificate
	 * 
	 * @throws FileNotFoundException
	 * @throws CertificateException
	 */
	private PublicKey initPublicKey() throws FileNotFoundException, CertificateException {
		X509Certificate bankCertificate = null;
		PublicKey publicKey = null;
		try (FileInputStream fin = new FileInputStream(bankCertificateFilePath)) {
			CertificateFactory factory = CertificateFactory.getInstance(X509);
			bankCertificate = (X509Certificate) factory.generateCertificate(fin);
			if(bankCertificate != null) {
				publicKey = bankCertificate.getPublicKey();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return publicKey;
	}
	

	/**
	 * Load public key from the bank's public certificate
	 * 
	 * @throws FileNotFoundException
	 * @throws CertificateException
	 */
	private PublicKey initApiPublicKey() throws FileNotFoundException, CertificateException {
		X509Certificate bankCertificate = null;
		PublicKey publicKey = null;
		try (FileInputStream fin = new FileInputStream(apibankCertificateFilePath)) {
			CertificateFactory factory = CertificateFactory.getInstance(X509);
			bankCertificate = (X509Certificate) factory.generateCertificate(fin);
			if(bankCertificate != null) {
				publicKey = bankCertificate.getPublicKey();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return publicKey;
	}
	

	/**
	 * Load public key from the bank's public certificate
	 * 
	 * @throws FileNotFoundException
	 * @throws CertificateException
	 */
	public PublicKey initDapPublicKey() throws FileNotFoundException, CertificateException {
		logger.info("dap_certificatepath :" + dapcertificatepath);
		X509Certificate bankCertificate = null;
		PublicKey	publicKey	= null;
		try(FileInputStream fin = new FileInputStream(dapcertificatepath)) {
			CertificateFactory factory = CertificateFactory.getInstance(X509);
			bankCertificate = (X509Certificate) factory.generateCertificate(fin);		
			if(bankCertificate != null) {
				publicKey = bankCertificate.getPublicKey();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return publicKey;
	}

	private Gson gson = new GsonBuilder().disableHtmlEscaping().create();

	
	public String generateRequest(String xmlRequest, String scope, String transactionId)
			throws CertificateException, UnrecoverableEntryException, SAXException, IOException {
		PublicKey bankPublicKey = initPublicKey();
		JsonRequest request = new JsonRequest();
		
		KeyGenerator keyGenerator = new KeyGenerator();
		byte[] key = keyGenerator.generateKey(32);

		// encrypt encoded value using random key
		AESEncrypterDecrypter aesEncrypter = new AESEncrypterDecrypter();
		byte[] encryptedValue = aesEncrypter.encrypt(xmlRequest, key);

		// encode the encrypted request
		Base64EncoderDecoder encoder = new Base64EncoderDecoder();
		byte[] encodedValue = encoder.encode(encryptedValue);

		request.setRequestSignatureEncryptedValue(new String(encodedValue));
//		logger.info("Request :" + new String(encodedValue));

		// encrypt symmetric key using bank's public key
		RSAEncrypterDecrypter rsaEncrypter = new RSAEncrypterDecrypter();
//		logger.info("bank public key :"+bankPublicKey);
		byte[] symmetricKeyEncryptedValue = rsaEncrypter.encrypt(key, bankPublicKey);

		// encode symmetric key
		encodedValue = encoder.encode(symmetricKeyEncryptedValue);
		request.setSymmetricKeyEncryptedValue(new String(encodedValue));
//		logger.info("Key :" + new String(encodedValue));

		request.setScope(scope);
		request.setTransactionId(transactionId);

		String oauthToken = authTokenGenerator.getOAuthToken(clientId, clientSecret, clientScope);
		request.setOAuthTokenValue(oauthToken);

		// convert request object to json
		String gsonRequest = gson.toJson(request);

		return gsonRequest;
	}

	public String generateCrmRequest(String xmlRequest, String scope, String transactionId)
			throws CertificateException, UnrecoverableEntryException, SAXException, IOException {
		PublicKey bankPublicKey = initPublicKey();
		CrmJsonRequest request = new CrmJsonRequest();
	
		// generate 32 byte random key
		KeyGenerator keyGenerator = new KeyGenerator();
		byte[] key = keyGenerator.generateKey(32);

		// encrypt encoded value using random key
		AESEncrypterDecrypter aesEncrypter = new AESEncrypterDecrypter();
		byte[] encryptedValue = aesEncrypter.encrypt(xmlRequest, key);

		// encode the encrypted request
		Base64EncoderDecoder encoder = new Base64EncoderDecoder();
		byte[] encodedValue = encoder.encode(encryptedValue);

		request.setRequestEncryptedValue(new String(encodedValue));
		logger.info("Request :" + new String(encodedValue));

		// encrypt symmetric key using bank's public key
		RSAEncrypterDecrypter rsaEncrypter = new RSAEncrypterDecrypter();
		logger.info("bank public key :" + bankPublicKey);
		byte[] symmetricKeyEncryptedValue = rsaEncrypter.encrypt(key, bankPublicKey);

		// encode symmetric key
		encodedValue = encoder.encode(symmetricKeyEncryptedValue);
		request.setSessionEncryptedValue(new String(encodedValue));
		logger.info("Key :" + new String(encodedValue));

		request.setSource(scope);
		request.setTransactionId(transactionId);

		String oauthToken = "";

		request.setOAuthTokenValue(oauthToken);

		request.setRequestDigitalSignatureValue("");
		request.setSessionDigitalSignatureValue("");
		// convert request object to json
		String gsonRequest = gson.toJson(request);

		return gsonRequest;
	}

	public String generateLeadStatusRequest(String xmlRequest, String scope, String transactionId)
			throws CertificateException, UnrecoverableEntryException, SAXException, IOException {

		PublicKey bankPublicKey = initPublicKey();
		LeadStatusJsonRequest request = new LeadStatusJsonRequest();
		// create XML Digital Signature for original XML Request
		/*
		 * XMLDigitalSignature xmlDigitalSignature = new XMLDigitalSignature(); String
		 * signedXML = xmlDigitalSignature.sign(xmlRequest, clientKeyStoreFilePath,
		 * clientKeyStorePassword, clientKeyAlias); signedXML =
		 * signedXML.substring(signedXML.indexOf('>')+1); Logger.info("Signed XML : "
		 * +signedXML);
		 */
		// generate 32 byte random key
		KeyGenerator keyGenerator = new KeyGenerator();
		byte[] key = keyGenerator.generateKey(32);

		// encrypt encoded value using random key
		AESEncrypterDecrypter aesEncrypter = new AESEncrypterDecrypter();
		byte[] encryptedValue = aesEncrypter.encrypt(xmlRequest, key);

		// encode the encrypted request
		Base64EncoderDecoder encoder = new Base64EncoderDecoder();
		byte[] encodedValue = encoder.encode(encryptedValue);

		request.setRequestEncryptedValue(new String(encodedValue));
		logger.info("Request :" + new String(encodedValue));

		// encrypt symmetric key using bank's public key
		RSAEncrypterDecrypter rsaEncrypter = new RSAEncrypterDecrypter();
		logger.info("bank public key :" + bankPublicKey);
		byte[] symmetricKeyEncryptedValue = rsaEncrypter.encrypt(key, bankPublicKey);

		// encode symmetric key
		encodedValue = encoder.encode(symmetricKeyEncryptedValue);
		request.setSymmetricKeyEncryptedValue(new String(encodedValue));
		logger.info("Key :" + new String(encodedValue));

		request.setScope(scope);
		request.setTransactionId(transactionId);

		// Generate OAUTH token
//		OAuthTokenGenerator oauthTokenGenerator = new OAuthTokenGenerator();
		String oauthToken = "";
//				authTokenGenerator.getOAuthToken(clientId, clientSecret, clientScope);
//		String oauthToken = "f58805c0-6527-47df-be1b-7ebeba3c11ef";
		request.setOAuthTokenValue(oauthToken);

		// convert request object to json
		String gsonRequest = gson.toJson(request);

		return gsonRequest;
	}

	/**
	 * Generate json request
	 * 
	 * @param xmlRequest    - original XML request without digital signature
	 * @param scope
	 * @param transactionId - Unique transaction Id for every request
	 * @return json request String
	 * @throws CertificateException        if any of the certificate in the key
	 *                                     store cannot be loaded
	 * @throws UnrecoverableEntryException if the password is invalid or unable to
	 *                                     retrieve private key
	 * @throws SAXException                if the XML passed to this method cannot
	 *                                     be parsed
	 * @throws IOException                 if unable to read public key file
	 */
	public String generateBilldeskRequest(String xmlRequest, String scope, String transactionId)
			throws CertificateException, UnrecoverableEntryException, SAXException, IOException {
		PublicKey bankPublicKey = initPublicKey();
		JsonRequest2 request = new JsonRequest2();
		// create XML Digital Signature for original XML Request
		/*
		 * XMLDigitalSignature xmlDigitalSignature = new XMLDigitalSignature(); String
		 * signedXML = xmlDigitalSignature.sign(xmlRequest, clientKeyStoreFilePath,
		 * clientKeyStorePassword, clientKeyAlias); signedXML =
		 * signedXML.substring(signedXML.indexOf('>')+1); Logger.info("Signed XML : "
		 * +signedXML);
		 */
		// generate 32 byte random key
		KeyGenerator keyGenerator = new KeyGenerator();
		byte[] key = keyGenerator.generateKey(32);

		// encrypt encoded value using random key
		AESEncrypterDecrypter aesEncrypter = new AESEncrypterDecrypter();
		byte[] encryptedValue = aesEncrypter.encrypt(xmlRequest, key);

		// encode the encrypted request
		Base64EncoderDecoder encoder = new Base64EncoderDecoder();
		byte[] encodedValue = encoder.encode(encryptedValue);

		request.setRequestEncryptedValue(new String(encodedValue));
		logger.info("Request :" + new String(encodedValue));

		// encrypt symmetric key using bank's public key
		RSAEncrypterDecrypter rsaEncrypter = new RSAEncrypterDecrypter();
		logger.info("bank public key :" + bankPublicKey);
		byte[] symmetricKeyEncryptedValue = rsaEncrypter.encrypt(key, bankPublicKey);

		// encode symmetric key
		encodedValue = encoder.encode(symmetricKeyEncryptedValue);
		request.setSymmetricKeyEncryptedValue(new String(encodedValue));
		logger.info("Key :" + new String(encodedValue));

		request.setScope(scope);
		request.setTransactionId(transactionId);

		// Generate OAUTH token
//		OAuthTokenGenerator oauthTokenGenerator = new OAuthTokenGenerator();
		String oauthToken = "";
//				authTokenGenerator.getOAuthToken(clientId, clientSecret, clientScope);
//		String oauthToken = "f58805c0-6527-47df-be1b-7ebeba3c11ef";
		request.setOAuthTokenValue(oauthToken);

//		request.setRequestDigitalSignatureValue("");
//		request.setSessionDigitalSignatureValue("");
		// convert request object to json
		String gsonRequest = gson.toJson(request);

		return gsonRequest;
	}

	public String generatePanRequest(String xmlRequest, String scope, String transactionId)
			throws CertificateException, UnrecoverableEntryException, SAXException, IOException {
		PublicKey bankPublicKey = initPublicKey();
		JsonRequest request = new JsonRequest();
		// create XML Digital Signature for original XML Request
		/*
		 * XMLDigitalSignature xmlDigitalSignature = new XMLDigitalSignature(); String
		 * signedXML = xmlDigitalSignature.sign(xmlRequest, clientKeyStoreFilePath,
		 * clientKeyStorePassword, clientKeyAlias); signedXML =
		 * signedXML.substring(signedXML.indexOf('>')+1); Logger.info("Signed XML : "
		 * +signedXML);
		 */
		// generate 32 byte random key
		KeyGenerator keyGenerator = new KeyGenerator();
		byte[] key = keyGenerator.generateKey(32);

//	//encrypt encoded value using random key
//	AESEncrypterDecrypter aesEncrypter = new AESEncrypterDecrypter();
//	byte[] encryptedValue = aesEncrypter.encrypt(xmlRequest, key);

		// encode the encrypted request
		Base64EncoderDecoder encoder = new Base64EncoderDecoder();
		byte[] encodedValue = encoder.encode(xmlRequest);

		AESEncrypterDecrypter aesEncrypter = new AESEncrypterDecrypter();
		byte[] encryptedValue = aesEncrypter.encrypt(new String(encodedValue), key);

		request.setRequestSignatureEncryptedValue(new String(encryptedValue));
//	logger.info("Request :" + new String(encodedValue));

		byte[] encodedKey = encoder.encode(key);

		// encrypt symmetric key using bank's public key
		RSAEncrypterDecrypter rsaEncrypter = new RSAEncrypterDecrypter();
//	logger.info("bank public key :"+bankPublicKey);
		byte[] symmetricKeyEncryptedValue = rsaEncrypter.encrypt(encodedKey, bankPublicKey);

		// encode symmetric key
		encodedValue = encoder.encode(symmetricKeyEncryptedValue);
		request.setSymmetricKeyEncryptedValue(new String(encodedValue));
//	logger.info("Key :" + new String(encodedValue));

		request.setScope(scope);
		request.setTransactionId(transactionId);

		// Generate OAUTH token
//	OAuthTokenGenerator oauthTokenGenerator = new OAuthTokenGenerator();
		String oauthToken = authTokenGenerator.getOAuthToken(clientId, clientSecret, clientScope);
//	String oauthToken = "f58805c0-6527-47df-be1b-7ebeba3c11ef";
		request.setOAuthTokenValue(oauthToken);

		// convert request object to json
		String gsonRequest = gson.toJson(request);

		return gsonRequest;
	}

	/**
	 * Generate json request
	 * 
	 * @param xmlRequest    - original XML request without digital signature
	 * @param scope
	 * @param transactionId - Unique transaction Id for every request
	 * @return json request String
	 * @throws CertificateException        if any of the certificate in the key
	 *                                     store cannot be loaded
	 * @throws UnrecoverableEntryException if the password is invalid or unable to
	 *                                     retrieve private key
	 * @throws SAXException                if the XML passed to this method cannot
	 *                                     be parsed
	 * @throws IOException                 if unable to read public key file
	 */
	public String generatePanValidationRequest(String xmlRequest, String scope, String transactionId)
			throws CertificateException, UnrecoverableEntryException, SAXException, IOException {
		PublicKey bankPublicKey = initPublicKey();
		PanValidationJsonRequest request = new PanValidationJsonRequest();
		// create XML Digital Signature for original XML Request
		/*
		 * XMLDigitalSignature xmlDigitalSignature = new XMLDigitalSignature(); String
		 * signedXML = xmlDigitalSignature.sign(xmlRequest, clientKeyStoreFilePath,
		 * clientKeyStorePassword, clientKeyAlias); signedXML =
		 * signedXML.substring(signedXML.indexOf('>')+1); Logger.info("Signed XML : "
		 * +signedXML);
		 */
		// generate 32 byte random key
		KeyGenerator keyGenerator = new KeyGenerator();
		byte[] key = keyGenerator.generateKey(32);

		// encrypt encoded value using random key
		AESEncrypterDecrypter aesEncrypter = new AESEncrypterDecrypter();
		byte[] encryptedValue = aesEncrypter.encrypt(xmlRequest, key);

		// encode the encrypted request
		Base64EncoderDecoder encoder = new Base64EncoderDecoder();
		byte[] encodedValue = encoder.encode(encryptedValue);

		request.setRequestEncryptedValue(new String(encodedValue));
		// logger.info("Request :" + new String(encodedValue));

		// encrypt symmetric key using bank's public key
		RSAEncrypterDecrypter rsaEncrypter = new RSAEncrypterDecrypter();
		// logger.info("bank public key :"+bankPublicKey);
		byte[] symmetricKeyEncryptedValue = rsaEncrypter.encrypt(key, bankPublicKey);

		// encode symmetric key
		encodedValue = encoder.encode(symmetricKeyEncryptedValue);
		request.setSymmetricKeyEncryptedValue(new String(encodedValue));
		// logger.info("Key :" + new String(encodedValue));

		request.setScope(scope);
		request.setTransactionId(transactionId);

		// Generate OAUTH token
//		OAuthTokenGenerator oauthTokenGenerator = new OAuthTokenGenerator();
		String oauthToken = "";
//				authTokenGenerator.getOAuthToken(clientId, clientSecret, clientScope);
//		String oauthToken = "f58805c0-6527-47df-be1b-7ebeba3c11ef";
		request.setOAuthTokenValue(oauthToken);

		// convert request object to json
		String gsonRequest = gson.toJson(request);

		return gsonRequest;
	}


	
	/**
	 * Generate json request
	 * 
	 * @param xmlRequest    - original XML request without digital signature
	 * @param scope
	 * @param transactionId - Unique transaction Id for every request
	 * @return json request String
	 * @throws CertificateException        if any of the certificate in the key
	 *                                     store cannot be loaded
	 * @throws UnrecoverableEntryException if the password is invalid or unable to
	 *                                     retrieve private key
	 * @throws SAXException                if the XML passed to this method cannot
	 *                                     be parsed
	 * @throws IOException                 if unable to read public key file
	 */
	public String generateAadhaarKYCValidationRequest(String xmlRequest, String scope, String transactionId)
			throws CertificateException, UnrecoverableEntryException, SAXException, IOException {
		PublicKey bankPublicKey = initPublicKey();
		AadharKYCValidationJsonRequest request = new AadharKYCValidationJsonRequest();
		// create XML Digital Signature for original XML Request
		/*
		 * XMLDigitalSignature xmlDigitalSignature = new XMLDigitalSignature(); String
		 * signedXML = xmlDigitalSignature.sign(xmlRequest, clientKeyStoreFilePath,
		 * clientKeyStorePassword, clientKeyAlias); signedXML =
		 * signedXML.substring(signedXML.indexOf('>')+1); Logger.info("Signed XML : "
		 * +signedXML);
		 */
		// generate 32 byte random key
		KeyGenerator keyGenerator = new KeyGenerator();
		byte[] key = keyGenerator.generateKey(32);

		// encrypt encoded value using random key
		AESEncrypterDecrypter aesEncrypter = new AESEncrypterDecrypter();
		byte[] encryptedValue = aesEncrypter.encrypt(xmlRequest, key);

		// encode the encrypted request
		Base64EncoderDecoder encoder = new Base64EncoderDecoder();
		byte[] encodedValue = encoder.encode(encryptedValue);

		request.setRequestEncryptedValue(new String(encodedValue));
		logger.info("Request :" + new String(encodedValue));

		// encrypt symmetric key using bank's public key
		RSAEncrypterDecrypter rsaEncrypter = new RSAEncrypterDecrypter();
		logger.info("bank public key :" + bankPublicKey);
		byte[] symmetricKeyEncryptedValue = rsaEncrypter.encrypt(key, bankPublicKey);

		// encode symmetric key
		encodedValue = encoder.encode(symmetricKeyEncryptedValue);
		request.setSymmetricKeyEncryptedValue(new String(encodedValue));
		logger.info("Key :" + new String(encodedValue));

		request.setScope(scope);
		request.setTransactionId(transactionId);

		// Generate OAUTH token
//		OAuthTokenGenerator oauthTokenGenerator = new OAuthTokenGenerator();
		String oauthToken = "";
//				authTokenGenerator.getOAuthToken(clientId, clientSecret, clientScope);
//		String oauthToken = "f58805c0-6527-47df-be1b-7ebeba3c11ef";
		request.setOAuthTokenValue(oauthToken);

		// convert request object to json
		String gsonRequest = gson.toJson(request);

		return gsonRequest;
	}
	
	public AadharEKYCJsonRequest generateAadharEKYCJsonRequest(String requestInput)
			throws CertificateException, UnrecoverableEntryException, SAXException, IOException {
		PublicKey bankPublicKey = initDapPublicKey();
		AadharEKYCJsonRequest request = new AadharEKYCJsonRequest();
		
		// generate 32 byte random key
		KeyGenerator keyGenerator = new KeyGenerator();
		String key = keyGenerator.generateAlphaNumericKey(32);
		logger.info("AadharEKYCJsonRequest Plain Session Key :: " + key);

		// encrypt encoded value using random key
		AESEncrypterDecrypter aesEncrypter = new AESEncrypterDecrypter();
		byte[] encryptedValue = aesEncrypter.encryptForAadhar(requestInput, key.getBytes());
		logger.info("AadharEKYCJsonRequest Encrtped Input Data :: " + new String(encryptedValue));

		// encode the encrypted request
		Base64EncoderDecoder encoder = new Base64EncoderDecoder();
		byte[] encodedValue = encoder.encode(encryptedValue);
		logger.info("AadharEKYCJsonRequest Encoded Input Data :: " + new String(encodedValue));

		request.setRequestEncryptedValue(new String(encodedValue));

		// encrypt symmetric key using bank's public key
		RSAEncrypterDecrypter rsaEncrypter = new RSAEncrypterDecrypter();
		logger.info("AadharEKYCJsonRequest Bank public key :" + bankPublicKey);
		byte[] symmetricKeyEncryptedValue = rsaEncrypter.encrypt(key.getBytes(), bankPublicKey);
		logger.info("AadharEKYCJsonRequest Encrtped Session Key :" + new String(symmetricKeyEncryptedValue));

		// encode symmetric key
		encodedValue = encoder.encode(symmetricKeyEncryptedValue);
		logger.info("AadharEKYCJsonRequest Encoded Session Key :" + new String(encodedValue));
		
		request.setSymmetricKeyEncryptedValue(new String(encodedValue));
		request.setPlainRequest(requestInput);

		return request;
	}

	public String generatePosidexSevice(String xmlRequest, String scope, String transactionId)
			throws CertificateException, UnrecoverableEntryException, SAXException, IOException {
		PublicKey bankPublicKey = initPublicKey();
		PanValidationJsonRequest request = new PanValidationJsonRequest();
		// create XML Digital Signature for original XML Request
		/*
		 * XMLDigitalSignature xmlDigitalSignature = new XMLDigitalSignature(); String
		 * signedXML = xmlDigitalSignature.sign(xmlRequest, clientKeyStoreFilePath,
		 * clientKeyStorePassword, clientKeyAlias); signedXML =
		 * signedXML.substring(signedXML.indexOf('>')+1); Logger.info("Signed XML : "
		 * +signedXML);
		 */
		// generate 32 byte random key
		KeyGenerator keyGenerator = new KeyGenerator();
		byte[] key = keyGenerator.generateKey(32);

		// encrypt encoded value using random key
		AESEncrypterDecrypter aesEncrypter = new AESEncrypterDecrypter();
		byte[] encryptedValue = aesEncrypter.encrypt(xmlRequest, key);

		// encode the encrypted request
		Base64EncoderDecoder encoder = new Base64EncoderDecoder();
		byte[] encodedValue = encoder.encode(encryptedValue);

		request.setRequestEncryptedValue(new String(encodedValue));
		logger.info("Request :" + new String(encodedValue));

		// encrypt symmetric key using bank's public key
		RSAEncrypterDecrypter rsaEncrypter = new RSAEncrypterDecrypter();
		logger.info("bank public key :" + bankPublicKey);
		byte[] symmetricKeyEncryptedValue = rsaEncrypter.encrypt(key, bankPublicKey);

		// encode symmetric key
		encodedValue = encoder.encode(symmetricKeyEncryptedValue);
		request.setSymmetricKeyEncryptedValue(new String(encodedValue));
		logger.info("Key :" + new String(encodedValue));

		request.setScope(scope);
		request.setTransactionId(transactionId);

		// Generate OAUTH token
//		OAuthTokenGenerator oauthTokenGenerator = new OAuthTokenGenerator();
		String oauthToken = "";
//				authTokenGenerator.getOAuthToken(clientId, clientSecret, clientScope);
//		String oauthToken = "f58805c0-6527-47df-be1b-7ebeba3c11ef";
		request.setOAuthTokenValue(oauthToken);

		// convert request object to json
		String gsonRequest = gson.toJson(request);

		return gsonRequest;
	}

	public String generateLeadInstaRequest(String xmlRequest, String scope, String transactionId)
			throws CertificateException, UnrecoverableEntryException, SAXException, IOException {
		PublicKey bankPublicKey = initApiPublicKey();
		JsonRequest request = new JsonRequest();
		
		KeyGenerator keyGenerator = new KeyGenerator();
		byte[] key = keyGenerator.generateAlphaNumericKey(32).getBytes();

		// encrypt encoded value using random key
		AESEncrypterDecrypter aesEncrypter = new AESEncrypterDecrypter();
		byte[] encryptedValue = aesEncrypter.encrypt(xmlRequest, key);

		// encode the encrypted request
		Base64EncoderDecoder encoder = new Base64EncoderDecoder();
		byte[] encodedValue = encoder.encode(encryptedValue);

		request.setRequestSignatureEncryptedValue(new String(encodedValue));
//	logger.info("Request :" + new String(encodedValue));

		// encrypt symmetric key using bank's public key
		RSAEncrypterDecrypter rsaEncrypter = new RSAEncrypterDecrypter();
//	logger.info("bank public key :"+bankPublicKey);
		byte[] symmetricKeyEncryptedValue = rsaEncrypter.encrypt(key, bankPublicKey);

		// encode symmetric key
		encodedValue = encoder.encode(symmetricKeyEncryptedValue);
		request.setSymmetricKeyEncryptedValue(new String(encodedValue));
//	logger.info("Key :" + new String(encodedValue));

		request.setScope(scope);
		request.setTransactionId(transactionId);

		// Generate OAUTH token
//	OAuthTokenGenerator oauthTokenGenerator = new OAuthTokenGenerator();
		String oauthToken = authTokenGenerator.getOAuthTokenBLEL(BLELclientId, BLELclientSecret, BLELclientScope);
//				authTokenGenerator.getOAuthToken(LeadInstaClientID, LeadInstaSecret, LEADINSTA_SCOPE);
//	String oauthToken = "f58805c0-6527-47df-be1b-7ebeba3c11ef";
		request.setOAuthTokenValue(oauthToken);

		// convert request object to json
		String gsonRequest = gson.toJson(request);

		return gsonRequest;
	}

	/**
	 * Generate json request
	 * Type : medium
	 * @param xmlRequest    - original XML request without digital signature
	 * @param scope
	 * @param transactionId - Unique transaction Id for every request
	 * @return json request String
	 * @throws CertificateException        if any of the certificate in the key
	 *                                     store cannot be loaded
	 * @throws UnrecoverableEntryException if the password is invalid or unable to
	 *                                     retrieve private key
	 * @throws SAXException                if the XML passed to this method cannot
	 *                                     be parsed
	 * @throws IOException                 if unable to read public key file
	 */

	public String generatePosidexRequest(String xmlRequest, String scope, String transactionId)
			throws CertificateException, UnrecoverableEntryException, SAXException, IOException {
		PublicKey bankPublicKey = initApiPublicKey();
		JsonRequest2 request = new JsonRequest2();

		KeyGenerator keyGenerator = new KeyGenerator();
		String alphakey = keyGenerator.generateAlphaNumericKey(32);

//		logger.info(" alphakey Key :" + alphakey);

		byte[]  key=alphakey.getBytes();

		// encrypt encoded value using random key
		AESEncrypterDecrypter aesEncrypter = new AESEncrypterDecrypter();
		byte[] encryptedValue = aesEncrypter.encrypt(xmlRequest, key);

		// encode the encrypted request
		Base64EncoderDecoder encoder = new Base64EncoderDecoder();
		byte[] encodedValue = encoder.encode(encryptedValue);

		request.setRequestEncryptedValue(new String(encodedValue));
//		logger.info("Request :" + new String(encodedValue));

		// encrypt symmetric key using bank's public key
		RSAEncrypterDecrypter rsaEncrypter = new RSAEncrypterDecrypter();
//		logger.info("bank public key :"+bankPublicKey);
		byte[] symmetricKeyEncryptedValue = rsaEncrypter.encrypt(key, bankPublicKey);

		// encode symmetric key
		encodedValue = encoder.encode(symmetricKeyEncryptedValue);
		request.setSymmetricKeyEncryptedValue(new String(encodedValue));
//		logger.info("Key :" + new String(encodedValue));

		request.setScope(scope);
		request.setTransactionId(transactionId);


		String oauthToken = ""; //authTokenGenerator.getOAuthTokenBLEL(BLELclientId, BLELclientSecret, BLELclientScope);
		request.setOAuthTokenValue(oauthToken);


		// convert request object to json
		String gsonRequest = gson.toJson(request);

		return gsonRequest;
	}
	
	public String generateIMPSRequestHigh(String xmlRequest, String scope, String transactionId)
			throws CertificateException, UnrecoverableEntryException, SAXException, IOException {
		PublicKey bankPublicKey = initPublicKey();
		JsonRequest request = new JsonRequest();
		// generate 32 byte random key
		KeyGenerator keyGenerator = new KeyGenerator();
		byte[] key = keyGenerator.generateKey(32);

		// encrypt encoded value using random key
		AESEncrypterDecrypter aesEncrypter = new AESEncrypterDecrypter();
		byte[] encryptedValue = aesEncrypter.encrypt(xmlRequest, key);

		// encode the encrypted request
		Base64EncoderDecoder encoder = new Base64EncoderDecoder();
		byte[] encodedValue = encoder.encode(encryptedValue);

		request.setRequestSignatureEncryptedValue(new String(encodedValue));
		// logger.info("Request :" + new String(encodedValue));

		// encrypt symmetric key using bank's public key
		RSAEncrypterDecrypter rsaEncrypter = new RSAEncrypterDecrypter();
		// logger.info("bank public key :"+bankPublicKey);
		byte[] symmetricKeyEncryptedValue = rsaEncrypter.encrypt(key, bankPublicKey);

		// encode symmetric key
		encodedValue = encoder.encode(symmetricKeyEncryptedValue);
		request.setSymmetricKeyEncryptedValue(new String(encodedValue));
		// logger.info("Key :" + new String(encodedValue));

		request.setScope(scope);
		request.setTransactionId(transactionId);

		// Generate OAUTH token
		String oauthToken = ""; 
//				authTokenGenerator.getOAuthToken(IMPS_API_CLIENT_ID, IMPS_API_SECRET_KEY, scope);
		request.setOAuthTokenValue(oauthToken);

		// convert request object to json
		String gsonRequest = gson.toJson(request);

		return gsonRequest;
	}

	public String generateIMPSRequestLow(String xmlRequest, String scope, String transactionId)
			throws CertificateException, UnrecoverableEntryException, SAXException, IOException {

		PublicKey bankPublicKey = initPublicKey();
		LeadStatusJsonRequest request = new LeadStatusJsonRequest();
		// create XML Digital Signature for original XML Request
		// generate 32 byte random key
		KeyGenerator keyGenerator = new KeyGenerator();
		byte[] key = keyGenerator.generateKey(32);

		// encrypt encoded value using random key
		AESEncrypterDecrypter aesEncrypter = new AESEncrypterDecrypter();
		byte[] encryptedValue = aesEncrypter.encrypt(xmlRequest, key);

		// encode the encrypted request
		Base64EncoderDecoder encoder = new Base64EncoderDecoder();
		byte[] encodedValue = encoder.encode(encryptedValue);

		request.setRequestEncryptedValue(new String(encodedValue));

		// encrypt symmetric key using bank's public key
		RSAEncrypterDecrypter rsaEncrypter = new RSAEncrypterDecrypter();
		byte[] symmetricKeyEncryptedValue = rsaEncrypter.encrypt(key, bankPublicKey);

		// encode symmetric key
		encodedValue = encoder.encode(symmetricKeyEncryptedValue);
		request.setSymmetricKeyEncryptedValue(new String(encodedValue));

		request.setScope(scope);
		request.setTransactionId(transactionId);
		String oauthToken = "";
		request.setOAuthTokenValue(oauthToken);

		// convert request object to json
		String gsonRequest = gson.toJson(request);

		return gsonRequest;
	}

	public String generateApiMedRequest(String xmlRequest, String scope, String transactionId)
			throws CertificateException, UnrecoverableEntryException, SAXException, IOException {
		PublicKey bankPublicKey = initPublicKey();
		PanValidationJsonRequest request = new PanValidationJsonRequest();
		// generate 32 byte random key
		KeyGenerator keyGenerator = new KeyGenerator();
		byte[] key = keyGenerator.generateKey(32);

		// encrypt encoded value using random key
		AESEncrypterDecrypter aesEncrypter = new AESEncrypterDecrypter();
		byte[] encryptedValue = aesEncrypter.encrypt(xmlRequest, key);

		// encode the encrypted request
		Base64EncoderDecoder encoder = new Base64EncoderDecoder();
		byte[] encodedValue = encoder.encode(encryptedValue);

		request.setRequestEncryptedValue(new String(encodedValue));

		// encrypt symmetric key using bank's public key
		RSAEncrypterDecrypter rsaEncrypter = new RSAEncrypterDecrypter();
		byte[] symmetricKeyEncryptedValue = rsaEncrypter.encrypt(key, bankPublicKey);

		// encode symmetric key
		encodedValue = encoder.encode(symmetricKeyEncryptedValue);
		request.setSymmetricKeyEncryptedValue(new String(encodedValue));

		request.setScope(scope);
		request.setTransactionId(transactionId);

		String oauthToken = "";
		request.setOAuthTokenValue(oauthToken);

		// convert request object to json
		String gsonRequest = gson.toJson(request);

		return gsonRequest;
	}

}
