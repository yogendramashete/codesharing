package com.hdfcbank.elengine.constant;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public abstract class ErrorCodes {

	public static final String failure   = "01";
	
	public static final String error   = "02";
}
