package com.hdfcbank.elengine.service;


import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Recover;
import org.springframework.retry.annotation.Retryable;
import org.springframework.scheduling.annotation.Async;

import com.hdfcbank.elengine.domain.request.common.InBreServices;
import com.hdfcbank.elengine.exception.CallBackException;

public interface ElCallbacks {
	@Async
	@Retryable( value = CallBackException.class, maxAttemptsExpression = "${mbcb.retry.maxAttempts}",
            backoff = @Backoff(delayExpression = "${mbcb.retry.maxDelay}"))
	void checkMbCallbacks(InBreServices breServices);
	@Recover
	void initBreCallBacks(InBreServices breServices);
	
}
