package com.hdfcbank.elengine.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import org.apache.commons.lang3.StringUtils;

import com.hdfcbank.elengine.constant.AppConstants;
import com.hdfcbank.elengine.domain.enums.ExpBreTagType;

public class BreUtils {

	public static String isValueEmpty(String value, String tagType) {
		if (tagType.equalsIgnoreCase(AppConstants.DATE_FMT_ddMMyyyy) && StringUtils.isNotBlank(value)) {
			if (value.length() >= 8) {
				return CommonUtility.formatDate(value, AppConstants.DATE_FMT_ddMMyyyy,
						AppConstants.DATE_FMT_yyyy_MM_dd);
			} else {
				return ExpBreTagType.valueOf(tagType).toString();
			}

		}
		return StringUtils.isBlank(value) == true ? ExpBreTagType.valueOf(tagType).toString() : value;

	}

	public static List<String> returnListItem(String itemValue, List<String> itemList, String tagType, int index) {

		if (Objects.isNull(itemList) && StringUtils.isBlank(itemValue)) {
			return null;
		} else if (Objects.isNull(itemList) && StringUtils.isNotBlank(itemValue)) {
			itemList = new ArrayList<>();
			for (int i = 0; i < index; i++) {
				itemList.add(ExpBreTagType.valueOf(tagType).toString());
			}
		}
		if (itemList.size() == 0) {
			if (StringUtils.isNotBlank(itemValue) && tagType.equalsIgnoreCase(AppConstants.DATE_FMT_ddMMyyyy)) {
				if (itemValue.length() >= 8) {
					itemValue = CommonUtility.formatDate(itemValue, AppConstants.DATE_FMT_ddMMyyyy,
							AppConstants.DATE_FMT_yyyy_MM_dd);
				} else {
					itemValue = ExpBreTagType.valueOf(tagType).toString();
				}

			}else if (StringUtils.isNotBlank(itemValue) && tagType.equalsIgnoreCase(AppConstants.DATE_FMT_ddMMyyyy)) {
				itemValue = itemValue.split(" ")[0];
			}else if (StringUtils.isNotBlank(itemValue) && tagType.equalsIgnoreCase(AppConstants.DATE_FMT_ddMMyyyy)) {
				itemValue = getDecimalTagValue(itemValue);
			}
			itemList.add(itemValue);

		} else if (itemList.size() == 1) {
			if (StringUtils.isEmpty(itemList.get(0))) {
				return null;
			} else {
				if (StringUtils.isBlank(itemValue) || itemValue.equalsIgnoreCase("null")) {
					itemList.add(ExpBreTagType.valueOf(tagType).toString());
				} else {
					if (StringUtils.isNotBlank(itemValue) && tagType.equalsIgnoreCase(AppConstants.DATE_FMT_ddMMyyyy)) {
						if (itemValue.length() >= 8) {
							itemValue = CommonUtility.formatDate(itemValue, AppConstants.DATE_FMT_ddMMyyyy,
									AppConstants.DATE_FMT_yyyy_MM_dd);
						} else {
							itemValue = ExpBreTagType.valueOf(tagType).toString();
						}
					}else if (StringUtils.isNotBlank(itemValue) && tagType.equalsIgnoreCase(AppConstants.DATE_FMT_ddMMyyyy)) {
						itemValue = itemValue.split(" ")[0];
					}
					else if (StringUtils.isNotBlank(itemValue) && tagType.equalsIgnoreCase(AppConstants.TAG_TYPE_DECIMAL)) {
						itemValue = getDecimalTagValue(itemValue);
					}
					itemList.add(itemValue);
				}
			}
		} else {

			if (StringUtils.isBlank(itemValue) || itemValue.equalsIgnoreCase("null")) {
				itemList.add(ExpBreTagType.valueOf(tagType).toString());
			} else {
				if (StringUtils.isNotBlank(itemValue) && tagType.equalsIgnoreCase(AppConstants.DATE_FMT_ddMMyyyy)) {
					if (itemValue.length() >= 8) {
						itemValue = CommonUtility.formatDate(itemValue, AppConstants.DATE_FMT_ddMMyyyy,
								AppConstants.DATE_FMT_yyyy_MM_dd);
					} else {
						itemValue = ExpBreTagType.valueOf(tagType).toString();
					}
				}else if (StringUtils.isNotBlank(itemValue) && tagType.equalsIgnoreCase(AppConstants.DATE_FMT_ddMMyyyy)) {
					itemValue = itemValue.split(" ")[0];
				} else if (StringUtils.isNotBlank(itemValue) && tagType.equalsIgnoreCase(AppConstants.DATE_FMT_ddMMyyyy)) {
					itemValue = getDecimalTagValue(itemValue);
				}
				itemList.add(itemValue);
			}
		}
		return itemList;
	}

	public static String getDecimalTagValue(String value) {
		if (StringUtils.isBlank(value) || value.equalsIgnoreCase("null")) {
			value  ="0";
		}
		return Double.valueOf(value) + "";
	}

	
	public static List<String> setEmptyListAsNull(List<String> list) {
		if(list == null || list.isEmpty()) {
			return null;
		}
		return StringUtils.isEmpty(list.get(0)) == true ?null:list;
	}
}

