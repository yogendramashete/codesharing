package com.hdfcbank.elengine.constant;

public class AppConstants {

	public static String SPRING_CONFIG_NAME = "application.properties";

	public static String BRE_STRING_EMPTY = "null";
	public static String BRE_DATE_EMPTY = "01/01/1900 00:00:00";
	public static int BRE_NUMERIC_EMPTY = 0;
	public static double BRE_DOUBLE_EMPTY = 0;
	public static String BRE_NUMERIC_STR_EMPTY = "0";

	public static String BLAPP_APPTYPE = "I";
	public static String BLAPP_APPR_TERM_N_SEB = "36";
	public static String BLAPP_APPR_TERM_N_SEP = "60";
	public static String BLAPP_APPR_TERM_N_SD = "60";

	public static String AES_IV = "554495832998beb0b0f7c198c46fbaba";
	public static String AES_SALT = "b914741dca31bfae4c2d4d003780b00e";
	public static String AES_PASS_PHRASE = "1f491ea331dafff3bd8c38e3c3830e97";

	public static int PERFIOS_START_MINUS = 1;
	public static int PERFIOS_END_MINUS = 5;

	public static String MALE_PATH = "assets/img/ico-male.svg";
	public static String FEMALE_PATH = "assets/img/ico-female.svg";
	public static String TRANSGENDER_PATH = "assets/img/ico-lgbtq.svg";

	public static String AWS_LOANS_FILE_LOCATION = "loans/";
	public static String AWS_PERFIOS_FILE_LOCATION = "loans/perfios/";
	public static String AWS_DOCUMENT_LOCATION = "loans/document/";
	public static String AWS_ETB_DOCUMENT_LOCATION = "loans/document/etb";
	public static String OPERATION_TYPE_LOANS = "Loans";
	public static String EMANDATE_LEADNO_SUFIX = "107AF";
	public static String TAG_TYPE_DATE = "DATE";
	public static String TAG_TYPE_DATE2 = "DATE2";
	public static String TAG_TYPE_DATE3 = "DATE3";
	public static String TAG_TYPE_STRING = "STRING";
	public static String TAG_TYPE_DECIMAL = "DECIMAL";
	public static String TAG_TYPE_INT = "INT";
	public static String PQL_INCOME = "PQL_INCOME";

	public static Long MAX_TIME_TO_CALL_BRE1 = 20800l;
	public static String BRE1_IS_INITIATED_Y = "Y";
	public static String BRE1_IS_INITIATED_N = "N";

	public static int FILTER_ADD_COUNT = 3;
	public static int FILTER_BL_ADD_COUNT = 1;
	public static int MB_MERGE_COUNT = 1;
	public static int HUNTER_MATCH_COUNT_SUCC = 1;
	public static int HUNTER_MATCH_COUNT_SUCC_0 = 0;
	public static int IMPS_INQUIRE_DELAY_TIME = 5000;

	public static String VCIP_RETRIVER_ACTION_REJ = "rejected";
	public static String IS_ENC = "Y";
	public static String BRE_SUCCESS = "SUCCESS";
	public static String BRE_FAIL = "FAIL";
	public static String BRE_SUCCESS_CODE = "000";
	public static String BRE_FAILURE_CODE = "001";
	public static String DATE_FMT_dd_MM_yyyy = "dd/MM/yyyy";
	public static String DATE_FMT_yyyy_MM_dd = "yyyy-MM-dd";
	public static String DATE_FMT_yyyy_MM_dd_T_HHMMss = "yyyy-MM-dd'T'HH:mm:ss";
	public static String DATE_FMT_yyyy_MM_dd_HHmmssa = "yyyy/MM/dd hh:mm:ss a";
	public static String DATE_FMT_yyyy_MM_dd_HHmmssSSS = "yyyy-MM-dd HH:mm:ss.SSS";
	public static String DATE_FMT_yyyy_MM_dd_HHmmss = "yyyy-MM-dd HH:mm:ss";
	public static String DATE_FMT_yyyyMMddHHmmssSSS = "yyyyMMddHHmmssSSSSSS";
	public static String YYYY_MM_dd_THH_mm_ss_SSSXXX = "YYYY-MM-dd'T'HH:mm:ss.SSSXXX";
	public static String DATE_FMT_dd_MMM_yyyy = "dd-MMM-yyyy";
	public static String DATE_FMT_ddMMyyyy = "ddMMyyyy";
	public static String DATE_FMT_yyyyMMdd = "yyyyMMdd";
	public static String DATE_FMT_ddMMyyyy2 = "dd-MM-yyyy";
	public static String PERFIOS_NB_FETCH = "netbankingFetch";
	public static String PERFIOS_STATEMENT = "statement";
	public static String ERROR = "Please try after sometime...";
	public static String DISBURSEMENT_ALREADY_INITIATED = "Disbursement already initiated for this number";
	public static String PERFIOS_TXNSTATUS = "success";
	public static String PERFIOS_FAILURE_TXNSTATUS = "fail";
	public static String PERFIOS_ERRORCODE = "E_NO_ERROR";
	public static String PERFIOS_REPORTTYPE = "xml";
	public static String PERFIOS_REPORTTYPE_PDF = "pdf";
	public static String PERFIOS_REPORTTYPE_XLSX = "xlsx";
	/////////////// Aadhar /////////////////////

	public static final String SECURITY_QUESTION_1 = "What is your Date of Birth ?";
	public static final String SECURITY_QUESTION_2 = "What is your Father's Name ?";
	public static final String SECURITY_QUESTION_3 = "What is your Mother's Name ?";
	public static final String SECURITY_QUESTION_5 = "What is the city of your office address?";
	public static final String SECURITY_QUESTION_6 = "What is the state of your office address?";
	// public static final String SECURITY_QUESTION_13 = "What is your Mobile number
	// ?";
	public static final String SECURITY_QUESTION_13 = "What are the last 4 digits of your mobile number?";
	public static final String SECURITY_QUESTION_14 = "What is your current resident type as selected during the application?";

	public static final String AADAHR_OT_GENERATION = "OTP-GENERATION";
	public static final String AADAHR_OT_VALIDATION = "OTP-VALIDATION";
	public static final String AADAHR_URL_GENERATION = "AADAHR-URL-GENERATION";
	public static final String AADAHR_CALLBACK_RESPONSE = "AADAHR-CALLBACK-RESPONSE";
	public static final String AADAHR_VCIP = "SYCN-PROFILE";
	public static final String AADAHR_PROFILE_DATA = "PROFILE-DATA";

	public static final String DIGEST_ALGO = "SHA-1";
	public static final String ENCRYPTION_ALGO = "RSA/ECB/PKCS1Padding";
	public static String SERVER = "demo.perfios.com";
	public static String VENDOR_ID = "hdfcBankRetail";
	public static String SME_VENDOR_ID = "hdfcBankSME";

	public static String API_VERSION = "2.0";
	public static String SOURCE_SYSTEM = "LoanAssist";
	// public static String LOAN_DURATION = "12";
	public static String APPLICANT_TYPE = "RETAIL";
	public static String PRODUCT_TYPE = "AL";
	public static String REPORT_TYPE = "xls";

	public static boolean IS_BRE_STATIC = false;
	public static boolean IS_PAN_VAL_STATIC = false;
	public static boolean IS_NAME_MATCH_AT_PAN = false;
	public static boolean IS_ADD_MATCH_STATIC = false;
	public static boolean IS_NAME_MATCH_STATIC = false;

	public static boolean IS_UAT = true;

	public static String DEFAULT_DATE = "1900-01-01";
	public static String RECORD_NOT_FOUND = "RECORD NOT FOUND";
	public static int POXIDEX_RETRY_COUNT = 3;
	public static int EKYC_RETRY_COUNT = 3;
	public static String API_SUCCESS = "SUCCESS";
	public static String API_FAIL = "FAIL";
	public static String API_SUCCESS_CODE = "0";
	public static String API_FAIL_CODE = "1";
	public static String SIZE_GREATER_THAN_3MB_MSG = "31";
	public static String SIZE_GREATER_THAN_10MB_MSG = "32";
	public static String PASSWORD_PROTECTED = "53";

	public static int PRETTY_PRINT_INDENT_FACTOR = 4;
	public static String PERFIOS_GENERATE_URL = "GENERATE-URL";
	public static String PERFIOS_TXN_STATUS = "TXN-STATUS";
	public static String PERFIOS_RETRIVE_DATA = "RETRIVE-DATA";
	public static String DOC_PERFIOS_GENERATE_URL = "DOC-GENERATE-URL";
	public static String DOC_PERFIOS_TXN_STATUS = "DOC-TXN-STATUS";
	public static String DOC_PERFIOS_RETRIVE_DATA = "DOC-RETRIVE-DATA";
	public static String BRE1 = "BRE1";
	public static String BRE2 = "BRE2";
	public static String BRE3 = "BRE3";
	public static String BRE1_SOURCE_ID = "BRE1";
	public static String BRE2_SOURCE_ID = "BRE2";
	public static String BRE3_SOURCE_ID = "BRE3";
	public static String BRE2_OPERATION_TYPE = "BRE2";
	public static String BRE3_OPERATION_TYPE = "BRE3";
	public static String ETB_BRE2_OPERATION_TYPE = "ETB-BRE2";
	public static String BRE_FAILURE = "BRE_FAIL";
	public static String AADHAR_GENERATE_URL = "AADHAR-GENERATE-URL";

	public static String TRUSTING_SOCIAL = "TRUSTING_SOCIAL";
	public static String NSDL = "NSDL";
	public static String POSIDEX_STATUS = "POSIDEX";
	public static String SIGNZ = "SIGNZ";
	public static String HUNTER = "HUNTER";
	public static String POSIDEX_NAME_MATCH = "POSIDEX_NAME_MATCH";
	public static String PERFIOS_STATUS = "PERFIOS";
	public static String EKYC_STATUS = "ekyc";
	public static String DL = "DL";
	public static String ELECTRICITY = "ELECTRICITY";
	public static String LPG = "LPG";
	public static String MOB_AUTH = "MOB_AUTH";
	public static String VOTER_ID = "VOTER_ID";
	public static String CP = "CP";
	public static String CIF = "CIF";
	public static String BRE1_FINAL_ELIG = "BRE1_FINAL_ELIG";
	public static String BRE2_FINAL_ELIG = "BRE2_FINAL_ELIG";

	public static String PROMOTION_SCHEME = "IND";
	public static String BRE_NOT_INITIATED = "NOT_INITIATED";
	public static String INITIATED = "initiated";
	public static String FIND_10MIN_BRE_STATUS = "FIND_10MIN_BRE_STATUS_";
	public static String PERFIOS_NOT_INITIATED = "PERFIOS_NOT_INITIATED";

	public static String SERVERERROR = "failure";
	public static String BRESTATUS_FAIL = "failure";

	public static String OFFER_PRODUCT = "<item>AUTO LOAN</item>";
	public static String OFFER_PRODUCT_CODE = "<item>AL</item>";
	public static int AADHAR_RETRY_COUNT = 1;
	// BRE 3 redis key for address match/////
	public static String PERFIOS = "Perfios_";
	public static String POSIDEX = "Posidex_";
	public static String MERGED = "Merged_";
	public static String EKYC = "eKYC_";
	public static String KARZA = "Karza_";
	public static String ADD_RESI = "Resi";
	public static String ADD_OFF = "Off";
	public static String ADHAR_OTP_FAILURE_STATUS_CODE = "11";
	public static String ADHAR_VERIFY_FAILURE_STATUS_CODE = "12";
	public static String ADHAR_OTP_FAILURE_STATUS_MSG = "Aadhar OTP Generation Failed.";
	public static String ADHAR_VERIFY_FAILURE_STATUS_MSG = "Aadhar OTP Validation Failed.";
	public static String DL_AUTHENTICATION = "DL-AUTHENTICATION";
	public static String DISBURSEMENT_STATUS = "DISBURSEMENT-STATUS";
	public static String SUBMIT_DISBURSEMENT = "SUBMIT-DISBURSEMENT";
	public static String PERFIOS_CALL = "PERFIOS";
	public static final String VCIP = "VCIP";
	public static final String SENDER_SRC_NAME_TYPE = "Sender-Name";
	public static final String COMPANY_SRC_NAME_TYPE = "Company-Name";
	public static final String PROFESSION_TYPE = "Self Employed";
	public static final String ACCOUNT_TYPE_CURRENT = "11";

	public static String INIT_SOURCE = "NON-ZEEBE";
	public static String TRAN_STATUS = "Initiated";

	public static long LEAD_INSTA_MONTHLY_EMI_LIMIT = 100000;

	public static String EMAIL_VERIFICATION = "emailVerification";
	public static String EMAIL_VERIFICATION_TOKEN = "emailVerificationToken";
	public static final String IMPS_PAYMENT = "IMPS-PAYMENT";
	public static final String IMPS_INQUIRY = "IMPS-INQUIRY";
	public static String SUCCESS = "success";
	public static String FAIL = "fail";
	public static String SUCCESS_CODE = "0";
	public static String FAIL_CODE = "1";
	///////////// Document/////////////////
	public static String ADD_REFERENCE = "ADD-REFERENCE";
	public static String VALIDATE_PARTNER = "VALIDATE-PARTNER";
	public static String APPLY_FOR_LOAN = "APPLY-FOR-LOAN";
	public static String COMPLETE_DOCUMENT_UPLOAD = "COMPLETE-DOCUMENT-UPLOAD";
	public static String DOCUMENT_UPLOAD = "DOCUMENT-UPLOAD";
	public static String DAF_DOCUMENT_UPLOAD = "DAF-DOCUMENT-UPLOAD";
	public static String VCIP_DOCUMENT_UPLOAD = "VCIP-DOCUMENT-UPLOAD";
	public static String EKYC_DOCUMENT_UPLOAD = "EKYC-DOCUMENT-UPLOAD";
	public static String EKYC_DOCUMENT_UPLOAD2 = "EKYC-DOCUMENT-UPLOAD2";
	public static String PI_DOCUMENT_UPLOAD = "ETB-PI-DOCUMENT-UPLOAD";
	public static String TRACK_YOUR_LOAN = "TRACK-YOUR-LOAN";
	public static String INJECTION = "INJECTION";
	public static String SIZE_GREATER_THAN_THREE_MSG = "Document size should be less than 2.8 MB";
	public static String SIZE_GREATER_THAN_TEN_MSG = "Total documents size should be less than 10 MB";
	public static double MAX_INDIVIDUAL_FILE_SIZE = 2.8;
	public static double MAX_TOTAL_FILE_SIZE = 10;
	public static String UPLOAD_FAIL = "failed to upload";
	public static String DOCUMENT_ALREADY_AVAILABLE = "Document already available";
	public static String MANDATORY_PARAM_NOT_PASSED = "Mandatory parameters not passed";
	public static String DOCUMENT_PASSWORD_PROTECTED = "Seems uploaded PDF is password protected, please upload unprotected PDF document.";
	public static String BRE3_PRODUCT = "ADL";
	public static String PROMOCODE_ADL = "XXVANILA";
	public static String PROMOCODE_NON_ADL = "XXXX";
	public static String DOC_UPLOAD_CONTENT_TYPE_PDF = "application/pdf";
	public static String DOC_UPLOAD_FLG_INTERNAL = "Yes";
	public static String SALARIED_CONSTITUTION_ID = "16";
	public static String SALARIED_CONSTITUTION_VAL = "SALARIED";
	public static String SELF_EMPLOYED_CONSTITUTION_ID = "15";
	public static String SELF_EMPLOYED_CONSTITUTION_VAL = "SELF - EMPLOYED";

	public static String ETB_ADD_REFERENCE = "ETB-ADD-REFERENCE";
	public static String ETB_VALIDATE_PARTNER = "ETB-VALIDATE-PARTNER";
	public static String ETB_APPLY_FOR_LOAN = "ETB-APPLY-FOR-LOAN";
	public static String ETB_COMPLETE_DOCUMENT_UPLOAD = "ETB-COMPLETE-DOCUMENT-UPLOAD";
	public static String ETB_DOCUMENT_UPLOAD = "ETB-DOCUMENT-UPLOAD";
	public static String ETB_DAF_DOCUMENT_UPLOAD = "ETB-DAF-DOCUMENT-UPLOAD";
	public static String ETB_TRACK_YOUR_LOAN = "ETB-TRACK-YOUR-LOAN";

	public static String NOT_STARTED_STATUS = "not started";
	public static String IN_PROGRESS_STATUS = "in_progress";
	public static String FAILURE_STATUS = "failure";
	public static String BRE_STATUS = "BRE failure";
	public static String PAN_FAILURE_STATUS = "PanValidation failure";
	public static String PAN_SUCCESS_STATUS = "PanValidation success";
	public static String COMPLETED_STATUS = "completed";

	public static String REQUEST_RESPONSE = "Request & Response";

	public static String ADD_REFERENCE_SUBJECT = "ADD-REFERENCE - ";
	public static String APPLY_FOR_LOAN_SUBJECT = "APPLY-FOR-LOAN - ";
	public static String COMPLETE_DOCUMENT_UPLOAD_SUBJECT = "COMPLETE-DOCUMENT-UPLOAD - ";
	public static String VALIDATE_PARTNER_SUBJECT = "VALIDATE-PARTNER - ";

	public static String ETB_ADD_REFERENCE_SUBJECT = "ETB-ADD-REFERENCE - ";
	public static String ETB_APPLY_FOR_LOAN_SUBJECT = "ETB-APPLY-FOR-LOAN - ";
	public static String ETB_COMPLETE_DOCUMENT_UPLOAD_SUBJECT = "ETB-COMPLETE-DOCUMENT-UPLOAD - ";
	public static String ETB_VALIDATE_PARTNER_SUBJECT = "ETB-VALIDATE-PARTNER - ";

	public static String NAME_MATCH_REQUEST_BANK_CODE = "08";
	public static String NAME_MATCH_REQUEST_CHANNEL = "APIGW";
	public static String NAME_MATCH_REQUEST_TRANSACTION_BRANCH = "089999";
	public static String NAME_MATCH_REQUEST_USER_ID = "DevUser01";
	public static String NAME_MATCH_REQUEST_TRANSACTING_PARTY_CODE = "50000045";

	public static String HUNTER_CUSTOMER_ID = "5";
	public static String HUNTER_CUSTOMER_NAME = "HDFCBANK";
	public static String HUNTER_SUBMISSION_LOAD = "1";
	public static String HUNTER_SCHEME_ID_28 = "28";
	public static String HUNTER_SCHEME_ID_20 = "20";
	public static String HUNTER_SCHEME_ID_21 = "21";
	public static String HUNTER_SCHEME_ID_22 = "22";
	public static String HUNTER_SCHEME_ID_23 = "23";
	public static String HUNTER_SCHEME_ID_24 = "24";
	public static String HUNTER_SCHEME_ID_25 = "25";
	public static String HUNTER_SCHEME_ID_26 = "26";
	public static String HUNTER_SCHEME_ID_27 = "27";
	public static String HUNTER_SCHEME_ID_56 = "56";
	public static String HUNTER_SCHEME_ID_58 = "58";
	public static String HUNTER_SCHEME_ID_78 = "78";
	public static String HUNTER_SCHEME_ID_93 = "93";
	public static String HUNTER_SCHEME_ID_94 = "94";
	public static String HUNTER_PERSIST_MATCHES = "1";
	public static String HUNTER_WORKLIST_INSERT = "1";
	public static String HUNTER_RSLT_CODE = "1";
	public static String HUNTER_COUNT = "1";
	public static String HUNTER_ORIGINATOR = "HDFCBANK";
	public static String HUNTER_CLASSIFICATION = "REFER";
	public static String HUNTER_STATUS_CLEAR = "Clear";

	public static String INITIATE_MB_AGGREGATOR_ID = "545";
	public static String INITIATE_MB_INSTITUTION_ID = "4010";
	public static String INITIATE_MB_MEMBER_ID = "cpu_AutoFirst@hdfcbank.com";
	public static String INITIATE_MB_PASSWORD = "ZXVARVM3Tlc=";
	public static String INITIATE_MB_REQUEST_TYPE = "REQUEST";
	public static String INITIATE_MB_SOURCE_SYSTEM = "AutoFirst";
	public static String INITIATE_MB_PRIORITY = "HIGH_PRIORITY";
	public static String INITIATE_MB_PRODUCT_TYPE = "CIR";
	public static String INITIATE_MB_LOAN_TYPE = "A";
	public static String INITIATE_MB_LOAN_AMOUNT = "100000";
	public static String INITIATE_MB_JOINT_IND = "INDV";
	public static String INITIATE_MB_SOURCE_SYSTEM_NAME = "AutoFDev";
	public static String INITIATE_MB_BUREAU_REGION = "QA/UAT";
	public static String INITIATE_MB_INQUIRY_STAGE = "Pre-Screen";
	public static String INITIATE_MB_INDIVIDUAL_CORPORATE_FLAG = "I";
	public static String INITIATE_MB_CONSTITUTION = "15";
	public static String INITIATE_MB_ADDRESS_TYPE = "CURRES";
	public static String INITIATE_MB_ADDRESS_RESIDENCE_CODE = "01";
	public static String INITIATE_MB_TENURE = "60";
	public static String INITIATE_MB_RESPONSE_FORMAT = "04";

	public static String POSIDEX_IN_SOA_PRODUCT_ID_C = "A";
	public static String POSIDEX_IN_SOA_BORROWER_FLAG_C = "C";
	public static String POSIDEX_IN_SOA_LOAN_AMT_N = "100000";
	public static String POSIDEX_IN_SOA_BRANCHID_N = "3";
	public static String POSIDEX_IN_SOA_EMPLOYER_NAME_C = "posidex";
	public static String POSIDEX_IN_SOA_IND_CORP_FLAG_C = "I";
	public static String POSIDEX_IN_SOA_SET_TARGET_DB = "AUTOF";
	public static String POSIDEX_IN_SOA_SET_CREDIT_BUREAUS = "CIBIL";
	public static String POSIDEX_IN_SOA_SOURCE_ID = "AUTOF";
	public static String POSIDEX_IN_FILLER_13 = "3";
	public static String POSIDEX_IN_FILLER_16 = "3";
	public static String POSIDEX_IN_FILLER_17 = "3";
	public static String POSIDEX_IN_FILLER_21 = "100";
	public static String POSIDEX_IN_FILLER_22 = "3";
	public static String POSIDEX_IN_FILLER_23 = "14";

	public static String EQUI_FAX_REQ_PRODUCT_CODE = "PRFIL";
	public static String EQUI_FAX_REQ_INQUIRY_PURPOSE = "01";
	public static String EQUI_FAX_REQ_PHONE_TYPE = "M";
	public static String EQUI_FAX_REQ_SEQ_1 = "1";
	public static String EQUI_FAX_REQ_ID_TYPE_T = "T";
	public static String EQUI_FAX_REQ_SEQ_2 = "2";
	public static String EQUI_FAX_REQ_ID_TYPE_M = "M";
	public static String EQUI_FAX_REQ_SEQ_3 = "3";
	public static String EQUI_FAX_REQ_ID_TYPE_V = "V";
	public static String EQUI_FAX_REQ_SOURCE = "Inquiry";
	public static String EQUI_FAX_REQ_KEY = "PRFIL_Custom_Logic";

	public static String OTP_AUTH_DEMOG_OFFER_PARTNER_UNAME = "Autocircle";
	public static String OTP_AUTH_DEMOG_OFFER_PARTNER_PWD = "cgSSeMxLm733B8pGz7+tUA==";
	public static String OTP_AUTH_DEMOG_OFFER_PARTNER_CODE = "AutoC";
	public static String OTP_AUTH_DEMOG_OFFER_UDF_4 = "udf_4";
	public static String OTP_AUTH_DEMOG_OFFER_UDF_5 = "udf_5";
	public static String OTP_AUTH_DEMOG_OFFER_UDF_6 = "udf_6";
	public static String OTP_AUTH_DEMOG_OFFER_UDF_7 = "udf_7";
	public static String OTP_AUTH_DEMOG_OFFER_UDF_8 = "udf_8";
	public static String OTP_AUTH_DEMOG_OFFER_UDF_9 = "udf_9";
	public static String OTP_AUTH_DEMOG_OFFER_UDF_10 = "udf_10";
	public static String OTP_AUTH_DEMOG_OFFER_UDF_11 = "udf_11";
	public static String OTP_AUTH_DEMOG_OFFER_UDF_12 = "udf_12";
	public static String OTP_AUTH_DEMOG_OFFER_UDF_13 = "udf_13";
	public static String OTP_AUTH_DEMOG_OFFER_UDF_14 = "udf_14";
	public static String OTP_AUTH_DEMOG_OFFER_UDF_15 = "udf_15";

	public static String CALL_FINTECH_OFFER_INDICATION_PARTNER_UNAME = "Autocircle";
	public static String CALL_FINTECH_OFFER_INDICATION_PARTNER_PWD = "cgSSeMxLm733B8pGz7+tUA==";
	public static String CALL_FINTECH_OFFER_INDICATION_PARTNER_CODE = "AutoC";
	public static String CALL_FINTECH_OFFER_INDICATION_IDENTIFIER_NAME = "DateOfBirth";
	public static String CALL_FINTECH_OFFER_INDICATION_SOURCE_NAME = "SourceName";
	public static String CALL_FINTECH_OFFER_INDICATION_CHANNEL_NAME = "ChannelName";
	public static String CALL_FINTECH_OFFER_INDICATION_UDF_1 = "udf_1";
	public static String CALL_FINTECH_OFFER_INDICATION_UDF_2 = "udf_2";
	public static String CALL_FINTECH_OFFER_INDICATION_UDF_3 = "udf_3";
	public static String CALL_FINTECH_OFFER_INDICATION_UDF_4 = "udf_4";
	public static String CALL_FINTECH_OFFER_INDICATION_UDF_5 = "udf_5";
	public static String CALL_FINTECH_OFFER_INDICATION_UDF_6 = "udf_6";
	public static String CALL_FINTECH_OFFER_INDICATION_UDF_7 = "udf_7";
	public static String CALL_FINTECH_OFFER_INDICATION_UDF_8 = "udf_8";
	public static String CALL_FINTECH_OFFER_INDICATION_UDF_9 = "udf_9";
	public static String CALL_FINTECH_OFFER_INDICATION_UDF_10 = "udf_10";
	public static String CALL_FINTECH_OFFER_INDICATION_UDF_11 = "udf_11";
	public static String CALL_FINTECH_OFFER_INDICATION_UDF_12 = "udf_12";
	public static String CALL_FINTECH_OFFER_INDICATION_UDF_13 = "udf_13";
	public static String CALL_FINTECH_OFFER_INDICATION_UDF_14 = "udf_14";
	public static String CALL_FINTECH_OFFER_INDICATION_UDF_15 = "udf_15";

	public static String FINTECH_GENERIC_OFFERS_AVAILABILITY_PARTNER_NAME = "Autocircle";
	public static String FINTECH_GENERIC_OFFERS_AVAILABILITY_IDENTIFIER_NAME = "DOB";
	public static String FINTECH_GENERIC_OFFERS_AVAILABILITY_PRODUCT_NAME = "AL";
	public static String FINTECH_GENERIC_OFFERS_AVAILABILITY_SECURITY_KEY = "c09f1cb9a5046d6083e1a84d62f8dcc1";
	public static String FINTECH_GENERIC_OFFERS_AVAILABILITY_BUSINESS_ID = "50082";
	public static String FINTECH_GENERIC_OFFERS_AVAILABILITY_ORGANIZATION_ID = "10000";
	public static String FINTECH_GENERIC_OFFERS_AVAILABILITY_CHANNEL = "BA";
	public static String FINTECH_GENERIC_OFFERS_AVAILABILITY_PREFERRED_LANGUAGE = "ENG";
	public static String FINTECH_GENERIC_OFFERS_AVAILABILITY_PREFERRED_LANGUAGE_ONLY = "T";
	public static String FINTECH_GENERIC_OFFERS_AVAILABILITY_IGNORE_SOURCE_RESTRICTION = "T";
	public static String FINTECH_GENERIC_OFFERS_AVAILABILITY_BYPASS_OPEN_N_CLICK_CHECK = "T";
	public static String FINTECH_GENERIC_OFFERS_AVAILABILITY_SOURCE = "OFR";
	public static String FINTECH_GENERIC_OFFERS_AVAILABILITY_SPECIFIED_SOURCE_ONLY = "F";
	public static String FINTECH_GENERIC_OFFERS_AVAILABILITY_CONTENT_COUNT = "0";
	public static String FINTECH_GENERIC_OFFERS_AVAILABILITY_PERSONALIZATION_REQUIRED = "T";
	public static String FINTECH_GENERIC_OFFERS_AVAILABILITY_SERVICE_USER = "string";
	public static String FINTECH_GENERIC_OFFERS_AVAILABILITY_SERVICE_PASSWORD = "string";
	public static String FINTECH_GENERIC_OFFERS_AVAILABILITY_CONSUMER_NAME = "string";
	public static String FINTECH_GENERIC_OFFERS_AVAILABILITY_UNIQUE_ID = "string";
	public static String FINTECH_GENERIC_OFFERS_AVAILABILITY_TIME_STAMP = "string";
	public static String FINTECH_GENERIC_OFFERS_AVAILABILITY_FILLER_1 = "string";
	public static String FINTECH_GENERIC_OFFERS_AVAILABILITY_FILLER_2 = "string";
	public static String FINTECH_GENERIC_OFFERS_AVAILABILITY_FILLER_3 = "string";
	public static String FINTECH_GENERIC_OFFERS_AVAILABILITY_FILLER_4 = "string";
	public static String FINTECH_GENERIC_OFFERS_AVAILABILITY_FILLER_5 = "string";
	public static String FINTECH_GENERIC_OFFERS_AVAILABILITY_FILLER_6 = "string";
	public static String FINTECH_GENERIC_OFFERS_AVAILABILITY_FILLER_7 = "string";
	public static String FINTECH_GENERIC_OFFERS_AVAILABILITY_FILLER_8 = "string";
	public static String FINTECH_GENERIC_OFFERS_AVAILABILITY_FILLER_9 = "string";
	public static String FINTECH_GENERIC_OFFERS_AVAILABILITY_FILLER_10 = "string";

	public static String FINTECH_GENERIC_OFFERS_DEMOGA_UTH_PARTNER_NAME = "Autocircle";
	public static String FINTECH_GENERIC_OFFERS_DEMOGA_UTH_IDENTIFIER_NAME = "DOB";
	public static String FINTECH_GENERIC_OFFERS_DEMOGA_UTH_PRODUCT_NAME = "AL";
	public static String FINTECH_GENERIC_OFFERS_DEMOGA_UTH_CALLER_ID = "hdfc_Api";
	public static String FINTECH_GENERIC_OFFERS_DEMOGA_UTH_INSTANCE_ID = "8888";
	public static String FINTECH_GENERIC_OFFERS_DEMOGA_UTH_LINK_DATA = "000000091";
	public static String FINTECH_GENERIC_OFFERS_DEMOGA_UTH_MESSAGE_HASH = "static:verpwdreq:06:14b5wAfmOfPklbgtTsXZGys8Q6o=";
	public static String FINTECH_GENERIC_OFFERS_DEMOGA_UTH_REF_NO = "5db047c6b1b522aff9ba49a3";
	public static String FINTECH_GENERIC_OFFERS_DEMOGA_UTH_AUTHENTICATIONS_ALLOWED = "1";
	public static String FINTECH_GENERIC_OFFERS_DEMOGA_UTH_EXPIRY_MIN = "15";
	public static String FINTECH_GENERIC_OFFERS_DEMOGA_UTH_MAX_ATTEMPTS = "3";
	public static String FINTECH_GENERIC_OFFERS_DEMOGA_UTH_PASSWORD_CATEGORY = "true";
	public static String FINTECH_GENERIC_OFFERS_DEMOGA_UTH_PASSWORD_LENGTH = "6";
	public static String FINTECH_GENERIC_OFFERS_DEMOGA_UTH_PASSWORD_MASK = "true";
	public static String FINTECH_GENERIC_OFFERS_DEMOGA_UTH_PASSWORD_VALUE = "123456";
	public static String FINTECH_GENERIC_OFFERS_DEMOGA_UTH_SECURITY_KEY = "c09f1cb9a5046d6083e1a84d62f8dcc1";
	public static String FINTECH_GENERIC_OFFERS_DEMOGA_UTH_BUSINESS_ID = "50082";
	public static String FINTECH_GENERIC_OFFERS_DEMOGA_UTH_ORGANIZATION_ID = "10000";
	public static String FINTECH_GENERIC_OFFERS_DEMOGA_UTH_PARTNER_CODE = "AutoC";
	public static String FINTECH_GENERIC_OFFERS_DEMOGA_UTH_CHANNEL = "BA";
	public static String FINTECH_GENERIC_OFFERS_DEMOGA_UTH_PREFERRED_LANGUAGE = "ENG";
	public static String FINTECH_GENERIC_OFFERS_DEMOGA_UTH_PREFERRED_LANGUAGE_ONLY = "T";
	public static String FINTECH_GENERIC_OFFERS_DEMOGA_UTH_IGNORE_SOURCE_RESTRICTION = "T";
	public static String FINTECH_GENERIC_OFFERS_DEMOGA_UTH_BYPASS_OPEN_N_CLICK_CHECK = "T";
	public static String FINTECH_GENERIC_OFFERS_DEMOGA_UTH_SOURCE = "OFR";
	public static String FINTECH_GENERIC_OFFERS_DEMOGA_UTH_SPECIFIED_SOURCE_ONLY = "F";
	public static String FINTECH_GENERIC_OFFERS_DEMOGA_UTH_CONTENT_COUNT = "0";
	public static String FINTECH_GENERIC_OFFERS_DEMOGA_UTH_PERSONALIZATION_REQUIRED = "T";

	public static String DISBURSEMENT_STATUS_PARTNER_CODE = "AutoC";
	public static String DISBURSEMENT_STATUS_PARTNER_UNAME = "Autocircle";
	public static String DISBURSEMENT_STATUS_PARTNER_PWD = "cgSSeMxLm733B8pGz7+tUA==";
	public static String DISBURSEMENT_STATUS_PRODUCT = "ZD";
	public static String DISBURSEMENT_STATUS_UDF_1 = "udf_1";
	public static String DISBURSEMENT_STATUS_UDF_2 = "udf_2";
	public static String DISBURSEMENT_STATUS_UDF_3 = "udf_3";
	public static String DISBURSEMENT_STATUS_UDF_4 = "udf_4";
	public static String DISBURSEMENT_STATUS_UDF_5 = "udf_5";
	public static String DISBURSEMENT_STATUS_UDF_6 = "udf_6";
	public static String DISBURSEMENT_STATUS_UDF_7 = "udf_7";
	public static String DISBURSEMENT_STATUS_UDF_8 = "udf_8";
	public static String DISBURSEMENT_STATUS_UDF_9 = "udf_9";
	public static String DISBURSEMENT_STATUS_UDF_10 = "udf_10";
	public static String DISBURSEMENT_STATUS_UDF_11 = "udf_11";
	public static String DISBURSEMENT_STATUS_UDF_12 = "udf_12";
	public static String DISBURSEMENT_STATUS_UDF_13 = "udf_13";
	public static String DISBURSEMENT_STATUS_UDF_14 = "udf_14";
	public static String DISBURSEMENT_STATUS_UDF_15 = "udf_15";

	public static String INJECTION_STATUS_BANKCODE = "08";
	public static String INJECTION_STATUS_CHANNEL = "APIGW";
	public static String INJECTION_STATUS_USERID = "DevUser01";
	public static String INJECTION_STATUS_TRANSACTIONBRANCH = "089999";
	public static String INJECTION_STATUS_EXTERNALREFERENCENO = "3";

	public static String ETB_INJECTION_STATUS_BANKCODE = "08";
	public static String ETB_INJECTION_STATUS_CHANNEL = "APIGW";
	public static String ETB_INJECTION_STATUS_USERID = "DevUser01";
	public static String ETB_INJECTION_STATUS_TRANSACTIONBRANCH = "089999";
	public static String ETB_INJECTION_STATUS_EXTERNALREFERENCENO = "3";
	public static String PARTNERID = "HDFCBANK";
	public static String CHANNELID = "ADOBE";
	public static int ACE_BRESUCCESS_CODE = 200;
    
}
