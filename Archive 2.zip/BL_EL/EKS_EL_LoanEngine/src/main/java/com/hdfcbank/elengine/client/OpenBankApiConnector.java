package com.hdfcbank.elengine.client;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.Charset;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.Base64;
import java.util.Calendar;
import java.util.Date;
import java.util.Objects;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.SSLContexts;
import org.apache.http.util.EntityUtils;
import org.json.XML;
import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.hdfcbank.elengine.constant.AppConstants;
import com.hdfcbank.elengine.constant.RedisConstants;
import com.hdfcbank.elengine.domain.entity.AppConfigMap;
import com.hdfcbank.elengine.domain.enums.ApiEnvironmentType;
import com.hdfcbank.elengine.openAPI.AESEncrypterDecrypter;
import com.hdfcbank.elengine.openAPI.AESUtils;
import com.hdfcbank.elengine.openAPI.AadharKYCValidationJsonResponse;
import com.hdfcbank.elengine.openAPI.Base64EncoderDecoder;
import com.hdfcbank.elengine.openAPI.CrmJsonResponse;
import com.hdfcbank.elengine.openAPI.DigitalSignature;
import com.hdfcbank.elengine.openAPI.JsonRequestGenerator;
import com.hdfcbank.elengine.openAPI.JsonResponse;
import com.hdfcbank.elengine.openAPI.JsonResponse2;
import com.hdfcbank.elengine.openAPI.JsonResponseReader;
import com.hdfcbank.elengine.openAPI.LeadStatusJsonResponse;
import com.hdfcbank.elengine.openAPI.MedEncryptJsonResponse;
import com.hdfcbank.elengine.openAPI.PanValidationJsonResponse;
import com.hdfcbank.elengine.openAPI.RSAEncrypterDecrypter;
import com.hdfcbank.elengine.openAPI.VcipJsonRequest;
import com.hdfcbank.elengine.openAPI.XMLDigitalSignature;
import com.hdfcbank.elengine.repository.AppConfigMapRepository;
import com.hdfcbank.elengine.util.CommonUtility;
import com.hdfcbank.elengine.util.JSonParser;
import com.hdfcbank.elengine.util.LoggerUtils;
import com.hdfcbank.elengine.util.RedisUtils;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class OpenBankApiConnector {
	public final static Logger logger = LoggerFactory.getLogger(OpenBankApiConnector.class);
	@Autowired
	JsonRequestGenerator jsonrequestGenerator;
	
	@Autowired
    AppConfigMapRepository appConfigMapRepository;
	
	String LEADINSTA_SCOPE;
	 
	private String IMPS_API_SCOPE;

	@Autowired
	LoggerUtils loggerUtils;
	
	@Value("${jwsreprotectheader}")
	String jwsreprotectheader;

	@Value("${pfxPath}")
	String pfxPath;

	@Value("${pfxPassword}")
	String pfxPassword;

	@Value("${spring.jackson.date-format}")
	String dateFormat;

	@Value("${clientScope}")
	String scope;

	@Value("${keyStorePath}")
	String keyStorePath;

	@Value("${trustStorePath}")
	String trustStorePath;

	@Value("${trustStorePassword}")
	String trustStorePassword;

	@Value("${keyStorePassword}")
	String keyStorePassword;

	@Value("${apiKey}")
	String apiKey;

	String leadInstApikey;

	@Value("${clientKeyStoreFilePath}")
	String clientKeyStoreFilePath;

	@Value("${clientKeyStorePassword}")
	String clientKeyStorePassword;

	@Value("${clientKeyAlias}")
	String clientKeyAlias;

	@Value("${crmapiKey}")
	String crmapiKey;

	@Value("${nsdlapiKey}")
	String nsdlapiKey;

	@Value("${NSDLSCOPE}")
	String NSDLSCOPE;

	@Value("${POSIDEX_KEY}")
	String posidexapiKey;

	@Value("${POSIDEX_SCOPE}")
	String posidexSCOPE;

	String AADHARSCOPE;

	String aadharapiKey;

	@Value("${NAMEMATCHAPIKEY}")
	String NAMEMATCHAPIKEY;

	String CIF2_SCOPE;

	String CIF2_API_KEY;

	private String IMPS_API_KEY;

	String impsKeyStoreFilePath;

	String impsKeyStorePassword;

	String impsKeyAlias;

	@Value("${openbankapiconnector.blelpfxpath}")
	private String blelpfxpath;

	@Value("${openbankapiconnector.blelpfxpassword}")
	private String blelpfxpassword;

	@Value("${openbankapiconnector.blelkeystorepath}")
	private String blelkeystorepath;

	@Value("${openbankapiconnector.blelkeystorepassword}")
	private String blelkeystorepassword;

	@Value("${openbankapiconnector.bleltruststorepath}")
	private String bleltruststorepath;

	@Value("${openbankapiconnector.bleltruststorepassword}")
	private String bleltruststorepassword;

	@Value("${openbankapiconnector.blelclientscope}")
	private String blelclientscope;

	@Autowired
	CommonUtility commonUtility;

	@Autowired
	RedisUtils redisUtils;

	@Autowired
	AESUtils aesUtils;

	public JSONObject processApiRequest(String payload, String url) throws Exception {
		JSONObject plainRes = new JSONObject();
		try {

			// logger.debug("jwsreprotectheader :"+jwsreprotectheader );
			String protectHeader = new Base64EncoderDecoder().encodeToString(jwsreprotectheader);

			// logger.debug("encoded value :" + protectHeader);

			String encodedPayload = new Base64EncoderDecoder().encodeToString(payload);

			// logger.debug("encoded paylod :" + encodedPayload);

			String request = new String();
			request = protectHeader + "." + encodedPayload;

			// logger.info("payload :" + payload);

			byte[] signRequest = new DigitalSignature().sign(request, pfxPath, pfxPassword);

			// logger.debug("sign request :" +
			// Base64.getEncoder().encodeToString(signRequest));

			request += "." + Base64.getEncoder().encodeToString(signRequest);
			logger.info("final request : " + request);
			String tranRefNo = commonUtility.genRandomNumber(12);

			String finalRePayload = jsonrequestGenerator.generateRequest(request, scope, tranRefNo);

			logger.info("final request payload :" + finalRePayload);

			String serviceResponse = serviceCall(url, finalRePayload);
			logger.info("service response :" + serviceResponse);
			if (null != serviceResponse) {
				JsonResponse jsonResponse = new JsonResponseReader().read(serviceResponse);

				String status = jsonResponse.getStatus();
                log.info("payload status {}",status);

				if (status.equalsIgnoreCase("SUCCESS")) {
					plainRes = decrpytResponsePayload(jsonResponse);
					return plainRes;
				}
			}
		} catch (Exception e) {
			logger.info("Exception :: " + CommonUtility.getPrintStackTrace(e));
		}
		return plainRes;
	}

	@SuppressWarnings("unchecked")
	public JSONObject processCRMApiRequest(String payload, String url) throws Exception {
		JSONObject plainRes = new JSONObject();
		try {

			logger.info("plain payload :" + payload);
			// String encodedPayload = new Base64EncoderDecoder().encodeToString(payload);

			// logger.debug("encoded paylod :" + encodedPayload);

			String finalRePayload = jsonrequestGenerator.generateCrmRequest(payload, "Autoc_crm", "123444444");
			// String finalRePayload = jsonrequestGenerator.generateRequest(payload,
			// "BITLY", "123444444");
			logger.info("final request payload :" + finalRePayload);

			String serviceResponse = crmserviceCall(url, finalRePayload);
			logger.info("service response :" + serviceResponse);
			if (null != serviceResponse) {
				CrmJsonResponse jsonResponse = new JsonResponseReader().crmread(serviceResponse);

				String status = jsonResponse.getStatus();
                log.info("payload status {}",status);

				if (status.equalsIgnoreCase("SUCCESS")) {
					plainRes = decrpytCRMResponsePayload(jsonResponse);
					return plainRes;
				} else {
					plainRes.put("Status", status);
					return plainRes;
				}
			}

		} catch (Exception e) {
			logger.info("Exception :: " + CommonUtility.getPrintStackTrace(e));
		}
		return plainRes;
	}

	public JSONObject processbilldeskApiRequest(String payload, String url) throws Exception {
		JSONObject plainRes = new JSONObject();
		try {

			logger.info("plain payload :" + payload);
			// String encodedPayload = new Base64EncoderDecoder().encodeToString(payload);

			// logger.debug("encoded paylod :" + encodedPayload);

			String finalRePayload = jsonrequestGenerator.generateBilldeskRequest(payload, "BITLY", "123444444");
			logger.info("final request payload :" + finalRePayload);

			String serviceResponse = billdeskserviceCall(url, finalRePayload);
			logger.info("service response :" + serviceResponse);
			if (null != serviceResponse) {
				JsonResponse2 jsonResponse = new JsonResponseReader().billdeskread(serviceResponse);

				String status = jsonResponse.getStatus();

				if (status.equalsIgnoreCase("SUCCESS")) {
					plainRes = decrpytBilldeskResponsePayload(jsonResponse);
					return plainRes;
				}
			}
		} catch (Exception e) {
			logger.info("Exception :: " + CommonUtility.getPrintStackTrace(e));
		}
		return plainRes;
	}

	public JSONObject decrpytBreResponsePayload(JsonResponse jsonResponse) {
		JSONObject jsonObject = new JSONObject();
		try {
			String encryptedData = jsonResponse.getGWSymmetricKeyEncryptedValue();
			if (StringUtils.isNotBlank(encryptedData)) {
				Base64EncoderDecoder encoder = new Base64EncoderDecoder();
				RSAEncrypterDecrypter rsaEncrypterDecrypter = new RSAEncrypterDecrypter();
				byte[] decoded = encoder.decode(encryptedData.getBytes());
				byte[] decryptedData = rsaEncrypterDecrypter.decrypt(decoded,
						DigitalSignature.privateKey(blelpfxpath, blelpfxpassword));
				logger.info("decrptyed data :" + new String(decryptedData));
				AESEncrypterDecrypter encrypterDecrypter = new AESEncrypterDecrypter();
				String encryptedValue = jsonResponse.getResponseSignatureEncryptedValue();
				byte[] decryptedValue = encrypterDecrypter.decrypt(encoder.decode(encryptedValue.getBytes()),
						decryptedData);
				logger.info("decrptyed data final  :" + new String(decryptedValue));
				String response = new String(decryptedValue);
				String resArray[] = response.split("[.]");
				String decodedRes = "";
				try {
					  decodedRes = new String(encoder.decode(resArray[1].getBytes()));
				} catch (IllegalArgumentException e) {
					  decodedRes = new String(org.apache.commons.codec.binary.Base64.decodeBase64 (resArray[1].getBytes(Charset.forName("UTF-8"))));
				}
				logger.debug("decoded payload :" + decodedRes);
				jsonObject = JSonParser.parseString(decodedRes);
			}else {
				jsonObject.put("message", jsonResponse.getStatus());
				jsonObject.put("status", "503");
			}
		} catch (Exception e) {
			logger.error("Exception :: " + CommonUtility.getPrintStackTrace(e));
		}
		return jsonObject;
	}

	public JSONObject decrpytResponsePayload(JsonResponse jsonResponse) {
		JSONObject jsonObject = new JSONObject();
		try {
			String encryptedData = jsonResponse.getGWSymmetricKeyEncryptedValue();
			Base64EncoderDecoder encoder = new Base64EncoderDecoder();
			RSAEncrypterDecrypter rsaEncrypterDecrypter = new RSAEncrypterDecrypter();
			byte[] decoded = encoder.decode(encryptedData.getBytes());
			byte[] decryptedData = rsaEncrypterDecrypter.decrypt(decoded,
					DigitalSignature.privateKey(pfxPath, pfxPassword));
			logger.info("decrptyed data :" + new String(decryptedData));
			AESEncrypterDecrypter encrypterDecrypter = new AESEncrypterDecrypter();
			String encryptedValue = jsonResponse.getResponseSignatureEncryptedValue();
			byte[] decryptedValue = encrypterDecrypter.decrypt(encoder.decode(encryptedValue.getBytes()),
					decryptedData);
			logger.debug("decrptyed data final  :" + new String(decryptedValue));
			String response = new String(decryptedValue);
			String resArray[] = response.split("[.]");
			String decodedRes = new String(encoder.decode(resArray[1].getBytes()));
			logger.info("decoded payload :" + decodedRes);
			jsonObject = JSonParser.parseString(decodedRes);
		} catch (Exception e) {
			logger.info("Exception :: " + CommonUtility.getPrintStackTrace(e));
		}
		return jsonObject;
	}

	public String decrpytResponseXmlPayload(JsonResponse jsonResponse) {
		try {
			String encryptedData = jsonResponse.getGWSymmetricKeyEncryptedValue();
			Base64EncoderDecoder encoder = new Base64EncoderDecoder();
			RSAEncrypterDecrypter rsaEncrypterDecrypter = new RSAEncrypterDecrypter();
			byte[] decoded = encoder.decode(encryptedData.getBytes());
			byte[] decryptedData = rsaEncrypterDecrypter.decrypt(decoded,
					DigitalSignature.privateKey(pfxPath, pfxPassword));
			// logger.info("decrptyed data :" + new String(decryptedData));
			AESEncrypterDecrypter encrypterDecrypter = new AESEncrypterDecrypter();
			String encryptedValue = jsonResponse.getResponseSignatureEncryptedValue();
			byte[] decryptedValue = encrypterDecrypter.decrypt(encoder.decode(encryptedValue.getBytes()),
					decryptedData);
			// logger.info("decrptyed data final :" + new String(decryptedValue));
			String response = new String(decryptedValue);
			return response;
		} catch (Exception e) {
			logger.info("Exception :: " + CommonUtility.getPrintStackTrace(e));
		}
		return "";
	}

	public String getDapDecData(String encryptedData) {

		try {
			Base64EncoderDecoder encoder = new Base64EncoderDecoder();
			RSAEncrypterDecrypter rsaEncrypterDecrypter = new RSAEncrypterDecrypter();

			byte[] decoded = encoder.decode(encryptedData.getBytes());
			byte[] decryptedData = rsaEncrypterDecrypter.decrypt(decoded,
					DigitalSignature.privateKey(pfxPath, pfxPassword));
			return new String(decryptedData);
		} catch (Exception e) {
			logger.info("Exception :: " + CommonUtility.getPrintStackTrace(e));
		}
		return encryptedData;
	}

	public JSONObject decrpytBilldeskResponsePayload(JsonResponse2 jsonResponse) {
		JSONObject jsonObject = new JSONObject();
		try {
			String encryptedData = jsonResponse.getGWSymmetricKeyEncryptedValue();
			Base64EncoderDecoder encoder = new Base64EncoderDecoder();
			RSAEncrypterDecrypter rsaEncrypterDecrypter = new RSAEncrypterDecrypter();
			byte[] decoded = encoder.decode(encryptedData.getBytes());
			byte[] decryptedData = rsaEncrypterDecrypter.decrypt(decoded,
					DigitalSignature.privateKey(pfxPath, pfxPassword));
			logger.info("decrptyed data :" + new String(decryptedData));
			AESEncrypterDecrypter encrypterDecrypter = new AESEncrypterDecrypter();
			String encryptedValue = jsonResponse.getResponseEncryptedValue();
			byte[] decryptedValue = encrypterDecrypter.decrypt(encoder.decode(encryptedValue.getBytes()),
					decryptedData);
			logger.info("decrptyed data final  :" + new String(decryptedValue));
			String response = new String(decryptedValue);
			String resArray[] = response.split("[.]");
			String decodedRes = new String(encoder.decode(resArray[1].getBytes()));
			logger.info("decoded payload :" + decodedRes);
			jsonObject = JSonParser.parseString(decodedRes);
		} catch (Exception e) {
			logger.info("Exception :: " + CommonUtility.getPrintStackTrace(e));
		}
		return jsonObject;
	}

	public JSONObject decrpytCRMResponsePayload(CrmJsonResponse jsonResponse) {
		JSONObject jsonObject = new JSONObject();
		try {
			String encryptedData = jsonResponse.getGWSessionEncryptedValue();
			Base64EncoderDecoder encoder = new Base64EncoderDecoder();
			RSAEncrypterDecrypter rsaEncrypterDecrypter = new RSAEncrypterDecrypter();
			byte[] decoded = encoder.decode(encryptedData.getBytes());
			byte[] decryptedData = rsaEncrypterDecrypter.decrypt(decoded,
					DigitalSignature.privateKey(pfxPath, pfxPassword));
			logger.info("decrptyed data :" + new String(decryptedData));

			AESEncrypterDecrypter encrypterDecrypter = new AESEncrypterDecrypter();
			String encryptedValue = jsonResponse.getResponseEncryptedValue();
			byte[] decryptedValue = encrypterDecrypter.decrypt(encoder.decode(encryptedValue.getBytes()),
					decryptedData);
			logger.info("decrptyed data final  :" + new String(decryptedValue));
			String response = new String(decryptedValue);
			String issuccess = StringUtils.substringBetween(response, "<Success>", "</Success>");
			System.out.println("is success :" + issuccess);
			String leadNumber = StringUtils.substringBetween(response, "<Lead_Number>", "</Lead_Number>");
			System.out.println("Lead_Number :" + leadNumber);
			jsonObject.put("isSuccess", issuccess);
			jsonObject.put("leadNumber", leadNumber);
			jsonObject.put("response", response);
		} catch (Exception e) {
			logger.info("Exception :: " + CommonUtility.getPrintStackTrace(e));
		}
		return jsonObject;
	}

	public String decrpytLeadStatusResponsePayload(LeadStatusJsonResponse jsonResponse) {
		JSONObject jsonObject = new JSONObject();
		String response = "";
		try {
			String encryptedData = jsonResponse.getGWSymmetricKeyEncryptedValue();
			Base64EncoderDecoder encoder = new Base64EncoderDecoder();
			RSAEncrypterDecrypter rsaEncrypterDecrypter = new RSAEncrypterDecrypter();
			byte[] decoded = encoder.decode(encryptedData.getBytes());
			byte[] decryptedData = rsaEncrypterDecrypter.decrypt(decoded,
					DigitalSignature.privateKey(pfxPath, pfxPassword));
			logger.info("decrptyed data : " + new String(decryptedData));

			AESEncrypterDecrypter encrypterDecrypter = new AESEncrypterDecrypter();
			String encryptedValue = jsonResponse.getResponseEncryptedValue();
			byte[] decryptedValue = encrypterDecrypter.decrypt(encoder.decode(encryptedValue.getBytes()),
					decryptedData);
			logger.info("decrptyed data final  : " + new String(decryptedValue));
			response = new String(decryptedValue);
		} catch (Exception e) {
			logger.info("Exception :: " + CommonUtility.getPrintStackTrace(e));
		}
		return response;
	}

	public String decrpytPosidexResponsePayload(PanValidationJsonResponse jsonResponse) {
		String response = "";
		try {
			String encryptedData = jsonResponse.getGWSymmetricKeyEncryptedValue();
			if (StringUtils.isNotBlank(encryptedData)) {
				Base64EncoderDecoder encoder = new Base64EncoderDecoder();
				RSAEncrypterDecrypter rsaEncrypterDecrypter = new RSAEncrypterDecrypter();
				byte[] decoded = encoder.decode(encryptedData.getBytes());
				byte[] decryptedData = rsaEncrypterDecrypter.decrypt(decoded,
						DigitalSignature.privateKey(blelpfxpath, blelpfxpassword));
				AESEncrypterDecrypter encrypterDecrypter = new AESEncrypterDecrypter();
				String encryptedValue = jsonResponse.getResponseEncryptedValue();
				byte[] decryptedValue = encrypterDecrypter.decrypt(encoder.decode(encryptedValue.getBytes()),
						decryptedData);

				response = new String(decryptedValue);
			}
		} catch (Exception e) {
			logger.error("Exception :: " + CommonUtility.getPrintStackTrace(e));
		}
		return response;
	}

	public String decrpytPANResponsePayload(PanValidationJsonResponse jsonResponse) {
		JSONObject jsonObject = new JSONObject();
		String response = "";
		try {
			String encryptedData = jsonResponse.getGWSymmetricKeyEncryptedValue();
			Base64EncoderDecoder encoder = new Base64EncoderDecoder();
			RSAEncrypterDecrypter rsaEncrypterDecrypter = new RSAEncrypterDecrypter();
			byte[] decoded = encoder.decode(encryptedData.getBytes());
			byte[] decryptedData = rsaEncrypterDecrypter.decrypt(decoded,
					DigitalSignature.privateKey(pfxPath, pfxPassword));
			// logger.info("decrptyed data :" + new String(decryptedData));

			AESEncrypterDecrypter encrypterDecrypter = new AESEncrypterDecrypter();
			String encryptedValue = jsonResponse.getResponseEncryptedValue();
			byte[] decryptedValue = encrypterDecrypter.decrypt(encoder.decode(encryptedValue.getBytes()),
					decryptedData);

			response = new String(decryptedValue);
		} catch (Exception e) {
			logger.info("Exception :: " + CommonUtility.getPrintStackTrace(e));
		}
		return response;
	}

	public String decrpytAadharKYCResponsePayload(AadharKYCValidationJsonResponse jsonResponse) {
		String response = "";
		try {
			String encryptedData = jsonResponse.getGWSymmetricKeyEncryptedValue();
			Base64EncoderDecoder encoder = new Base64EncoderDecoder();
			RSAEncrypterDecrypter rsaEncrypterDecrypter = new RSAEncrypterDecrypter();
			byte[] decoded = encoder.decode(encryptedData.getBytes());
			byte[] decryptedData = rsaEncrypterDecrypter.decrypt(decoded,
					DigitalSignature.privateKey(pfxPath, pfxPassword));
			logger.info("decrptyed data :" + new String(decryptedData));

			AESEncrypterDecrypter encrypterDecrypter = new AESEncrypterDecrypter();
			String encryptedValue = jsonResponse.getResponseEncryptedValue();
			byte[] decryptedValue = encrypterDecrypter.decrypt(encoder.decode(encryptedValue.getBytes()),
					decryptedData);
			logger.info("decrptyed data final  :" + new String(decryptedValue));
			response = new String(decryptedValue);
		} catch (Exception e) {
			logger.info("Exception :: " + CommonUtility.getPrintStackTrace(e));
		}
		return response;
	}

	public String serviceCall(String url, String requestpayload) throws Exception {
		String response = "";
		logger.info("inside servicecall");
		try {

			CloseableHttpClient httpClient = createHttpClient();

			HttpPost httpPost = new HttpPost(url);
			logger.info("apiKey :" + apiKey);
			StringEntity entity = new StringEntity(requestpayload);
			httpPost.setEntity(entity);
			httpPost.setHeader("Accept", "application/json");
			httpPost.setHeader("Content-type", "application/json");
			httpPost.setHeader("apikey", apiKey);

			CloseableHttpResponse httpResponse = httpClient.execute(httpPost);
			logger.info("httpResponse :" + httpResponse);
			int status = httpResponse.getStatusLine().getStatusCode();
			loggerUtils.setHttpStatusCode(status);
			logger.info("httpResponse status code:" + status);

			HttpEntity entity2 = httpResponse.getEntity();

			response = EntityUtils.toString(entity2);
			logger.info("resposne :" + response);
			return response;
		} catch (Exception e) {
			logger.info("Exception :: " + CommonUtility.getPrintStackTrace(e));
		}
		return response;

	}

	public String leadInstServiceCall(String url, String requestpayload) throws Exception {
		String response = "";
		try {

			CloseableHttpClient httpClient = createHttpClient();

			HttpPost httpPost = new HttpPost(url);
			StringEntity entity = new StringEntity(requestpayload);
			httpPost.setEntity(entity);
			httpPost.setHeader("Accept", "application/json");
			httpPost.setHeader("Content-type", "application/json");
			httpPost.setHeader("apikey", leadInstApikey);

			CloseableHttpResponse httpResponse = httpClient.execute(httpPost);
			logger.info("httpResponse :" + httpResponse);
			int status = httpResponse.getStatusLine().getStatusCode();
			loggerUtils.setHttpStatusCode(status);
			logger.info("httpResponse status code:" + status);

			HttpEntity entity2 = httpResponse.getEntity();

			response = EntityUtils.toString(entity2);
			logger.info("resposne :" + response);
			return response;
		} catch (Exception e) {
			logger.info("Exception :: " + CommonUtility.getPrintStackTrace(e));
		}
		return response;

	}

	public String crmserviceCall(String url, String requestpayload) throws Exception {
		String response = "";
		try {

			CloseableHttpClient httpClient = createHttpClient();

			HttpPost httpPost = new HttpPost(url);
			logger.info("crmapiKey :" + crmapiKey);
			StringEntity entity = new StringEntity(requestpayload);
			httpPost.setEntity(entity);
			httpPost.setHeader("Accept", "application/json");
			httpPost.setHeader("Content-type", "application/json");
			httpPost.setHeader("apikey", crmapiKey);

			CloseableHttpResponse httpResponse = httpClient.execute(httpPost);
			logger.info("httpResponse :" + httpResponse);
			int status = httpResponse.getStatusLine().getStatusCode();
			loggerUtils.setHttpStatusCode(status);
			logger.info("httpResponse status code:" + status);

			HttpEntity entity2 = httpResponse.getEntity();

			response = EntityUtils.toString(entity2);
			logger.info("resposne :" + response);
			return response;
		} catch (Exception e) {
			logger.info("Exception :: " + CommonUtility.getPrintStackTrace(e));
		}
		return response;

	}

	public String billdeskserviceCall(String url, String requestpayload) throws Exception {
		String response = "";
		try {

			CloseableHttpClient httpClient = createHttpClient();

			HttpPost httpPost = new HttpPost(url);
			logger.info("crmapiKey :" + crmapiKey);
			StringEntity entity = new StringEntity(requestpayload);
			httpPost.setEntity(entity);
			httpPost.setHeader("Accept", "application/json");
			httpPost.setHeader("Content-type", "application/json");
			httpPost.setHeader("apikey", "l750f7b9d803444178b9b7e45b76dc92e0");

			CloseableHttpResponse httpResponse = httpClient.execute(httpPost);
			logger.info("httpResponse :" + httpResponse);
			int status = httpResponse.getStatusLine().getStatusCode();
			loggerUtils.setHttpStatusCode(status);
			logger.info("httpResponse status code:" + status);

			HttpEntity entity2 = httpResponse.getEntity();

			response = EntityUtils.toString(entity2);
			logger.info("resposne :" + response);
			return response;
		} catch (Exception e) {
			logger.info("Exception :: " + CommonUtility.getPrintStackTrace(e));
		}
		return response;

	}

	private CloseableHttpClient createHttpClient() throws Exception {

		return HttpClients.custom().setSSLSocketFactory(getSSLSocketFactory()).build();

	}

	private SSLConnectionSocketFactory getSSLSocketFactory() throws Exception {

		SSLConnectionSocketFactory sslSocketFactory = new SSLConnectionSocketFactory(loadSSLContext(),

				new String[] { "SSLv3", "TLSv1", "TLSv1.1", "TLSv1.2" }, null,
				SSLConnectionSocketFactory.getDefaultHostnameVerifier());

		return sslSocketFactory;
	}

	private SSLContext loadSSLContext() throws Exception {

		HostnameVerifier hostnameVerifier = new HostnameVerifier() {
			@Override
			public boolean verify(String arg0, SSLSession arg1) {
				return true;
			}
		};

		SSLContext sslcontext = SSLContexts.custom().loadKeyMaterial(new File(keyStorePath),

				keyStorePassword.toCharArray(),

				keyStorePassword.toCharArray())

				.loadTrustMaterial(new File(trustStorePath), trustStorePassword.toCharArray())

				.build();

		return sslcontext;

	}

	private CloseableHttpClient BLELcreateHttpClient() throws Exception {

		return HttpClients.custom().setSSLSocketFactory(getBLELSSLSocketFactory()).build();

	}

	private SSLConnectionSocketFactory getBLELSSLSocketFactory() throws Exception {

		SSLConnectionSocketFactory sslSocketFactory = new SSLConnectionSocketFactory(BLELloadSSLContext(),

				new String[] { "SSLv3", "TLSv1", "TLSv1.1", "TLSv1.2" }, null,
				SSLConnectionSocketFactory.getDefaultHostnameVerifier());

		return sslSocketFactory;
	}

	private SSLContext BLELloadSSLContext() throws Exception {

//		logger.info("loadSSLContext : BLELkeyStorePath :: " +blelkeystorepath +" BLELkeyStorePath:: "+blelkeystorepath+" BLELkeyStorePassword:: "+blelkeystorepassword+" BLELtrustStorePath :: "+bleltruststorepath +" BLELtrustStorePassword:: "+bleltruststorepassword);
		HostnameVerifier hostnameVerifier = new HostnameVerifier() {
			@Override
			public boolean verify(String arg0, SSLSession arg1) {
				return true;
			}
		};

		SSLContext sslcontext = SSLContexts.custom().loadKeyMaterial(new File(blelkeystorepath),

				blelkeystorepassword.toCharArray(),

				blelkeystorepassword.toCharArray())

				.loadTrustMaterial(new File(bleltruststorepath), bleltruststorepassword.toCharArray())

				.build();

		return sslcontext;

	}

	public String processPanValidationApiRequest(String payload, String url, String mobileNumber, String tranRefNo)
			throws Exception {
		String plainRes = "", serviceResponse = "", apiStatus = "Failed", creationTime = "", updationTime = "";
		try {
			logger.info("AesEncReqPayload :: " + payload);
			creationTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").format(Calendar.getInstance().getTime());
			logger.info("creationtime ::" + creationTime);
			redisUtils.set(RedisConstants.PAN_CREATION_TIME + mobileNumber + RedisConstants.US + tranRefNo,
					creationTime);
			logger.info("processPanValidationApiRequest plain payload :" + payload);

			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");

			String finalRePayload = jsonrequestGenerator.generatePanValidationRequest(payload, NSDLSCOPE.trim(),
					formatter.format(new Date()));
			logger.info("processPanValidationApiRequest final request payload ==:" + finalRePayload);

			serviceResponse = panValidationServiceCall(url, finalRePayload);
			logger.info("processPanValidationApiRequest service response=====:" + serviceResponse);
			updationTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").format(Calendar.getInstance().getTime());
			logger.info("updationTime::" + updationTime);
			if (null != serviceResponse) {
				PanValidationJsonResponse jsonResponse = new JsonResponseReader().panRead(serviceResponse);

				String status = jsonResponse.getStatus();
                log.info("payload status {}",status);
				if (status.equalsIgnoreCase("SUCCESS")) {
					apiStatus = "Success";
					plainRes = decrpytPANResponsePayload(jsonResponse);
					return plainRes;
				} else {
					apiStatus = "failure";
					return jsonResponse.toString();
				}
			}
		} catch (Exception e) {
			logger.info("Exception :: " + CommonUtility.getPrintStackTrace(e));
			logger.info("processPanValidationApiRequest Exception :: " + CommonUtility.getPrintStackTrace(e));
			apiStatus = "server error";
			updationTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").format(Calendar.getInstance().getTime());
		} finally {

		}
		return plainRes;
	}

	public String processGateWayApiRequest(String payload, String url) throws Exception {
		String plainRes = "";
		try {

			logger.debug("plain payload :" + payload);

			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");

			String finalRePayload = jsonrequestGenerator.generatePanValidationRequest(payload, NSDLSCOPE.trim(),
					formatter.format(new Date()));
			logger.debug("final request payload processGateWayApiRequest==:" + finalRePayload);
			String serviceResponse = panValidationServiceCall(url, finalRePayload);
			if (null != serviceResponse) {
				PanValidationJsonResponse jsonResponse = new JsonResponseReader().panRead(serviceResponse);

				String status = jsonResponse.getStatus();
                log.info("payload status {}",status);
                loggerUtils.setPayloadStatus(status);
				if (status.equalsIgnoreCase("SUCCESS")) {
					plainRes = decrpytPANResponsePayload(jsonResponse);
					return plainRes;
				} else {
					logger.debug("processGateWayApiRequest service response=====: url :: " + url + " " + plainRes);
					// return plainRes;
					return serviceResponse;
				}
			} else {
				logger.info("processGateWayApiRequest service response=====: url :: " + url + " " + serviceResponse);
			}
		} catch (Exception e) {
			logger.info("Exception :: " + CommonUtility.getPrintStackTrace(e));
			logger.info("Exception processGateWayApiRequest : " + e.getMessage());
		}
		return plainRes;
	}

	public String processPosidexInGateWayApiRequest(String payload, String url,String serviceName) throws Exception {
		String plainRes = "";
		try {

			String tranRefNo = commonUtility.genRandomNumber(12);

			String finalRePayload = jsonrequestGenerator.generatePosidexRequest(payload, posidexSCOPE.trim(),
					tranRefNo);

			log.debug("final request payload processGateWayApiRequest {}", finalRePayload);
			String serviceResponse = posidexServiceCall(url, finalRePayload,serviceName);
			log.debug("final response payload processGateWayApiRequest {}", serviceResponse);
			if (null != serviceResponse) {
				PanValidationJsonResponse jsonResponse = new JsonResponseReader().panRead(serviceResponse);

				String status = jsonResponse.getStatus();
				loggerUtils.setPayloadStatus(status);
				if (status.equalsIgnoreCase("SUCCESS")) {
					plainRes = decrpytPosidexResponsePayload(jsonResponse);
					return plainRes;
				} else {
					logger.debug("processGateWayApiRequest service response=====: url :: " + url + " " + plainRes);
					return serviceResponse;
				}
			} else {
				logger.debug("processGateWayApiRequest service response=====: url :: " + url + " " + serviceResponse);
			}
		} catch (Exception e) {
			logger.error("Exception :: " + CommonUtility.getPrintStackTrace(e));
		}
		return plainRes;
	}

	public String processPosidexDedupeGateWayApiRequest(String payload, String url, String mobileNumber,
			String operationtype, String tranRefNumber) throws Exception {
		String plainRes = "", apistatus = "";
		String creationTime = "", updationTime = "";
		try {

			// logger.info("plain payload :" + payload);
			creationTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").format(Calendar.getInstance().getTime());

			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");

			String finalRePayload = jsonrequestGenerator.generatePanValidationRequest(payload, NSDLSCOPE.trim(),
					formatter.format(new Date()));
			// logger.info("final request payload processPanValidationApi==:" +
			// finalRePayload);

			String serviceResponse = panValidationServiceCall(url, finalRePayload);
			// logger.info("service response=====:" + serviceResponse);
			updationTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").format(Calendar.getInstance().getTime());
			if (null != serviceResponse) {
				PanValidationJsonResponse jsonResponse = new JsonResponseReader().panRead(serviceResponse);
				String status = jsonResponse.getStatus();
				if (status.equalsIgnoreCase("SUCCESS")) {
					apistatus = "success";
					plainRes = decrpytPANResponsePayload(jsonResponse);
					return plainRes;
				}
			}
		} catch (Exception e) {
			apistatus = "Server Error";
			updationTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").format(Calendar.getInstance().getTime());
			logger.info("Exception :: " + CommonUtility.getPrintStackTrace(e));
		} finally {
			if (operationtype.equals("posidexOutputService")) {
//				breUtil.setAPIReqAndRespTime(AppConstants.POSIDEX_STATUS, mobileNumber, tranRefNumber, creationTime,
//						updationTime);
			}

//			ntbLoanDao.insertposedexDetails(aesUtils.encrypt(mobileNumber), aesUtils.encrypt(payload), aesUtils.encrypt(plainRes), creationTime, updationTime, operationtype,
//					apistatus, tranRefNumber);
		}
		return plainRes;
	}

	@Async
	public String processPosidexGateWayApiRequest(String payload, String url) throws Exception {
		String plainRes = "";
		try {

			logger.info("plain payload :" + payload);

			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");

			String finalRePayload = jsonrequestGenerator.generatePanValidationRequest(payload, NSDLSCOPE.trim(),
					formatter.format(new Date()));
			logger.info("final request payload processPanValidationApi==:" + finalRePayload);

			String serviceResponse = panValidationServiceCall(url, finalRePayload);
			logger.info("service response=====:" + serviceResponse);
			if (null != serviceResponse) {
				PanValidationJsonResponse jsonResponse = new JsonResponseReader().panRead(serviceResponse);

				String status = jsonResponse.getStatus();

				if (status.equalsIgnoreCase("SUCCESS")) {
					plainRes = decrpytPANResponsePayload(jsonResponse);
					return plainRes;
				}
			}
		} catch (Exception e) {
			logger.info("Exception :: " + CommonUtility.getPrintStackTrace(e));
		}
		return plainRes;
	}

	public String processBREApiGateWayRequest(String payload, String url) throws Exception {
		String plainRes = "";
		try {

			logger.info("plain payload :" + payload);

			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");

			String finalRePayload = jsonrequestGenerator.generatePanValidationRequest(payload, CIF2_SCOPE.trim(),
					formatter.format(new Date()));
			logger.info("final request payload processBREApiGateWayRequest==:" + finalRePayload);

			String serviceResponse = cif2ServiceCall(url, finalRePayload);
			logger.info("cif2 service response=====:" + serviceResponse);
			if (null != serviceResponse) {
				PanValidationJsonResponse jsonResponse = new JsonResponseReader().panRead(serviceResponse);

				String status = jsonResponse.getStatus();

				if (status.equalsIgnoreCase("SUCCESS")) {
					plainRes = decrpytPANResponsePayload(jsonResponse);
					return plainRes;
				}
			}
		} catch (Exception e) {
			logger.info("Exception :: " + CommonUtility.getPrintStackTrace(e));
		}
		return plainRes;
	}

	public String posidexServiceCall(String url, String requestpayload,String serviceName) throws Exception {
		String response = "";
		String environment = "";
		try {
			if(StringUtils.isNotBlank(serviceName)) {
				serviceName =  ApiEnvironmentType.valueOf(serviceName).toString();
				AppConfigMap appConfigMap =	appConfigMapRepository.findByDatakeyAndIsactive(serviceName, "Y");
			    if(Objects.nonNull(appConfigMap)) {
			    	environment =  appConfigMap.getDatavalue();
			    }
			}
			log.info("environment {}",environment);
			log.info("endpoint {}",url);
			CloseableHttpClient httpClient = BLELcreateHttpClient();

			HttpPost httpPost = new HttpPost(url);
			StringEntity entity = new StringEntity(requestpayload);
			httpPost.setEntity(entity);
			httpPost.setHeader("Accept", "application/json");
			httpPost.setHeader("Content-type", "application/json");
			httpPost.setHeader("apikey", posidexapiKey);
			httpPost.setHeader("environment", environment);
			CloseableHttpResponse httpResponse = httpClient.execute(httpPost);
			logger.info("httpResponse :" + httpResponse);
			int status = httpResponse.getStatusLine().getStatusCode();
			loggerUtils.setHttpStatusCode(status);
			logger.info("httpResponse status code:" + status);

			HttpEntity entity2 = httpResponse.getEntity();

			response = EntityUtils.toString(entity2);

			return response;
		} catch (Exception e) {
			logger.error("Exception :: " + CommonUtility.getPrintStackTrace(e));
		}
		return response;

	}

	public String hunterServiceCall(String url, String requestpayload) throws Exception {
		String response = "";
		try {

			CloseableHttpClient httpClient = BLELcreateHttpClient();

			HttpPost httpPost = new HttpPost(url);
			StringEntity entity = new StringEntity(requestpayload);
			httpPost.setEntity(entity);
			httpPost.setHeader("Accept", "application/json");
			httpPost.setHeader("Content-type", "application/json");
			httpPost.setHeader("apikey", posidexapiKey);

			CloseableHttpResponse httpResponse = httpClient.execute(httpPost);
			logger.info("httpResponse :" + httpResponse);
			int status = httpResponse.getStatusLine().getStatusCode();
			loggerUtils.setHttpStatusCode(status);
			logger.info("httpResponse status code:" + status);

			HttpEntity entity2 = httpResponse.getEntity();

			response = EntityUtils.toString(entity2);

			return response;
		} catch (Exception e) {
			log.error("Exception {}" , CommonUtility.getPrintStackTrace(e));
		}
		return response;

	}

	public String panValidationServiceCall(String url, String requestpayload) throws Exception {
		String response = "";
		try {

			CloseableHttpClient httpClient = createHttpClient();

			HttpPost httpPost = new HttpPost(url);
			// logger.info("nsdlapiKey :" + nsdlapiKey);
			StringEntity entity = new StringEntity(requestpayload);
			httpPost.setEntity(entity);
			httpPost.setHeader("Accept", "application/json");
			httpPost.setHeader("Content-type", "application/json");
			httpPost.setHeader("apikey", nsdlapiKey);

			CloseableHttpResponse httpResponse = httpClient.execute(httpPost);
			logger.info("httpResponse :" + httpResponse);
			int status = httpResponse.getStatusLine().getStatusCode();
			loggerUtils.setHttpStatusCode(status);
			log.info("httpResponse status code {}" + status);

			HttpEntity entity2 = httpResponse.getEntity();

			response = EntityUtils.toString(entity2);
			// logger.info("resposne nsdl :" + response);
			return response;
		} catch (Exception e) {
			logger.info("Exception :: " + CommonUtility.getPrintStackTrace(e));
		}
		return response;

	}

	public String cif2ServiceCall(String url, String requestpayload) throws Exception {
		String response = "";
		try {

			CloseableHttpClient httpClient = createHttpClient();

			HttpPost httpPost = new HttpPost(url);
			// logger.info("nsdlapiKey :" + nsdlapiKey);
			StringEntity entity = new StringEntity(requestpayload);
			httpPost.setEntity(entity);
			httpPost.setHeader("Accept", "application/json");
			httpPost.setHeader("Content-type", "application/json");
			httpPost.setHeader("apikey", CIF2_API_KEY);

			CloseableHttpResponse httpResponse = httpClient.execute(httpPost);
			// logger.info("httpResponse :" + httpResponse);
			int status = httpResponse.getStatusLine().getStatusCode();
			loggerUtils.setHttpStatusCode(status);
			// logger.info("httpResponse status code:" + status);

			HttpEntity entity2 = httpResponse.getEntity();

			response = EntityUtils.toString(entity2);
			// logger.info("resposne nsdl :" + response);
			return response;
		} catch (Exception e) {
			logger.info("Exception :: " + CommonUtility.getPrintStackTrace(e));
		}
		return response;

	}

	public String aadharKYCValidationServiceCall(String url, String requestpayload) throws Exception {
		String response = "";
		try {

			CloseableHttpClient httpClient = createHttpClient();

			HttpPost httpPost = new HttpPost(url);
			logger.info("aadharapiKey :" + aadharapiKey);
			StringEntity entity = new StringEntity(requestpayload);
			httpPost.setEntity(entity);
			httpPost.setHeader("Accept", "application/json");
			httpPost.setHeader("Content-type", "application/json");
			httpPost.setHeader("apikey", aadharapiKey);

			CloseableHttpResponse httpResponse = httpClient.execute(httpPost);
			logger.info("httpResponse :" + httpResponse);
			int status = httpResponse.getStatusLine().getStatusCode();
			loggerUtils.setHttpStatusCode(status);
			logger.info("httpResponse status code:" + status);

			HttpEntity entity2 = httpResponse.getEntity();

			response = EntityUtils.toString(entity2);
			logger.info("resposne aadharkyc :" + response);
			return response;
		} catch (Exception e) {
			logger.info("Exception :: " + CommonUtility.getPrintStackTrace(e));
		}
		return response;

	}

	public String apiServiceCall(String url, String requestpayload, String apiKey) throws Exception {
		String response = "";
		try {

			CloseableHttpClient httpClient = createHttpClient();

			HttpPost httpPost = new HttpPost(url);
			StringEntity entity = new StringEntity(requestpayload);
			httpPost.setEntity(entity);
			httpPost.setHeader("Accept", "application/json");
			httpPost.setHeader("Content-type", "application/json");
			httpPost.setHeader("apikey", apiKey);

			CloseableHttpResponse httpResponse = httpClient.execute(httpPost);
			// logger.info("httpResponse :" + httpResponse);
			int status = httpResponse.getStatusLine().getStatusCode();
			loggerUtils.setHttpStatusCode(status);
			// logger.info("httpResponse status code:" + status);

			HttpEntity entity2 = httpResponse.getEntity();

			response = EntityUtils.toString(entity2);
			return response;
		} catch (Exception e) {
			logger.info("Exception :: " + CommonUtility.getPrintStackTrace(e));
		}
		return response;

	}

	public String processApiRequest(String payload, String url, String scope) throws Exception {
		String plainRes = "";
		try {

			logger.info("plain payload :" + payload);
			// String encodedPayload = new Base64EncoderDecoder().encodeToString(payload);

			// logger.debug("encoded paylod :" + encodedPayload);
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");

			String finalRePayload = jsonrequestGenerator.generatePanValidationRequest(payload, scope.trim(),
					formatter.format(new Date()));
			// String finalRePayload = jsonrequestGenerator.generateRequest(payload,
			// "BITLY", "123444444");
			// finalRePayload="{ \"RequestEncryptedValue\" :
			// \"FueUed/w5KwEtxREy3WAs2P/bqtI2GqjCbot/8rC+xl809wUMOtdtK96YDGR56Y7p5pxDO3aC7m+
			// dCFo0y5OPILUPWCiZIJBOYhLcBMoxnq+0Thdik4l9lHtzwCK99YGKS1FKOTlFyvTBEo7jlW8Ezzi
			// tf1LWbgP9Hd5Ueht2/xkT5D+3L/gqhP1kX9IhyCwTE8AilooQTmSTlrO/hNV76nPSW1+p8pWBjoc
			// m9A+z2TUDzyAZY9/twymXv9cIVwK76D1PBEJiWGQkDs0g//ASmwlM0z7YpVcLiKZIYXRtAoQWHTK
			// GJIxFnw65rK7DMVFt/Rdq+geuvvVs8edYlDnIelV+PT/nqzFlO0PGHRyu/6uavx6DCUN/1kGDSeH
			// 9wD/Ix0jE7qGV27BAN4mpVGp7FPfuf9FkgANz7APzOybKeXQtOWmXbrAuMq10fnvWx2+iW2pxX3y
			// 3QSYw9EhYwEydiLTa3bYl7+nCUnHZUCrDDKEWn5QnxJwl9qHSS7AAo6aGPaBf1u/Z4dkZNQA1jCk
			// vSM6EHmN3NGnLwKrc8gLO+tJXG6p+KzFpjdgR3piZ6vQ3q8mMRiuUzkTz51b2iC8sbcgIAIc7Vsq
			// m1oAKRSxhXXb7H/7ZFaZuAaU9plSHP+B/DR0UEZXvnkqM3ZEHoAHcrojANxLNARvV2CGolkUk4gk
			// c8ivUgqwADPlO6I/fjSWswYF4NH3ATI0WciP6/uFKJNqKmIoEbi1Qr1HCd1ShxHsSsP3UQvV9zfA
			// TRdEs6WM\", \"SymmetricKeyEncryptedValue\" :
			// \"S9wT9rWTAXwRArDlG/ZciCKOiNHbtgMgU8CNU29yUQe6CVKSMIZjy/yJ0XvBDc275twnxUgDR/g
			// aPKU1Ah6s065sr05lbw/vD1NuD6LxlDELXm6p+NOaH9uVfps3XkUSYfNa8nFAKmCc/wHrmkEVXXK
			// uuiPNR1r+aJTQlvk6oFvLLFUSanGr8E1M5US8a//z4W0y0R5139oL4KUYyezosx68cc7Ya04T6B1
			// SlN4bjfng87+Ekzjfw/5f1Pkvt6XngJEewqoeII4KDOP9+6bYqbXtXZ8DXtRrxUnQBnCZuBeCMCm
			// RIxgAwTO3x6r45tVgwj0aIA23EPVWNZ3dbpx0Q==\", \"Scope\" : \"AutoFirstSW\",
			// \"TransactionId\" : \"2020-11-06T12:23:22.454+05:30\", \"OAuthTokenValue\" :
			// \"\" }";
			logger.info("final request payload processApiRequest==:" + finalRePayload);

			String serviceResponse = panValidationServiceCall(url, finalRePayload);
			logger.info("service response processApiRequest=====:" + serviceResponse);
			if (null != serviceResponse) {
				PanValidationJsonResponse jsonResponse = new JsonResponseReader().panRead(serviceResponse);

				String status = jsonResponse.getStatus();

				if (status.equalsIgnoreCase("SUCCESS")) {
					plainRes = decrpytPANResponsePayload(jsonResponse);
					return plainRes;
				}
			}
		} catch (Exception e) {
			logger.info("Exception :: " + CommonUtility.getPrintStackTrace(e));
		}
		return plainRes;
	}

	public JSONObject processPosidexNameMatchApiRequest(String payload, String url, String scope, String timeStamp,
			String mobileNumber, String tranRefNo) throws Exception {
		JSONObject plainRes = new JSONObject();
		String apiStatus = "", serviceResponse = "";
		String creationTime = "";
		String updationTime = "";
		try {
			creationTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").format(Calendar.getInstance().getTime());
			// logger.info("plain payload :" + payload);
			String finalRePayload = jsonrequestGenerator.generatePanValidationRequest(payload, scope.trim(),
					timeStamp.toString());
			// logger.info("final request payload processPosidexNameMatchApiRequest==:" +
			// finalRePayload);

			serviceResponse = apiServiceCall(url, finalRePayload, NAMEMATCHAPIKEY.trim());
			logger.info("service response processPosidexNameMatchApi=====:" + serviceResponse);
			updationTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").format(Calendar.getInstance().getTime());
			if (null != serviceResponse) {
				PanValidationJsonResponse jsonResponse = new JsonResponseReader().panRead(serviceResponse);

				String status = jsonResponse.getStatus();

				if (status.equalsIgnoreCase("SUCCESS")) {
					apiStatus = "Success";
					plainRes = decrpytNameMismatchResponsePayload(jsonResponse, mobileNumber, tranRefNo, payload,
							creationTime, updationTime);
					return plainRes;
				}
			}

		} catch (Exception e) {
			logger.info("Exception :: " + CommonUtility.getPrintStackTrace(e));
			apiStatus = "Failure";
		} finally {

		}
		return plainRes;
	}

	public JSONObject decrpytNameMismatchResponsePayload(PanValidationJsonResponse jsonResponse, String mobileNumber,
			String tranRefNo, String payload, String creationTime, String updationTime) {
		JSONObject jsonObject = new JSONObject();
		String response = "", apiStatus = "failure";

		try {
			String encryptedData = jsonResponse.getGWSymmetricKeyEncryptedValue();
			Base64EncoderDecoder encoder = new Base64EncoderDecoder();
			RSAEncrypterDecrypter rsaEncrypterDecrypter = new RSAEncrypterDecrypter();
			byte[] decoded = encoder.decode(encryptedData.getBytes());
			byte[] decryptedData = rsaEncrypterDecrypter.decrypt(decoded,
					DigitalSignature.privateKey(pfxPath, pfxPassword));
			// logger.info("decrptyed data :" + new String(decryptedData));

			AESEncrypterDecrypter encrypterDecrypter = new AESEncrypterDecrypter();
			String encryptedValue = jsonResponse.getResponseEncryptedValue();
			byte[] decryptedValue = encrypterDecrypter.decrypt(encoder.decode(encryptedValue.getBytes()),
					decryptedData);
			logger.info("decrptyed data final : " + new String(decryptedValue));
			response = new String(decryptedValue);
			org.json.JSONObject xmlTojsonObject = new org.json.JSONObject();
			xmlTojsonObject = XML.toJSONObject(response);
			String responseErrorCode = StringUtils.substringBetween(response, "<responseservice:errorCode>",
					"</responseservice:errorCode>");
			if (responseErrorCode.equalsIgnoreCase("0")) {
				apiStatus = "success";
			}
			String nameMatchPercentage = StringUtils.substringBetween(response, "<namePercentage>",
					"</namePercentage>");
			// System.out.println("Lead_Number :"+leadNumber);
			jsonObject.put("responseErrorCode", responseErrorCode);
			jsonObject.put("nameMatchPercentage", nameMatchPercentage);
			// jsonObject.put("PanValidationResponse", xmlTojsonObject);

			redisUtils.set(RedisConstants.NTB_NAME_MATCH + mobileNumber + RedisConstants.US + tranRefNo, response);

			org.json.JSONObject posidexNameMatchXmlTojsonObject = XML.toJSONObject(response);
			org.json.JSONObject nmjsn = (org.json.JSONObject) posidexNameMatchXmlTojsonObject.get("S:Envelope");
			org.json.JSONObject nmjsn2 = (org.json.JSONObject) nmjsn.get("S:Body");
			org.json.JSONObject nmjsn3 = (org.json.JSONObject) nmjsn2.get("ns11:doAddressMatchPercentageResponse");
			org.json.JSONObject nameMatchReturnObject = (org.json.JSONObject) nmjsn3.get("return");
			org.json.JSONObject responseserviceStatus = (org.json.JSONObject) nameMatchReturnObject
					.get("responseservice:status");

			String responseServiceErrorCode = responseserviceStatus.get("responseservice:errorCode").toString();

		} catch (Exception e) {
			logger.info("Exception :: " + CommonUtility.getPrintStackTrace(e));
		} finally {
		}
		return jsonObject;
	}

	public JSONObject processNameMatchApiRequest(String payload, String url, String scope, String mobileNumber,
			String tranRefNo, String operationType) throws Exception {
		JSONObject plainRes = new JSONObject();
		String apiStatus = "", serviceResponse = "";
		String creationTime = "";
		String updationTime = "";
		try {
			creationTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").format(Calendar.getInstance().getTime());
			Long timeStamp = Instant.now().toEpochMilli();
			// logger.info("plain payload :" + payload);
			String finalRePayload = jsonrequestGenerator.generatePanValidationRequest(payload, scope.trim(),
					timeStamp.toString());
			// logger.info("final request payload processPosidexNameMatchApiRequest==:" +
			// finalRePayload);

			serviceResponse = apiServiceCall(url, finalRePayload, NAMEMATCHAPIKEY.trim());
			// logger.info("service response processPosidexNameMatchApi=====:" +
			// serviceResponse);
			updationTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").format(Calendar.getInstance().getTime());
			if (null != serviceResponse) {
				PanValidationJsonResponse jsonResponse = new JsonResponseReader().panRead(serviceResponse);

				String status = jsonResponse.getStatus();

				if (status.equalsIgnoreCase("SUCCESS")) {
					apiStatus = "Success";
					plainRes = decrpytNameMatchResponsePayload(jsonResponse, mobileNumber, tranRefNo, payload,
							operationType, creationTime, updationTime);
					return plainRes;
				}
			}
		} catch (Exception e) {
			logger.info("Exception :: " + CommonUtility.getPrintStackTrace(e));
			apiStatus = "Failure";
		} finally {

		}
		return plainRes;
	}

	public JSONObject decrpytNameMatchResponsePayload(PanValidationJsonResponse jsonResponse, String mobileNumber,
			String tranRefNo, String payload, String operationType, String creationTime, String updationTime) {
		JSONObject jsonObject = new JSONObject();
		String response = "", apiStatus = "failure";
		try {

			String encryptedData = jsonResponse.getGWSymmetricKeyEncryptedValue();
			Base64EncoderDecoder encoder = new Base64EncoderDecoder();
			RSAEncrypterDecrypter rsaEncrypterDecrypter = new RSAEncrypterDecrypter();
			byte[] decoded = encoder.decode(encryptedData.getBytes());
			byte[] decryptedData = rsaEncrypterDecrypter.decrypt(decoded,
					DigitalSignature.privateKey(pfxPath, pfxPassword));
			// logger.info("decrptyed data :" + new String(decryptedData));

			AESEncrypterDecrypter encrypterDecrypter = new AESEncrypterDecrypter();
			String encryptedValue = jsonResponse.getResponseEncryptedValue();
			byte[] decryptedValue = encrypterDecrypter.decrypt(encoder.decode(encryptedValue.getBytes()),
					decryptedData);
			// logger.info("decrptyed data final :" + new String(decryptedValue));
			response = new String(decryptedValue);
			org.json.JSONObject xmlTojsonObject = new org.json.JSONObject();
			xmlTojsonObject = XML.toJSONObject(response);
			String responseErrorCode = StringUtils.substringBetween(response, "<responseservice:errorCode>",
					"</responseservice:errorCode>");
			if (responseErrorCode.equalsIgnoreCase("0")) {
				apiStatus = "success";
			}
			String nameMatchPercentage = StringUtils.substringBetween(response, "<namePercentage>",
					"</namePercentage>");
			// System.out.println("Lead_Number :"+leadNumber);
			jsonObject.put("responseErrorCode", responseErrorCode);
			jsonObject.put("nameMatchPercentage", nameMatchPercentage);
			// jsonObject.put("PanValidationResponse", xmlTojsonObject);
			if (operationType.equals("perfiosNameMatchAPI")) {
				redisUtils.set(RedisConstants.NTB_PERFIOS_NAME_MATCH + mobileNumber + RedisConstants.US + tranRefNo,
						response);
			}

			if (operationType.equals("ekycNameMatchAPI")) {
				redisUtils.set(RedisConstants.NTB_EKYC_NAME_MATCH + mobileNumber + RedisConstants.US + tranRefNo,
						response);
			}
		} catch (Exception e) {
			apiStatus = "failure";
			logger.info("Exception :: " + CommonUtility.getPrintStackTrace(e));
		} finally {
		}
		return jsonObject;
	}

	public JSONObject processLeadInstaApiRequest(String payload, String url) throws Exception {
		JSONObject plainRes = new JSONObject();

		try {
			// logger.debug("jwsreprotectheader :"+jwsreprotectheader );
			String protectHeader = new Base64EncoderDecoder().encodeToString(jwsreprotectheader);

			// logger.debug("encoded value :" + protectHeader);

			String encodedPayload = new Base64EncoderDecoder().encodeToString(payload);

			// logger.debug("encoded paylod :" + encodedPayload);
			logger.info("LEADINSTA_SCOPE:" + LEADINSTA_SCOPE);
			String request = new String();
			request = protectHeader + "." + encodedPayload;

			// logger.info("payload :" + payload);

			byte[] signRequest = new DigitalSignature().sign(request, pfxPath, pfxPassword);

			// logger.debug("sign request :" +
			// Base64.getEncoder().encodeToString(signRequest));

			request += "." + Base64.getEncoder().encodeToString(signRequest);
			logger.debug("Lead insta final request :" + request);
			String tranRefNo = commonUtility.genRandomNumber(12);

			String finalRePayload = jsonrequestGenerator.generateLeadInstaRequest(request, LEADINSTA_SCOPE, tranRefNo);

			logger.info("Lead insta final request payload :" + finalRePayload);

			String serviceResponse = leadInstServiceCall(url, finalRePayload);
			logger.info("Lead insta service response :" + serviceResponse);
			if (null != serviceResponse) {
				JsonResponse jsonResponse = new JsonResponseReader().read(serviceResponse);

				String status = jsonResponse.getStatus();

				/*
				 * if (status.equalsIgnoreCase("SUCCESS")) { plainRes =
				 * decrpytResponsePayload(jsonResponse); return plainRes; } else { plainRes =
				 * decrpytResponsePayload(jsonResponse); return plainRes; }
				 */
				plainRes = decrpytResponsePayload(jsonResponse);
				return plainRes;
			}
		} catch (Exception e) {
			logger.info("Exception :: " + CommonUtility.getPrintStackTrace(e));
		}
		return plainRes;
	}

	public JSONObject processBREApiRequest(String payload, String url) throws Exception {
		JSONObject plainRes = new JSONObject();

		try {
			String protectHeader = new Base64EncoderDecoder().encodeToString(jwsreprotectheader);
			String encodedPayload = new Base64EncoderDecoder().encodeToString(payload);
			String request = new String();
			request = protectHeader + "." + encodedPayload;
			byte[] signRequest = new DigitalSignature().sign(request, blelpfxpath, blelpfxpassword);

			request += "." + Base64.getEncoder().encodeToString(signRequest);
			logger.debug("BRE final request :" + request);
			logger.info("BRE final request url :" + url);

			String tranRefNo = commonUtility.genRandomNumber(12);

			String finalRePayload = jsonrequestGenerator.generateLeadInstaRequest(request, blelclientscope, tranRefNo);

			logger.debug("BRE final request payload :" + finalRePayload);

			String serviceResponse = posidexServiceCall(url, finalRePayload,"");
			logger.debug("BRE service response :" + serviceResponse);
			if (null != serviceResponse) {
				JsonResponse jsonResponse = new JsonResponseReader().read(serviceResponse);

				String status = jsonResponse.getStatus();
                log.info("payload status {}",status);
                loggerUtils.setPayloadStatus(status);
				if (status.equalsIgnoreCase("SUCCESS")) {
 					plainRes = decrpytBreResponsePayload(jsonResponse);
					return plainRes;
				} else {
					logger.info("processGateWayApiRequest service error response=====: url :: " + url + " " + serviceResponse);
					plainRes = decrpytBreResponsePayload(jsonResponse);
					return plainRes;
				}
			}
		} catch (Exception e) {
			logger.error("Exception :: " + CommonUtility.getPrintStackTrace(e));
		}
		return plainRes;
	}

	public String processAadharKYCValidationApiRequest(String payload, String url) throws Exception {
		String plainRes = "", serviceResponse = "", apiStatus = "Failed";
		try {

			logger.info("plain payload :" + payload);

			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");

			String finalRePayload = jsonrequestGenerator.generateAadhaarKYCValidationRequest(payload,
					AADHARSCOPE.trim(), formatter.format(new Date()));
			logger.info("final request payload processAadhaarKYCValidationApiRequest==:" + finalRePayload);

			serviceResponse = aadharKYCValidationServiceCall(url, finalRePayload);
			logger.info("service response===== :: " + serviceResponse);
			if (null != serviceResponse) {

				AadharKYCValidationJsonResponse jsonResponse = new JsonResponseReader().aadharKYCRead(serviceResponse);

				String status = jsonResponse.getStatus();

				if (status.equalsIgnoreCase("SUCCESS")) {
					apiStatus = "Success";
					plainRes = decrpytAadharKYCResponsePayload(jsonResponse);
					return plainRes;
				}
			}
		} catch (Exception e) {
			logger.info("Exception :: " + CommonUtility.getPrintStackTrace(e));
			apiStatus = "Failed";
		} finally {
			// int count = ntbLoanDao.insertPanValidationDetails(mobileNumber, payload,
			// plainRes, "PanValidationAPI",
			// apiStatus);
		}
		return plainRes;
	}

	public JSONObject processPosidexAddressMatchApiRequest(String payload, String url, String scope,
			String mobileNumber, String tranRefNo) throws Exception {
		JSONObject plainRes = new JSONObject();
		String apiStatus = "", serviceResponse = "";
		String creationTime = "";
		String updationTime = "";

		try {
			Long timeStamp = Instant.now().toEpochMilli();
			logger.info("plain payload :" + payload);
			String finalRePayload = jsonrequestGenerator.generatePanValidationRequest(payload, scope.trim(),
					timeStamp.toString());
			logger.info("final request payload processPosidexNameMatchApiRequest==:" + finalRePayload);

			creationTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").format(Calendar.getInstance().getTime());
			serviceResponse = apiServiceCall(url, finalRePayload, NAMEMATCHAPIKEY.trim());
			logger.info("service response processPosidexNameMatchApi=====:" + serviceResponse);
			updationTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").format(Calendar.getInstance().getTime());

			if (null != serviceResponse) {
				PanValidationJsonResponse jsonResponse = new JsonResponseReader().panRead(serviceResponse);

				String status = jsonResponse.getStatus();

				if (status.equalsIgnoreCase("SUCCESS")) {
					apiStatus = "Success";
					plainRes = decrpytAddressMatchResponsePayload(jsonResponse, mobileNumber, tranRefNo, payload,
							creationTime, updationTime);
					return plainRes;
				}
			}
		} catch (Exception e) {
			logger.info("Exception :: " + CommonUtility.getPrintStackTrace(e));
			apiStatus = "Failure";
		} finally {

		}
		return plainRes;
	}

	public JSONObject decrpytAddressMatchResponsePayload(PanValidationJsonResponse jsonResponse, String mobileNumber,
			String tranRefNo, String payload, String creationTime, String updationTime) {
		JSONObject jsonObject = new JSONObject();
		String response = "", apiStatus = "failure";
		try {
			String encryptedData = jsonResponse.getGWSymmetricKeyEncryptedValue();
			Base64EncoderDecoder encoder = new Base64EncoderDecoder();
			RSAEncrypterDecrypter rsaEncrypterDecrypter = new RSAEncrypterDecrypter();
			byte[] decoded = encoder.decode(encryptedData.getBytes());
			byte[] decryptedData = rsaEncrypterDecrypter.decrypt(decoded,
					DigitalSignature.privateKey(pfxPath, pfxPassword));
			// logger.info("decrptyed data :" + new String(decryptedData));

			AESEncrypterDecrypter encrypterDecrypter = new AESEncrypterDecrypter();
			String encryptedValue = jsonResponse.getResponseEncryptedValue();
			byte[] decryptedValue = encrypterDecrypter.decrypt(encoder.decode(encryptedValue.getBytes()),
					decryptedData);
			logger.info("decrptyed Address final  :" + new String(decryptedValue));
			response = new String(decryptedValue);
			updationTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").format(Calendar.getInstance().getTime());
			org.json.JSONObject xmlTojsonObject = new org.json.JSONObject();
			xmlTojsonObject = XML.toJSONObject(response);
			String responseErrorCode = StringUtils.substringBetween(response, "<responseservice:errorCode>",
					"</responseservice:errorCode>");
			if (responseErrorCode.equalsIgnoreCase("0")) {
				apiStatus = "success";
			}
			String addressPercentage = StringUtils.substringBetween(response, "<addressPercentage>",
					"</addressPercentage>");
			// System.out.println("Lead_Number :"+leadNumber);
			jsonObject.put("responseErrorCode", responseErrorCode);
			jsonObject.put("addressPercentage", addressPercentage);
			// jsonObject.put("PanValidationResponse", xmlTojsonObject);

			redisUtils.set(RedisConstants.NTB_ADDRESS_MATCH + mobileNumber + RedisConstants.US + tranRefNo, response);
			// logger.info("NTB_NAME_MATCH_ ::" + cluster.get("NTB_NAME_MATCH_" +
			// mobileNumber + "_" + tranRefNo));
		} catch (Exception e) {
			apiStatus = "Server Error";
			logger.info("Exception :: " + CommonUtility.getPrintStackTrace(e));
		} finally {
		}
		return jsonObject;
	}

	public String processLeadInstaStatusApiGateWayRequest(String payload, String url) throws Exception {
		// JSONObject plainRes = new JSONObject();
		String plainRes = "";
		try {

			logger.info("plain payload :" + payload);

			// String tranRefNo = commonUtility.generateRandomNo(9);
			String tranRefNo = commonUtility.genRandomNumber(12);
			String finalRePayload = jsonrequestGenerator.generateLeadStatusRequest(payload, LEADINSTA_SCOPE, tranRefNo);

			logger.info("final request payload generateLeadInstaRequest==: " + finalRePayload);

			String serviceResponse = leadInstServiceCall(url, finalRePayload);

			logger.info("service response :" + serviceResponse);
			if (null != serviceResponse) {
				LeadStatusJsonResponse jsonResponse = new JsonResponseReader().leadRead(serviceResponse);
				String status = jsonResponse.getStatus();

				if (status.equalsIgnoreCase("SUCCESS")) {
					plainRes = decrpytLeadStatusResponsePayload(jsonResponse);
					return plainRes;
				}
			}

		} catch (Exception e) {
			logger.info("Exception :: " + CommonUtility.getPrintStackTrace(e));
		}
		return plainRes;
	}

	public String processIMPSApiRequestHigh(String payload, String url) throws Exception {
		JSONObject plainRes = new JSONObject();
		try {

			String signedPayload = new XMLDigitalSignature().sign(payload, impsKeyStoreFilePath, impsKeyStorePassword,
					impsKeyAlias, pfxPath, pfxPassword);

			logger.info("processIMPSApiRequest final request : " + signedPayload);

			String tranRefNo = commonUtility.genRandomNumber(12);

			String finalRePayload = jsonrequestGenerator.generateIMPSRequestHigh(signedPayload, IMPS_API_SCOPE,
					tranRefNo);

			logger.info("processIMPSApiRequest final request payload :" + finalRePayload);

			String serviceResponse = impsServiceCall(url, finalRePayload);
			logger.info("processIMPSApiRequest service response :" + serviceResponse);
			if (null != serviceResponse) {
				JsonResponse jsonResponse = new JsonResponseReader().read(serviceResponse);

				String status = jsonResponse.getStatus();

				/*
				 * if (status.equalsIgnoreCase("SUCCESS")) { return
				 * decrpytResponseXmlPayload(jsonResponse); } else { return
				 * decrpytResponseXmlPayload(jsonResponse); }
				 */
				return decrpytResponseXmlPayload(jsonResponse);
			}
		} catch (Exception e) {
			logger.info("Exception :: " + CommonUtility.getPrintStackTrace(e));
		}
		return "";
	}

	public String impsServiceCall(String url, String requestpayload) throws Exception {
		String response = "";
		try {

			CloseableHttpClient httpClient = createHttpClient();

			HttpPost httpPost = new HttpPost(url);
			StringEntity entity = new StringEntity(requestpayload);
			httpPost.setEntity(entity);
			httpPost.setHeader("Accept", "application/json");
			httpPost.setHeader("Content-type", "application/json");
			httpPost.setHeader("apikey", IMPS_API_KEY);

			CloseableHttpResponse httpResponse = httpClient.execute(httpPost);
			logger.info("impsServiceCall httpResponse :" + httpResponse);
			int status = httpResponse.getStatusLine().getStatusCode();
			loggerUtils.setHttpStatusCode(status);
			logger.info("impsServiceCall httpResponse status code:" + status);

			HttpEntity entity2 = httpResponse.getEntity();

			response = EntityUtils.toString(entity2);
			logger.info("impsServiceCall resposne :" + response);
			return response;
		} catch (Exception e) {
			logger.info("Exception :: " + CommonUtility.getPrintStackTrace(e));
		}
		return response;

	}

	public String processIMPSApiRequestLow(String payload, String url) throws Exception {
		String plainRes = "";
		try {

			String tranRefNo = commonUtility.genRandomNumber(12);
			String finalRePayload = jsonrequestGenerator.generateIMPSRequestLow(payload, IMPS_API_SCOPE, tranRefNo);

			logger.info("finalRePayload processIMPSApiRequestLow :: " + finalRePayload);

			String serviceResponse = impsServiceCall(url, finalRePayload);

			logger.info("serviceResponse processIMPSApiRequestLow :: " + serviceResponse);
			if (null != serviceResponse) {
				LeadStatusJsonResponse jsonResponse = new JsonResponseReader().leadRead(serviceResponse);
				String status = jsonResponse.getStatus();
                log.info("payload status {}",status);

				if (status.equalsIgnoreCase("SUCCESS")) {
					plainRes = decrpytLeadStatusResponsePayload(jsonResponse);
					return plainRes;
				} else {
					return serviceResponse;
				}
			}

		} catch (Exception e) {
			logger.info("Exception :: " + CommonUtility.getPrintStackTrace(e));
		}
		return plainRes;
	}

	public String decrpytVCIPResponsePayload(VcipJsonRequest jsonRequest) {
		JSONObject jsonObject = new JSONObject();
		String response = "";
		try {
			String encryptedData = jsonRequest.getSymmetricKeyEncryptedValue();
			Base64EncoderDecoder encoder = new Base64EncoderDecoder();
			RSAEncrypterDecrypter rsaEncrypterDecrypter = new RSAEncrypterDecrypter();
			byte[] decoded = encoder.decode(encryptedData.getBytes());
			byte[] decryptedData = rsaEncrypterDecrypter.decrypt(decoded,
					DigitalSignature.privateKey(pfxPath, pfxPassword));
			logger.info("decrpytVCIPResponsePayload decrptyed data :" + new String(decryptedData));
			AESEncrypterDecrypter encrypterDecrypter = new AESEncrypterDecrypter();
			String encryptedValue = jsonRequest.getRequestEncryptedValue();
			byte[] decryptedValue = encrypterDecrypter.decrypt(encoder.decode(encryptedValue.getBytes()),
					decryptedData);
			logger.debug("decrpytVCIPResponsePayload decrptyed data final  :" + new String(decryptedValue));
			response = new String(decryptedValue);

		} catch (Exception e) {
			logger.info("Exception :: " + CommonUtility.getPrintStackTrace(e));
			logger.info("decrpytVCIPResponsePayload :: Exception " + CommonUtility.getPrintStackTrace(e));
		}
		return response;
	}

	public String processApiMedService(String plainReqPayload, String apiUrl, String apiKey, String scope,
			String serviceName, String referenceNumber) throws Exception {
		logger.info("processApiMedService :: ");
		String plainRes = "";
		try {
			String transactionId = CommonUtility.getDate(AppConstants.YYYY_MM_dd_THH_mm_ss_SSSXXX);
			String encryptReqPayload = jsonrequestGenerator.generateApiMedRequest(plainReqPayload, scope,
					transactionId);
			String serviceResponse = apiServiceCall(apiUrl, encryptReqPayload, apiKey);
			if (StringUtils.isNotBlank(serviceResponse)) {
				MedEncryptJsonResponse jsonResponse = new JsonResponseReader().medJsonRead(serviceResponse);
				String status = jsonResponse.getStatus();
                log.info("payload status {}",status);

				if (status.equalsIgnoreCase("SUCCESS")) {
					plainRes = decrpytApiMedResponse(jsonResponse);
					return plainRes;
				} else {
					plainRes = decrpytApiMedResponse(jsonResponse);
					logger.info("processApiMedService :: serviceName :: " + serviceName + " referenceNumber :: "
							+ referenceNumber + " plainRes:: " + plainRes);
				}
			} else {
				logger.info("processApiMedService :: serviceName :: " + serviceName + " referenceNumber :: "
						+ referenceNumber + " serviceResponse:: " + serviceResponse);
			}
		} catch (Exception e) {
			logger.info("Exception :: " + CommonUtility.getPrintStackTrace(e));
			logger.info("processApiService Exception :: serviceName :: " + serviceName + " "
					+ CommonUtility.getPrintStackTrace(e));
		}
		return plainRes;
	}

	public String restHunterXMLPostMethodAPI(String baseUrl, String reqStr, String operationType, String mobileNo,
			String tranRefNumber) {
		logger.info("restPostMethodAPI :: ");
		HttpURLConnection conn = null;
		StringBuilder response = new StringBuilder();
		BufferedReader in = null;
		OutputStream out = null;
		// String soapAction = "";
		logger.info("baseUrl :: " + baseUrl);
		logger.info("request :: " + reqStr);
		String jsonResponse = "", apiStatus = "Failure";
		String creationTime = "", updationTime = "";

		try {

			try {
				trustAllHttpsCertificates();
			} catch (Exception e) {
				e.printStackTrace();
				logger.info("restPostMethodAPI exception :: " + e);
			}
			creationTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").format(Calendar.getInstance().getTime());

			URL obj = new URL(baseUrl);
			conn = (HttpURLConnection) obj.openConnection();
			ByteArrayOutputStream bout = new ByteArrayOutputStream();
			byte[] buffer = new byte[reqStr.length()];
			buffer = reqStr.getBytes();
			bout.write(buffer);
			byte[] b = bout.toByteArray();

			conn.setRequestProperty("Content-Type", "text/xml");
			conn.setRequestMethod("POST");
			conn.setConnectTimeout(60000);
			conn.setReadTimeout(90000);
			conn.setDoOutput(true);
			conn.setDoInput(true);

			out = conn.getOutputStream();
			out.write(b);
			out.flush();
			out.close();
			int responseCode = conn.getResponseCode();
			loggerUtils.setHttpStatusCode(responseCode);
			String jsonString = conn.getResponseMessage();
			logger.info("response code from server :" + responseCode);
			logger.info("response message code from server :" + jsonString);
			updationTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").format(Calendar.getInstance().getTime());
			if (responseCode == 200) {
				apiStatus = "Success";
				loggerUtils.setPayloadStatus(apiStatus);
				in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
				String inputLine;

				while ((inputLine = in.readLine()) != null) {
					response.append(inputLine);
				}
				in.close();
				logger.info("response :: " + response);
				jsonResponse = response.toString();
			} else {
				apiStatus = "Failure";
				BufferedReader reader = null;
				reader = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
				logger.info("error stream :" + reader.read());
				JSONObject failRespObj = new JSONObject();
				failRespObj.put("responseCode", responseCode);
				failRespObj.put("responseMessage", jsonString);
				failRespObj.put("errorStream", reader);
				jsonResponse = failRespObj.toString();
			}

			logger.info("jsonResponse :: " + jsonResponse);
		} catch (Exception e) {
			e.printStackTrace();
			apiStatus = "Failure";
			logger.info("exception :: " + e);
		} finally {
			if (null != conn)
				conn.disconnect();
			conn = null;
			in = null;
		}
		logger.info("Rest service Server end  Time...:" + new java.util.Date());

		return jsonResponse;

	}

	private static void trustAllHttpsCertificates() throws Exception {
		logger.info("trustAllHttpsCertificates :: ");

		// Create a trust manager that does not validate certificate chains:
		

		javax.net.ssl.TrustManager[] trustAllCerts = new javax.net.ssl.TrustManager[1];

		javax.net.ssl.TrustManager tm = new TempTrustedManager();

		trustAllCerts[0] = tm;

		javax.net.ssl.SSLContext sc =  new OpenBankApiConnector().BLELloadSSLContext();
//				javax.net.ssl.SSLContext.getInstance("SSL");
//		sc.init(null, trustAllCerts, new SecureRandom());
//		SSLParameters parameters = sc.getDefaultSSLParameters();
//
//		String rr[] = parameters.getProtocols();
//
//		for (int i = 0; i < rr.length; i++) {
//			// logger.info("Supported ssl params :" + rr[i]);
//		}

		javax.net.ssl.HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
		
	}

	public static class TempTrustedManager implements javax.net.ssl.TrustManager, javax.net.ssl.X509TrustManager {
		public java.security.cert.X509Certificate[] getAcceptedIssuers() {
			return null;
		}

		public boolean isServerTrusted(java.security.cert.X509Certificate[] certs) {
			return true;
		}

		public boolean isClientTrusted(java.security.cert.X509Certificate[] certs) {
			return true;
		}

		public void checkServerTrusted(java.security.cert.X509Certificate[] certs, String authType)
				throws java.security.cert.CertificateException {
			return;
		}

		public void checkClientTrusted(java.security.cert.X509Certificate[] certs, String authType)
				throws java.security.cert.CertificateException {
			return;
		}
	}

	public String decrpytApiMedResponse(MedEncryptJsonResponse jsonResponse) {
		String response = "";
		try {
			String encryptedData = jsonResponse.getGWSymmetricKeyEncryptedValue();
			Base64EncoderDecoder encoder = new Base64EncoderDecoder();
			RSAEncrypterDecrypter rsaEncrypterDecrypter = new RSAEncrypterDecrypter();
			byte[] decoded = encoder.decode(encryptedData.getBytes());
			byte[] decryptedData = rsaEncrypterDecrypter.decrypt(decoded,
					DigitalSignature.privateKey(pfxPath, pfxPassword));

			AESEncrypterDecrypter encrypterDecrypter = new AESEncrypterDecrypter();
			String encryptedValue = jsonResponse.getResponseEncryptedValue();
			byte[] decryptedValue = encrypterDecrypter.decrypt(encoder.decode(encryptedValue.getBytes()),
					decryptedData);
			response = new String(decryptedValue);
		} catch (Exception e) {
			logger.info("Exception :: " + CommonUtility.getPrintStackTrace(e));
		}
		return response;
	}
public static void main(String[] args) {
	Base64EncoderDecoder encoder = new Base64EncoderDecoder();
	String res = "eyJwMjdfbm9kZSI6NDIsInAyN19iYW5kIjoiYjIiLCJpcGFfYmFuZCI6IlJlZCIsImlwYV9lbGlnaWJpbGl0eV9hbW91bnQiOjAsInN0cF9mYWlsX3JlYXNvbiI6W3sicmVhc29uXzEiOiJ-RlROUl9QQVNTX0ZMQUc9RlROUl8xIn1dLCJicmUyY193b3JrZmxvd19zdGF0dXMiOlt7InN0cF9ub25zdHAiOiJub25zdHAiLCJoYXJkcmVqZWN0Ijoibm8iLCJvZmZlcl90eXBlIjoibWFya2V0aW5nIn0seyJzdHBfbm9uc3RwIjoic3RwIiwiaGFyZHJlamVjdCI6Im51bGwiLCJvZmZlcl90eXBlIjoibnVsbCJ9XSwiYnJlMmNfc3RwX29mZmVyX2FtdCI6W3sidGVudXJlIjowLCJvZmZlcl9hbW91bnQiOjB9XSwiYnJlMmNfc3RwX2lyciI6W3sidGVudXJlIjowLCJpcnIiOjB9XSwiYnJlMmNfc3RwX3Byb2NmZWVwZXIiOlt7InRlbnVyZSI6MCwicHJvY2ZlZXBlciI6MH1dLCJicmUyY19ub25zdHBfb2ZmZXJfYW10IjpbeyJ0ZW51cmUiOjEyLCJvZmZlcl9hbW91bnQiOjMyMDAwMH0seyJ0ZW51cmUiOjI0LCJvZmZlcl9hbW91bnQiOjU4ODAwMH0seyJ0ZW51cmUiOjM2LCJvZmZlcl9hbW91bnQiOjgxMjAwMH0seyJ0ZW51cmUiOjQ4LCJvZmZlcl9hbW91bnQiOjEwMDAwMDB9XSwiYnJlMmNfbm9uc3RwX2lyciI6W3sidGVudXJlIjoxMiwiaXJyIjowLjE4fSx7InRlbnVyZSI6MjQsImlyciI6MC4xNH0seyJ0ZW51cmUiOjM2LCJpcnIiOjAuMTIyNX0seyJ0ZW51cmUiOjQ4LCJpcnIiOjAuMTJ9XSwiYnJlMmNfbm9uc3RwX3Byb2NmZWVwZXIiOlt7InRlbnVyZSI6MTIsInByb2NmZWVwZXIiOjAuMDJ9LHsidGVudXJlIjoyNCwicHJvY2ZlZXBlciI6MC4wMn0seyJ0ZW51cmUiOjM2LCJwcm9jZmVlcGVyIjowLjAyfSx7InRlbnVyZSI6NDgsInByb2NmZWVwZXIiOjAuMDJ9XSwiYnJlMmNfZmFpbGVkX3JlYXNvbiI6bnVsbCwic3RhdHVzIjoyMDAsIm1lc3NhZ2UiOiJTdWNjZXNzIn0";
	
	System.out.println("ddd :"+new String(org.apache.commons.codec.binary.Base64.decodeBase64 (res.getBytes(Charset.forName("UTF-8")))));
}
}
