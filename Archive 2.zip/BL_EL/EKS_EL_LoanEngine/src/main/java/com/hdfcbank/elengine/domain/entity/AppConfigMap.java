package com.hdfcbank.elengine.domain.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Table(name = "el_app_configmap")
@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class AppConfigMap {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id", unique = true, nullable = false)
	private Integer uid;
	
	@Column(name =  "channelid")
	private String channelid;
	
	@Column(name = "dataname")
	private String dataname;
	
	@Column(name = "datakey")
	private String datakey;
	
	@Column(name = "datavalue")
	private String datavalue;
	
	@Column(name = "isactive")
	private String isactive;
	
	
}
