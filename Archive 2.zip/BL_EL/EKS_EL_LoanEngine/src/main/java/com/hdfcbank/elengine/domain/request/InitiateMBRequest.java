package com.hdfcbank.elengine.domain.request;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@Data
@NoArgsConstructor
@AllArgsConstructor
public class InitiateMBRequest {
	@NotBlank(message = "name may not be blank")
	@Pattern(regexp = "^[a-zA-Z ]*$",message = "enter proper name")
	private String name;
	@NotBlank(message = "gender may not be blank")
	@Pattern(regexp = "^[a-zA-Z]*$",message = "enter proper gender")
	private String gender;
	@NotBlank(message = "age may not be blank")
	@Pattern(regexp = "\\d+",message = "enter proper age")
	private String age;
	@NotBlank(message = "dob may not be blank")
	@Pattern(regexp = "\\d+",message = "enter proper dob")
	private String dob;
	@NotBlank(message = "address may not be blank")
	@Pattern(regexp = "^[a-zA-Z0-9, ]*$",message = "enter proper address")
	private String address;
	@NotBlank(message = "city may not be blank")
	@Pattern(regexp = "^[a-zA-Z]*$",message = "enter proper city")
	private String city;
	@NotBlank(message = "pincode may not be blank")
	@Pattern(regexp = "\\d+",message = "enter proper pincode")
	private String pin;
	@NotBlank(message = "state may not be blank")
	@Pattern(regexp = "^[a-zA-Z]*$",message = "enter proper state")
	private String state;
	@NotBlank(message = "pan number may not be blank")
	@Pattern(regexp = "^[a-zA-Z0-9]*$",message = "enter proper panNumber")
	private String panNumber;
	@NotBlank(message = "mobile number may not be blank")
	@Pattern(regexp="(^$|[0-9]{10})",message = "mobile number must be 10 digit")
	private String mobileNumber;

	@NotBlank(message = "transaction reference number may not be blank")
	@Pattern(regexp = "\\d+",message = "enter proper tranRefNumber")
	private String tranRefNumber;

	@NotBlank(message = "productCode may not be blank")
	@Pattern(regexp = "^[a-zA-Z]*$",message = "enter proper productCode")
	private String productCode;

	@NotBlank(message = "customerID may not be blank")
	@Pattern(regexp = "\\d+",message = "enter proper customerId")
	private String customerId;

	@Pattern(regexp = "\\d+",message = "enter proper partnerJourneyId")
	private String partnerJourneyId;
}
