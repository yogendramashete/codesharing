package com.hdfcbank.elengine.domain.request;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "perfiosTxnId", "ackId", "productCode","mobileNumber" })
@AllArgsConstructor
@NoArgsConstructor
@Data
public class InitIncomeOffer {

	@JsonProperty("perfiosTxnId")
	public String perfiosTxnId;
	@JsonProperty("ackId")
	public String ackId;
	@JsonProperty("productCode")
	public String productCode;
	@JsonProperty("mobileNumber")
	public String mobileNumber;
	@JsonProperty("pqgcOffer")
	public String pqgcOffer;

}