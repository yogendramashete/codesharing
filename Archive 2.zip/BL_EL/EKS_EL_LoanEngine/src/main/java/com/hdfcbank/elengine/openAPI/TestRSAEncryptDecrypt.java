package com.hdfcbank.elengine.openAPI;

import java.io.FileInputStream;
import java.security.KeyFactory;
import java.security.KeyStore;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;


public class TestRSAEncryptDecrypt /* extends TestCase */ {
	private static final String KEY_STORE_FILE_PATH = 
//			"C:/Program Files/Java/jre1.8.0_51/lib/security/cacerts"; 
			"D:/hdfcautocircle/openapiuat.hdfcbank.com_updated/openapiuat.hdfcbank.com/snapjks";
	private static final String KEYSTORE_PWD = "snap1234";
	private static final String KEYSTORE_ALIAS = "snapjks";
	
	public void testEncryptDecrypt() throws Exception {		
		String value = "Hello World. This is a very very long content. This is used to test RSA encryption and decryption. You are running a JUnit test case. ";
		
		KeyStore ks = KeyStore.getInstance("JKS");
		ks.load(new FileInputStream(KEY_STORE_FILE_PATH), KEYSTORE_PWD.toCharArray());			
		KeyStore.PrivateKeyEntry privateKeyEntry = (KeyStore.PrivateKeyEntry) ks.getEntry(KEYSTORE_ALIAS, new KeyStore.PasswordProtection(KEYSTORE_PWD.toCharArray()));
		
		//get certificate
		X509Certificate certificate = (X509Certificate) privateKeyEntry.getCertificate();

		RSAEncrypterDecrypter rsaEncrypterDecrypter = new RSAEncrypterDecrypter();
		byte[] encryptedData = rsaEncrypterDecrypter.encrypt(value.getBytes(), certificate.getPublicKey());
		
		byte[] decryptedData = rsaEncrypterDecrypter.decrypt(encryptedData, privateKeyEntry.getPrivateKey());
		
	}
	
	public void testEncryptDecryptRandom() throws Exception {
		byte[] randomData = new byte[32];
		SecureRandom random = new SecureRandom();
		random.nextBytes(randomData);
		
		KeyStore ks = KeyStore.getInstance("JKS");
		ks.load(new FileInputStream(KEY_STORE_FILE_PATH), KEYSTORE_PWD.toCharArray());			
		KeyStore.PrivateKeyEntry privateKeyEntry = (KeyStore.PrivateKeyEntry) ks.getEntry(KEYSTORE_ALIAS, new KeyStore.PasswordProtection(KEYSTORE_PWD.toCharArray()));
		
		//get certificate
		X509Certificate certificate = (X509Certificate) privateKeyEntry.getCertificate();

		RSAEncrypterDecrypter rsaEncrypterDecrypter = new RSAEncrypterDecrypter();
		byte[] encryptedData = rsaEncrypterDecrypter.encrypt(randomData, certificate.getPublicKey());
		
		Base64EncoderDecoder encoder = new Base64EncoderDecoder();
		String encoded = new String(encoder.encode(encryptedData));
		//Logger.info(encoded);
		
		byte[] decoded = encoder.decode(encoded.getBytes());
		
		byte[] decryptedData = rsaEncrypterDecrypter.decrypt(decoded, privateKeyEntry.getPrivateKey());

	}
	
	public void testDecryptEncoded() throws Exception {
		String encodedValue = "iEYOc74h+yFlmWREnxh6I+1xz4ME/J/qvSbaLm6TgUbhLB7JzbNuy8k0dm79RCfduRKSI35ttMMuxruwLTaiavLOj3SbO/Iu/LzP4Sh/JkDJBN1wJiOLVCamNe0DKM9YPb8TzS8GyNIbN3cKcu+n2EdUU9ThmsMxeoHDF9BrrZv//Rexz3hSuNHC2V8I3o0G+GfuRoaIzpDvANyR5raTAehUmVcUkyNxhXndntyvxlynk1XzlBwWcYDo8ycLf5gKFXnrjXuFYGATs8TTLYLJI/oP0ZgKQDbYJkUMGfr/e4lIhSajV4jVLHQJesecB+hg+1RXWsV9P6z+dAjpe1sMSQ==";
		Base64EncoderDecoder decoder = new Base64EncoderDecoder();
		byte[] decoded = decoder.decode(encodedValue.getBytes());
		//Logger.info(decoded.length);

		KeyStore ks = KeyStore.getInstance("JKS");
		ks.load(new FileInputStream(KEY_STORE_FILE_PATH), KEYSTORE_PWD.toCharArray());			
		KeyStore.PrivateKeyEntry privateKeyEntry = (KeyStore.PrivateKeyEntry) ks.getEntry(KEYSTORE_ALIAS, new KeyStore.PasswordProtection(KEYSTORE_PWD.toCharArray()));
		
		//get certificate
		X509Certificate certificate = (X509Certificate) privateKeyEntry.getCertificate();
		RSAEncrypterDecrypter rsaEncrypterDecrypter = new RSAEncrypterDecrypter();
		byte[] decryptedData = rsaEncrypterDecrypter.decrypt(decoded, privateKeyEntry.getPrivateKey());
		assert(decryptedData.length > 0);
	}

	public static PublicKey getPublicKey(String base64PublicKey){
        PublicKey publicKey = null;
        try{
            X509EncodedKeySpec keySpec = new X509EncodedKeySpec(Base64.getDecoder().decode(base64PublicKey.getBytes()));
            KeyFactory keyFactory = KeyFactory.getInstance("RSA");
            publicKey = keyFactory.generatePublic(keySpec);
            return publicKey;
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (InvalidKeySpecException e) {
            e.printStackTrace();
        }
        return publicKey;
    }
	
	
	
//public static void main(String[] args) throws Exception {
//
//	KeyStore ks = KeyStore.getInstance("JKS");
//	ks.load(new FileInputStream("D:/hdfcautocircle/openapiuat.hdfcbank.com_updated/openapiuat.hdfcbank.com/snapjks2"), KEYSTORE_PWD.toCharArray());			
//	KeyStore.PrivateKeyEntry privateKeyEntry = (KeyStore.PrivateKeyEntry) ks.getEntry("snapjks2", new KeyStore.PasswordProtection(KEYSTORE_PWD.toCharArray()));
////	Logger.info("private key entry :"+privateKeyEntry);
//	/*
//	 * FileInputStream fin = new FileInputStream(
//	 * "D:\\hdfcautocircle\\openapiuat.hdfcbank.com_updated\\openapiuat.hdfcbank.com\\openapiuat_hdfcbank_com.cer"
//	 * ); CertificateFactory f = CertificateFactory.getInstance("X.509");
//	 * X509Certificate certificate = (X509Certificate)f.generateCertificate(fin);
//	 * PublicKey pk = certificate.getPublicKey(); RSAEncrypterDecrypter
//	 * rsaEncrypterDecrypter = new RSAEncrypterDecrypter(); byte[] encryptedData =
//	 * rsaEncrypterDecrypter.encrypt("hello world".getBytes(), pk);
//	 * Base64EncoderDecoder encoder = new Base64EncoderDecoder(); String encoded =
//	 * new String(encoder.encode(encryptedData)); Logger.info(encoded);
//	 */
////	new TestRSAEncryptDecrypt().testEncryptDecrypt();
//}
}
