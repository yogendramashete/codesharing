package com.hdfcbank.elengine.domain.enums;

public enum PosidexDedupeServiceType {
  PosidexIn,PosidexPublish,PosidexOut
}
