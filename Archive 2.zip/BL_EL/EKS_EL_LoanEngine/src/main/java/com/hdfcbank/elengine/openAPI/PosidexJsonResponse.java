package com.hdfcbank.elengine.openAPI;

/**
 * Json Response
 * @author Madhura Oak
 *
 */
public class PosidexJsonResponse {
	private String ResponseEncryptedValue;
	private String GWSymmetricKeyEncryptedValue;
	private String Source;
	private String TransactionId;
	private String Status;
	public String getResponseEncryptedValue() {
		return ResponseEncryptedValue;
	}
	public void setResponseEncryptedValue(String responseEncryptedValue) {
		ResponseEncryptedValue = responseEncryptedValue;
	}
	public String getGWSymmetricKeyEncryptedValue() {
		return GWSymmetricKeyEncryptedValue;
	}
	public void setGWSymmetricKeyEncryptedValue(String gWSymmetricKeyEncryptedValue) {
		GWSymmetricKeyEncryptedValue = gWSymmetricKeyEncryptedValue;
	}
	public String getSource() {
		return Source;
	}
	public void setSource(String source) {
		Source = source;
	}
	public String getTransactionId() {
		return TransactionId;
	}
	public void setTransactionId(String transactionId) {
		TransactionId = transactionId;
	}
	public String getStatus() {
		return Status;
	}
	public void setStatus(String status) {
		Status = status;
	}
	
	}
