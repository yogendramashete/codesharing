package com.hdfcbank.elengine.openAPI;

/**
 * Json Request
 * @author Madhura Oak
 *
 */
public class CrmJsonRequest {
	private String RequestEncryptedValue;
	private String RequestDigitalSignatureValue;
	private String SessionEncryptedValue;
	private String SessionDigitalSignatureValue;
	private String Source;
	private String TransactionId;
	private String OAuthTokenValue;
	public String getRequestEncryptedValue() {
		return RequestEncryptedValue;
	}
	public void setRequestEncryptedValue(String requestEncryptedValue) {
		RequestEncryptedValue = requestEncryptedValue;
	}
	public String getRequestDigitalSignatureValue() {
		return RequestDigitalSignatureValue;
	}
	public void setRequestDigitalSignatureValue(String requestDigitalSignatureValue) {
		RequestDigitalSignatureValue = requestDigitalSignatureValue;
	}
	public String getSessionEncryptedValue() {
		return SessionEncryptedValue;
	}
	public void setSessionEncryptedValue(String sessionEncryptedValue) {
		SessionEncryptedValue = sessionEncryptedValue;
	}
	public String getSessionDigitalSignatureValue() {
		return SessionDigitalSignatureValue;
	}
	public void setSessionDigitalSignatureValue(String sessionDigitalSignatureValue) {
		SessionDigitalSignatureValue = sessionDigitalSignatureValue;
	}
	 
	public String getTransactionId() {
		return TransactionId;
	}
	public String getSource() {
		return Source;
	}
	public void setSource(String source) {
		Source = source;
	}
	public void setTransactionId(String transactionId) {
		TransactionId = transactionId;
	}
	public String getOAuthTokenValue() {
		return OAuthTokenValue;
	}
	public void setOAuthTokenValue(String oAuthTokenValue) {
		OAuthTokenValue = oAuthTokenValue;
	}	

 
}
