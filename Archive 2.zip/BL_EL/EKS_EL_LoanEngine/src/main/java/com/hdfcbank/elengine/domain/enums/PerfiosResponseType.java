package com.hdfcbank.elengine.domain.enums;

public enum PerfiosResponseType {
    txn_status, Retreive_data;
}
