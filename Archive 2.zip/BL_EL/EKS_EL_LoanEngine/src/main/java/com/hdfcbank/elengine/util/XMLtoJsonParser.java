package com.hdfcbank.elengine.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;

import org.apache.commons.lang3.StringUtils;
import org.json.JSONObject;
import org.json.XML;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hdfcbank.elengine.domain.enums.EmploymentType;
import com.hdfcbank.elengine.domain.response.bre.BlResponse;
import com.hdfcbank.elengine.domain.response.bre.blbre1b.BlBre1bResponse;
import com.hdfcbank.elengine.domain.response.bre.blbre2b.BlBre2bResponse;
import com.hdfcbank.elengine.domain.response.bre.ftnr.FtnrResponse;
import com.hdfcbank.elengine.domain.response.hunter.HunterResponse;
import com.hdfcbank.elengine.domain.response.mb.callback.cibil.CibilSropDomainList;
import com.hdfcbank.elengine.domain.response.mb.callback.cibil.MbCibilResponse;
import com.hdfcbank.elengine.domain.response.mb.callback.crfhighmark.ChmBaseSropDomain;
import com.hdfcbank.elengine.domain.response.mb.callback.crfhighmark.ChmBaseSropDomainList1;
import com.hdfcbank.elengine.domain.response.mb.callback.crfhighmark.MbCrfHighMarkResponse;
import com.hdfcbank.elengine.domain.response.mb.callback.eot.MbEotResponse;
import com.hdfcbank.elengine.domain.response.mb.callback.eot.MultiBureauEoTRequest;
import com.hdfcbank.elengine.domain.response.mb.callback.eot.success.MBEOTSuccessResponse;
import com.hdfcbank.elengine.domain.response.mb.callback.eot.success.MBEoTRequestType;
import com.hdfcbank.elengine.domain.response.mb.callback.equifax.EquifaxSropDomain;
import com.hdfcbank.elengine.domain.response.mb.callback.equifax.MbEquifaxResponse;
import com.hdfcbank.elengine.domain.response.mb.callback.mergedscore.MbMergedScoreResponse;
import com.hdfcbank.elengine.domain.response.mb.callback.mergedscore.MergedSropDomain;
import com.hdfcbank.elengine.domain.response.perfios.PIRData;
import com.hdfcbank.elengine.domain.response.perfios.PerfiosResponse;
import com.hdfcbank.elengine.domain.response.perfios.sme.PerfiosSmeResponse;
import com.hdfcbank.elengine.domain.response.perfios.txnstatus.Part;
import com.hdfcbank.elengine.domain.response.perfios.txnstatus.PerfiosTxnStatusResponse;
import com.hdfcbank.elengine.domain.response.perfios.txnstatus.Status;
import com.hdfcbank.elengine.domain.response.posidexdedupe.PosidexOutData;
import com.hdfcbank.elengine.domain.response.posidexdedupe.PosidexOutResponse;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class XMLtoJsonParser {
	@Autowired
	ObjectMapper objectMapper;

	public PosidexOutData[] parsePosidexOutput(String responseObj) {
		if (StringUtils.isBlank(responseObj)) {
			return null;
		}
		try {
			JSONObject jsonObj = XML.toJSONObject(responseObj);
			PosidexOutResponse posidexOutResponse = objectMapper
					.enable(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY)
					.readValue(jsonObj.toString(), PosidexOutResponse.class);
			PosidexOutData[] outBody = posidexOutResponse.getEnvelope().getBody().getOutputResponse().getOutputData();
			return outBody;
		} catch (Exception e) {
			log.error("parsePosidexOutput parsing exe {}", e);
		}
		return null;
	}

	public CibilSropDomainList[] parseCibilResponse(String responseObj)
			throws JsonMappingException, JsonProcessingException {
		if (StringUtils.isBlank(responseObj)) {
			return null;
		}
		JSONObject jsonObj = XML.toJSONObject(responseObj);
		MbCibilResponse mbCibilResponse = objectMapper.enable(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY)
				.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false)
				.configure(DeserializationFeature.READ_UNKNOWN_ENUM_VALUES_AS_NULL, true)
				.configure(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT, true)
				.readValue(jsonObj.toString(), MbCibilResponse.class);
		if (mbCibilResponse.getSoapenvEnvelope().getSoapenvBody().getMultiBureauResponse().getResponse()
				.getFinished() != null) {
			CibilSropDomainList[] sropDomainLists = mbCibilResponse.getSoapenvEnvelope().getSoapenvBody()
					.getMultiBureauResponse().getResponse().getFinished().getJsonResponseObject()
					.getCibilSropDomainList();
			return sropDomainLists;
		}
		return null;
	}

	public EquifaxSropDomain[] parseEquifaxResponse(String responseObj)
			throws JsonMappingException, JsonProcessingException {
		if (StringUtils.isNotBlank(responseObj)) {
			JSONObject jsonObj = XML.toJSONObject(responseObj);
			MbEquifaxResponse mbEquifaxResponse = objectMapper
					.enable(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY)
					.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false)
					.configure(DeserializationFeature.READ_UNKNOWN_ENUM_VALUES_AS_NULL, true)
					.configure(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT, true)
					.readValue(jsonObj.toString(), MbEquifaxResponse.class);
			if (mbEquifaxResponse.getSoapenvEnvelope().getSoapenvBody().getMultiBureauResponse().getResponse()
					.getFinished() != null) {
				if (mbEquifaxResponse.getSoapenvEnvelope().getSoapenvBody().getMultiBureauResponse().getResponse()
						.getFinished().getJsonResponseObject() != null) {
					EquifaxSropDomain[] equifaxSropDomains = mbEquifaxResponse.getSoapenvEnvelope().getSoapenvBody()
							.getMultiBureauResponse().getResponse().getFinished().getJsonResponseObject()
							.getEquifaxSropDomainList();
					return equifaxSropDomains;
				}
			}
		}
		return null;
	}

	public ChmBaseSropDomainList1[] parseCrifHighMarkResponse(String responseObj)
			throws JsonMappingException, JsonProcessingException {
		if (StringUtils.isNotBlank(responseObj)) {
			JSONObject jsonObj = XML.toJSONObject(responseObj);
			MbCrfHighMarkResponse mbCrfHighMarkResponse = objectMapper
					.enable(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY)
					.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false)
					.configure(DeserializationFeature.READ_UNKNOWN_ENUM_VALUES_AS_NULL, true)
					.configure(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT, true)
					.readValue(jsonObj.toString(), MbCrfHighMarkResponse.class);
			if (mbCrfHighMarkResponse.getSoapenvEnvelope().getSoapenvBody().getMultiBureauResponse().getResponse()
					.getFinished() != null) {
				ChmBaseSropDomain[] chmBaseSropDomain = mbCrfHighMarkResponse.getSoapenvEnvelope().getSoapenvBody()
						.getMultiBureauResponse().getResponse().getFinished().getJsonResponseObject()
						.getChmBaseSropDomainList();
				List<ChmBaseSropDomainList1> chmBaseSropDomainList1s = new ArrayList<ChmBaseSropDomainList1>();
				if (!Objects.isNull(chmBaseSropDomain)) {
					for (ChmBaseSropDomain chmBaseSropDomain2 : chmBaseSropDomain) {
						chmBaseSropDomainList1s.add(chmBaseSropDomain2.getChmBaseSropDomainList1());
					}

					ChmBaseSropDomainList1[] baseSropDomainList1s = chmBaseSropDomainList1s.stream()
							.toArray(ChmBaseSropDomainList1[]::new);

//				log.info("chmBaseSropDomain {}", chmBaseSropDomainList1s.size());
					return baseSropDomainList1s;
				}
			}
		}
		return null;
	}

	public MBEoTRequestType parseEotResponse(String responseObj) throws JsonMappingException, JsonProcessingException {
		if (StringUtils.isNotBlank(responseObj)) {
			JSONObject jsonObj = XML.toJSONObject(responseObj);
			if (null == objectMapper) {
				objectMapper = new ObjectMapper();
			}
			MBEOTSuccessResponse mbEotResponse = objectMapper
					.enable(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY)
					.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false)
					.configure(DeserializationFeature.READ_UNKNOWN_ENUM_VALUES_AS_NULL, true)
					.configure(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT, true)
					.readValue(jsonObj.toString(), MBEOTSuccessResponse.class);
			MBEoTRequestType mbEoTRequestType = mbEotResponse.getMBEoTRequestType();
			return mbEoTRequestType;
		}
		return null;
	}

	public MultiBureauEoTRequest parseEotFailureResponse(String responseObj)
			throws JsonMappingException, JsonProcessingException {
		if (StringUtils.isNotBlank(responseObj)) {
			JSONObject jsonObj = XML.toJSONObject(responseObj);
			MbEotResponse mbEotResponse = objectMapper.enable(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY)
					.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false)
					.configure(DeserializationFeature.READ_UNKNOWN_ENUM_VALUES_AS_NULL, true)
					.configure(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT, true)
					.readValue(jsonObj.toString(), MbEotResponse.class);
			MultiBureauEoTRequest mbEoTRequestType = mbEotResponse.getSoapenvEnvelope().getSoapenvBody()
					.getMultiBureauEoTRequest();
			return mbEoTRequestType;
		}
		return null;
	}

	public MergedSropDomain[] parseMergedResponse(String responseObj)
			throws JsonMappingException, JsonProcessingException {
		if (StringUtils.isNotBlank(responseObj)) {
			JSONObject jsonObj = XML.toJSONObject(responseObj);
			MbMergedScoreResponse mbMergedScoreResponse = objectMapper
					.enable(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY)
					.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false)
					.configure(DeserializationFeature.READ_UNKNOWN_ENUM_VALUES_AS_NULL, true)
					.configure(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT, true)
					.readValue(jsonObj.toString(), MbMergedScoreResponse.class);
			if (mbMergedScoreResponse.getSoapenvEnvelope().getSoapenvBody().getNs0MultiBureauResponse().getResponse()
					.getFinished().getJsonResponseObject() != null) {
				MergedSropDomain[] mergedSropDomain = mbMergedScoreResponse.getSoapenvEnvelope().getSoapenvBody()
						.getNs0MultiBureauResponse().getResponse().getFinished().getJsonResponseObject()
						.getMergedSropDomainList();
				return mergedSropDomain;
			}
		}
		return null;
	}

	public PIRData getPerfiosRetailResponse(String responseObj) throws JsonMappingException, JsonProcessingException {
		JSONObject jsonObj = XML.toJSONObject(responseObj);
		log.info("retail perfios response json {}", jsonObj);
		PerfiosResponse perfiosResponse = objectMapper.enable(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY)
				.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false)
				.configure(DeserializationFeature.READ_UNKNOWN_ENUM_VALUES_AS_NULL, true)
				.configure(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT, true)
				.readValue(jsonObj.toString(), PerfiosResponse.class);
		PIRData pirData = perfiosResponse.pIRData;
		return pirData;
	}

	public com.hdfcbank.elengine.domain.response.perfios.sme.PIRData getPerfiosSmeResponse(String responseObj)
			throws JsonMappingException, JsonProcessingException {
		JSONObject jsonObj = XML.toJSONObject(responseObj);
		objectMapper.enable(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY)
				.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false)
				.configure(DeserializationFeature.READ_UNKNOWN_ENUM_VALUES_AS_NULL, true)
				.configure(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT, true);
		PerfiosSmeResponse perfiosResponse = objectMapper.readValue(jsonObj.toString(), PerfiosSmeResponse.class);
		com.hdfcbank.elengine.domain.response.perfios.sme.PIRData pirData = perfiosResponse.pIRData;
		return pirData;
	}

	public BlResponse parseBlResponse(String response) throws JsonMappingException, JsonProcessingException {
		return StringUtils.isNotBlank(response) ? objectMapper.readValue(response, BlResponse.class) : new BlResponse();
	}

	public FtnrResponse parseFtnrResponse(String response) throws JsonMappingException, JsonProcessingException {
		return StringUtils.isNotBlank(response) ? objectMapper.readValue(response, FtnrResponse.class)
				: new FtnrResponse();
	}

	public BlBre2bResponse parsePerfliosdebitscoreResponse(String response)
			throws JsonMappingException, JsonProcessingException {
		return StringUtils.isNotBlank(response) ? objectMapper.readValue(response, BlBre2bResponse.class)
				: new BlBre2bResponse();
	}

	public BlBre1bResponse parseBlBre1bResponse(String response) throws JsonMappingException, JsonProcessingException {
		objectMapper.enable(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY);
		objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false)
				.configure(DeserializationFeature.READ_UNKNOWN_ENUM_VALUES_AS_NULL, true)
				.configure(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT, true);
		return StringUtils.isNotBlank(response) ? objectMapper.readValue(response, BlBre1bResponse.class)
				: new BlBre1bResponse();
	}

	public HunterResponse parseHunterResponse(String response) {
		try {
			if (StringUtils.isNotBlank(response)) {
				response = response.replace("&lt;", "<").replace("&gt;", ">");
				JSONObject jsonObj = XML.toJSONObject(response);
				objectMapper.enable(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY);
				objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false)
						.configure(DeserializationFeature.READ_UNKNOWN_ENUM_VALUES_AS_NULL, true)
						.configure(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT, true);
				HunterResponse hunterResponse = objectMapper.readValue(jsonObj.toString(), HunterResponse.class);
				return hunterResponse;
			} else {
				return new HunterResponse();
			}

		} catch (Exception e) {
			log.error("exception in hunter parsing {}", e);
		}
		return new HunterResponse();
	}

	public List<Part> parsePerfiosTxnStatusResponse(String response)
			throws JsonMappingException, JsonProcessingException {
		JSONObject jsonObj = XML.toJSONObject(response);
		objectMapper.enable(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY);
		PerfiosTxnStatusResponse perfiosTxnStatusResponse = objectMapper.readValue(jsonObj.toString(),
				PerfiosTxnStatusResponse.class);
		if (!Objects.isNull(perfiosTxnStatusResponse)) {
			Status status = perfiosTxnStatusResponse.getStatus();
			if (!Objects.isNull(status)) {
				List<Part> part = status.part;
				return part;
			}
		}
		return null;
	}

	public ArrayList<String> parseMergedAddressResponse(String responseObj)
			throws JsonMappingException, JsonProcessingException {
		if (responseObj != null) {
			MergedSropDomain[] mergedSropDomainList = this.parseMergedResponse(responseObj);
			ArrayList<String> addressValue = new ArrayList<String>();
			for (MergedSropDomain mergedSropDomain : mergedSropDomainList) {
				addressValue.add(mergedSropDomain.getDispCredAddressValue());
			}
			return addressValue;
		}
		return null;
	}

	public String parseMergedNameResponse(String responseObj) throws JsonMappingException, JsonProcessingException {
		if (responseObj != null) {
			MergedSropDomain[] mergedSropDomainList = this.parseMergedResponse(responseObj);
			String addressValue = "";
			for (MergedSropDomain mergedSropDomain : mergedSropDomainList) {
				addressValue = mergedSropDomain.getDispCredNameValue();
			}
			return addressValue;
		}
		return "null";
	}

	public String parsePerfiosAddressResponse(String responseObj, String employmentType)
			throws JsonMappingException, JsonProcessingException {

		if (employmentType.equalsIgnoreCase(EmploymentType.SEB.toString())) {
			com.hdfcbank.elengine.domain.response.perfios.sme.PIRData pirData = getPerfiosSmeResponse(responseObj);
			if (null != pirData) {
				String address = pirData.customerInfo.address;
				return address;
			}
		} else {
			PIRData data = getPerfiosRetailResponse(responseObj);
			String address = data.customerInfo.address;
			return address;
		}

		return null;
	}

	public HashMap<String, ArrayList<String>> parsePosidexAddressResponse(String responseObj) {
		HashMap<String, ArrayList<String>> hashMap = new HashMap<>();
		ArrayList<String> resiAddrList = new ArrayList<>();
		ArrayList<String> officeAddrList = new ArrayList<>();

		if (responseObj != null) {
			PosidexOutData[] outDatas = this.parsePosidexOutput(responseObj);
			for (PosidexOutData posidexOutData : outDatas) {
				String FILLER_11 = posidexOutData.getFILLER_11();
				String FILLER_2 = posidexOutData.getFILLER_2();
				String FILLER_22 = posidexOutData.getFILLER_22();
				String FILLER_12 = posidexOutData.getFILLER_12();
				String posidexResiAdd = FILLER_11 + " " + FILLER_2 + " " + FILLER_22 + " " + FILLER_12;
				resiAddrList.add(posidexResiAdd);
				String FILLER_42 = posidexOutData.getFILLER_42();
				String FILLER_43 = posidexOutData.getFILLER_43();
				String posidexOffAdd = FILLER_42 + " " + FILLER_43;
				officeAddrList.add(posidexOffAdd);
			}
			hashMap.put("posidexResiAdd", resiAddrList);
			hashMap.put("posidexoffAdd", officeAddrList);
		}
		return hashMap;
	}

}
