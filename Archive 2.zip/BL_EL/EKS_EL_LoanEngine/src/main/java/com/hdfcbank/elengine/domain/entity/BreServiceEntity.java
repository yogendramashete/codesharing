package com.hdfcbank.elengine.domain.entity;

import java.time.OffsetDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.hdfcbank.elengine.domain.enums.BreServiceType;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Table(name = "el_bre_auditlogs")
@Entity
@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
@Getter
public class BreServiceEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	@Column(name =  "mobileno")
	private String mobileNo;
	
	@Column(name = "request")
	private String request;
	
	@Column(name = "response")
	private String response;
	
	@Column(name = "creationdate")
	private OffsetDateTime creationdate;
	
	@Column(name = "updateddate")
	private OffsetDateTime updateddate;
	
	@Column(name = "product")
	private String product;
	
	@Column(name = "operationtype")
	@Enumerated(EnumType.STRING)
	private BreServiceType operationtype;
	
	@Column(name = "status")
	private String status;
	
	@Column(name = "tranrefnumber")
	private String tranRefNumber;

	public BreServiceEntity(String mobileNo, String request, String response, OffsetDateTime creationdate,
			OffsetDateTime updateddate, String product, BreServiceType operationtype, String status,
			String tranRefNumber) {
		super();
		this.mobileNo = mobileNo;
		this.request = request;
		this.response = response;
		this.creationdate = creationdate;
		this.updateddate = updateddate;
		this.product = product;
		this.operationtype = operationtype;
		this.status = status;
		this.tranRefNumber = tranRefNumber;
	}
	
	

}
