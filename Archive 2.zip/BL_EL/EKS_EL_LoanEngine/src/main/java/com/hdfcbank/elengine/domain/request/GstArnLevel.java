
package com.hdfcbank.elengine.domain.request;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "return_type",
    "tax_period",
    "date_of_filing",
    "due_date_of_filing",
    "delay_in_filing",
    "days_delay",
    "status",
    "arn",
    "mof",
    "valid"
})
@Data
public class GstArnLevel {

    @JsonProperty("return_type")
    public String returnType;
    @JsonProperty("tax_period")
    public String taxPeriod;
    @JsonProperty("date_of_filing")
    public String dateOfFiling;
    @JsonProperty("due_date_of_filing")
    public String dueDateOfFiling;
    @JsonProperty("delay_in_filing")
    public String delayInFiling;
    @JsonProperty("days_delay")
    public Integer daysDelay;
    @JsonProperty("status")
    public String status;
    @JsonProperty("arn")
    public String arn;
    @JsonProperty("mof")
    public String mof;
    @JsonProperty("valid")
    public String valid;

}
