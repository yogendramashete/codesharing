package com.hdfcbank.elengine.domain.entity;

import java.time.OffsetDateTime;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.EntityListeners;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;
import javax.persistence.Version;

import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import lombok.EqualsAndHashCode;

@MappedSuperclass
@EntityListeners(AuditingEntityListener.class)
@EqualsAndHashCode
public class AbstractBaseEntity {

	@Id
	private String id;

	@Version
	private int version;
	@Column(name = "created_at", nullable = false, updatable = false)
	@CreatedDate
	private OffsetDateTime createdAt;

	@Column(name = "last_modified_at")
	@LastModifiedDate
	private OffsetDateTime lastModifiedAt;

	@Column(name = "created_by")
	@CreatedBy
	private String createdBy;

	@Column(name = "last_modified_by")
	@LastModifiedBy
	private String lastModifiedBy;

	public AbstractBaseEntity() {
		this.id = UUID.randomUUID().toString();
	}
}
