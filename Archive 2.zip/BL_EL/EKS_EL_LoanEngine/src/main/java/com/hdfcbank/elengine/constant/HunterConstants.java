package com.hdfcbank.elengine.constant;

import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Data
@Component
public class HunterConstants {

    @Value("${HUNTER_SOAP_XMLNS_ENVELOP}")
    public String HUNTER_SOAP_XMLNS_ENVELOP;
    @Value("${HUNTER_IN_SOAP_XSD}")
    public String HUNTER_IN_SOAP_XSD;
    @Value("${HUNTER_CUSTOMER_ID}")
    public String HUNTER_CUSTOMER_ID;
    @Value("${HUNTER_CUSTOMER_NAME}")
    public String HUNTER_CUSTOMER_NAME;
    @Value("${HUNTER_SUBMISSION_LOAD}")
    public String HUNTER_SUBMISSION_LOAD;
    @Value("${HUNTER_SCHEME_ID_28}")
    public String HUNTER_SCHEME_ID_28;
    @Value("${HUNTER_SCHEME_ID_20}")
    public String HUNTER_SCHEME_ID_20;
    @Value("${HUNTER_SCHEME_ID_21}")
    public String HUNTER_SCHEME_ID_21;
    @Value("${HUNTER_SCHEME_ID_22}")
    public String HUNTER_SCHEME_ID_22;
    @Value("${HUNTER_SCHEME_ID_23}")
    public String HUNTER_SCHEME_ID_23;
    @Value("${HUNTER_SCHEME_ID_24}")
    public String HUNTER_SCHEME_ID_24;
    @Value("${HUNTER_SCHEME_ID_25}")
    public String HUNTER_SCHEME_ID_25;
    @Value("${HUNTER_SCHEME_ID_26}")
    public String HUNTER_SCHEME_ID_26;
    @Value("${HUNTER_SCHEME_ID_27}")
    public String HUNTER_SCHEME_ID_27;
    @Value("${HUNTER_SCHEME_ID_56}")
    public String HUNTER_SCHEME_ID_56;
    @Value("${HUNTER_SCHEME_ID_58}")
    public String HUNTER_SCHEME_ID_58;
    @Value("${HUNTER_SCHEME_ID_78}")
    public String HUNTER_SCHEME_ID_78;
    @Value("${HUNTER_SCHEME_ID_93}")
    public String HUNTER_SCHEME_ID_93;
    @Value("${HUNTER_SCHEME_ID_94}")
    public String HUNTER_SCHEME_ID_94;
    @Value("${HUNTER_PERSIST_MATCHES}")
    public String HUNTER_PERSIST_MATCHES;
    @Value("${HUNTER_WORKLIST_INSERT}")
    public String HUNTER_WORKLIST_INSERT;
    @Value("${HUNTER_RSLT_CODE}")
    public String HUNTER_RSLT_CODE;
    @Value("${HUNTER_COUNT}")
    public String HUNTER_COUNT;
    @Value("${HUNTER_ORIGINATOR}")
    public String HUNTER_ORIGINATOR ;
    @Value("${HUNTER_CLASSIFICATION}")
    public String HUNTER_CLASSIFICATION ;
    @Value("${HUNTER_STATUS_CLEAR}")
    public String HUNTER_STATUS_CLEAR;
    @Value("${HUNTER_URN}")
    public String HUNTER_URN;



}
