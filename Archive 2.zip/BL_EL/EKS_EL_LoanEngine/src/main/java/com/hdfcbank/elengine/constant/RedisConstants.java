package com.hdfcbank.elengine.constant;

public class RedisConstants {
	
	public static String EKYC_FILE_PATH = "EKYC_FILE_PATH_";
	public static String BRE1_IS_INITIATED = "BRE1_IS_INITIATED_";
	public static String BRE1_INITIATED_TIME = "BRE1_INITIATED_TIME_";
	public static String MULTI_BUREAU_ACK = "MULTIBUREAU_ACK_";
	public static String MULTI_BUREAU_CB_CNT = "MULTI_BUREAU_CB_CNT_";
	public static String MULTI_BUREAU_MERGE_ACK = "MULTIBUREAUMERGE_ACK_";
	public static String NTB_MOBILE_NO = "EL_NTB_MOBILE_NO_";
	public static String NTB_TRAN_REF_NO = "EL_NTB_TRAN_REF_NO_";
	public static String ETB_MOBILE_NO = "ETB_MOBILE_NO_";
	public static String ETB_TRAN_REF_NO = "ETB_TRAN_REF_NO_";
	public static String GENERATE_AADHAR_URL_REQ = "GENERATE_AADHAR_URL_REQ_";
	public static String TEN_SEC_ETB_MOBILE_NO = "TEN_SEC_ETB_MOBILE_NO_";
	public static String TEN_SEC_ETB_TRAN_REF_NO = "TEN_SEC_ETB_TRAN_REF_NO_";
	public static String PRODUCTCODE = "PRODUCTCODE_";
	public static String CIBIL = "CIBIL_";
	public static String MERGED_SCORE = "MERGED_SCORE_";
	public static String NTB_JOURNEY_INPUT = "NTB_JOURNEY_INPUT_";
	public static String NTB_TRUSTING_SOCIAL = "NTB_TRUSTING_SOCIAL_";
	public static String NTB_PAN_VALIDATION = "NTB_PAN_VALIDATION_";
	public static String NTB_NAME_MATCH = "NTB_NAME_MATCH_";
	public static String NTB_DEDUPE_OUTPUT = "EL_NTB_DEDUPE_OUTPUT_";
	public static String NTB_EMAIL_VALIDATION = "NTB_EMAIL_VALIDATION_";
	public static String NTB_HUNTER = "EL_NTB_HUNTER_";
	public static String MBEOT = "MBEOT_";
	public static String MBEOT_WOUN = "MBEOT";
	public static String NTB_ADDRESS = "NTB_ADDRESS_";
	public static String NTB_PAN_FILLER2 = "NTB_PAN_FILLER2_";
	public static String NSDL_INVALIDCOUNT = "NSDL_INVALIDCOUNT_";
	public static String NTB_PAN_TRANREF_MOB = "NTB_PAN_TRANREF_MOB_";
	public static String POXIDEX_RETRY_COUNT = "EL_POXIDEX_RETRY_COUNT_";
	public static String ETB_POSIDEX_PUBLISH = "ETB_POSIDEX_PUBLISH_";
	public static String ADD_REF_DOCUMENTS_API = "ADD_REF_DOCUMENTS_API_";
	public static String ADD_REF_DOCUMENTS_API_REQ = "ADD_REF_DOCUMENTS_API_REQ_";
	public static String ETB_ADD_REF_DOCUMENTS_API_REQ = "ETB_ADD_REF_DOCUMENTS_API_REQ_";
	public static String ETB_ADD_REF_DOCUMENTS_API = "ETB_ADD_REF_DOCUMENTS_API_";
	public static String DOC_UPLOAD_DOCUMENTS_API = "DOC_UPLOAD_DOCUMENTS_API_";
	public static String ETB_DOC_UPLOAD_DOCUMENTS_API = "ETB_DOC_UPLOAD_DOCUMENTS_API_";
	public static String COM_DOC_UPLOAD_DOCUMENTS_API = "COM_DOC_UPLOAD_DOCUMENTS_API_";
	public static String ETB_COM_DOC_UPLOAD_DOCUMENTS_API = "ETB_COM_DOC_UPLOAD_DOCUMENTS_API_";
	public static String BRE1 = "BRE1_";
	public static String BRE2 = "BRE2_";
	public static String ETB_BRE2 = "ETB_BRE2_";
	public static String BRE3 = "BRE3_";
	public static String CIF = "CIF_";
	public static String PERFIOS_RETRIVE_DATA = "PERFIOS_RETRIVE_DATA_";
	public static String DOC_PERFIOS_RETRIVE_DATA = "DOC_PERFIOS_RETRIVE_DATA_";
	public static String DOC_PERFIOS_RETRIVE_DATA_PDF = "DOC_PERFIOS_RETRIVE_DATA_PDF_";
	public static String CP_DATA = "CP_DATA_";
	public static String CIF_DATA = "CIF_DATA_";
	public static String MULTICALLBACKS = "MULTICALLBACKS_";
	public static String AADHAR_OTP_VALDN = "AADHAR_OTP_VALDN_";
	public static String AADHAR_CALLBACK_RESP = "AADHAR_CALLBACK_RESP_";
	public static String AADHAR_RETRY_ATTEMPTS = "AADHAR_RETRY_ATTEMPTS_";
	public static String ADD_MATCH_SCORE = "ADDRESS_MATCH_SCORE_";
	public static int EXPIRE_KEY = 15000;
	public static String ADD_REF_RETRY_COUNT = "ADD_REF_RETRY_COUNT_";
	public static String ETB_ADD_REF_RETRY_COUNT = "ETB_ADD_REF_RETRY_COUNT_";
	public static String DOC_UPLOAD_RETRY_COUNT = "DOC_UPLOAD_RETRY_COUNT_";
	public static String ETB_DOC_UPLOAD_RETRY_COUNT = "ETB_DOC_UPLOAD_RETRY_COUNT_";
	public static String COM_DOC_RETRY_COUNT = "COM_DOC_RETRY_COUNT_";
	public static String ETB_COM_DOC_RETRY_COUNT = "ETB_COM_DOC_RETRY_COUNT_";
	public static String INSTALLMENT_MODE = "INSTALLMENT_MODE_";
	public static String NTB = "ECS";
	public static String ETB = "SI";
	public static String OFFICE_EMAILID = "OFFICE_EMAILID_";
	public static String NTB_PAN_NAME_MATCH_RESP = "NTB_PAN_NAME_MATCH_RESP_";
	public static String NTB_PAN_SOURCE_NAME = "NTB_PAN_SOURCE_NAME_";

	public static String INJECTION_STATUS_RETRY_COUNT = "INJECTION_STATUS_RETRY_COUNT_";
	public static String ETB_INJECTION_STATUS_RETRY_COUNT = "ETB_INJECTION_STATUS_RETRY_COUNT_";

	public static String US = "_";
	public static int CTA_CALL_COUNT = 5;
	public static String NTB_DL_AUTHENTICATION = "NTB_DL_AUTHENTICATION_";
	public static String NTB_EB_AUTHENTICATION = "NTB_EB_AUTHENTICATION_";
	public static String NTB_LPG_AUTHENTICATION = "NTB_LPG_AUTHENTICATION_";
	public static String NTB_MB_AUTHENTICATION = "NTB_MB_AUTHENTICATION_";
	public static String NTB_VID_AUTHENTICATION = "NTB_VID_AUTHENTICATION_";
	public static String NTB_OPERATION_TYPE = "OPERATIONTYPE";

	/////////////////// BRE//////////////////////
	public static String BRE_INITIATED = "Initiated";
	public static String BRE_FAIL = "Fail";
	public static String BRE_SUCCESS = "Success";
	public static String BRE_REQUEST_OBJECT = "BRE_REQUEST_OBJECT_";

	public static String BRE2_CALL_STATUS = "BRE2_CALL_STATUS_";
	public static String ETB_BRE2_CALL_STATUS = "ETB_BRE2_CALL_STATUS_";
	public static String BRE2_CALL_DATA = "BRE2_CALL_DATA_";
	public static String ETB_BRE2_CALL_DATA = "ETB_BRE2_CALL_DATA_";
	public static String BRE2_PERFIOS_CUST_NAME = "BRE2_PERFIOS_CUST_NAME_";
	public static String BRE2_PERFIOS_CUST_NAME_SCORE = "BRE2_PERFIOS_CUST_NAME_SCORE_";
	public static String BRE2_REQUEST_OBJECT = "BRE2_REQUEST_OBJECT";
	public static String ETB_BRE2_REQUEST_OBJECT = "ETB_BRE2_REQUEST_OBJECT";
	public static String BRE2_ACCOUNT_NUMBER = "BRE2_ACCOUNT_NUMBER_";

	public static String BRE3_CALL_STATUS = "BRE3_CALL_STATUS_";
	public static String BRE3_CALL_DATA = "BRE3_CALL_DATA_";
	public static String BRE3_REQUEST_OBJECT = "BRE3_REQUEST_OBJECT_";
	public static String BRE3_EKYC_CUST_NAME = "BRE3_KYC_CUST_NAME_";
	public static String BRE3_EKYC_CUST_NAME_SCORE = "BRE3_KYC_CUST_NAME_SCORE_";

	public static String BRE3_PERFIOS_OPRTATION = "BRE3_PERFIOS_OPRTATION_";
	public static String BRE3_KYC_OPRTATION = "BRE3_KYC_OPRTATION_";
	public static String BRE3_NAMEMATCH_OPERATION = "BRE3_NAMEMATCH_OPERATION_";
	public static String EKYC_PHOTO = "EKYC_PHOTO_";
	public static String EKYC_STATUS = "EKYC_STATUS_";

	public static String NTB_EKYC_NAME_MATCH = "NTB_EKYC_NAME_MATCH";
	public static String NTB_PAN_NAME_MATCH_SCORE = "NTB_PAN_NAME_MATCH_SCORE_";
	public static String NTB_PAN_TARGET_NAME = "NTB_PAN_TARGET_NAME_";

	/* JOURNEY STAGING */
	public static String EMPLOYMENT_STAGE = "EMPLOYMENT_STAGE_";
	public static String PRINCIPLE_LOAN_OFFER = "PRINCIPLE_LOAN_OFFER_";
	public static String PERFIOS_STAGE = "PERFIOS_STAGE_";
	public static String CAR_DEALER_SECTION = "CAR_DEALER_SECTION_";
	public static String KYC_STAGE = "KYC_STAGE_";
	public static String DIGITAL_DISBURSEMENT = "DIGITAL_DISBURSEMENT_";
	public static String DIGITAL_DISBURSEMENT_STATUS = "DIGITAL_DISBURSEMENT_STATUS_";
	public static String BTR_REF_NUMBER = "BTR_REF_NUMBER_";
	public static String LEAD_STATUS_DATA = "LEAD_STATUS_DATA_";
	public static String LEADINSTA_REF_NUM = "LEADINSTA_REF_NUM_";
	public static String LEADINSTA_SNAP_REF_NUM = "LEADINSTA_SNAP_REF_NUM_";
	public static String VCIP_STAGE = "VCIP_STAGE_";
	public static String VCIP_PROFILEID = "VCIP_PROFILEID_";
	public static String VCIP_SATAUS_UNIQUEID = "VCIP_SATAUS_UNIQUEID_";
	public static String VCIP_EXPIRE = "VCIP_EXPIRE_";
	/* JOURNEY STAGING */

	public static String PAN_NAME_SCORE = "Pan_Name_Score_";
	public static String EMAIL_NAME_SCORE = "Email_Name_Score_";
	public static String EKYC_NAME_SCORE = "Ekyc_Name_Score_";
	public static String PERFIOS_NAME_SCORE = "Perfios_Name_Score_";
	public static String MERGED_NAME_SCORE = "Merged_Name_Score_";
	public static String SET_POSTAL_CODE = "EL_SET_POSTAL_CODE_";

	public static String VCIP_REFERENCE_ID = "VCIP_REFERENCE_ID_";
	public static String VCIP_STATUS = "VCIP_STATUS_";
	// APPLNLOSFILLERSFILLERTEXT8 status tags
	public static String BRE_APIS_STATUS = "BRE_APIS_STATUS_";
	public static String BRE_APIS_TIME = "BRE_APIS_TIME_";
	/* WB With Mobile */
	public static String BRE_APIS_STATUS_WM = "BRE_APIS_STATUS_WM_";
	public static String BRE_APIS_TIME_WM = "BRE_APIS_TIME_WM_";

	/////////// NTB Journey Code////////////////////
	public static String NTB_JOURNY_DATA = "NTB_JOURNY_DATA_";
	public static String STAMP_DUTY_DATA = "STAMP_DUTY_DATA_";
	public static String LOAN_CALC_API_RESP = "LOAN_CALC_API_RESP_";
	public static String INJECTION_API_REQ = "INJECTION_API_REQ_";
	public static String DIGITAL_DISBURSEMENT_PDF_DATA = "DIGITAL_DISBURSEMENT_PDF_DATA_";

	public static String EKYC_OTPGEN_COUNT = "OTPGENCNT_";
	public static String EKYC_OTPVERIFY_COUNT = "OTPVERIFYCNT_";
	public static String ACKNOWLEDGEMENT_ID = "EL_ACKNOWLEDGEMENT_ID_";
	///////////////// 03022021//////////////////
	public static String JWT_TOKEN_RANDOM_ID = "jwttokenrandomid_";
	public static String BTRN_REF_NO = "BTrnRefNo_";
	public static String CUST_LOANS = "CustLoans_";
	public static String CUTOMER_STAGING = "CutomerStaging_";
	public static String NTB_MULTI_BUREAU = "EL_NTB_MULTI_BUREAU_";
	public static String BRECALL_STATUS = "BRECALL_STATUS";
	public static String BRECALL_DATA = "BRECALL_DATA";
	public static String NTB_DEDUPE_INPUT = "EL_NTB_DEDUPE_INPUT_";
	public static String POSIDEX_FILENAME = "EL_POSIDEX_FILENAME_";
	public static String ETB_POSIDEX_FILENAME = "ETB_POSIDEX_FILENAME_";
	public static String NTB_DEDUPE_PUBLISH = "EL_NTB_DEDUPE_PUBLISH_";
	public static String NTB_OTP_GENERATION = "NTB_OTP_GENERATION_";
	public static String NTB_RESEND_OTP = "NTB_RESEND_OTP_";
	public static String NTB_PERFIOS_NAME_MATCH = "NTB_PERFIOS_NAME_MATCH_";
	public static String NTB_ADDRESS_MATCH = "NTB_ADDRESS_MATCH_";
	public static String TRUSTING_SOCIAL_BEARER_TOKEN = "trusting_social_bearer_token_";
	public static String USER_NAME = "USER_NAME_";
	public static String PINCODE = "PINCODE_";

	/* IMPS */
	public static String BATCH_NUM_NEXT_COUNT = "BATCH_NUM_NEXT_COUNT_";

	// Perfios call back check
	public static String PERFIOS_CALLBACK_STATUS = "PERFIOS_CALLBACK_STATUS_";

	// Email otp
	public static String EMAIL_OTP_TAG = "EMAIL_OTP_TAG_";
	public static String NTB_CUSTOMER_NAME = "NTB_CUSTOMER_NAME_";
	public static String LEAD_NUMBAR = "LEAD_NUMBAR_";
	/* Document */
	public static String FIN_DOC_ADD_REF_FILLER1 = "FIN_DOC_ADD_REF_FILLER1_";
	public static String FIN_DOC_ADD_REF_FILLER2 = "FIN_DOC_ADD_REF_FILLER2_";
	public static String FIN_DOC_CIBIL_ACK_NO = "FIN_DOC_CIBIL_ACK_NO_";
	public static String FIN_DOC_ADD_REF_COUNT = "FIN_DOC_ADD_REF_COUNT_";
	public static String FIN_DOC_SOURCE_UNIQUE_ID = "FIN_DOC_SOURCE_UNIQUE_ID_";
	public static String NTB_PERFIOS_DESTINATION = "NTB_PERFIOS_DESTINATION_";

	public static String PERFIOS_GENERATE_URL_REQUEST = "PERFIOS_GENERATE_URL_REQUEST_";
	public static String ETB_PERFIOS_GENERATE_URL_REQUEST = "ETB_PERFIOS_GENERATE_URL_REQUEST_";
	public static String ETB_DOC_GENERATE_PERFIOS_URL_REQ = "ETB_DOC_GENERATE_PERFIOS_URL_REQ_";
	public static String EKYC_GENERATE_URL_REQUEST = "EKYC_GENERATE_URL_REQUEST_";


	public static String OFFER_INDICATION_RESPONSE = "OFFER_INDICATION_RESPONSE_";

	public static String LOS_DOCUMENT_CONSTITUTION = "LOS_DOCUMENT_CONSTITUTION_";
	public static String COMPLETE_DOC_RESP = "COMPLETE_DOC_RESP_";
	public static String COMPLETE_DOC_STATUS = "COMPLETE_DOC_STATUS_";
	public static String VCIP_DOC_UPLOADED = "VCIP_DOC_UPLOADED_";
	public static String ETB_COMPLETE_DOC_RESP = "ETB_COMPLETE_DOC_RESP_";
	public static String INJECTION_REQUEST = "INJECTION_REQUEST_";
	public static String IFSC_STATUS = "IFSC_STATUS_";
	public static String TRACK_YOUR_LOAN_STR_REF_NO = "TRACK_YOUR_LOAN_STR_REF_NO_";

	public static String ADD_REFERENCE_REQ = "ADD_REFERENCE_REQ_";
	public static String ETB_ADD_REFERENCE_REQ = "ETB_ADD_REFERENCE_REQ_";
	public static String TRACK_STARUS_RESP = "TRACK_STARUS_RESP_";
	public static String ETB_TRACK_STARUS_RESP = "ETB_TRACK_STARUS_RESP_";

	public static String APPLY_FOR_LOAN_REQUEST = "APPLY_FOR_LOAN_REQUEST_";
	public static String APPLY_FOR_LOAN_RESPONSE = "APPLY_FOR_LOAN_RESPONSE_";

	public static String ETB_APPLY_FOR_LOAN_REQUEST = "ETB_APPLY_FOR_LOAN_REQUEST_";
	public static String ETB_APPLY_FOR_LOAN_RESPONSE = "ETB_APPLY_FOR_LOAN_RESPONSE_";

	public static String COMP_DOCUMENT_RESP = "COMP_DOCUMENT_RESP_";
	public static String ETB_COMP_DOCUMENT_RESP = "ETB_COMP_DOCUMENT_RESP_";
	public static String OTPVERIFYCNT = "OTPVERIFYCNT_";
	public static String OTPGENFLAG = "OTPGENFLAG_";
	public static String OTPGENCNT = "OTPGENCNT_";
	public static String BRE_CREATION_TIME = "BRE_CREATION_TIME_";
	public static String BRE2_CREATION_TIME = "BRE2_CREATION_TIME_";
	public static String BRE3_CREATION_TIME = "BRE3_CREATION_TIME_";
	
	public static String DIGITAL_DISBURSEMENT_DUEDATE = "DIGITAL_DISBURSEMENT_DUEDATE_";
	public static String CIF2_CUSTOMERID = "CIF2_CUSTOMERID_";
	public static String AADHAR_DOB = "AADHAR_DOB_";
	public static String AADHAR_ADDRESS = "AADHAR_ADDRESS_";
	public static String EKYC_ADDR = "EKYC_ADDR_";
	
	public static String IP_ADDRESS = "IP_ADDRESS_";
	//hourly report data
	public static String PAN_FIRST_NAME = "PAN_FIRST_NAME_";
	public static String PAN_LAST_NAME = "PAN_LAST_NAME_";
	public static String PAN_MIDDLE_NAME = "PAN_MIDDLE_NAME_";
	public static String HUNTER_CITY = "EL_HUNTER_CITY_";
	public static String HUNTER_CODE = "EL_HUNTER_CODE_";
	public static String MB_GENDER = "EL_MB_GENDER_";
	public static String STATE_ID = "STATE_ID_";
	public static String BRE_RISK_CAT_AL = "BRE_RISK_CAT_AL_";
	public static String BRE_COMPCAT = "BRE_COMPCAT_";
	public static String BRE2_COL01 = "BRE2_COL01_";
	public static String BRE_MASTERDATA_OBJECT = "BRE_MASTERDATA_OBJECT_";

	public static String SOURCE_ADDRESS = "SOURCE_ADDRESS_";
	public static String TARGET_ADDRESS = "TARGET_ADDRESS_";
	public static String AADHAR_NUMBER = "AADHAR_NUMBER_";
	public static String EKYC_STAN = "EKYC_STAN_";
	public static String DL_NUMBER = "DL_NUMBER_";
	public static String LEADINSTA_STATE = "LEADINSTA_STATE_";
	public static String LEADINSTA_OBJ = "LEADINSTA_OBJ_";
	public static String DOC_MANUF_ID = "DOC_MANUF_ID_";
	public static String DOC_PRODUCT = "DOC_PRODUCT_";
	public static String DOC_SCHEME_ID = "DOC_SCHEME_ID_";
	public static String DOC_DSA = "DOC_DSA_";
	
	public static String PAN_STATUS = "PAN_STATUS_";
	public static String BUREAU_FAIL = "BUREAU_FAIL_";
	public static String BRE_STATUS = "BRE_STATUS_";
	public static String BRE2_STATUS = "BRE2_STATUS_";
	public static String BRE3_STATUS = "BRE3_STATUS_";
	public static String EKYCSTATUS = "EKYCSTATUS_";
	public static String VCIPSTATUS = "VCIPSTATUS_";
	public static String INSTA_DISBURSEMENT_STATUS = "INSTA_DISBURSEMENT_STATUS_";
	public static String LEADINSTA_STATUS = "LEADINSTA_STATUS_";
	public static String DEALER_DETAIL = "DEALER_DETAIL_";
	public static String CAR_DETAIL = "CAR_DETAIL_";
	public static String OFFICE_ADDR = "OFFICE_ADDR_";
	public static String RESI_ADDR = "RESI_ADDR_";
	
	public static String PAN_CREATION_TIME = "PAN_CREATION_TIME_";
	public static String KYC_CREATION_TIME = "KYC_CREATION_TIME_";
	public static String MB_CREATION_TIME = "EL_MB_CREATION_TIME_";
	public static String VCIP_CREATION_TIME = "VCIP_CREATION_TIME_";
	public static String LEADINSTA_CREATION_TIME = "LEADINSTA_CREATION_TIME_";
	
	public static String COMPANY_NAME = "COMPANY_NAME_";
	public static String PERSONAL_EMAIL = "PERSONAL_EMAIL_";
	public static String TRANSREFNO_PARTNER = "TRANSREFNO_PARTNER_";
	public static String BTRNREFNO_PARTNER = "BTRNREFNO_PARTNER_";
	public static String HDFCBANKREFNO_PARTNER = "HDFCBANKREFNO_PARTNER_";
	
	public static String OFFER_AVAILABLE = "OFFER_AVAILABLE_";
	public static String EXISTING_CUST = "EXISTING_CUST_";
	public static String PRODUCT_NAME = "PRODUCT_NAME_";
	
	public static String BRE1_ELIG = "BRE1_ELIG_";
	public static String BRE2_ELIG = "BRE2_ELIG_";
	public static String BRE3_ELIG = "BRE3_ELIG_";
	public static String BRE3_LOAN_AMOUNT = "BRE3_LOAN_AMOUNT_";
	
	public static String DL_KYC_STAGE = "DL_KYC_STAGE_";
	public static String PENNY_DROP_STATUS = "PENNY_DROP_STATUS_";
	public static String PENNY_NAME_MATCH_PERCENTAGE = "PENNY_NAME_MATCH_PERCENTAGE_";
	public static String SOURCE_DEATIL_OBJ = "SOURCE_DEATIL_OBJ_";
	
	public static String BUREAU_REQ = "EL_BUREAU_REQ_";
	public static String INCOMEOFFER_REQ = "EL_INCOMEOFFER_REQ_";
	public static String STPNONSTP_REQ = "EL_STPNONSTP_REQ_";
	public static String NTB_BLAPP = "EL_NTB_BLAPP_";
	public static String NTB_FTNR = "EL_NTB_FTNR_";
	public static String NTB_BLBRE1B = "EL_NTB_BLBRE1B_";
	public static String NTB_BLBRE1B_SUC = "EL_NTB_BLBRE1B_SUC";
	public static String NTB_BLBRE2A = "EL_NTB_BLBRE2A_";
	public static String NTB_BLBRE2B = "EL_NTB_BLBRE2B_";
	public static String NTB_BLBRE2C = "EL_NTB_BLBRE2C_";
	public static String NTB_BLBRE2C_SUC = "EL_NTB_BLBRE2C_SUC";
	public static String NTB_BLBRE3A = "EL_NTB_BLBRE3A_";
	public static String NTB_BLBRE3B = "EL_NTB_BLBRE3B_";
	public static String NTB_BLBRE3B_SUC = "EL_NTB_BLBRE3B_SUC";
	public static String PARTNER_JOURNEYID = "PARTNER_JOURNEYID";
	public static String NTB_EXPBRE1 = "EL_NTB_EXPBRE1_";
	public static String NTB_EXPBRE2 = "EL_NTB_EXPBRE2_";
	public static String NTB_EXPBRE3 = "EL_NTB_EXPBRE3_";
	
	public static String BRE_CALBACK_URL = "BRE_CALBACK_URL_";
	public static String EMPLOYMENT_TYPE = "EMPLOYMENT_TYPE_";
	
}


