package com.hdfcbank.elengine.domain.enums;

public enum EmploymentType {
    SD,SEB,SEP
}
