package com.hdfcbank.elengine.openAPI;

/**
 * Json Response
 * @author Madhura Oak
 *
 */
public class CrmJsonResponse {
	private String ResponseEncryptedValue;
	private String GWSessionEncryptedValue;
	private String ResponseDigitalSignatureValue;
	private String GWSessionDigitalSignatureValue;
	private String Source;
	private String TransactionId;
	private String OAuthTokenValue; 
	private String Status;
	
	
	
	
	public String getResponseEncryptedValue() {
		return ResponseEncryptedValue;
	}
	public void setResponseEncryptedValue(String responseEncryptedValue) {
		ResponseEncryptedValue = responseEncryptedValue;
	}
	public String getGWSessionEncryptedValue() {
		return GWSessionEncryptedValue;
	}
	public void setGWSessionEncryptedValue(String gWSessionEncryptedValue) {
		GWSessionEncryptedValue = gWSessionEncryptedValue;
	}
	public String getResponseDigitalSignatureValue() {
		return ResponseDigitalSignatureValue;
	}
	public void setResponseDigitalSignatureValue(String responseDigitalSignatureValue) {
		ResponseDigitalSignatureValue = responseDigitalSignatureValue;
	}
	public String getGWSessionDigitalSignatureValue() {
		return GWSessionDigitalSignatureValue;
	}
	public void setGWSessionDigitalSignatureValue(String gWSessionDigitalSignatureValue) {
		GWSessionDigitalSignatureValue = gWSessionDigitalSignatureValue;
	}
	public String getSource() {
		return Source;
	}
	public void setSource(String source) {
		Source = source;
	}
	public String getStatus() {
		return Status;
	}
	public void setStatus(String status) {
		Status = status;
	}

    public String getTransactionId() {
		return TransactionId;
	}
	public void setTransactionId(String transactionId) {
		TransactionId = transactionId;
	}
	public String getOAuthTokenValue() {
		return OAuthTokenValue;
	}
	public void setOAuthTokenValue(String oAuthTokenValue) {
		OAuthTokenValue = oAuthTokenValue;
	}	
}
