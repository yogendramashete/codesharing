package com.hdfcbank.elengine.openAPI;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.security.PublicKey;
import java.security.UnrecoverableEntryException;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.xml.sax.SAXException;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

/**
 * Generate Json request
 * 
 * @author Madhura Oak
 *
 */
@Service
public class VcipJsonRequestGenerator {
	private static final String X509 = "X.509";
	private static final String CONFIG = "Config";
	public final static Logger logger = LoggerFactory.getLogger(DigitalSignature.class);

	@Value("${clientKeyStoreFilePath}")
	String clientKeyStoreFilePath;

	@Value("${clientKeyStorePassword}")
	String clientKeyStorePassword;

	@Value("${clientKeyAlias}")
	String clientKeyAlias;

	String vcipCertificateFilePath;

	@Value("${clientId}")
	String clientId;

	@Value("${clientSecret}")
	String clientSecret;

	@Value("${clientScope}")
	String clientScope;

	String LeadInstaClientID;

	String LeadInstaSecret;

	String LEADINSTA_SCOPE;

	@Autowired
	OAuthTokenGenerator authTokenGenerator;

	String dapcertificatepath;

	private String IMPS_API_CLIENT_ID;

	private String IMPS_API_SECRET_KEY;

	/**
	 * Load public key from the bank's public certificate
	 * 
	 * @throws FileNotFoundException
	 * @throws CertificateException
	 */
	private PublicKey initPublicKey() throws FileNotFoundException, CertificateException {
		X509Certificate bankCertificate = null;
		PublicKey		publicKey		= null;
		try(FileInputStream fin = new FileInputStream(vcipCertificateFilePath)) {
			CertificateFactory factory = CertificateFactory.getInstance(X509);
			bankCertificate = (X509Certificate) factory.generateCertificate(fin);	
			if(bankCertificate != null) {
				publicKey = bankCertificate.getPublicKey();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return publicKey;
	}

	/**
	 * Load public key from the bank's public certificate
	 * 
	 * @throws FileNotFoundException
	 * @throws CertificateException
	 */
	public PublicKey initDapPublicKey() throws FileNotFoundException, CertificateException {
		logger.info("dap_certificatepath :" + dapcertificatepath);
		X509Certificate bankCertificate = null;
		PublicKey		publicKey		= null;
		try(FileInputStream fin = new FileInputStream(dapcertificatepath)) {
			CertificateFactory factory = CertificateFactory.getInstance(X509);
			bankCertificate = (X509Certificate) factory.generateCertificate(fin);
			if(bankCertificate != null) {
				publicKey = bankCertificate.getPublicKey();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return publicKey;
	}

	static { /*
				 * try { // initPublicKey(); } catch (CertificateException e) { //TODO handle
				 * exception } catch (FileNotFoundException e) { //TODO handle exception }
				 */
	}

	private Gson gson = new GsonBuilder().disableHtmlEscaping().create();

	/**
	 * Generate json request
	 * 
	 * @param xmlRequest    - original XML request without digital signature
	 * @param scope
	 * @param transactionId - Unique transaction Id for every request
	 * @return json request String
	 * @throws CertificateException        if any of the certificate in the key
	 *                                     store cannot be loaded
	 * @throws UnrecoverableEntryException if the password is invalid or unable to
	 *                                     retrieve private key
	 * @throws SAXException                if the XML passed to this method cannot
	 *                                     be parsed
	 * @throws IOException                 if unable to read public key file
	 */
	public String generateRequest(String xmlRequest, String scope, String transactionId,String status)
			throws CertificateException, UnrecoverableEntryException, SAXException, IOException {
		PublicKey bankPublicKey = initPublicKey();
		JsonRequest request = new JsonRequest();
		VcipCallBackResponse backResponse = new VcipCallBackResponse();
		// create XML Digital Signature for original XML Request
		/*
		 * XMLDigitalSignature xmlDigitalSignature = new XMLDigitalSignature(); String
		 * signedXML = xmlDigitalSignature.sign(xmlRequest, clientKeyStoreFilePath,
		 * clientKeyStorePassword, clientKeyAlias); signedXML =
		 * signedXML.substring(signedXML.indexOf('>')+1); Logger.info("Signed XML : "
		 * +signedXML);
		 */
		// generate 32 byte random key
		KeyGenerator keyGenerator = new KeyGenerator();
		byte[] key = keyGenerator.generateKey(32);

		// encrypt encoded value using random key
		AESEncrypterDecrypter aesEncrypter = new AESEncrypterDecrypter();
		byte[] encryptedValue = aesEncrypter.encrypt(xmlRequest, key);

		// encode the encrypted request
		Base64EncoderDecoder encoder = new Base64EncoderDecoder();
		byte[] encodedValue = encoder.encode(encryptedValue);

		backResponse.setResponseEncryptedValue(new String(encodedValue));
//		logger.info("Request :" + new String(encodedValue));

		// encrypt symmetric key using bank's public key
		RSAEncrypterDecrypter rsaEncrypter = new RSAEncrypterDecrypter();
//		logger.info("bank public key :"+bankPublicKey);
		byte[] symmetricKeyEncryptedValue = rsaEncrypter.encrypt(key, bankPublicKey);

		// encode symmetric key
		encodedValue = encoder.encode(symmetricKeyEncryptedValue);
		backResponse.setGWSymmetricKeyEncryptedValue(new String(encodedValue));
//		logger.info("Key :" + new String(encodedValue));

		backResponse.setScope(scope);
		backResponse.setTransactionId(transactionId);
		backResponse.setStatus(status);
		// Generate OAUTH token
//		OAuthTokenGenerator oauthTokenGenerator = new OAuthTokenGenerator();
//		String oauthToken = authTokenGenerator.getOAuthToken(clientId, clientSecret, clientScope);
//		String oauthToken = "f58805c0-6527-47df-be1b-7ebeba3c11ef";
//		request.setOAuthTokenValue(oauthToken);

		// convert request object to json
		String gsonRequest = gson.toJson(backResponse);

		return gsonRequest;
	}
	
	

	/**
	 * Generate json request
	 * 
	 * @param xmlRequest    - original XML request without digital signature
	 * @param scope
	 * @param transactionId - Unique transaction Id for every request
	 * @return json request String
	 * @throws CertificateException        if any of the certificate in the key
	 *                                     store cannot be loaded
	 * @throws UnrecoverableEntryException if the password is invalid or unable to
	 *                                     retrieve private key
	 * @throws SAXException                if the XML passed to this method cannot
	 *                                     be parsed
	 * @throws IOException                 if unable to read public key file
	 */
	public String generateCrmRequest(String xmlRequest, String scope, String transactionId)
			throws CertificateException, UnrecoverableEntryException, SAXException, IOException {
		PublicKey bankPublicKey = initPublicKey();
		CrmJsonRequest request = new CrmJsonRequest();
		// create XML Digital Signature for original XML Request
		/*
		 * XMLDigitalSignature xmlDigitalSignature = new XMLDigitalSignature(); String
		 * signedXML = xmlDigitalSignature.sign(xmlRequest, clientKeyStoreFilePath,
		 * clientKeyStorePassword, clientKeyAlias); signedXML =
		 * signedXML.substring(signedXML.indexOf('>')+1); Logger.info("Signed XML : "
		 * +signedXML);
		 */
		// generate 32 byte random key
		KeyGenerator keyGenerator = new KeyGenerator();
		byte[] key = keyGenerator.generateKey(32);

		// encrypt encoded value using random key
		AESEncrypterDecrypter aesEncrypter = new AESEncrypterDecrypter();
		byte[] encryptedValue = aesEncrypter.encrypt(xmlRequest, key);

		// encode the encrypted request
		Base64EncoderDecoder encoder = new Base64EncoderDecoder();
		byte[] encodedValue = encoder.encode(encryptedValue);

		request.setRequestEncryptedValue(new String(encodedValue));
		logger.info("Request :" + new String(encodedValue));

		// encrypt symmetric key using bank's public key
		RSAEncrypterDecrypter rsaEncrypter = new RSAEncrypterDecrypter();
		logger.info("bank public key :" + bankPublicKey);
		byte[] symmetricKeyEncryptedValue = rsaEncrypter.encrypt(key, bankPublicKey);

		// encode symmetric key
		encodedValue = encoder.encode(symmetricKeyEncryptedValue);
		request.setSessionEncryptedValue(new String(encodedValue));
		logger.info("Key :" + new String(encodedValue));

		request.setSource(scope);
		request.setTransactionId(transactionId);

		// Generate OAUTH token
//		OAuthTokenGenerator oauthTokenGenerator = new OAuthTokenGenerator();
		String oauthToken = "";
//				authTokenGenerator.getOAuthToken(clientId, clientSecret, clientScope);
//		String oauthToken = "f58805c0-6527-47df-be1b-7ebeba3c11ef";
		request.setOAuthTokenValue(oauthToken);

		request.setRequestDigitalSignatureValue("");
		request.setSessionDigitalSignatureValue("");
		// convert request object to json
		String gsonRequest = gson.toJson(request);

		return gsonRequest;
	}

	public String generateLeadStatusRequest(String xmlRequest, String scope, String transactionId)
			throws CertificateException, UnrecoverableEntryException, SAXException, IOException {

		PublicKey bankPublicKey = initPublicKey();
		LeadStatusJsonRequest request = new LeadStatusJsonRequest();
		// create XML Digital Signature for original XML Request
		/*
		 * XMLDigitalSignature xmlDigitalSignature = new XMLDigitalSignature(); String
		 * signedXML = xmlDigitalSignature.sign(xmlRequest, clientKeyStoreFilePath,
		 * clientKeyStorePassword, clientKeyAlias); signedXML =
		 * signedXML.substring(signedXML.indexOf('>')+1); Logger.info("Signed XML : "
		 * +signedXML);
		 */
		// generate 32 byte random key
		KeyGenerator keyGenerator = new KeyGenerator();
		byte[] key = keyGenerator.generateKey(32);

		// encrypt encoded value using random key
		AESEncrypterDecrypter aesEncrypter = new AESEncrypterDecrypter();
		byte[] encryptedValue = aesEncrypter.encrypt(xmlRequest, key);

		// encode the encrypted request
		Base64EncoderDecoder encoder = new Base64EncoderDecoder();
		byte[] encodedValue = encoder.encode(encryptedValue);

		request.setRequestEncryptedValue(new String(encodedValue));
		logger.info("Request :" + new String(encodedValue));

		// encrypt symmetric key using bank's public key
		RSAEncrypterDecrypter rsaEncrypter = new RSAEncrypterDecrypter();
		logger.info("bank public key :" + bankPublicKey);
		byte[] symmetricKeyEncryptedValue = rsaEncrypter.encrypt(key, bankPublicKey);

		// encode symmetric key
		encodedValue = encoder.encode(symmetricKeyEncryptedValue);
		request.setSymmetricKeyEncryptedValue(new String(encodedValue));
		logger.info("Key :" + new String(encodedValue));

		request.setScope(scope);
		request.setTransactionId(transactionId);

		// Generate OAUTH token
//		OAuthTokenGenerator oauthTokenGenerator = new OAuthTokenGenerator();
		String oauthToken = "";
//				authTokenGenerator.getOAuthToken(clientId, clientSecret, clientScope);
//		String oauthToken = "f58805c0-6527-47df-be1b-7ebeba3c11ef";
		request.setOAuthTokenValue(oauthToken);

		// convert request object to json
		String gsonRequest = gson.toJson(request);

		return gsonRequest;
	}

	/**
	 * Generate json request
	 * 
	 * @param xmlRequest    - original XML request without digital signature
	 * @param scope
	 * @param transactionId - Unique transaction Id for every request
	 * @return json request String
	 * @throws CertificateException        if any of the certificate in the key
	 *                                     store cannot be loaded
	 * @throws UnrecoverableEntryException if the password is invalid or unable to
	 *                                     retrieve private key
	 * @throws SAXException                if the XML passed to this method cannot
	 *                                     be parsed
	 * @throws IOException                 if unable to read public key file
	 */
	public String generateBilldeskRequest(String xmlRequest, String scope, String transactionId)
			throws CertificateException, UnrecoverableEntryException, SAXException, IOException {
		PublicKey bankPublicKey = initPublicKey();
		JsonRequest2 request = new JsonRequest2();
		// create XML Digital Signature for original XML Request
		/*
		 * XMLDigitalSignature xmlDigitalSignature = new XMLDigitalSignature(); String
		 * signedXML = xmlDigitalSignature.sign(xmlRequest, clientKeyStoreFilePath,
		 * clientKeyStorePassword, clientKeyAlias); signedXML =
		 * signedXML.substring(signedXML.indexOf('>')+1); Logger.info("Signed XML : "
		 * +signedXML);
		 */
		// generate 32 byte random key
		KeyGenerator keyGenerator = new KeyGenerator();
		byte[] key = keyGenerator.generateKey(32);

		// encrypt encoded value using random key
		AESEncrypterDecrypter aesEncrypter = new AESEncrypterDecrypter();
		byte[] encryptedValue = aesEncrypter.encrypt(xmlRequest, key);

		// encode the encrypted request
		Base64EncoderDecoder encoder = new Base64EncoderDecoder();
		byte[] encodedValue = encoder.encode(encryptedValue);

		request.setRequestEncryptedValue(new String(encodedValue));
		logger.info("Request :" + new String(encodedValue));

		// encrypt symmetric key using bank's public key
		RSAEncrypterDecrypter rsaEncrypter = new RSAEncrypterDecrypter();
		logger.info("bank public key :" + bankPublicKey);
		byte[] symmetricKeyEncryptedValue = rsaEncrypter.encrypt(key, bankPublicKey);

		// encode symmetric key
		encodedValue = encoder.encode(symmetricKeyEncryptedValue);
		request.setSymmetricKeyEncryptedValue(new String(encodedValue));
		logger.info("Key :" + new String(encodedValue));

		request.setScope(scope);
		request.setTransactionId(transactionId);

		// Generate OAUTH token
//		OAuthTokenGenerator oauthTokenGenerator = new OAuthTokenGenerator();
		String oauthToken = "";
//				authTokenGenerator.getOAuthToken(clientId, clientSecret, clientScope);
//		String oauthToken = "f58805c0-6527-47df-be1b-7ebeba3c11ef";
		request.setOAuthTokenValue(oauthToken);

//		request.setRequestDigitalSignatureValue("");
//		request.setSessionDigitalSignatureValue("");
		// convert request object to json
		String gsonRequest = gson.toJson(request);

		return gsonRequest;
	}

	public String generatePanRequest(String xmlRequest, String scope, String transactionId)
			throws CertificateException, UnrecoverableEntryException, SAXException, IOException {
		PublicKey bankPublicKey = initPublicKey();
		JsonRequest request = new JsonRequest();
		// create XML Digital Signature for original XML Request
		/*
		 * XMLDigitalSignature xmlDigitalSignature = new XMLDigitalSignature(); String
		 * signedXML = xmlDigitalSignature.sign(xmlRequest, clientKeyStoreFilePath,
		 * clientKeyStorePassword, clientKeyAlias); signedXML =
		 * signedXML.substring(signedXML.indexOf('>')+1); Logger.info("Signed XML : "
		 * +signedXML);
		 */
		// generate 32 byte random key
		KeyGenerator keyGenerator = new KeyGenerator();
		byte[] key = keyGenerator.generateKey(32);

//	//encrypt encoded value using random key
//	AESEncrypterDecrypter aesEncrypter = new AESEncrypterDecrypter();
//	byte[] encryptedValue = aesEncrypter.encrypt(xmlRequest, key);

		// encode the encrypted request
		Base64EncoderDecoder encoder = new Base64EncoderDecoder();
		byte[] encodedValue = encoder.encode(xmlRequest);

		AESEncrypterDecrypter aesEncrypter = new AESEncrypterDecrypter();
		byte[] encryptedValue = aesEncrypter.encrypt(new String(encodedValue), key);

		request.setRequestSignatureEncryptedValue(new String(encryptedValue));
//	logger.info("Request :" + new String(encodedValue));

		byte[] encodedKey = encoder.encode(key);

		// encrypt symmetric key using bank's public key
		RSAEncrypterDecrypter rsaEncrypter = new RSAEncrypterDecrypter();
//	logger.info("bank public key :"+bankPublicKey);
		byte[] symmetricKeyEncryptedValue = rsaEncrypter.encrypt(encodedKey, bankPublicKey);

		// encode symmetric key
		encodedValue = encoder.encode(symmetricKeyEncryptedValue);
		request.setSymmetricKeyEncryptedValue(new String(encodedValue));
//	logger.info("Key :" + new String(encodedValue));

		request.setScope(scope);
		request.setTransactionId(transactionId);

		// Generate OAUTH token
//	OAuthTokenGenerator oauthTokenGenerator = new OAuthTokenGenerator();
		String oauthToken = authTokenGenerator.getOAuthToken(clientId, clientSecret, clientScope);
//	String oauthToken = "f58805c0-6527-47df-be1b-7ebeba3c11ef";
		request.setOAuthTokenValue(oauthToken);

		// convert request object to json
		String gsonRequest = gson.toJson(request);

		return gsonRequest;
	}

	/**
	 * Generate json request
	 * 
	 * @param xmlRequest    - original XML request without digital signature
	 * @param scope
	 * @param transactionId - Unique transaction Id for every request
	 * @return json request String
	 * @throws CertificateException        if any of the certificate in the key
	 *                                     store cannot be loaded
	 * @throws UnrecoverableEntryException if the password is invalid or unable to
	 *                                     retrieve private key
	 * @throws SAXException                if the XML passed to this method cannot
	 *                                     be parsed
	 * @throws IOException                 if unable to read public key file
	 */
	public String generatePanValidationRequest(String xmlRequest, String scope, String transactionId)
			throws CertificateException, UnrecoverableEntryException, SAXException, IOException {
		PublicKey bankPublicKey = initPublicKey();
		PanValidationJsonRequest request = new PanValidationJsonRequest();
		// create XML Digital Signature for original XML Request
		/*
		 * XMLDigitalSignature xmlDigitalSignature = new XMLDigitalSignature(); String
		 * signedXML = xmlDigitalSignature.sign(xmlRequest, clientKeyStoreFilePath,
		 * clientKeyStorePassword, clientKeyAlias); signedXML =
		 * signedXML.substring(signedXML.indexOf('>')+1); Logger.info("Signed XML : "
		 * +signedXML);
		 */
		// generate 32 byte random key
		KeyGenerator keyGenerator = new KeyGenerator();
		byte[] key = keyGenerator.generateKey(32);

		// encrypt encoded value using random key
		AESEncrypterDecrypter aesEncrypter = new AESEncrypterDecrypter();
		byte[] encryptedValue = aesEncrypter.encrypt(xmlRequest, key);

		// encode the encrypted request
		Base64EncoderDecoder encoder = new Base64EncoderDecoder();
		byte[] encodedValue = encoder.encode(encryptedValue);

		request.setRequestEncryptedValue(new String(encodedValue));
		// logger.info("Request :" + new String(encodedValue));

		// encrypt symmetric key using bank's public key
		RSAEncrypterDecrypter rsaEncrypter = new RSAEncrypterDecrypter();
		// logger.info("bank public key :"+bankPublicKey);
		byte[] symmetricKeyEncryptedValue = rsaEncrypter.encrypt(key, bankPublicKey);

		// encode symmetric key
		encodedValue = encoder.encode(symmetricKeyEncryptedValue);
		request.setSymmetricKeyEncryptedValue(new String(encodedValue));
		// logger.info("Key :" + new String(encodedValue));

		request.setScope(scope);
		request.setTransactionId(transactionId);

		// Generate OAUTH token
//		OAuthTokenGenerator oauthTokenGenerator = new OAuthTokenGenerator();
		String oauthToken = "";
//				authTokenGenerator.getOAuthToken(clientId, clientSecret, clientScope);
//		String oauthToken = "f58805c0-6527-47df-be1b-7ebeba3c11ef";
		request.setOAuthTokenValue(oauthToken);

		// convert request object to json
		String gsonRequest = gson.toJson(request);

		return gsonRequest;
	}

	/**
	 * Generate json request
	 * 
	 * @param xmlRequest    - original XML request without digital signature
	 * @param scope
	 * @param transactionId - Unique transaction Id for every request
	 * @return json request String
	 * @throws CertificateException        if any of the certificate in the key
	 *                                     store cannot be loaded
	 * @throws UnrecoverableEntryException if the password is invalid or unable to
	 *                                     retrieve private key
	 * @throws SAXException                if the XML passed to this method cannot
	 *                                     be parsed
	 * @throws IOException                 if unable to read public key file
	 */
	public String generateAadhaarKYCValidationRequest(String xmlRequest, String scope, String transactionId)
			throws CertificateException, UnrecoverableEntryException, SAXException, IOException {
		PublicKey bankPublicKey = initPublicKey();
		AadharKYCValidationJsonRequest request = new AadharKYCValidationJsonRequest();
		// create XML Digital Signature for original XML Request
		/*
		 * XMLDigitalSignature xmlDigitalSignature = new XMLDigitalSignature(); String
		 * signedXML = xmlDigitalSignature.sign(xmlRequest, clientKeyStoreFilePath,
		 * clientKeyStorePassword, clientKeyAlias); signedXML =
		 * signedXML.substring(signedXML.indexOf('>')+1); Logger.info("Signed XML : "
		 * +signedXML);
		 */
		// generate 32 byte random key
		KeyGenerator keyGenerator = new KeyGenerator();
		byte[] key = keyGenerator.generateKey(32);

		// encrypt encoded value using random key
		AESEncrypterDecrypter aesEncrypter = new AESEncrypterDecrypter();
		byte[] encryptedValue = aesEncrypter.encrypt(xmlRequest, key);

		// encode the encrypted request
		Base64EncoderDecoder encoder = new Base64EncoderDecoder();
		byte[] encodedValue = encoder.encode(encryptedValue);

		request.setRequestEncryptedValue(new String(encodedValue));
		logger.info("Request :" + new String(encodedValue));

		// encrypt symmetric key using bank's public key
		RSAEncrypterDecrypter rsaEncrypter = new RSAEncrypterDecrypter();
		logger.info("bank public key :" + bankPublicKey);
		byte[] symmetricKeyEncryptedValue = rsaEncrypter.encrypt(key, bankPublicKey);

		// encode symmetric key
		encodedValue = encoder.encode(symmetricKeyEncryptedValue);
		request.setSymmetricKeyEncryptedValue(new String(encodedValue));
		logger.info("Key :" + new String(encodedValue));

		request.setScope(scope);
		request.setTransactionId(transactionId);

		// Generate OAUTH token
//		OAuthTokenGenerator oauthTokenGenerator = new OAuthTokenGenerator();
		String oauthToken = "";
//				authTokenGenerator.getOAuthToken(clientId, clientSecret, clientScope);
//		String oauthToken = "f58805c0-6527-47df-be1b-7ebeba3c11ef";
		request.setOAuthTokenValue(oauthToken);

		// convert request object to json
		String gsonRequest = gson.toJson(request);

		return gsonRequest;
	}

	public String generatePosidexSevice(String xmlRequest, String scope, String transactionId)
			throws CertificateException, UnrecoverableEntryException, SAXException, IOException {
		PublicKey bankPublicKey = initPublicKey();
		PanValidationJsonRequest request = new PanValidationJsonRequest();
		// create XML Digital Signature for original XML Request
		/*
		 * XMLDigitalSignature xmlDigitalSignature = new XMLDigitalSignature(); String
		 * signedXML = xmlDigitalSignature.sign(xmlRequest, clientKeyStoreFilePath,
		 * clientKeyStorePassword, clientKeyAlias); signedXML =
		 * signedXML.substring(signedXML.indexOf('>')+1); Logger.info("Signed XML : "
		 * +signedXML);
		 */
		// generate 32 byte random key
		KeyGenerator keyGenerator = new KeyGenerator();
		byte[] key = keyGenerator.generateKey(32);

		// encrypt encoded value using random key
		AESEncrypterDecrypter aesEncrypter = new AESEncrypterDecrypter();
		byte[] encryptedValue = aesEncrypter.encrypt(xmlRequest, key);

		// encode the encrypted request
		Base64EncoderDecoder encoder = new Base64EncoderDecoder();
		byte[] encodedValue = encoder.encode(encryptedValue);

		request.setRequestEncryptedValue(new String(encodedValue));
		logger.info("Request :" + new String(encodedValue));

		// encrypt symmetric key using bank's public key
		RSAEncrypterDecrypter rsaEncrypter = new RSAEncrypterDecrypter();
		logger.info("bank public key :" + bankPublicKey);
		byte[] symmetricKeyEncryptedValue = rsaEncrypter.encrypt(key, bankPublicKey);

		// encode symmetric key
		encodedValue = encoder.encode(symmetricKeyEncryptedValue);
		request.setSymmetricKeyEncryptedValue(new String(encodedValue));
		logger.info("Key :" + new String(encodedValue));

		request.setScope(scope);
		request.setTransactionId(transactionId);

		// Generate OAUTH token
//		OAuthTokenGenerator oauthTokenGenerator = new OAuthTokenGenerator();
		String oauthToken = "";
//				authTokenGenerator.getOAuthToken(clientId, clientSecret, clientScope);
//		String oauthToken = "f58805c0-6527-47df-be1b-7ebeba3c11ef";
		request.setOAuthTokenValue(oauthToken);

		// convert request object to json
		String gsonRequest = gson.toJson(request);

		return gsonRequest;
	}

	public String generateLeadInstaRequest(String xmlRequest, String scope, String transactionId)
			throws CertificateException, UnrecoverableEntryException, SAXException, IOException {
		PublicKey bankPublicKey = initPublicKey();
		JsonRequest request = new JsonRequest();
		// create XML Digital Signature for original XML Request
		/*
		 * XMLDigitalSignature xmlDigitalSignature = new XMLDigitalSignature(); String
		 * signedXML = xmlDigitalSignature.sign(xmlRequest, clientKeyStoreFilePath,
		 * clientKeyStorePassword, clientKeyAlias); signedXML =
		 * signedXML.substring(signedXML.indexOf('>')+1); Logger.info("Signed XML : "
		 * +signedXML);
		 */
		// generate 32 byte random key
		KeyGenerator keyGenerator = new KeyGenerator();
		byte[] key = keyGenerator.generateKey(32);

		// encrypt encoded value using random key
		AESEncrypterDecrypter aesEncrypter = new AESEncrypterDecrypter();
		byte[] encryptedValue = aesEncrypter.encrypt(xmlRequest, key);

		// encode the encrypted request
		Base64EncoderDecoder encoder = new Base64EncoderDecoder();
		byte[] encodedValue = encoder.encode(encryptedValue);

		request.setRequestSignatureEncryptedValue(new String(encodedValue));
//	logger.info("Request :" + new String(encodedValue));

		// encrypt symmetric key using bank's public key
		RSAEncrypterDecrypter rsaEncrypter = new RSAEncrypterDecrypter();
//	logger.info("bank public key :"+bankPublicKey);
		byte[] symmetricKeyEncryptedValue = rsaEncrypter.encrypt(key, bankPublicKey);

		// encode symmetric key
		encodedValue = encoder.encode(symmetricKeyEncryptedValue);
		request.setSymmetricKeyEncryptedValue(new String(encodedValue));
//	logger.info("Key :" + new String(encodedValue));

		request.setScope(scope);
		request.setTransactionId(transactionId);

		// Generate OAUTH token
//	OAuthTokenGenerator oauthTokenGenerator = new OAuthTokenGenerator();
		String oauthToken = authTokenGenerator.getOAuthToken(LeadInstaClientID, LeadInstaSecret, LEADINSTA_SCOPE);
//	String oauthToken = "f58805c0-6527-47df-be1b-7ebeba3c11ef";
		request.setOAuthTokenValue(oauthToken);

		// convert request object to json
		String gsonRequest = gson.toJson(request);

		return gsonRequest;
	}

	public String generateIMPSRequestHigh(String xmlRequest, String scope, String transactionId)
			throws CertificateException, UnrecoverableEntryException, SAXException, IOException {
		PublicKey bankPublicKey = initPublicKey();
		JsonRequest request = new JsonRequest();
		// generate 32 byte random key
		KeyGenerator keyGenerator = new KeyGenerator();
		byte[] key = keyGenerator.generateKey(32);

		// encrypt encoded value using random key
		AESEncrypterDecrypter aesEncrypter = new AESEncrypterDecrypter();
		byte[] encryptedValue = aesEncrypter.encrypt(xmlRequest, key);

		// encode the encrypted request
		Base64EncoderDecoder encoder = new Base64EncoderDecoder();
		byte[] encodedValue = encoder.encode(encryptedValue);

		request.setRequestSignatureEncryptedValue(new String(encodedValue));
		// logger.info("Request :" + new String(encodedValue));

		// encrypt symmetric key using bank's public key
		RSAEncrypterDecrypter rsaEncrypter = new RSAEncrypterDecrypter();
		// logger.info("bank public key :"+bankPublicKey);
		byte[] symmetricKeyEncryptedValue = rsaEncrypter.encrypt(key, bankPublicKey);

		// encode symmetric key
		encodedValue = encoder.encode(symmetricKeyEncryptedValue);
		request.setSymmetricKeyEncryptedValue(new String(encodedValue));
		// logger.info("Key :" + new String(encodedValue));

		request.setScope(scope);
		request.setTransactionId(transactionId);

		// Generate OAUTH token
		String oauthToken = authTokenGenerator.getOAuthToken(IMPS_API_CLIENT_ID, IMPS_API_SECRET_KEY, scope);
		request.setOAuthTokenValue(oauthToken);

		// convert request object to json
		String gsonRequest = gson.toJson(request);

		return gsonRequest;
	}

	public String generateIMPSRequestLow(String xmlRequest, String scope, String transactionId)
			throws CertificateException, UnrecoverableEntryException, SAXException, IOException {

		PublicKey bankPublicKey = initPublicKey();
		LeadStatusJsonRequest request = new LeadStatusJsonRequest();
		// create XML Digital Signature for original XML Request
		// generate 32 byte random key
		KeyGenerator keyGenerator = new KeyGenerator();
		byte[] key = keyGenerator.generateKey(32);

		// encrypt encoded value using random key
		AESEncrypterDecrypter aesEncrypter = new AESEncrypterDecrypter();
		byte[] encryptedValue = aesEncrypter.encrypt(xmlRequest, key);

		// encode the encrypted request
		Base64EncoderDecoder encoder = new Base64EncoderDecoder();
		byte[] encodedValue = encoder.encode(encryptedValue);

		request.setRequestEncryptedValue(new String(encodedValue));

		// encrypt symmetric key using bank's public key
		RSAEncrypterDecrypter rsaEncrypter = new RSAEncrypterDecrypter();
		byte[] symmetricKeyEncryptedValue = rsaEncrypter.encrypt(key, bankPublicKey);

		// encode symmetric key
		encodedValue = encoder.encode(symmetricKeyEncryptedValue);
		request.setSymmetricKeyEncryptedValue(new String(encodedValue));

		request.setScope(scope);
		request.setTransactionId(transactionId);
		String oauthToken = "";
		request.setOAuthTokenValue(oauthToken);

		// convert request object to json
		String gsonRequest = gson.toJson(request);

		return gsonRequest;
	}

	public static void main(String[] args) {
		try {

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
