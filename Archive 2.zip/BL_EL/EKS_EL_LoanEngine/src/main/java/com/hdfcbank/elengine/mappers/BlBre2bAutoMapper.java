package com.hdfcbank.elengine.mappers;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.hdfcbank.elengine.domain.request.bre.blbre2b.InitBlBre2bApplication;
import com.hdfcbank.elengine.domain.response.perfios.sme.StandardVariables;

@Mapper
public interface BlBre2bAutoMapper {

	BlBre2bAutoMapper INSTANCE =  Mappers.getMapper(BlBre2bAutoMapper.class);
	
	
	@Mapping(target = "aqb",expression = "java(MapperUtils.defaultSetToDouble(standardVariables.aqb))")
	@Mapping(target = "ttlnetcreditInl6mon",expression = "java(MapperUtils.defaultSetToDouble(standardVariables.totalNetCreditInLast6Months))")
	@Mapping(target = "ttltrunccreditInl6mon",expression = "java(MapperUtils.defaultSetToDouble(standardVariables.totalTruncCreditInLast6Months))")
	@Mapping(target = "avgutilizationInl6mon",expression = "java(MapperUtils.defaultSetToDouble(standardVariables.avgUtilizationInLast6Months))")
	@Mapping(target = "maxutilizationInl6mon", expression = "java(MapperUtils.defaultSetToDouble(standardVariables.maxUtilizationInLast6Months))")
	@Mapping(target = "inwchqreturnInl3mon", expression = "java(MapperUtils.defaultSetToDouble(standardVariables.inwChqReturnInLast3Months))")
	@Mapping(target = "oputwchqreturnInl3mon",expression = "java(MapperUtils.defaultSetToDouble(standardVariables.outwChqReturnInLast3Months))")
	@Mapping(target = "maxintrestServdays",expression = "java(MapperUtils.defaultSetToDouble(standardVariables.maxInterestServicingDays))")
	@Mapping(target = "todInl3mon", expression = "java(MapperUtils.defaultSetToDouble(standardVariables.tODInLast3Months))")
	@Mapping(target = "noNetcredits",expression = "java(MapperUtils.defaultSetToDouble(standardVariables.noOfNetCredits))")
	@Mapping(target = "noTrunccredits",expression = "java(MapperUtils.defaultSetToDouble(standardVariables.noOfTruncCredits))")
	@Mapping(target = "noTruncdebits", expression = "java(MapperUtils.defaultSetToDouble(standardVariables.noOfTruncDebits))")
	@Mapping(target = "apiPerfiosSmeFiller1", constant = "null")
	@Mapping(target = "apiPerfiosSmeFiller2", constant = "null")
	@Mapping(target = "apiPerfiosSmeFiller3", constant = "null")
	@Mapping(target = "apiPerfiosSmeFiller4", constant = "null")
	@Mapping(target = "apiPerfiosSmeFiller5", constant = "null")
	@Mapping(target = "apiPerfiosSmeFiller6", constant = "null")
	@Mapping(target = "apiPerfiosSmeFiller7", constant = "null")
	@Mapping(target = "apiPerfiosSmeFiller8", constant = "null")
	@Mapping(target = "apiPerfiosSmeFiller9", constant = "null")
	@Mapping(target = "apiPerfiosSmeFiller10", constant = "null")
	@Mapping(target = "apiPerfiosSmeFiller11", constant = "null")
	@Mapping(target = "apiPerfiosSmeFiller12", constant = "null")
	@Mapping(target = "apiPerfiosSmeFiller13", constant = "null")
	@Mapping(target = "apiPerfiosSmeFiller14", constant = "null")
	@Mapping(target = "apiPerfiosSmeFiller15", constant = "null")
	@Mapping(target = "apiPerfiosSmeFiller16", constant = "null")
	@Mapping(target = "apiPerfiosSmeFiller17", constant = "null")
	@Mapping(target = "apiPerfiosSmeFiller18", constant = "null")
	@Mapping(target = "apiPerfiosSmeFiller19", constant = "null")
	@Mapping(target = "apiPerfiosSmeFiller20", constant = "null")
	@Mapping(target = "apiPerfiosSmeFiller21", constant = "null")
	@Mapping(target = "apiPerfiosSmeFiller22", constant = "null")
	@Mapping(target = "apiPerfiosSmeFiller23", constant = "null")
	@Mapping(target = "apiPerfiosSmeFiller24", constant = "null")
	@Mapping(target = "apiPerfiosSmeFiller25", constant = "null")
	@Mapping(target = "apiPerfiosSmeFiller26", constant = "null")
	@Mapping(target = "apiPerfiosSmeFiller27", constant = "null")
	@Mapping(target = "apiPerfiosSmeFiller28", constant = "null")
	@Mapping(target = "apiPerfiosSmeFiller29", constant = "null")
	@Mapping(target = "apiPerfiosSmeFiller30", constant = "null")
	InitBlBre2bApplication mapBre2bApplication(StandardVariables standardVariables);
	
}
