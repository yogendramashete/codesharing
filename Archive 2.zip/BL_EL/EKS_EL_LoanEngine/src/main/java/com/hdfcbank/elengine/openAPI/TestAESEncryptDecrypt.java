package com.hdfcbank.elengine.openAPI;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class TestAESEncryptDecrypt  {
	public final static Logger logger = LoggerFactory.getLogger(DigitalSignature.class);

	public void testEncryptionDecryption() {
		String value = "Hello World";
		
		KeyGenerator keyGenerator = new KeyGenerator();
		byte[] key = keyGenerator.generateKey(32);
		AESEncrypterDecrypter encrypterDecrypter = new AESEncrypterDecrypter();
		byte[] encryptedValue = encrypterDecrypter.encrypt(value, key);
		byte[] decryptedValue = encrypterDecrypter.decrypt(encryptedValue, key);
		
		logger.info("enc value :"+new String(encryptedValue));
		logger.info("dec value :"+new String(decryptedValue));
	}

}
