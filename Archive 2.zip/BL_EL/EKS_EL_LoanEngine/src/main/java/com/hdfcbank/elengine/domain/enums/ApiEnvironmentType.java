package com.hdfcbank.elengine.domain.enums;

public enum ApiEnvironmentType {


	HUNTER("hunter.api.environment"),POSIDEX("posidex.api.environment");

	private final String code;

	private ApiEnvironmentType(String code) {
		this.code = code;
	}

	public String toInt() {
		return code;
	}

	public String toString() {
		return String.valueOf(code);
	}

}
