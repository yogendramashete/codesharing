package com.hdfcbank.elengine.openAPI;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;
import java.nio.file.Files;
import java.security.InvalidAlgorithmParameterException;
import java.security.Key;
import java.security.KeyFactory;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.UnrecoverableEntryException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.xml.crypto.AlgorithmMethod;
import javax.xml.crypto.KeySelector;
import javax.xml.crypto.KeySelectorException;
import javax.xml.crypto.KeySelectorResult;
import javax.xml.crypto.MarshalException;
import javax.xml.crypto.XMLCryptoContext;
import javax.xml.crypto.XMLStructure;
import javax.xml.crypto.dsig.CanonicalizationMethod;
import javax.xml.crypto.dsig.DigestMethod;
import javax.xml.crypto.dsig.Reference;
import javax.xml.crypto.dsig.SignedInfo;
import javax.xml.crypto.dsig.XMLSignature;
import javax.xml.crypto.dsig.XMLSignatureException;
import javax.xml.crypto.dsig.XMLSignatureFactory;
import javax.xml.crypto.dsig.dom.DOMSignContext;
import javax.xml.crypto.dsig.dom.DOMValidateContext;
import javax.xml.crypto.dsig.keyinfo.KeyInfo;
import javax.xml.crypto.dsig.keyinfo.KeyInfoFactory;
import javax.xml.crypto.dsig.keyinfo.X509Data;
import javax.xml.crypto.dsig.spec.C14NMethodParameterSpec;
import javax.xml.crypto.dsig.spec.SignatureMethodParameterSpec;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Result;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

/**
 * Digitally sign XML using the client's private key. 
 * @author Madhura Oak
 *
 */
public class XMLDigitalSignature {
	
	
	private static final String DOM = "DOM";
	private static final String RSA = "RSA";
	private static final String JKS = "JKS";
	private static final String ID = "Id";
	private static final String URI = "URI";
	private static final String HYPHEN = "-";
	private static final String HASH = "#";
	private static final String RSA_SHA_256 = "http://www.w3.org/2001/04/xmldsig-more#rsa-sha256";
	private static final String SIGNATURE = "Signature";
	private static final String REQUEST = "request";
	private static final String REFERENCE = "Reference";
	private static final String RESPONSE ="response";
	private static final String CANNOT_FIND_SIGNATURE = "Cannot find Signature element";
	
	private XMLSignatureFactory factory = XMLSignatureFactory.getInstance(DOM);
	private TransformerFactory transformerFactory = TransformerFactory.newInstance();
	private DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
	private DocumentBuilder documentBuilder;
	
	public XMLDigitalSignature() {
		try {
			documentBuilderFactory.setNamespaceAware(true);
			documentBuilder = documentBuilderFactory.newDocumentBuilder();			
		}
		catch(ParserConfigurationException exp) {
			//TODO handle this exception
		}
	}
	
	/**
	 * Get private key located at file path
	 * @param private key file path
	 * @return private key
	 */
	private PrivateKey getPrivateKey(String privateKeyFilePath) throws IOException, NoSuchAlgorithmException, InvalidKeySpecException {
		byte[] keyBytes = Files.readAllBytes(new File(privateKeyFilePath).toPath());
		PKCS8EncodedKeySpec spec = new PKCS8EncodedKeySpec(keyBytes);
		KeyFactory kf = KeyFactory.getInstance(RSA);
		return kf.generatePrivate(spec);
	}
	
	/**
	 * Returns ID attribute value of Document element. If is doesn't exist then creates an ID attribute on Document element and returns the ID value 
	 * @param xml Document to be signed
	 * @return value of ID attribute
	 */
	private String generateOrGetId(Document xmlDocument) {
		StringBuilder builder = new StringBuilder();
		if(xmlDocument.getDocumentElement().hasAttribute(ID)) {
			builder.append(xmlDocument.getDocumentElement().getAttribute(ID));
		}
		else {
			//generate new ID 
			KeyGenerator keyGenerator = new KeyGenerator();
			builder.append(keyGenerator.generateAlphaNumericKey(32));
			
		}
		return builder.toString();
	}
	
	
	/**
	 * Digitally sign XML document. This method takes Document element of the XML to be digitally signed as an argument and returns Document element containing 
	 * digitally signed XML.
	 * @param xmlDocument - Document object representing the XML document to be signed
	 * @param keyStoreFilePath - Key Store path containing private key used for digital signature and public key to be included in signature
	 * @param keyStorePassword - Key store password
	 * @param keyAlias - Alias of private key
	 * @return Digitally signed XML Document element
	 * @throws CertificateException if any of the certificate in the key store cannot be loaded
	 * @throws UnrecoverableEntryException if the password is invalid or unable to retrieve private key 
	 */
	public Document sign(Document xmlDocument, String keyStoreFilePath, String keyStorePassword, String keyAlias,String pfxPath,String pfxPassWord) throws CertificateException, UnrecoverableEntryException {
		Document signedDocument = null;
			
		try {
			//get ID of Document element
			String id = generateOrGetId(xmlDocument);
			//Logger.info(xmlDocument.getDocumentElement());
			
			//create Id attribute in request element
			xmlDocument.getDocumentElement().setAttribute(ID, id);
			xmlDocument.getDocumentElement().setIdAttribute(ID, true);
			
			Document requestDocument = documentBuilder.newDocument();
			Element requestElement = requestDocument.createElement(REQUEST);
			requestDocument.appendChild(requestElement);
			
			//add original request xml
			Node copy = requestDocument.importNode(xmlDocument.getDocumentElement(), true);
			requestElement.appendChild(copy);
			 
			Reference ref = factory.newReference(HASH+id, factory.newDigestMethod(DigestMethod.SHA256, null));
					
			SignedInfo si = factory.newSignedInfo(factory.newCanonicalizationMethod(CanonicalizationMethod.INCLUSIVE,
					(C14NMethodParameterSpec) null),
					factory.newSignatureMethod(RSA_SHA_256,(SignatureMethodParameterSpec)null),
					Collections.singletonList(ref));

			//get private key from key store
			/*
			 * KeyStore ks = KeyStore.getInstance(JKS); ks.load(new
			 * FileInputStream(keyStoreFilePath), keyStorePassword.toCharArray());
			 * KeyStore.PrivateKeyEntry privateKeyEntry = (KeyStore.PrivateKeyEntry)
			 * ks.getEntry(keyAlias, new
			 * KeyStore.PasswordProtection(keyStorePassword.toCharArray())); PrivateKey
			 * privateKey = privateKeyEntry.getPrivateKey();
			 * 
			 * //get certificate X509Certificate certificate = (X509Certificate)
			 * privateKeyEntry.getCertificate();
			 */
			
			//get private key from key store
			KeyStore ks = KeyStore.getInstance(JKS);
			ks.load(new FileInputStream(keyStoreFilePath), keyStorePassword.toCharArray());		
//			 System.out.println("get certificate :"+ks.getCertificate(keyAlias));
			
			KeyStore.PrivateKeyEntry privateKeyEntry = (KeyStore.PrivateKeyEntry) ks.getEntry(keyAlias, new KeyStore.PasswordProtection(keyStorePassword.toCharArray()));
//			System.out.println("privatekey entry :"+privateKeyEntry);
			PrivateKey privateKey =   DigitalSignature.privateKey(pfxPath, pfxPassWord);
//					privateKeyEntry.getPrivateKey();
			
			//get certificate
			X509Certificate certificate = (X509Certificate)ks.getCertificate("techepochroot");
//					(keyAlias, new KeyStore.PasswordProtection(keyStorePassword.toCharArray()));
//					privateKeyEntry.getCertificate();
		
			
			KeyInfoFactory kif = factory.getKeyInfoFactory();			
			List x509Content = new ArrayList();
			x509Content.add(certificate.getSubjectX500Principal().getName());
			x509Content.add(certificate);
			X509Data xd = kif.newX509Data(x509Content);
			KeyInfo ki = kif.newKeyInfo(Collections.singletonList(xd));
			
			//create new Document that will hold XML signature
			Document signDocument = documentBuilder.newDocument();
			DOMSignContext dsc = new DOMSignContext(privateKey, signDocument);
			//dsc.setParent(requestElement);
			dsc.setIdAttributeNS((Element)xmlDocument.getDocumentElement(), xmlDocument.getNamespaceURI(), ID);			
			
			//create new XML Signature
			XMLSignature signature = factory.newXMLSignature(si, ki);
			
			//Marshal and generate the detached XML Signature. The DOM element will contain XML Signature if this method returns successfully. 
			signature.sign(dsc);
			
			//Node reference = signDocument.getElementsByTagName(REFERENCE).item(0);
			//reference.getAttributes().getNamedItem(URI).setNodeValue(HASH+id);

			//add signature element
			copy = requestDocument.importNode(signDocument.getDocumentElement(), true);
			requestElement.appendChild(copy);

			signedDocument = requestDocument;
		}
		catch(IOException exp) {
			exp.printStackTrace();
		}
		catch(NoSuchAlgorithmException exp) {
			//TODO handle this exception
			exp.printStackTrace();
		}
		catch(InvalidAlgorithmParameterException exp) {
			//TODO handle this exception
			exp.printStackTrace();
		}
		catch(KeyStoreException exp) {
			//TODO handle this exception
			exp.printStackTrace();
		}
		catch(XMLSignatureException exp) {
			//TODO handle this exception
			exp.printStackTrace();
		}
		catch(CertificateException exp) {
			//TODO handle this exception
		exp.printStackTrace();
		}
		catch(MarshalException exp) {
			//TODO handle this exception
			exp.printStackTrace();
		}
		return signedDocument;
	}
	
	private Document getXMLDocument(InputSource in) throws ParserConfigurationException, IOException, SAXException {
		Document XMLDocument = documentBuilder.parse(in);
		return XMLDocument;
	}
		
	private Document getSignedXMLDocument(InputSource in, String keyStoreFilePath, String keyStorePassword, String keyAlias,
			String pfxPath ,String pfxPassword) 
			throws ParserConfigurationException, IOException, SAXException, UnrecoverableEntryException, CertificateException {
		Document XMLDocument = getXMLDocument(in);
		return sign(XMLDocument, keyStoreFilePath, keyStorePassword, keyAlias,pfxPath,pfxPassword);
	}
	
	private void writeSignedXMLDocument(Document signedXMLDocument, Writer writer) throws TransformerConfigurationException, TransformerException {
		Transformer transformer = transformerFactory.newTransformer();
		Result result = new StreamResult(writer);
		transformer.transform(new DOMSource(signedXMLDocument), result);
	}

	/**
	 * Digitally sign XML document. This method takes XML document to be signed as a String as an argument. The digitally signed XML is returned as a String.  
	 * @param xmlDocument - String containing xml document to be signed
	 * @param keyStoreFilePath - path of key store file
	 * @param keyStorePassword - password to access key store file
	 * @param keyAlias - key alias of private key
	 * @return signed XML document as String 
	 * @throws CertificateException if any of the certificate in the key store cannot be loaded
	 * @throws UnrecoverableEntryException if the password is invalid or unable to retrieve private key 
	 * @throws SAXException if the xml document to be signed cannot be parsed 
	 */
	public String sign(String xmlDocument, String keyStoreFilePath, String keyStorePassword, String keyAlias,String pfxPath,String PfxPassword) throws CertificateException, UnrecoverableEntryException, 
			SAXException {
		String signedXML = null;
		try {
			InputSource in = new InputSource(new StringReader(xmlDocument));
			Document signedXMLDocument = getSignedXMLDocument(in, keyStoreFilePath, keyStorePassword, keyAlias,pfxPath,PfxPassword);
			StringWriter writer = new StringWriter();
			writeSignedXMLDocument(signedXMLDocument, writer);
			signedXML = writer.getBuffer().toString();
		}
		catch(ParserConfigurationException exp) {
			//TODO handle this exception
		}
		catch(IOException exp) {
			//TODO handle this exception
		}
		catch(TransformerConfigurationException exp) {
			//TODO handle this exception
		}
		catch(TransformerException exp) {
			//TODO handle this exception
		}catch(Exception e) {
			e.printStackTrace();
		}
		return signedXML;
	}
	
	/**
	 * Digitally sign XML document. This method takes File object of the XML to be digitally signed as an argument. A digitally signed XML is created at the file path
	 * mentioned in signedXMLFilePath argument. 
	 * @param xmlDocument - File object representing the xmlDocument to be digitally signed
	 * @param keyStoreFilePath - path of key store file
	 * @param keyStorePassword - password to access key store file
	 * @param keyAlias - key alias of private key
	 * @param signedXMLFilePath - path of the signed XML document to be created
	 * @throws CertificateException if any of the certificate in the key store cannot be loaded
	 * @throws UnrecoverableEntryException if the password is invalid or unable to retrieve private key 
	 * @throws SAXException if the xml document to be signed cannot be parsed 
	 * @throws FileNotFoundException if the file containing xmlDocument to be signed is not found
	 */
	public void sign(File xmlDocument, String keyStoreFilePath, String keyStorePassword, String keyAlias, String signedXMLFilePath,
			String pfxPath, String pfxPassword) 
			throws CertificateException, UnrecoverableEntryException, SAXException, FileNotFoundException {
		try {		
			InputSource in = new InputSource(new FileReader(xmlDocument));
			Document signedXMLDocument = getSignedXMLDocument(in, keyStoreFilePath, keyStorePassword, keyAlias,pfxPath,pfxPassword);
			FileWriter fileWriter = new FileWriter(new File(signedXMLFilePath));
			writeSignedXMLDocument(signedXMLDocument, fileWriter);
		}
		catch(ParserConfigurationException exp) {
			//TODO handle this exception
		}
		catch(IOException exp) {
			//TODO handle this exception
		}
		catch(TransformerConfigurationException exp) {
			//TODO handle this exception
		}
		catch(TransformerException exp) {
			//TODO handle this exception
		}		
	}
	
	/**
	 * Remove Signature element from response XML. Also remove the response parent element and return original response xml. 
	 * @param xmlDocument
	 * @return
	 * @throws SAXException
	 */
	public String removeSignature(String xmlDocument) throws SAXException {
		String responseXML = null;
		try {
			//parse String xml response to Document object
			InputSource in = new InputSource(new StringReader(xmlDocument));
			Element xml = getXMLDocument(in).getDocumentElement();
			
			NodeList nl = xml.getChildNodes();
			
			//remove signature element from response XML
			Node signatureNode = null;
			for(int i=0; i < nl.getLength(); i++) {
				Node node = nl.item(i);
				if(node.getNodeType() == Node.ELEMENT_NODE && node.getLocalName().equals(SIGNATURE)) {
					signatureNode = node;
					break;
				}
			}
			
			xml.removeChild(signatureNode);
			
			
			//get first element from response
			Node originalResponse = null;
			for(int i=0; i < nl.getLength(); i++) {
				Node node = nl.item(i);
				if(node.getNodeType() == Node.ELEMENT_NODE) {
					originalResponse = node;
					break;
				}
			}
			  
			Transformer transformer = transformerFactory.newTransformer();
			StringWriter writer = new StringWriter();
			transformer.transform(new DOMSource(originalResponse), new StreamResult(writer));
			responseXML = writer.getBuffer().toString();
		}
		catch(ParserConfigurationException exp) {
			//TODO handle this exception
		}
		catch(TransformerException exp) {
			//TODO handle this exception
		}
		catch(IOException exp) {
			//TODO handle this exception
		}
		return responseXML;
	}
	
	/**
	 * Validate signature element in response XML. This method returns true if signature is valid. 
	 * @param xmlDocument - string XML of response containing Signature element to be validated
	 * @return true if signature is valid. false if invalid.
	 * @throws SAXException if cannot parse response XML document
	 * @throws MarshalException if unable to marshal XML signature
	 * @throws XMLSignatureException 
	 * @throws IllegalArgumentException if Signature element is not found in response XML
	 */
	public boolean validate(String xmlDocument) throws SAXException, MarshalException, XMLSignatureException {
		boolean valid = false;
		try {
			InputSource in = new InputSource(new StringReader(xmlDocument));
			Document XMLDocument = getXMLDocument(in);
			Node responseElement = XMLDocument.getElementsByTagName(RESPONSE).item(0);
			NodeList nl = responseElement.getChildNodes();			
			Node signatureNode = null;
			for(int i=0; i < nl.getLength(); i++) {
				Node node = nl.item(i);
				//Logger.info(node);
				//Logger.info(node.getNamespaceURI());
				if(node.getNamespaceURI() != null && node.getNamespaceURI().equals(XMLSignature.XMLNS) && node.getLocalName().equals(SIGNATURE)) {
					signatureNode = node;
					break;
				}
			}
			
			Node responseNode = null;
			for(int i=0; i < nl.getLength(); i++) {
				Node node = nl.item(i);
				//Logger.info(node);
				//Logger.info(node.getNamespaceURI());
				if(node.getNodeType() == Node.ELEMENT_NODE && !(node.getNamespaceURI() != null && node.getNamespaceURI().equals(XMLSignature.XMLNS) && node.getLocalName().equals(SIGNATURE))) {
					responseNode = node;
					break;
				}
			}

					
			if (signatureNode == null) {
			    throw new IllegalArgumentException(CANNOT_FIND_SIGNATURE);
			}
			DOMValidateContext valContext = new DOMValidateContext(new X509KeySelector(), signatureNode);
			if(responseNode != null) {
				valContext.setIdAttributeNS((Element)responseNode, responseNode.getNamespaceURI(), ID);
			}
			XMLSignature signature = factory.unmarshalXMLSignature(valContext);

			valid = signature.validate(valContext);			
		}
		catch(ParserConfigurationException exp) {
			//TODO handle this exception
		}
		catch(IOException exp) {
			//TODO handle this exception
		}
		return valid;
	}
	
	class X509KeySelector extends KeySelector {
		private static final String NO_DATA_FOUND = "No key found!";

		public KeySelectorResult select(KeyInfo keyInfo, Purpose purpose, AlgorithmMethod method, XMLCryptoContext context) throws KeySelectorException {
			List structures = keyInfo.getContent();
			for(Object structure : structures) {
				XMLStructure xmlStructure = (XMLStructure) structure;
				if(xmlStructure instanceof X509Data) {
					X509Data x509Data = (X509Data) xmlStructure;
		            List certificates = x509Data.getContent();
		            for(Object certificate : certificates) {
		            	if(certificate instanceof X509Certificate) {
			            	X509Certificate cert = (X509Certificate) certificate;
			            	if(cert instanceof X509Certificate) {
			            		PublicKey key = cert.getPublicKey();
			            		if(key.getAlgorithm().equalsIgnoreCase(RSA) && method.getAlgorithm().equalsIgnoreCase(RSA_SHA_256)) {
			            			return new KeySelectorResult() {							
			            				public Key getKey() {
			            					return key;
										}
									};
			            		}		            		
			            	}
		            	}
		            }
				}
			}
			throw new KeySelectorException(NO_DATA_FOUND);
		}
	}
}
