package com.hdfcbank.elengine.domain.request;

import javax.validation.constraints.NotBlank;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@Data
@NoArgsConstructor
@AllArgsConstructor
public class InitiatePerfios {
	
	@NotBlank(message = "perfios txnid may not be blank")
	private String txnId;
   
	@NotBlank(message = "mobile number may not be blank")
	private String mobileNumber;
   
	@NotBlank(message = "ackId may not be blank")
	private String ackId;
   
	@NotBlank(message = "product may not be blank")
	private String product;
   
	
	
}
