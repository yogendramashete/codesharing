package com.hdfcbank.elengine.domain.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class Bre3AppData {
	public Float appofficeBureauMatchPerc;
	public Float appofficePerfiosMatchPerc;
	public Float appresiBureauMatchPerc;
	public Float appresiPerfiosMatchPerc;
	public String customerResidenceAddress;
	public String customerOfficeAddress;
	public String addressFromBureauOff;
	public String customerName;
	public String nameFromBureau;
	public String addressPerfios;
	public String addressFromBureauResi;
	public String splitTime;
}
