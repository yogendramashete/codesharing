package com.hdfcbank.elengine.domain.entity;

import java.time.OffsetDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.hdfcbank.elengine.domain.enums.PosidexDedupeServiceType;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Table(name = "el_dedupeposidex_auditlogs")
@Entity
@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class PosidexDedupeEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	@Column(name =  "mobileno")
	@Pattern(regexp="(^$|[0-9]{10})",message = "mobile number must be 10 digit")
	private String mobileNo;
	
	@Column(name = "request")
	private String request;
	
	@Column(name = "response")
	private String response;
	
	@Column(name = "creationdate")
	@Pattern(regexp = "^\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2}:\\d{3}")
	private OffsetDateTime creationdate;
	
	@Column(name = "updateddate")
	@Pattern(regexp = "^\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2}:\\d{3}")
	private OffsetDateTime updateddate;
	
	@Column(name = "product")
	@Pattern(regexp = "^[a-zA-Z]*$",message = "enter proper product code")
	private String product;
	
	@Column(name = "operationtype")
	@Pattern(regexp = "^[a-zA-Z]*$",message = "enter proper operationtype")
	@Enumerated(EnumType.STRING)
	private PosidexDedupeServiceType operationtype;
	
	@Column(name = "status")
	@Pattern(regexp = "^[a-zA-Z]*$",message = "enter proper status")
	private String status;
	
	@Column(name = "tranrefnumber")
	@Pattern(regexp="(^$|[0-9]{12})",message = "tranRefNumber must be 12 digit")
	private String tranRefNumber;

	public PosidexDedupeEntity(String mobileNo, String request, String response, OffsetDateTime creationdate,
			OffsetDateTime updateddate, String product, PosidexDedupeServiceType operationtype, String status,
			String tranRefNumber) {
		super();
		this.mobileNo = mobileNo;
		this.request = request;
		this.response = response;
		this.creationdate = creationdate;
		this.updateddate = updateddate;
		this.product = product;
		this.operationtype = operationtype;
		this.status = status;
		this.tranRefNumber = tranRefNumber;
	}
	
	
}
