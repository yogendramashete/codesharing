package com.hdfcbank.elengine.service.impl;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.function.Supplier;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.json.JSONObject;
import org.json.XML;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import com.hdfcbank.elengine.client.OpenBankApiConnector;
import com.hdfcbank.elengine.client.UrlConnection;
import com.hdfcbank.elengine.constant.AppConstants;
import com.hdfcbank.elengine.constant.ConstantMessages;
import com.hdfcbank.elengine.constant.RedisConstants;
import com.hdfcbank.elengine.domain.entity.BreServiceEntity;
import com.hdfcbank.elengine.domain.entity.HunterEntity;
import com.hdfcbank.elengine.domain.entity.MBEntity;
import com.hdfcbank.elengine.domain.entity.PerfiosEntity;
import com.hdfcbank.elengine.domain.entity.PosidexDedupeEntity;
import com.hdfcbank.elengine.domain.enums.ApiResponseType;
import com.hdfcbank.elengine.domain.enums.BreServiceType;
import com.hdfcbank.elengine.domain.enums.ConstitutionType;
import com.hdfcbank.elengine.domain.enums.EmploymentType;
import com.hdfcbank.elengine.domain.enums.HunterType;
import com.hdfcbank.elengine.domain.enums.LappProductId;
import com.hdfcbank.elengine.domain.enums.LappTermIn;
import com.hdfcbank.elengine.domain.enums.MBServiceType;
import com.hdfcbank.elengine.domain.enums.PerfiosResponseType;
import com.hdfcbank.elengine.domain.enums.PosidexDedupeServiceType;
import com.hdfcbank.elengine.domain.request.InitIncomeOffer;
import com.hdfcbank.elengine.domain.request.InitiateBlBrebApp;
import com.hdfcbank.elengine.domain.request.InitiateHunter;
import com.hdfcbank.elengine.domain.request.InitiateMBRequest;
import com.hdfcbank.elengine.domain.request.InitiatePerfios;
import com.hdfcbank.elengine.domain.request.InitiatePosidexDedupe;
import com.hdfcbank.elengine.domain.request.bre.BlApplication;
import com.hdfcbank.elengine.domain.request.bre.BlLosInputFromsa;
import com.hdfcbank.elengine.domain.request.bre.blbre1b.BlBre1bApplication;
import com.hdfcbank.elengine.domain.request.bre.blbre2a.Bre1bOutput;
import com.hdfcbank.elengine.domain.request.bre.blbre2a.InitBlbre2aApplication;
import com.hdfcbank.elengine.domain.request.bre.blbre2a.PerfiosSmeUrlgenDtl;
import com.hdfcbank.elengine.domain.request.bre.blbre2a.PerfsmeMonthlydtl;
import com.hdfcbank.elengine.domain.request.bre.blbre2a.PerfsmePeabacNetfigureDtl;
import com.hdfcbank.elengine.domain.request.bre.blbre2a.PerfsmeSummaryinfo;
import com.hdfcbank.elengine.domain.request.bre.blbre2a.PerfsmeXnDtl;
import com.hdfcbank.elengine.domain.request.bre.blbre2b.InitBlBre2bApplication;
import com.hdfcbank.elengine.domain.request.bre.blbre2c.InitBlbre2cApplication;
import com.hdfcbank.elengine.domain.request.bre.blbre2c.IpaScorecard;
import com.hdfcbank.elengine.domain.request.bre.blbre2c.StpFailReason;
import com.hdfcbank.elengine.domain.request.bre.ftnr.FtnrApplication;
import com.hdfcbank.elengine.domain.request.bre.ftnr.LosCibAccdetailSrop;
import com.hdfcbank.elengine.domain.request.bre.ftnr.LosEqAccdetailsSrop;
import com.hdfcbank.elengine.domain.request.bre.ftnr.LosHmBasePriAcctypeSrop;
import com.hdfcbank.elengine.domain.request.bre.ftnr.LosInputFromsa;
import com.hdfcbank.elengine.domain.request.bre.ftnr.LosMbReqStatus;
import com.hdfcbank.elengine.domain.request.bre.ftnr.LosMergedPastenqSrop;
import com.hdfcbank.elengine.domain.request.bre.ftnr.LosMergedPaymenthistSrop;
import com.hdfcbank.elengine.domain.request.bre.ftnr.LosMergedTradelinesSrop;
import com.hdfcbank.elengine.domain.request.callback.CallbackRequest;
import com.hdfcbank.elengine.domain.request.callback.ContextParam;
import com.hdfcbank.elengine.domain.request.callback.ResponseObject;
import com.hdfcbank.elengine.domain.request.callback.ResponseParam;
import com.hdfcbank.elengine.domain.request.common.InBreServices;
import com.hdfcbank.elengine.domain.request.hunter.HunterRequest;
import com.hdfcbank.elengine.domain.request.mb.MultibureauRequest;
import com.hdfcbank.elengine.domain.request.mb.callback.MbCallbackRequest;
import com.hdfcbank.elengine.domain.request.mb.callback.mergedbureau.MergedbureauCallbackRequest;
import com.hdfcbank.elengine.domain.request.perfios.txnstatus.PerfiosTxnStatusRequest;
import com.hdfcbank.elengine.domain.request.posidexdedupe.Envelope;
import com.hdfcbank.elengine.domain.request.posidexdedupe.PosidexOutRequest;
import com.hdfcbank.elengine.domain.response.bre.BlResponse;
import com.hdfcbank.elengine.domain.response.bre.blbre1b.BlBre1bResponse;
import com.hdfcbank.elengine.domain.response.bre.blbre2a.BlBre2AResponse;
import com.hdfcbank.elengine.domain.response.bre.blbre2b.BlBre2bResponse;
import com.hdfcbank.elengine.domain.response.bre.blbre2c.BlBre2CResponse;
import com.hdfcbank.elengine.domain.response.bre.ftnr.FtnrResponse;
import com.hdfcbank.elengine.domain.response.hunter.HunterResponse;
import com.hdfcbank.elengine.domain.response.hunter.ResultBlock;
import com.hdfcbank.elengine.domain.response.mb.MbResponse;
import com.hdfcbank.elengine.domain.response.mb.callback.cibil.CibilSropDomainList;
import com.hdfcbank.elengine.domain.response.mb.callback.crfhighmark.ChmBaseSropDomainList1;
import com.hdfcbank.elengine.domain.response.mb.callback.eot.MultiBureauEoTRequest;
import com.hdfcbank.elengine.domain.response.mb.callback.eot.success.MBEoTRequestType;
import com.hdfcbank.elengine.domain.response.mb.callback.equifax.EquifaxSropDomain;
import com.hdfcbank.elengine.domain.response.mb.callback.generic.GenericResponse;
import com.hdfcbank.elengine.domain.response.mb.callback.genericfailure.GenericFailureResponse;
import com.hdfcbank.elengine.domain.response.mb.callback.mergedscore.MergedSropDomain;
import com.hdfcbank.elengine.domain.response.perfios.Detail;
import com.hdfcbank.elengine.domain.response.perfios.EODBalance;
import com.hdfcbank.elengine.domain.response.perfios.EODBalances;
import com.hdfcbank.elengine.domain.response.perfios.MonthlyDetails;
import com.hdfcbank.elengine.domain.response.perfios.PIRData;
import com.hdfcbank.elengine.domain.response.perfios.PerfiosResponse;
import com.hdfcbank.elengine.domain.response.perfios.ScoringDetails;
import com.hdfcbank.elengine.domain.response.perfios.Xn;
import com.hdfcbank.elengine.domain.response.perfios.Xns;
import com.hdfcbank.elengine.domain.response.perfios.sme.HighValueCreditXn;
import com.hdfcbank.elengine.domain.response.perfios.sme.HighValueCreditXns;
import com.hdfcbank.elengine.domain.response.perfios.sme.HighValueDebitXn;
import com.hdfcbank.elengine.domain.response.perfios.sme.HighValueDebitXns;
import com.hdfcbank.elengine.domain.response.perfios.sme.LAPOUTPUTDetails;
import com.hdfcbank.elengine.domain.response.perfios.sme.LAPSummaryInfo;
import com.hdfcbank.elengine.domain.response.perfios.sme.MonthlyDetail;
import com.hdfcbank.elengine.domain.response.perfios.sme.PerfiosNetFigureDetail;
import com.hdfcbank.elengine.domain.response.perfios.sme.PerfiosSmeResponse;
import com.hdfcbank.elengine.domain.response.perfios.sme.StandardVariables;
import com.hdfcbank.elengine.domain.response.perfios.sme.SummaryInfo;
import com.hdfcbank.elengine.domain.response.perfios.txnstatus.Part;
import com.hdfcbank.elengine.domain.response.perfios.txnstatus.PerfiosTxnStatusResponse;
import com.hdfcbank.elengine.domain.response.posidexdedupe.PosidexInResponse;
import com.hdfcbank.elengine.domain.response.posidexdedupe.PosidexOutData;
import com.hdfcbank.elengine.domain.response.posidexdedupe.PosidexPublishResponse;
import com.hdfcbank.elengine.mappers.BlBre1bAutoMapper;
import com.hdfcbank.elengine.mappers.BlBre2aAutoMapper;
import com.hdfcbank.elengine.mappers.BlBre2aSmeAutoMapper;
import com.hdfcbank.elengine.mappers.BlBre2bAutoMapper;
import com.hdfcbank.elengine.mappers.BlBre2cAutoMapper;
import com.hdfcbank.elengine.mappers.FtnrAutoMapper;
import com.hdfcbank.elengine.repository.BreRepository;
import com.hdfcbank.elengine.repository.FetchConfigMapRepository;
import com.hdfcbank.elengine.repository.HunterRepository;
import com.hdfcbank.elengine.repository.MultiBureauRepository;
import com.hdfcbank.elengine.repository.PerfiosRepository;
import com.hdfcbank.elengine.repository.PosidexDedupeRepository;
import com.hdfcbank.elengine.service.ElCallbacks;
import com.hdfcbank.elengine.service.ElServices;
import com.hdfcbank.elengine.util.AddressMatchUtil;
import com.hdfcbank.elengine.util.ApiResponse;
import com.hdfcbank.elengine.util.CommonUtility;
import com.hdfcbank.elengine.util.PerfiosUtil;
import com.hdfcbank.elengine.util.RedisUtils;
import com.hdfcbank.elengine.util.XMLtoJsonParser;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class ElServicesImpl implements ElServices {

	@Autowired
	AddressMatchUtil addressMatchUtil;
	
	@Autowired
	ObjectMapper objectMapper;

	@Autowired
	RedisUtils redisUtils;

	@Autowired
	ElCallbacks callbacks;

	@Autowired
	OpenBankApiConnector openBankapiConnector;

	@Autowired
	FetchConfigMapRepository fetchConfigMapRepository;

	@Autowired
	MultiBureauRepository multiBureauRepository;

	@Autowired
	PosidexDedupeRepository posidexDedupeRepository;

	@Autowired
	HunterRepository hunterRepository;

	@Autowired
	BreRepository breRepository;

	@Autowired
	PerfiosRepository perfiosRepository;

	@Autowired
	XMLtoJsonParser xmLtoJsonParser;

	@Autowired
	CommonUtility commonUtility;

	@Autowired
	UrlConnection connection;

	@Value("${BRE_URL}")
	String BRE_URL;

	@Value("${HUNTER_URL}")
	String HUNTER_URL;

	@Value("${MULTIBUREU_URL}")
	String MULTIBUREU_URL;

	@Value("${POSIDEXINPUT_URL}")
	String POSIDEXINPUT_URL;

	@Value("${POSIDEXOUTPUT_URL}")
	String POSIDEXOUTPUT_URL;

	@Value("${POSIDEXPUBLISH_URL}")
	String POSIDEXPUBLISH_URL;

	@Value("${HUNTER_USERNAME}")
	private String HUNTER_USERNAME;

	@Value("${HUNTER_PASSWORD}")
	private String HUNTER_PASSWORD;

	@Value("${SOURCENAMEPOSIDEXDEDUPE}")
	private String SOURCENAMEPOSIDEXDEDUPE;

	@Value("${PERFIOS_RETRIEVE}")
	private String PERFIOS_RETRIEVE;

	@Value("${PERFIOS_TXN_STATUS}")
	private String PERFIOS_TXN_STATUS;

	@Value("${bre.service-url.blapp}")
	private String blAppUrl;

	@Value("${bre.service-url.ftnr}")
	private String ftnrUrl;

	@Value("${bre.service-url.bre1b}")
	private String bre1bUrl;

	@Value("${bre.service-url.bre2a}")
	private String bre2aUrl;

	@Value("${bre.service-url.bre2b}")
	private String bre2bUrl;

	@Value("${bre.service-url.bre2c}")
	private String bre2cUrl;

	@Value("${bre.callback.url}")
	private String brecallBackUrl;

//	@Value("${posidexin-response}")
//	String posidexinResponse;
//
//	@Value("${posidexpub-response}")
//	String posidexpubResponse;
//
//	@Value("${posidexout-response}")
//	String posidexoutResponse;
//
//	@Value("${hunter-response}")
//	String hunterResponse;
//
//	@Value("${blbre-response}")
//	String blbreResponse;
//
//	@Value("${ftnr-response}")
//	String ftnrResponse;
//
//	@Value("${ftnr-request}")
//	String ftnrRequest;
//
//	@Value("${blbre1b-response}")
//	String blbre1bResponse;
//
//	@Value("${blbre2a-response}")
//	String blbre2aResponse;
//
//	@Value("${blbre2b-response}")
//	String blbre2bResponse;
//
//	@Value("${blbre2c-response}")
//	String blbre2cResponse;
//
//	@Value("${blbre3a-response}")
//	String blbre3aResponse;
//
//	@Value("${blbre3b-response}")
//	String blbre3bResponse;

	@Value("${mbMergedScoreLog-response}")
	String mbMergedScoreLog;

	@Value("${initiateBlBrebApp-response}")
	String initiateBlBrebApp;

	@Value("${bre3App-response}")
	String bre3App;

	@Value("${perf-custinfo-response}")
	String perfcustinfo;

	@Value("${appdata-response}")
	String appdata;

	@Value("${bre2c-request}")
	String bre2cRequest;
 

	@Async
	public ApiResponse<Boolean> initiateMultiBureu(InitiateMBRequest request) throws Exception {
		String responseObj = "";
		boolean isALreadyProcessed = false;
        InBreServices req = null;
		String ackId = "";
		String mbStatus = "";
        MBEntity mbEntity = null;
		try {
            req = new InBreServices(request.getTranRefNumber(), request.getMobileNumber(), request.getProductCode(), request.getPartnerJourneyId(), "", "", "", "");
            mbEntity = new MBEntity(request.getMobileNumber(), null, responseObj, OffsetDateTime.now(),
					OffsetDateTime.now(), request.getProductCode(), MBServiceType.MBINPUT,
					ApiResponseType.initiated.toString(), request.getTranRefNumber());
			String tranRefNo = request.getTranRefNumber();
			log.info("tranRefNo {}", tranRefNo);
			redisUtils.set(RedisConstants.MB_GENDER + request.getMobileNumber() + RedisConstants.US + tranRefNo,
					request.getGender());

			String creationTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS")
					.format(Calendar.getInstance().getTime());

			redisUtils.set(RedisConstants.MB_CREATION_TIME + request.getMobileNumber() + RedisConstants.US + tranRefNo,
					creationTime);
			redisUtils.set(RedisConstants.NTB_MOBILE_NO + tranRefNo, request.getMobileNumber());
			if (!redisUtils.exists(
					RedisConstants.NTB_MULTI_BUREAU + request.getMobileNumber() + RedisConstants.US + tranRefNo)) {

				String apiReq = new XmlMapper().writeValueAsString(MultibureauRequest.toMultibureauServiceRequest(
						request.getTranRefNumber(), request.getCustomerId(), request.getName(), request.getGender(),
						request.getAge(), request.getDob(), request.getAddress(), request.getCity(), request.getPin(),
						request.getState(), request.getPanNumber(), request.getMobileNumber()));
				apiReq = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" + apiReq;
				log.info("Mulitburue tranRefNo {} ,request {}", request.getTranRefNumber(), apiReq);
				mbEntity.setRequest(apiReq);
                if (Objects.nonNull(mbEntity)) {
				this.multiBureauRepository.save(mbEntity);
                }
				responseObj = openBankapiConnector.processPosidexInGateWayApiRequest(apiReq, MULTIBUREU_URL.trim(),"");
				mbEntity.setResponse(responseObj);
				mbEntity.setUpdateddate(OffsetDateTime.now());
				log.info("Mulitburue tranRefNo {}, response {}", request.getTranRefNumber(), responseObj);

			} else {
				isALreadyProcessed = true;
				responseObj = redisUtils.get(
						RedisConstants.NTB_MULTI_BUREAU + request.getMobileNumber() + RedisConstants.US + tranRefNo);
				log.info("Mulitburue tranRefNo {}, exists response {}", request.getTranRefNumber(), responseObj);
			}
			if (!isALreadyProcessed) {
				if (StringUtils.isNotBlank(responseObj)) {
					JSONObject jsonObj = XML.toJSONObject(responseObj);
					MbResponse mbResponse = null;
					try {
						mbResponse = new ObjectMapper().readValue(jsonObj.toString(), MbResponse.class);
						mbStatus = mbResponse.getEnvelope().getBody().getMultiBureauServiceResponse()
								.getACKNOWLEDGEMENT().STATUS;
						ackId = mbResponse.getEnvelope().getBody().getMultiBureauServiceResponse()
								.getACKNOWLEDGEMENT().ACKNOWLEDGEMENTID;

					} catch (Exception e) {
						log.error("Failed to parse JSON  Mulitibureu response for tranRefnum {}. Response {}",
								request.getTranRefNumber(), jsonObj);
					}

					if (mbStatus.equalsIgnoreCase(ApiResponseType.success.toString())) {
						mbEntity.setStatus(ApiResponseType.success.toString());
						redisUtils.set(
								RedisConstants.PRODUCTCODE + request.getMobileNumber() + RedisConstants.US + tranRefNo,
								request.getProductCode());
						req.setProductId(request.getProductCode());
						req.setAckid(request.getTranRefNumber());
						req.setMobileNo(request.getMobileNumber());
						req.setField1(request.getPartnerJourneyId());
					} else {
						mbEntity.setStatus(ApiResponseType.failure.toString());
						req.setProductId(request.getProductCode());
						req.setAckid(request.getTranRefNumber());
						req.setMobileNo(request.getMobileNumber());
						req.setField1(request.getPartnerJourneyId());
						String description = mbResponse.getEnvelope().getBody().getMultiBureauServiceResponse()
								.getACKNOWLEDGEMENT().ERRORS.DESCRIPTION;
						;

						this.prepareCallBackRequest(req, BreServiceType.GetBureauOffer.toString(),
								objectMapper.writeValueAsString(new ResponseObject(description, "500")));
					}

					redisUtils.set(
							RedisConstants.NTB_MULTI_BUREAU + request.getMobileNumber() + RedisConstants.US + tranRefNo,
							responseObj);
					redisUtils.set(RedisConstants.ACKNOWLEDGEMENT_ID + tranRefNo + RedisConstants.US
							+ request.getMobileNumber(), ackId);
					return ApiResponse.success(true);
				}
			}
		} catch (Exception e) {
			log.error("mb service exception {}", e);
		} finally {
            if (Objects.nonNull(mbEntity)) {
                this.multiBureauRepository.save(mbEntity);
            }
			if (mbStatus.equalsIgnoreCase(ApiResponseType.success.toString())) {
				callbacks.checkMbCallbacks(req);
			}
			log.info("method end time {}", new Date());
		}
		return ApiResponse.success(true);
	}

	public ApiResponse<Boolean> initiatePosidexDedupe(InitiatePosidexDedupe request) throws Exception {
		boolean isALreadyProcessed = false;
		String responseObj = "";
		PosidexDedupeEntity posidexDedupeEntity = new PosidexDedupeEntity(request.getMobileNumber(), null, responseObj,
				OffsetDateTime.now(), OffsetDateTime.now(), request.getProductCode(),
				PosidexDedupeServiceType.PosidexIn, ApiResponseType.initiated.toString(), request.getTranRefNumber());
		Date date = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat("ddMMyyyy");
		String currentDate = formatter.format(date);
		String fileName = SOURCENAMEPOSIDEXDEDUPE.trim() + currentDate + request.getTranRefNumber();
		SimpleDateFormat formatter1 = new SimpleDateFormat("dd/MM/yyyy");
		currentDate = formatter1.format(date);
		if (!redisUtils.exists(RedisConstants.NTB_DEDUPE_INPUT + request.getMobileNumber() + RedisConstants.US
				+ request.getTranRefNumber())) {
			String apiReq = new XmlMapper().writeValueAsString(
					Envelope.toEnvelope(request.getTranRefNumber(), request.getCustomerID(), request.getName(),
							request.getDob(), request.getAddress(), request.getCity(), request.getState(),
							request.getZipCode(), request.getMobileNumber(), request.getPanNumber(), fileName));
			posidexDedupeEntity.setRequest(apiReq);
            if (Objects.nonNull(posidexDedupeEntity)) {
			this.posidexDedupeRepository.save(posidexDedupeEntity);
            }
			log.info("Posidex dedupe in tranRefNo {} ,request {}", request.getTranRefNumber(), apiReq);
			log.info("Posidex dedupe url {} ", POSIDEXINPUT_URL);
				responseObj = openBankapiConnector.processPosidexInGateWayApiRequest(apiReq.toString(),
						POSIDEXINPUT_URL.trim(), AppConstants.POSIDEX_STATUS);
			 
			log.info("Posidex dedupe in tranRefNo {} ,response {}", request.getTranRefNumber(), responseObj);
		} else {
			isALreadyProcessed = true;
			responseObj = redisUtils.get(RedisConstants.NTB_DEDUPE_INPUT + request.getMobileNumber() + RedisConstants.US
					+ request.getTranRefNumber());
			log.info("tranRefNo {} Response of posidexinput exists {}", request.getTranRefNumber(), responseObj);
		}
		if (!isALreadyProcessed) {
			if (StringUtils.isNotBlank(responseObj)) {
				JSONObject jsonObj = XML.toJSONObject(responseObj);
				try {
					PosidexInResponse posidexInResponse = new ObjectMapper().readValue(jsonObj.toString(),
							PosidexInResponse.class);
					String instcnt = posidexInResponse.getEnvelope().getBody().getServiceResponse().getInsCnt();
					log.info("tranrefnumber {} of instcount {}", request.getTranRefNumber(), instcnt);
					if (instcnt.equalsIgnoreCase("1")) {
						posidexDedupeEntity.setStatus(ApiResponseType.success.toString());
					} else {
						posidexDedupeEntity.setStatus(ApiResponseType.failure.toString());
						InBreServices req = new InBreServices();
						req.setProductId(request.getProductCode());
						req.setAckid(request.getTranRefNumber());
						req.setMobileNo(request.getMobileNumber());
						req.setField1(request.getPartnerJourneyId());
						this.prepareCallBackRequest(req, BreServiceType.GetBureauOffer.toString(), objectMapper
								.writeValueAsString(new ResponseObject("posdeix in service failure", "500")));
					}
					redisUtils.set(RedisConstants.NTB_DEDUPE_INPUT + request.getMobileNumber() + RedisConstants.US
							+ request.getTranRefNumber(), responseObj);
					redisUtils.set(RedisConstants.POSIDEX_FILENAME + request.getMobileNumber() + RedisConstants.US
							+ request.getTranRefNumber(), fileName);
					posidexDedupeEntity.setResponse(responseObj);
					posidexDedupeEntity.setUpdateddate(OffsetDateTime.now());
                    if (Objects.nonNull(posidexDedupeEntity)) {
					this.posidexDedupeRepository.save(posidexDedupeEntity);
                    }
					return ApiResponse.success(true);
				} catch (Exception e) {
					log.error("Failed to parse JSON posidex dedupe in response for tranRefnum {}. Response {}",
							request.getTranRefNumber(), jsonObj);
				}
			}
		}
		return ApiResponse.success(false);
	}

	public ApiResponse<Boolean> publishPosidexDedupe(InitiatePosidexDedupe request) throws Exception {
		String responseObj = "";
		PosidexDedupeEntity posidexDedupeEntity = new PosidexDedupeEntity(request.getMobileNumber(), null, responseObj,
				OffsetDateTime.now(), OffsetDateTime.now(), request.getProductCode(),
				PosidexDedupeServiceType.PosidexPublish, ApiResponseType.initiated.toString(),
				request.getTranRefNumber());
		String fileName = redisUtils.get(RedisConstants.POSIDEX_FILENAME + request.getMobileNumber() + RedisConstants.US
				+ request.getTranRefNumber());

		if (!redisUtils.exists(RedisConstants.NTB_DEDUPE_PUBLISH + request.getMobileNumber() + RedisConstants.US
				+ request.getTranRefNumber())) {

			String apiReq = new XmlMapper().writeValueAsString(
					PosidexOutRequest.toPosidexOutRequest(fileName, ConstantMessages.POSIDEX_IN_SOA_SOURCE_ID));
			posidexDedupeEntity.setRequest(apiReq);
			log.info("Posidex dedupe publish tranRefNo {} ,request {}", request.getTranRefNumber(), apiReq);
				posidexDedupeEntity.setRequest(apiReq);
                if (Objects.nonNull(posidexDedupeEntity)) {
				this.posidexDedupeRepository.save(posidexDedupeEntity);
                }
				responseObj = openBankapiConnector.processPosidexInGateWayApiRequest(apiReq.toString(),
						POSIDEXPUBLISH_URL.trim(), AppConstants.POSIDEX_STATUS);
			 
			log.info("Posidex dedupe publish tranRefNo {} ,response {}", request.getTranRefNumber(), responseObj);

		} else {
			responseObj = redisUtils.get(RedisConstants.NTB_DEDUPE_PUBLISH + request.getMobileNumber()
					+ RedisConstants.US + request.getTranRefNumber());
			log.info("tranRefNo {} Response of posidex publish exists {}", request.getTranRefNumber(), responseObj);
		}

		if (StringUtils.isNotBlank(responseObj)) {
			JSONObject jsonObj = XML.toJSONObject(responseObj);
			String finalAvlStatus = "";
			try {
				PosidexPublishResponse posidexPublishResponse = new ObjectMapper().readValue(jsonObj.toString(),
						PosidexPublishResponse.class);
				finalAvlStatus = posidexPublishResponse.getEnvelope().getBody().getPublishResponse()
						.getOutputFileNames().getFinalAvlStatus();

				if (finalAvlStatus.equals("Y")) {
					redisUtils.set(RedisConstants.NTB_DEDUPE_PUBLISH + request.getMobileNumber() + RedisConstants.US
							+ request.getTranRefNumber(), responseObj);
					posidexDedupeEntity.setStatus(ApiResponseType.success.toString());
				} else {
					posidexDedupeEntity.setStatus(ApiResponseType.failure.toString());
					InBreServices req = new InBreServices();
					req.setProductId(request.getProductCode());
					req.setAckid(request.getTranRefNumber());
					req.setMobileNo(request.getMobileNumber());
					req.setField1(request.getPartnerJourneyId());
					this.prepareCallBackRequest(req, BreServiceType.GetBureauOffer.toString(),
							objectMapper.writeValueAsString(new ResponseObject("posdeix publish failure", "500")));
				}
				posidexDedupeEntity.setResponse(responseObj);
				posidexDedupeEntity.setUpdateddate(OffsetDateTime.now());
                if (Objects.nonNull(posidexDedupeEntity)) {
				this.posidexDedupeRepository.save(posidexDedupeEntity);
                }
			} catch (Exception e) {
				log.error("Failed to parse JSON posidex dedupe publishresponse for tranRefnum {}. Response {}",
						request.getTranRefNumber(), jsonObj);
			}
			if (finalAvlStatus.equals("Y")) {
				return getPosidexOutput(request, fileName);
			} else {
				long poxidexRetryCount = redisUtils.incr(RedisConstants.POXIDEX_RETRY_COUNT + request.getMobileNumber()
						+ RedisConstants.US + request.getTranRefNumber());
				log.info("poxidexRetryCount {}" + poxidexRetryCount);
				redisUtils.expire(RedisConstants.POXIDEX_RETRY_COUNT + request.getMobileNumber() + RedisConstants.US
						+ request.getTranRefNumber(), RedisConstants.EXPIRE_KEY);
				if (poxidexRetryCount < AppConstants.POXIDEX_RETRY_COUNT) {
					try {
						Thread.sleep(5000);
					} catch (InterruptedException e) {
						Thread.currentThread().interrupt();
					}
					publishPosidexDedupe(request);
				} else {
					redisUtils.del(RedisConstants.POXIDEX_RETRY_COUNT + request.getMobileNumber() + RedisConstants.US
							+ request.getTranRefNumber());
				}
			}
		}

		return ApiResponse.success(false);
	}

	public ApiResponse<Boolean> getPosidexOutput(InitiatePosidexDedupe request, String fileName) throws Exception {
		String responseObj = "";
		boolean isAlreadyProcessed = false;
		PosidexDedupeEntity posidexDedupeEntity = new PosidexDedupeEntity(request.getMobileNumber(), null, responseObj,
				OffsetDateTime.now(), OffsetDateTime.now(), request.getProductCode(),
				PosidexDedupeServiceType.PosidexOut, ApiResponseType.initiated.toString(), request.getTranRefNumber());
		if (!redisUtils.exists(RedisConstants.NTB_DEDUPE_OUTPUT + request.getMobileNumber() + RedisConstants.US
				+ request.getTranRefNumber())) {
			String apiReq = new XmlMapper().writeValueAsString(
					PosidexOutRequest.toPosidexOutRequest(fileName, ConstantMessages.POSIDEX_IN_SOA_SOURCE_ID));
			log.info("Posidex dedupe output tranRefNo {} ,request {}", request.getTranRefNumber(), apiReq);
				posidexDedupeEntity.setRequest(apiReq);
                if (Objects.nonNull(posidexDedupeEntity)) {
				this.posidexDedupeRepository.save(posidexDedupeEntity);
                }
				responseObj = openBankapiConnector.processPosidexInGateWayApiRequest(apiReq.toString(),
						POSIDEXOUTPUT_URL.trim(), AppConstants.POSIDEX_STATUS);
			 
			log.info("Posidex dedupe output tranRefNo {} ,response {}", request.getTranRefNumber(), responseObj);

			redisUtils.set(RedisConstants.NTB_DEDUPE_OUTPUT + request.getMobileNumber() + RedisConstants.US
					+ request.getTranRefNumber(), responseObj);
		} else {
			isAlreadyProcessed = true;
			responseObj = redisUtils.get(RedisConstants.NTB_DEDUPE_OUTPUT + request.getMobileNumber()
					+ RedisConstants.US + request.getTranRefNumber());
			log.info("tranRefNo {} Response of posidex output exists {}", request.getTranRefNumber(),
					responseObj.length());
		}

		if (StringUtils.isNotBlank(responseObj)) {
			try {
				PosidexOutData[] outBody = xmLtoJsonParser.parsePosidexOutput(responseObj);

				posidexDedupeEntity.setResponse(responseObj);
				posidexDedupeEntity.setUpdateddate(OffsetDateTime.now());
				if (!Objects.isNull(outBody)) {
					posidexDedupeEntity.setStatus(ApiResponseType.success.toString());
					return ApiResponse.success(true);
				} else {
					InBreServices req = new InBreServices();
					req.setProductId(request.getProductCode());
					req.setAckid(request.getTranRefNumber());
					req.setMobileNo(request.getMobileNumber());
					req.setField1(request.getPartnerJourneyId());
					this.prepareCallBackRequest(req, BreServiceType.GetBureauOffer.toString(),
							objectMapper.writeValueAsString(new ResponseObject("posdiex output failure", "500")));

					posidexDedupeEntity.setStatus(ApiResponseType.failure.toString());
					return ApiResponse.success(false);
				}
			} catch (JsonProcessingException e) {
				log.error("Failed to parse JSON response for tranRefnum {}. Response {}", request.getTranRefNumber(),
						responseObj);
			} finally {
				if (!isAlreadyProcessed)
					this.posidexDedupeRepository.save(posidexDedupeEntity);
			}

		}
		return ApiResponse.success(false);
	}

	public ApiResponse<Boolean> initiateHunter(InitiateHunter request) throws Exception {
		String hunterCode = "";
		String responseObj = "";
		HunterEntity hunterEntity = new HunterEntity(request.getMobileNumber(), null, responseObj, OffsetDateTime.now(),
				OffsetDateTime.now(), request.getProductCode(), HunterType.Hunter, ApiResponseType.initiated.toString(),
				request.getTranRefNumber());
		String pincode = redisUtils.get(RedisConstants.SET_POSTAL_CODE + request.getMobileNumber() + RedisConstants.US
				+ request.getTranRefNumber());
		log.info("pincode from equifax {}", pincode);
		if (StringUtils.isBlank(pincode)) {
			redisUtils.set(RedisConstants.SET_POSTAL_CODE + request.getMobileNumber() + RedisConstants.US
					+ request.getTranRefNumber(), request.getPinCode());
		}
		redisUtils.set(
				RedisConstants.HUNTER_CITY + request.getMobileNumber() + RedisConstants.US + request.getTranRefNumber(),
				"");
		redisUtils.set(
				RedisConstants.HUNTER_CODE + request.getMobileNumber() + RedisConstants.US + request.getTranRefNumber(),
				hunterCode);

		if (!redisUtils.exists(RedisConstants.NTB_HUNTER + request.getMobileNumber() + RedisConstants.US
				+ request.getTranRefNumber())) {

			String apiReq = new XmlMapper().disable(SerializationFeature.FAIL_ON_EMPTY_BEANS)
					.writeValueAsString(HunterRequest.toHunterRequest(request.getProductCode(),
							new SimpleDateFormat("yyyy-MM-dd").format(Calendar.getInstance().getTime()),
							request.getTranRefNumber(), request.getPanNumber(), request.getFirstName(),
							request.getLastName(), request.getDob(), request.getMobileNumber(), HUNTER_USERNAME,
							HUNTER_PASSWORD));
			log.info("Hunter tranRefNo {} ,request {}", request.getTranRefNumber(), apiReq);
			hunterEntity.setRequest(apiReq);
			responseObj = openBankapiConnector.processPosidexInGateWayApiRequest(apiReq.toString(), HUNTER_URL.trim(),
					AppConstants.HUNTER);
			log.info("Hunter tranRefNo {} ,response {}", request.getTranRefNumber(), responseObj);
			redisUtils.set(RedisConstants.NTB_HUNTER + request.getMobileNumber() + RedisConstants.US
					+ request.getTranRefNumber(), responseObj);
			hunterEntity.setResponse(responseObj);
			if (!Objects.isNull(responseObj)) {
				HunterResponse hunterResponse = xmLtoJsonParser.parseHunterResponse(responseObj);
				try {
					if (Objects.isNull(hunterResponse.envelope.body.matchResponse.matchResult.resultBlock)) {
						hunterEntity.setStatus(ApiResponseType.failure.toString());
						InBreServices req = new InBreServices();
						req.setProductId(request.getProductCode());
						req.setAckid(request.getTranRefNumber());
						req.setMobileNo(request.getMobileNumber());
						req.setField1(request.getPartnerJourneyId());
						this.prepareCallBackRequest(req, HunterType.Hunter.toString(),
								objectMapper.writeValueAsString(new ResponseObject("hunter failure", "500")));
					} else {
						hunterEntity.setStatus(ApiResponseType.success.toString());
					}
				} catch (Exception e) {

				}
			} else {
				hunterEntity.setStatus(ApiResponseType.failure.toString());
			}
            if (Objects.nonNull(hunterEntity)) {
			this.hunterRepository.save(hunterEntity);
            }
		} else {
			responseObj = redisUtils.get(RedisConstants.NTB_HUNTER + request.getMobileNumber() + RedisConstants.US
					+ request.getTranRefNumber());
			log.info("Hunter tranRefNo {} ,response exists {}", request.getTranRefNumber(), responseObj);
		}
		return ApiResponse.success(true);
	}

	public ApiResponse<Boolean> initiateBlApplication(InBreServices request) throws Exception {
		log.info("ackId {}", request.getAckid());
		String requestString = redisUtils
				.get(RedisConstants.BUREAU_REQ + request.getMobileNo() + RedisConstants.US + request.getAckid());
		BlApplication breApplication = new BlApplication();
		if (StringUtils.isNotBlank(requestString)) {
			InitiateBlBrebApp initiateBlBrebApp = objectMapper.readValue(requestString, InitiateBlBrebApp.class);
			if (Objects.nonNull(initiateBlBrebApp)) {
				String poisdexOutput = redisUtils.get(RedisConstants.NTB_DEDUPE_OUTPUT + request.getMobileNo()
						+ RedisConstants.US + request.getAckid());

				PosidexOutData[] outBody = xmLtoJsonParser.parsePosidexOutput(poisdexOutput);

				BlLosInputFromsa inputFromsa = new BlLosInputFromsa();
				if (Objects.nonNull(outBody)) {
					PosidexOutData outData = outBody[0];
					inputFromsa.setLsiCustTypeC(outData.getSOA_CUST_TYPE_C());
					inputFromsa.setLsiAppIdC(outData.getSOA_APP_ID_C());
				} else {
					inputFromsa.setLsiCustTypeC("null");
					inputFromsa.setLsiAppIdC("null");
				}
				ArrayList<BlLosInputFromsa> list = new ArrayList<BlLosInputFromsa>();
				list.add(inputFromsa);

				breApplication.setAppIdC(request.getAckid());
				breApplication.setCustIdN(new CommonUtility().genRandomNumber(12));
				breApplication.setLaaAppTypeC(ConstantMessages.BLAPP_LAPPTYPE);
				breApplication.setLaaAppApprTermN(LappTermIn.valueOf(initiateBlBrebApp.getEmploymentType()).toInt());
				breApplication.setAge(CommonUtility.ageCalculator(initiateBlBrebApp.dob));
				breApplication.setZipcode(Integer.valueOf(initiateBlBrebApp.getCurrResiAddPincode()));
				breApplication.setLaaBranchid(
						StringUtils.isBlank(initiateBlBrebApp.getBranchCode()) == true ? AppConstants.BRE_STRING_EMPTY
								: initiateBlBrebApp.getBranchCode());
				breApplication.setLosInputFromsas(list);
				breApplication.setLaaPromotionscheme(ConstantMessages.BLAPP_PROMOTION_SCHEME);
				breApplication.setAddress(initiateBlBrebApp.getCurrResiAddLine1());
				breApplication
						.setConstitution(ConstitutionType.valueOf(initiateBlBrebApp.getEmploymentType()).toString());
				breApplication.setLoanPurpose(StringUtils.isBlank(initiateBlBrebApp.getPurposeOfLoan()) == true
						? AppConstants.BRE_STRING_EMPTY
						: initiateBlBrebApp.getPurposeOfLoan());
				breApplication.setEmploymentType(initiateBlBrebApp.getEmploymentType());

				String apirequest = objectMapper.writeValueAsString(breApplication);
				String response = "";
				OffsetDateTime creationTime = OffsetDateTime.now();
				String status = "";
					status = ApiResponseType.initiated.toString();
					try {
						log.info("blapp request {}", apirequest);
						org.json.simple.JSONObject jsonObject = openBankapiConnector
								.processBREApiRequest(apirequest.toString(), blAppUrl.trim());
						log.info("blapp response {}", jsonObject);
						response = jsonObject.toString();
					} catch (Exception e) {
						throw e;
					}
				 
				if (StringUtils.isNotBlank(response)) {
					redisUtils.set(RedisConstants.NTB_BLAPP + request.mobileNo + RedisConstants.US + request.ackid,
							response);
					BlResponse blResponse = xmLtoJsonParser.parseBlResponse(response);
					if (blResponse.getStatus() == AppConstants.ACE_BRESUCCESS_CODE) {
						status = ApiResponseType.success.toString();
					} else {
						status = ApiResponseType.failure.toString();
						request.setProductId(initiateBlBrebApp.productCode);
						request.setField1(initiateBlBrebApp.partnerJourneyId);
						this.prepareCallBackRequest(request, BreServiceType.GetBureauOffer.toString(), response);
					}
				} else {
					status = ApiResponseType.failure.toString();
				}
                BreServiceEntity breServiceEntity = new BreServiceEntity(request.getMobileNo(),
                        objectMapper.writeValueAsString(breApplication), response, creationTime, OffsetDateTime.now(),
                        initiateBlBrebApp.productCode, BreServiceType.blapp, status, request.ackid);
                if(Objects.nonNull(breServiceEntity)) {
                    this.breRepository.save(breServiceEntity);
                }
			}
		}
		return ApiResponse.success(true);
	}

	public ApiResponse<Object> initiateFtnrApplication(InBreServices request) throws Exception {
		String mobileNo = request.getMobileNo();
		String tranRefNumber = request.getAckid();
		String posidexOutput = "";
		String productId = "";
		InitiateBlBrebApp initiateBlBrebApp = null;
		String requestString = redisUtils
				.get(RedisConstants.BUREAU_REQ + request.getMobileNo() + RedisConstants.US + request.getAckid());
		if (StringUtils.isNotBlank(requestString)) {
			initiateBlBrebApp = objectMapper.readValue(requestString, InitiateBlBrebApp.class);
			productId = LappProductId.valueOf(initiateBlBrebApp.getEmploymentType()).toString();
		}
		posidexOutput = redisUtils.get(RedisConstants.NTB_DEDUPE_OUTPUT + mobileNo + RedisConstants.US + tranRefNumber);
		PosidexOutData[] posidexOutDatas = xmLtoJsonParser.parsePosidexOutput(posidexOutput);

		List<LosInputFromsa> inputFromsas = new ArrayList<>();
		if (!Objects.isNull(posidexOutDatas)) {
			Supplier<Stream<PosidexOutData>> supplier = () -> Stream.of(posidexOutDatas);
			supplier.get().forEach(data -> inputFromsas.add(getLosData(data)));
			log.info("out array count {}", inputFromsas.size());
		} else {
			inputFromsas.add(getLosData(new PosidexOutData()));
		}
		String cibilResponse = redisUtils
				.get(MBServiceType.CIBIL.toString() + mobileNo + RedisConstants.US + tranRefNumber);
		log.info("cibilResponse {}", cibilResponse.length());
		List<LosCibAccdetailSrop> cib_accdetail = new ArrayList<>();
		CibilSropDomainList[] sropDomainLists = xmLtoJsonParser.parseCibilResponse(cibilResponse);
		if (!Objects.isNull(sropDomainLists)) {
			Supplier<Stream<CibilSropDomainList>> cibilsupplier = () -> Stream.of(sropDomainLists);
			cibilsupplier.get().forEach(data -> cib_accdetail.add(getCibilAccSropData(data)));
			log.info("cib_accdetail out array count {}", cib_accdetail.size());
		} else {
			cib_accdetail.add(getCibilAccSropData(new CibilSropDomainList()));
		}
		String equifaxResponse = redisUtils
				.get(MBServiceType.EQUIFAX.toString() + mobileNo + RedisConstants.US + tranRefNumber);
		EquifaxSropDomain[] equifaxSropDomains = xmLtoJsonParser.parseEquifaxResponse(equifaxResponse);
		List<LosEqAccdetailsSrop> eqAccdetailsSrops = new ArrayList<>();
		if (!Objects.isNull(equifaxSropDomains)) {
			Supplier<Stream<EquifaxSropDomain>> equifaxsupplier = () -> Stream.of(equifaxSropDomains);
			equifaxsupplier.get().forEach(data -> eqAccdetailsSrops.add(getEqLosEqAccdetailsSrop(data)));
			log.info("equifax out array count {}", eqAccdetailsSrops.size());
		} else {
			eqAccdetailsSrops.add(getEqLosEqAccdetailsSrop(new EquifaxSropDomain()));
		}

		String crifHighMarkResponse = redisUtils
				.get(MBServiceType.HIGHMARK.toString() + mobileNo + RedisConstants.US + tranRefNumber);

		ChmBaseSropDomainList1[] chmBaseSropDomainList1 = xmLtoJsonParser
				.parseCrifHighMarkResponse(crifHighMarkResponse);
		List<LosHmBasePriAcctypeSrop> hmBasePriAcctypeSrops = new ArrayList<LosHmBasePriAcctypeSrop>();
		if (!Objects.isNull(chmBaseSropDomainList1)) {
			Supplier<Stream<ChmBaseSropDomainList1>> crifHmsupplier = () -> Stream.of(chmBaseSropDomainList1);
			crifHmsupplier.get().forEach(data -> hmBasePriAcctypeSrops.add(getLosHmBasePriAcctypeSrop(data)));
			log.info("crifhighmark out array count {}", hmBasePriAcctypeSrops.size());
		} else {
			hmBasePriAcctypeSrops.add(getLosHmBasePriAcctypeSrop(new ChmBaseSropDomainList1()));
		}
		String eotLog = redisUtils.get(MBServiceType.MBEOT.toString() + mobileNo + RedisConstants.US + tranRefNumber);
		MBEoTRequestType mbEoTRequestType = xmLtoJsonParser.parseEotResponse(eotLog);
		List<LosMbReqStatus> losMbReqStatus = new ArrayList<LosMbReqStatus>();
		if (!Objects.isNull(mbEoTRequestType)) {
			LosMbReqStatus mbReqStatus = getLosMbReqStatus(mbEoTRequestType);
			losMbReqStatus.add(mbReqStatus);
		} else {
			MultiBureauEoTRequest mbEoTFailureRequestType = xmLtoJsonParser.parseEotFailureResponse(eotLog);
			if (!Objects.isNull(mbEoTFailureRequestType)) {
				LosMbReqStatus mbReqStatus = getLosMbFailureReqStatus(mbEoTFailureRequestType);
				losMbReqStatus.add(mbReqStatus);
			}
		}

		String mbMergedScoreLog = redisUtils
				.get(MBServiceType.MERGED_SCORE.toString() + mobileNo + RedisConstants.US + tranRefNumber);
		MergedSropDomain[] mergedSropDomains = xmLtoJsonParser.parseMergedResponse(mbMergedScoreLog);
		List<LosMergedPastenqSrop> mergedSrops = new ArrayList<LosMergedPastenqSrop>();
		List<LosMergedPaymenthistSrop> mergedPaymenthistSrops = new ArrayList<LosMergedPaymenthistSrop>();
		List<LosMergedTradelinesSrop> mergedTradelinesSrops = new ArrayList<LosMergedTradelinesSrop>();
		if (!Objects.isNull(mergedSropDomains)) {
			Supplier<Stream<MergedSropDomain>> mergedScoresupplier = () -> Stream.of(mergedSropDomains);
			mergedScoresupplier.get().forEach(data -> mergedSrops.add(getLosMergedPastenqSrop(data)));
			mergedScoresupplier.get().forEach(data -> mergedPaymenthistSrops.add(getLosMergedPaymenthistSrop(data)));
			mergedScoresupplier.get().forEach(data -> mergedTradelinesSrops.add(getLosMergedTradelinesSrop(data)));
		} else {
			mergedSrops.add(getLosMergedPastenqSrop(new MergedSropDomain()));
			mergedPaymenthistSrops.add(getLosMergedPaymenthistSrop(new MergedSropDomain()));
			mergedTradelinesSrops.add(getLosMergedTradelinesSrop(new MergedSropDomain()));
		}
		FtnrApplication ftnrApplication = FtnrAutoMapper.INSTANCE.mapFtnrApplication(request);
		ftnrApplication.setLosInputFromsas(inputFromsas);
		ftnrApplication.setLaaProductIdC(productId);
		ftnrApplication.setLosCibAccdetailSrop(cib_accdetail);
		ftnrApplication.setLosEqAccdetailsSrop(eqAccdetailsSrops);
		ftnrApplication.setLosHmBasePriAcctypeSrop(hmBasePriAcctypeSrops);
		ftnrApplication.setLosMbReqStatus(losMbReqStatus);
		ftnrApplication.setLosMergedPastenqSrop(mergedSrops);
		ftnrApplication.setLosMergedPaymenthistSrop(mergedPaymenthistSrops);
		ftnrApplication.setLosMergedTradelinesSrop(mergedTradelinesSrops);

		String apirequest = objectMapper.writeValueAsString(ftnrApplication);
		String response = "";
//		apirequest = ftnrRequest;
		OffsetDateTime creationTime = OffsetDateTime.now();
		String status = "";
 			status = ApiResponseType.initiated.toString();
			try {
				log.info("ftnr api request {}", apirequest);
				org.json.simple.JSONObject jsonObject = openBankapiConnector.processBREApiRequest(apirequest.toString(),
						ftnrUrl.trim());
				response = jsonObject.toString();
				log.info("ftnr api response {}", response);
			} catch (Exception e) {
				throw e;
			}
 
		if (StringUtils.isNotBlank(response)) {
			redisUtils.set(RedisConstants.NTB_FTNR + request.mobileNo + RedisConstants.US + request.ackid, response);
			FtnrResponse ftnrResponse = xmLtoJsonParser.parseFtnrResponse(response);
			if (!Objects.isNull(ftnrResponse) && ftnrResponse.getStatus() == AppConstants.ACE_BRESUCCESS_CODE) {
				status = ApiResponseType.success.toString();
			} else {
				status = ApiResponseType.failure.toString();
				request.setProductId(initiateBlBrebApp.productCode);
				request.setField1(initiateBlBrebApp.partnerJourneyId);
				this.prepareCallBackRequest(request, BreServiceType.GetBureauOffer.toString(), response);
			}
		} else {
			status = ApiResponseType.failure.toString();
		}
        BreServiceEntity breServiceEntity = new BreServiceEntity(request.getMobileNo(),
                objectMapper.writeValueAsString(ftnrApplication), response, creationTime, OffsetDateTime.now(),
                initiateBlBrebApp.productCode, BreServiceType.ftnr, status, request.ackid);
        if (Objects.nonNull(breServiceEntity)) {
            this.breRepository.save(breServiceEntity);
        }

		return ApiResponse.success(true);
	}

	public ApiResponse<Object> initiateBlbre1BApplication(InBreServices request) throws Exception {
		String mobileNo = request.getMobileNo();
		String tranRefNumber = request.getAckid();
		String posidexOutput = "";
		String productId = "";
		InitiateBlBrebApp initiateBlBrebApp = null;
		String requestString = redisUtils
				.get(RedisConstants.BUREAU_REQ + request.getMobileNo() + RedisConstants.US + request.getAckid());
		if (StringUtils.isNotBlank(requestString)) {
			initiateBlBrebApp = objectMapper.readValue(requestString, InitiateBlBrebApp.class);
			redisUtils.set(
					RedisConstants.PARTNER_JOURNEYID + request.getMobileNo() + RedisConstants.US + request.getAckid(),
					initiateBlBrebApp.partnerJourneyId);
			productId = LappProductId.valueOf(initiateBlBrebApp.getEmploymentType()).toString();
		}
		posidexOutput = redisUtils.get(RedisConstants.NTB_DEDUPE_OUTPUT + mobileNo + RedisConstants.US + tranRefNumber);
		PosidexOutData[] posidexOutDatas = xmLtoJsonParser.parsePosidexOutput(posidexOutput);

		List<LosInputFromsa> inputFromsas = new ArrayList<>();
		if (!Objects.isNull(posidexOutDatas)) {
			Supplier<Stream<PosidexOutData>> supplier = () -> Stream.of(posidexOutDatas);
			supplier.get().forEach(data -> inputFromsas.add(getLosData(data)));
			log.info("out array count {}", inputFromsas.size());
		} else {
			inputFromsas.add(getLosData(new PosidexOutData()));
		}
		String cibilResponse = redisUtils
				.get(MBServiceType.CIBIL.toString() + mobileNo + RedisConstants.US + tranRefNumber);
		log.info("cibilResponse {}", cibilResponse.length());
		List<LosCibAccdetailSrop> cib_accdetail = new ArrayList<>();
		CibilSropDomainList[] sropDomainLists = xmLtoJsonParser.parseCibilResponse(cibilResponse);
		CibilSropDomainList cibilSropDomainList = null;
		if (!Objects.isNull(sropDomainLists)) {
			Supplier<Stream<CibilSropDomainList>> cibilsupplier = () -> Stream.of(sropDomainLists);
			cibilsupplier.get().forEach(data -> cib_accdetail.add(getCibilAccSropData(data)));
			log.info("cib_accdetail out array count {}", cib_accdetail.size());
			cibilSropDomainList = sropDomainLists[0];
		} else {
			cibilSropDomainList = new CibilSropDomainList();
			cib_accdetail.add(getCibilAccSropData(new CibilSropDomainList()));
		}
		String equifaxResponse = redisUtils
				.get(MBServiceType.EQUIFAX.toString() + mobileNo + RedisConstants.US + tranRefNumber);
		EquifaxSropDomain[] equifaxSropDomains = xmLtoJsonParser.parseEquifaxResponse(equifaxResponse);
		List<LosEqAccdetailsSrop> eqAccdetailsSrops = new ArrayList<>();
		if (!Objects.isNull(equifaxSropDomains)) {
			Supplier<Stream<EquifaxSropDomain>> equifaxsupplier = () -> Stream.of(equifaxSropDomains);
			equifaxsupplier.get().forEach(data -> eqAccdetailsSrops.add(getEqLosEqAccdetailsSrop(data)));
			log.info("equifax out array count {}", eqAccdetailsSrops.size());
		} else {
			eqAccdetailsSrops.add(getEqLosEqAccdetailsSrop(new EquifaxSropDomain()));
		}

		String crifHighMarkResponse = redisUtils
				.get(MBServiceType.HIGHMARK.toString() + mobileNo + RedisConstants.US + tranRefNumber);

		ChmBaseSropDomainList1[] chmBaseSropDomainList1 = xmLtoJsonParser
				.parseCrifHighMarkResponse(crifHighMarkResponse);
		List<LosHmBasePriAcctypeSrop> hmBasePriAcctypeSrops = new ArrayList<LosHmBasePriAcctypeSrop>();
		if (!Objects.isNull(chmBaseSropDomainList1)) {
			Supplier<Stream<ChmBaseSropDomainList1>> crifHmsupplier = () -> Stream.of(chmBaseSropDomainList1);
			crifHmsupplier.get().forEach(data -> hmBasePriAcctypeSrops.add(getLosHmBasePriAcctypeSrop(data)));
			log.info("crifhighmark out array count {}", hmBasePriAcctypeSrops.size());
		} else {
			hmBasePriAcctypeSrops.add(getLosHmBasePriAcctypeSrop(new ChmBaseSropDomainList1()));
		}
		String eotLog = redisUtils.get(MBServiceType.MBEOT.toString() + mobileNo + RedisConstants.US + tranRefNumber);
		MBEoTRequestType mbEoTRequestType = xmLtoJsonParser.parseEotResponse(eotLog);
		List<LosMbReqStatus> losMbReqStatus = new ArrayList<LosMbReqStatus>();
		if (!Objects.isNull(mbEoTRequestType)) {
			LosMbReqStatus mbReqStatus = getLosMbReqStatus(mbEoTRequestType);
			losMbReqStatus.add(mbReqStatus);
		} else {
			MultiBureauEoTRequest mbEoTFailureRequestType = xmLtoJsonParser.parseEotFailureResponse(eotLog);
			if (!Objects.isNull(mbEoTFailureRequestType)) {
				LosMbReqStatus mbReqStatus = getLosMbFailureReqStatus(mbEoTFailureRequestType);
				losMbReqStatus.add(mbReqStatus);
			}
		}

		String mbMergedScoreLog = redisUtils
				.get(MBServiceType.MERGED_SCORE.toString() + mobileNo + RedisConstants.US + tranRefNumber);
		MergedSropDomain[] mergedSropDomains = xmLtoJsonParser.parseMergedResponse(mbMergedScoreLog);
		List<LosMergedPastenqSrop> mergedSrops = new ArrayList<LosMergedPastenqSrop>();
		List<LosMergedPaymenthistSrop> mergedPaymenthistSrops = new ArrayList<LosMergedPaymenthistSrop>();
		List<LosMergedTradelinesSrop> mergedTradelinesSrops = new ArrayList<LosMergedTradelinesSrop>();
		if (!Objects.isNull(mergedSropDomains)) {
			Supplier<Stream<MergedSropDomain>> mergedScoresupplier = () -> Stream.of(mergedSropDomains);
			mergedScoresupplier.get().forEach(data -> mergedSrops.add(getLosMergedPastenqSrop(data)));
			mergedScoresupplier.get().forEach(data -> mergedPaymenthistSrops.add(getLosMergedPaymenthistSrop(data)));
			mergedScoresupplier.get().forEach(data -> mergedTradelinesSrops.add(getLosMergedTradelinesSrop(data)));
		} else {
			mergedSrops.add(getLosMergedPastenqSrop(new MergedSropDomain()));
			mergedPaymenthistSrops.add(getLosMergedPaymenthistSrop(new MergedSropDomain()));
			mergedTradelinesSrops.add(getLosMergedTradelinesSrop(new MergedSropDomain()));
		}

		String hunterResponse = redisUtils
				.get(RedisConstants.NTB_HUNTER + mobileNo + RedisConstants.US + tranRefNumber);

		HunterResponse hunterResponseObj = xmLtoJsonParser.parseHunterResponse(hunterResponse);

		ResultBlock resultBlock = null;
		if (!Objects.isNull(hunterResponseObj.getEnvelope())) {
			resultBlock = hunterResponseObj.getEnvelope().getBody().getMatchResponse().getMatchResult()
					.getResultBlock();
		} else {
			resultBlock = new ResultBlock();
		}
		String blResponseStr = redisUtils.get(RedisConstants.NTB_BLAPP + mobileNo + RedisConstants.US + tranRefNumber);
		BlResponse blResponse = xmLtoJsonParser.parseBlResponse(blResponseStr);
		String ftnrResponseStr = redisUtils.get(RedisConstants.NTB_FTNR + mobileNo + RedisConstants.US + tranRefNumber);
		FtnrResponse ftnrResponseobj = xmLtoJsonParser.parseFtnrResponse(ftnrResponseStr);

		BlBre1bApplication blBre1bApplication = getBlBre1bApplication(initiateBlBrebApp);
		blBre1bApplication = getBlBre1bApplication(blBre1bApplication, resultBlock, cibilSropDomainList, blResponse,
				ftnrResponseobj);

		blBre1bApplication.setLosInputFromsas(inputFromsas);
		blBre1bApplication.setLaaProductIdC(productId);
		blBre1bApplication.setLosCibAccdetailSrop(cib_accdetail);
		blBre1bApplication.setLosEqAccdetailsSrop(eqAccdetailsSrops);
		blBre1bApplication.setLosHmBasePriAcctypeSrop(hmBasePriAcctypeSrops);
		blBre1bApplication.setLosMbReqStatus(losMbReqStatus);
		blBre1bApplication.setLosMergedPastenqSrop(mergedSrops);
		blBre1bApplication.setLosMergedTradelinesSrop(mergedTradelinesSrops);
		blBre1bApplication.setLosMergedPaymenthistSrop(mergedPaymenthistSrops);

		String apirequest = objectMapper.writeValueAsString(blBre1bApplication);
		String response = "";
		OffsetDateTime creationTime = OffsetDateTime.now();
		String status = "";
			status = ApiResponseType.initiated.toString();
			try {
				log.info("blbre1b api request {}", apirequest);
				org.json.simple.JSONObject jsonObject = openBankapiConnector.processBREApiRequest(apirequest.toString(),
						bre1bUrl.trim());
				response = jsonObject.toString();
				log.info("blbre1b api response {}", response);
			} catch (Exception e) {
				throw e;
			}
		 
		if (StringUtils.isNotBlank(response)) {
			redisUtils.set(RedisConstants.NTB_BLBRE1B + request.mobileNo + RedisConstants.US + request.ackid, response);
			BlBre1bResponse blBre1bResponse = xmLtoJsonParser.parseBlBre1bResponse(response);
			if (!Objects.isNull(blBre1bResponse) && blBre1bResponse.status == AppConstants.ACE_BRESUCCESS_CODE) {
				status = ApiResponseType.success.toString();
				redisUtils.set(RedisConstants.NTB_BLBRE1B_SUC + request.mobileNo + RedisConstants.US + request.ackid,
						status);
				request.setProductId(initiateBlBrebApp.productCode);
				request.setField1(initiateBlBrebApp.partnerJourneyId);
				this.prepareCallBackRequest(request, BreServiceType.GetBureauOffer.toString(), response);
			} else {
				status = ApiResponseType.failure.toString();
				request.setProductId(initiateBlBrebApp.productCode);
				request.setField1(initiateBlBrebApp.partnerJourneyId);
				this.prepareCallBackRequest(request, BreServiceType.GetBureauOffer.toString(), response);
			}
		} else {
			status = ApiResponseType.failure.toString();
		}

        BreServiceEntity breServiceEntity = new BreServiceEntity(request.mobileNo,
                objectMapper.writeValueAsString(blBre1bApplication), response, creationTime, OffsetDateTime.now(),
                initiateBlBrebApp.productCode, BreServiceType.bl_bre1b, status, request.ackid);
        if (Objects.nonNull(breServiceEntity)) {
            this.breRepository.save(breServiceEntity);
        }
		return ApiResponse.success(true);
	}

	@Override
	public ApiResponse<Object> getPerfiosData(@Valid InitiatePerfios request) throws Exception {
		InitiateBlBrebApp initiateBlBrebApp = null;
		PerfiosTxnStatusResponse jsonObj = null;
		String requestString = redisUtils
				.get(RedisConstants.BUREAU_REQ + request.getMobileNumber() + RedisConstants.US + request.getAckId());
		if (StringUtils.isNotBlank(requestString)) {
			initiateBlBrebApp = objectMapper.readValue(requestString, InitiateBlBrebApp.class);
		}

		PerfiosTxnStatusRequest perfiosTxnStatusRequest = PerfiosTxnStatusRequest
				.toPerfiosTxnStatusRequest(request.getTxnId(), initiateBlBrebApp);
		String txnStatusPayload = new XmlMapper().disable(SerializationFeature.FAIL_ON_EMPTY_BEANS)
				.writeValueAsString(perfiosTxnStatusRequest);
		log.info("payload for txn status {} ", txnStatusPayload);
		String signature = PerfiosUtil.getSignature(AppConstants.ENCRYPTION_ALGO, AppConstants.DIGEST_ALGO,
				txnStatusPayload.toString(), initiateBlBrebApp.employmentType);
		log.info("signature for txn status {} ", signature);
		String requestPayload = "payload=" + txnStatusPayload + "&signature=" + signature + "";
		String perfiosTxnStatusResponse = connection.perfiosCall(requestPayload, PERFIOS_TXN_STATUS);
		log.info("perfiosTxnStatusResponse {}", perfiosTxnStatusResponse);

		PerfiosEntity perfiosEntity = new PerfiosEntity(request.getMobileNumber(), txnStatusPayload,
				perfiosTxnStatusResponse, OffsetDateTime.now(), OffsetDateTime.now(), request.getProduct(),
				PerfiosResponseType.txn_status, "initiated", request.getAckId());
        if (Objects.nonNull(perfiosEntity)) {
            this.perfiosRepository.save(perfiosEntity);
        }
		if (StringUtils.isNotBlank(perfiosTxnStatusResponse)) {

			List<Part> parts = xmLtoJsonParser.parsePerfiosTxnStatusResponse(perfiosTxnStatusResponse);
            JSONObject txnStatusObj = XML.toJSONObject(perfiosTxnStatusResponse);
			if (Objects.nonNull(parts)) {
				for (Part part : parts) {
					String status = part.status;
					perfiosEntity.setStatus(status);
					perfiosEntity.setUpdateddate(OffsetDateTime.now());
                    if (Objects.nonNull(perfiosEntity)) {
					this.perfiosRepository.save(perfiosEntity);
                    }
					objectMapper.enable(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY);
					jsonObj = objectMapper.readValue(txnStatusObj.toString(), PerfiosTxnStatusResponse.class);
					if (status.equalsIgnoreCase(AppConstants.SUCCESS)) {
						String payload = "";
						if (initiateBlBrebApp.employmentType.equalsIgnoreCase(EmploymentType.SEB.toString())) {
							payload = "apiVersion=" + AppConstants.API_VERSION + "&perfiosTransactionId="
									+ part.perfiosTransactionId + "&reportType=" + AppConstants.PERFIOS_REPORTTYPE
									+ "&txnId=" + request.getTxnId() + "&vendorId=" + AppConstants.SME_VENDOR_ID + "";
						} else {
							payload = "apiVersion=" + AppConstants.API_VERSION + "&perfiosTransactionId="
									+ part.perfiosTransactionId + "&reportType=" + AppConstants.PERFIOS_REPORTTYPE
									+ "&txnId=" + request.getTxnId() + "&vendorId=" + AppConstants.VENDOR_ID + "";
						}

						log.info("perfiosRetrieve request {}", payload);
						String perfiosResponse = connection.perfiosCall(payload, PERFIOS_RETRIEVE);
						log.info("perfiosRetrieve response {}", perfiosResponse);
						objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
						objectMapper.configure(DeserializationFeature.READ_UNKNOWN_ENUM_VALUES_AS_NULL, true);
						objectMapper.configure(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT, true);
						if (StringUtils.isNotBlank(perfiosResponse)) {
							JSONObject json = org.json.XML.toJSONObject(perfiosResponse);
							if (initiateBlBrebApp.employmentType.equalsIgnoreCase(EmploymentType.SEB.toString())
									|| initiateBlBrebApp.employmentType
											.equalsIgnoreCase(EmploymentType.SEP.toString())) {
								PerfiosSmeResponse perfiosSmeResponse = objectMapper.readValue(json.toString(),
										PerfiosSmeResponse.class);
								if (Objects.nonNull(perfiosSmeResponse))
									log.debug("perfios SME response object {}", "valid response");
							} else {
								PerfiosResponse perfiosResponse1 = objectMapper.readValue(json.toString(),
										PerfiosResponse.class);
								if (Objects.nonNull(perfiosResponse1))
									log.debug("perfios RETAIL response object {}", "valid response");
							}
							redisUtils.set(RedisConstants.PERFIOS_RETRIVE_DATA + request.getMobileNumber()
									+ RedisConstants.US + request.getAckId(), perfiosResponse);
							redisUtils.set(RedisConstants.EMPLOYMENT_TYPE + request.getMobileNumber()
									+ RedisConstants.US + request.getAckId(), EmploymentType.SEP.toString());

                            PerfiosEntity perfiosEntity1 = new PerfiosEntity(request.getMobileNumber(), payload,
                                    perfiosResponse, OffsetDateTime.now(), OffsetDateTime.now(), request.getProduct(),
                                    PerfiosResponseType.Retreive_data, "success", request.getAckId());
                            if (Objects.nonNull(perfiosEntity1)) {
                                this.perfiosRepository.save(perfiosEntity1);
                            }
							return ApiResponse.success(jsonObj);
						}
					} else {
						// bre callback shoudl call here ...
						return ApiResponse.errordata(jsonObj);
					}
				}
			} else {
				return ApiResponse.errordata(null);
			}
		}
		return ApiResponse.errordata(null);
	}

	@Override
	public ApiResponse<Object> initiateBlBre2AApplication(@Valid InBreServices request) throws Exception {
		String mobileNo = request.getMobileNo();
		String tranRefNumber = request.getAckid();
		String posidexOutput = "";
		InitBlbre2aApplication initBlbre2aApplication = null;
		InitiateBlBrebApp initiateBlBrebApp = null;
		String pqgcoffer = getPqgcOffer(request);
		log.info("pqgcoffer {}", pqgcoffer);
		if (pqgcoffer.equalsIgnoreCase("Y")) {

			String requestString = redisUtils
					.get(RedisConstants.BUREAU_REQ + request.getMobileNo() + RedisConstants.US + request.getAckid());
			if (StringUtils.isNotBlank(requestString)) {
				initiateBlBrebApp = objectMapper.readValue(requestString, InitiateBlBrebApp.class);
			}

			posidexOutput = redisUtils
					.get(RedisConstants.NTB_DEDUPE_OUTPUT + mobileNo + RedisConstants.US + tranRefNumber);
			PosidexOutData[] posidexOutDatas = xmLtoJsonParser.parsePosidexOutput(posidexOutput);
			PosidexOutData posidexOutData = null;
			List<LosInputFromsa> inputFromsas = new ArrayList<>();
			if (!Objects.isNull(posidexOutDatas)) {
				Supplier<Stream<PosidexOutData>> supplier = () -> Stream.of(posidexOutDatas);
				supplier.get().forEach(data -> inputFromsas.add(getLosData(data)));
				log.info("out array count {}", inputFromsas.size());
				posidexOutData = posidexOutDatas[0];
			} else {
				posidexOutData = new PosidexOutData();
				inputFromsas.add(getLosData(new PosidexOutData()));
			}
			String cibilResponse = redisUtils
					.get(MBServiceType.CIBIL.toString() + mobileNo + RedisConstants.US + tranRefNumber);
			log.info("cibilResponse {}", cibilResponse.length());
			List<LosCibAccdetailSrop> cib_accdetail = new ArrayList<>();
			CibilSropDomainList[] sropDomainLists = xmLtoJsonParser.parseCibilResponse(cibilResponse);
			if (!Objects.isNull(sropDomainLists)) {
				Supplier<Stream<CibilSropDomainList>> cibilsupplier = () -> Stream.of(sropDomainLists);
				cibilsupplier.get().forEach(data -> cib_accdetail.add(getCibilAccSropData(data)));
				log.info("cib_accdetail out array count {}", cib_accdetail.size());
			} else {
				cib_accdetail.add(getCibilAccSropData(new CibilSropDomainList()));
			}
			String equifaxResponse = redisUtils
					.get(MBServiceType.EQUIFAX.toString() + mobileNo + RedisConstants.US + tranRefNumber);
			EquifaxSropDomain[] equifaxSropDomains = xmLtoJsonParser.parseEquifaxResponse(equifaxResponse);
			List<LosEqAccdetailsSrop> eqAccdetailsSrops = new ArrayList<>();
			if (!Objects.isNull(equifaxSropDomains)) {
				Supplier<Stream<EquifaxSropDomain>> equifaxsupplier = () -> Stream.of(equifaxSropDomains);
				equifaxsupplier.get().forEach(data -> eqAccdetailsSrops.add(getEqLosEqAccdetailsSrop(data)));
				log.info("equifax out array count {}", eqAccdetailsSrops.size());
			} else {
				eqAccdetailsSrops.add(getEqLosEqAccdetailsSrop(new EquifaxSropDomain()));
			}

			String crifHighMarkResponse = redisUtils
					.get(MBServiceType.HIGHMARK.toString() + mobileNo + RedisConstants.US + tranRefNumber);

			ChmBaseSropDomainList1[] chmBaseSropDomainList1 = xmLtoJsonParser
					.parseCrifHighMarkResponse(crifHighMarkResponse);
			List<LosHmBasePriAcctypeSrop> hmBasePriAcctypeSrops = new ArrayList<LosHmBasePriAcctypeSrop>();
			if (!Objects.isNull(chmBaseSropDomainList1)) {
				Supplier<Stream<ChmBaseSropDomainList1>> crifHmsupplier = () -> Stream.of(chmBaseSropDomainList1);
				crifHmsupplier.get().forEach(data -> hmBasePriAcctypeSrops.add(getLosHmBasePriAcctypeSrop(data)));
				log.info("crifhighmark out array count {}", hmBasePriAcctypeSrops.size());
			} else {
				hmBasePriAcctypeSrops.add(getLosHmBasePriAcctypeSrop(new ChmBaseSropDomainList1()));
			}
			String eotLog = redisUtils
					.get(MBServiceType.MBEOT.toString() + mobileNo + RedisConstants.US + tranRefNumber);
			MBEoTRequestType mbEoTRequestType = xmLtoJsonParser.parseEotResponse(eotLog);
			List<LosMbReqStatus> losMbReqStatus = new ArrayList<LosMbReqStatus>();
			if (!Objects.isNull(mbEoTRequestType)) {
				LosMbReqStatus mbReqStatus = getLosMbReqStatus(mbEoTRequestType);
				losMbReqStatus.add(mbReqStatus);
			} else {
				MultiBureauEoTRequest mbEoTFailureRequestType = xmLtoJsonParser.parseEotFailureResponse(eotLog);
				if (!Objects.isNull(mbEoTFailureRequestType)) {
					LosMbReqStatus mbReqStatus = getLosMbFailureReqStatus(mbEoTFailureRequestType);
					losMbReqStatus.add(mbReqStatus);
				} else {
					LosMbReqStatus mbReqStatus = getLosMbReqEmptyStatus(tranRefNumber);
					losMbReqStatus.add(mbReqStatus);
				}
			}

			String mbMergedScoreLog = redisUtils
					.get(MBServiceType.MERGED_SCORE.toString() + mobileNo + RedisConstants.US + tranRefNumber);
			MergedSropDomain[] mergedSropDomains = xmLtoJsonParser.parseMergedResponse(mbMergedScoreLog);
			List<LosMergedPastenqSrop> mergedSrops = new ArrayList<LosMergedPastenqSrop>();
			List<LosMergedPaymenthistSrop> mergedPaymenthistSrops = new ArrayList<LosMergedPaymenthistSrop>();
			List<LosMergedTradelinesSrop> mergedTradelinesSrops = new ArrayList<LosMergedTradelinesSrop>();
			if (!Objects.isNull(mergedSropDomains)) {
				Supplier<Stream<MergedSropDomain>> mergedScoresupplier = () -> Stream.of(mergedSropDomains);
				mergedScoresupplier.get().forEach(data -> mergedSrops.add(getLosMergedPastenqSrop(data)));
				mergedScoresupplier.get()
						.forEach(data -> mergedPaymenthistSrops.add(getLosMergedPaymenthistSrop(data)));
				mergedScoresupplier.get().forEach(data -> mergedTradelinesSrops.add(getLosMergedTradelinesSrop(data)));
			} else {
				mergedSrops.add(getLosMergedPastenqSrop(new MergedSropDomain()));
				mergedPaymenthistSrops.add(getLosMergedPaymenthistSrop(new MergedSropDomain()));
				mergedTradelinesSrops.add(getLosMergedTradelinesSrop(new MergedSropDomain()));
			}
 

			String employmentType = initiateBlBrebApp.employmentType;
			String perfiosResponse = redisUtils
					.get(RedisConstants.PERFIOS_RETRIVE_DATA + mobileNo + RedisConstants.US + tranRefNumber);
			if (employmentType.equalsIgnoreCase(EmploymentType.SEB.toString())) {
				// sme
				log.info("sme employment perfios response {}", perfiosResponse.length());
				List<LAPSummaryInfo> lapSummaryInfos = new ArrayList<LAPSummaryInfo>();
				com.hdfcbank.elengine.domain.response.perfios.sme.PIRData pirSmeData = xmLtoJsonParser
						.getPerfiosSmeResponse(perfiosResponse);

				LAPOUTPUTDetails lapoutputDetails = pirSmeData.getLAPOUTPUTDetails();

				lapSummaryInfos
						.add(lapoutputDetails.getAccount1() != null ? lapoutputDetails.getAccount1().getLAPSummaryInfo()
								: null);
				lapSummaryInfos
						.add(lapoutputDetails.getAccount2() != null ? lapoutputDetails.getAccount1().getLAPSummaryInfo()
								: null);
				lapSummaryInfos
						.add(lapoutputDetails.getAccount3() != null ? lapoutputDetails.getAccount1().getLAPSummaryInfo()
								: null);
				lapSummaryInfos
						.add(lapoutputDetails.getAccount4() != null ? lapoutputDetails.getAccount1().getLAPSummaryInfo()
								: null);
				lapSummaryInfos
						.add(lapoutputDetails.getAccount5() != null ? lapoutputDetails.getAccount1().getLAPSummaryInfo()
								: null);

				log.info("lapSummaryInfos size {}", lapSummaryInfos.size());
				lapSummaryInfos = lapSummaryInfos.stream().filter(x -> x != null).collect(Collectors.toList());
				log.info("lapSummaryInfos size after filter null {}", lapSummaryInfos.size());
				List<PerfiosSmeUrlgenDtl> perfiosSmeUrlgenDtls = new ArrayList<PerfiosSmeUrlgenDtl>();
				
				lapSummaryInfos.stream()
						.forEach(data -> perfiosSmeUrlgenDtls.add(getPerfiosSmeUrlgenDtl(data, null, null)));

				List<PerfsmeMonthlydtl> perfsmeMonthlydtls = new ArrayList<PerfsmeMonthlydtl>();
				List<com.hdfcbank.elengine.domain.response.perfios.sme.MonthlyDetails> monthlyDetails = new ArrayList<com.hdfcbank.elengine.domain.response.perfios.sme.MonthlyDetails>();
				pirSmeData.getAccountAnalysis().parallelStream()
						.forEach(data -> monthlyDetails.add(data.getMonthlyDetails()));
				monthlyDetails.parallelStream().forEach(data -> setMonthlyDetails(data, perfsmeMonthlydtls));
				log.info("perfsmeMonthlydtls size {}", perfsmeMonthlydtls.size());

				List<PerfiosNetFigureDetail> figureDetails = new ArrayList<PerfiosNetFigureDetail>();

				if (pirSmeData.getPAEBACDetails().getSummaryInfo1() != null) {
					pirSmeData.getPAEBACDetails().getSummaryInfo1().getPerfiosNetFigure1().getPerfiosNetFigureDetails()
							.parallelStream().forEach(data -> figureDetails.add(data));
				}
				if (pirSmeData.getPAEBACDetails().getSummaryInfo2() != null) {
					pirSmeData.getPAEBACDetails().getSummaryInfo2().getPerfiosNetFigure2().getPerfiosNetFigureDetails()
							.parallelStream().forEach(data -> figureDetails.add(data));
				}
				if (pirSmeData.getPAEBACDetails().getSummaryInfo3() != null) {
					pirSmeData.getPAEBACDetails().getSummaryInfo3().getPerfiosNetFigure3().getPerfiosNetFigureDetails()
							.parallelStream().forEach(data -> figureDetails.add(data));
				}
				if (pirSmeData.getPAEBACDetails().getSummaryInfo4() != null) {
					pirSmeData.getPAEBACDetails().getSummaryInfo4().getPerfiosNetFigure4().getPerfiosNetFigureDetails()
							.parallelStream().forEach(data -> figureDetails.add(data));
				}
				if (pirSmeData.getPAEBACDetails().getSummaryInfo5() != null) {
					pirSmeData.getPAEBACDetails().getSummaryInfo5().getPerfiosNetFigure5().getPerfiosNetFigureDetails()
							.parallelStream().forEach(data -> figureDetails.add(data));
				}

				List<PerfsmePeabacNetfigureDtl> perfsmePeabacNetfigureDtls = new ArrayList<PerfsmePeabacNetfigureDtl>();
				figureDetails.parallelStream()
						.forEach(data -> perfsmePeabacNetfigureDtls.add(getPeabacNetfigureDtl(data)));

				List<PerfsmeSummaryinfo> perfsmeSummaryinfos = new ArrayList<PerfsmeSummaryinfo>();
				List<SummaryInfo> summaryInfos = new ArrayList<SummaryInfo>();
				pirSmeData.getAccountAnalysis().parallelStream()
						.forEach(data -> summaryInfos.add(data.getSummaryInfo()));
				summaryInfos.parallelStream().forEach(data -> perfsmeSummaryinfos.add(getPerfsmeSummaryinfo(data)));
				summaryInfos.parallelStream()
						.forEach(data -> perfsmeSummaryinfos.add(getPerfsmeSummaryAverageinfo(data)));

				List<PerfsmeXnDtl> perfsmeXnDtls = new ArrayList<PerfsmeXnDtl>();
				List<HighValueCreditXns> highValueCreditXns = new ArrayList<HighValueCreditXns>();
				List<HighValueDebitXns> highValueDebitXns = new ArrayList<HighValueDebitXns>();

				pirSmeData.getAccountAnalysis().parallelStream()
						.forEach(data -> highValueCreditXns.add(data.getHighValueCreditXns()));
				highValueCreditXns.parallelStream().forEach(data -> setPerfsmeCreditXnDtl(data, perfsmeXnDtls));
				pirSmeData.getAccountAnalysis().parallelStream()
						.forEach(data -> highValueDebitXns.add(data.getHighValueDebitXns()));
				highValueDebitXns.parallelStream().forEach(data -> setPerfsmeDebitXnDtl(data, perfsmeXnDtls));

				String blbre1bResponse = redisUtils
						.get(RedisConstants.NTB_BLBRE1B + mobileNo + RedisConstants.US + tranRefNumber);
				BlBre1bResponse blBre1bResponse = xmLtoJsonParser.parseBlBre1bResponse(blbre1bResponse);

				Bre1bOutput blBre1bResponse1 = BlBre2aAutoMapper.INSTANCE.mapBlBre1bResponse(blBre1bResponse);

				List<Bre1bOutput> list = new ArrayList<Bre1bOutput>();
				list.add(blBre1bResponse1);

				initBlbre2aApplication = BlBre2aSmeAutoMapper.INSTANCE.mapInitBlbre2aApplication(pirSmeData,
						pirSmeData.getPAEBACDetails().getStandardVariables(), list, posidexOutData);
				initBlbre2aApplication.setLosCibAccdetailSrop(cib_accdetail);
				initBlbre2aApplication.setLosEqAccdetailsSrop(eqAccdetailsSrops);
				initBlbre2aApplication.setLosHmBasePriAcctypeSrop(hmBasePriAcctypeSrops);
				initBlbre2aApplication.setLosMbReqStatus(losMbReqStatus);
				initBlbre2aApplication.setLosMergedPastenqSrop(mergedSrops);
				initBlbre2aApplication.setLosMergedTradelinesSrop(mergedTradelinesSrops);
				initBlbre2aApplication.setLosMergedPaymenthistSrop(mergedPaymenthistSrops);
				initBlbre2aApplication.setPerfiosSmeUrlgenDtl(perfiosSmeUrlgenDtls);
				initBlbre2aApplication.setPerfsmeMonthlydtl(perfsmeMonthlydtls);
				initBlbre2aApplication.setPerfsmePeabacNetfigureDtl(perfsmePeabacNetfigureDtls);
				initBlbre2aApplication.setPerfsmeSummaryinfo(perfsmeSummaryinfos);
				initBlbre2aApplication.setPerfsmeXnDtl(perfsmeXnDtls);

			} else {
				// retail
				log.info("retail perfios response {}", perfiosResponse);
				PIRData pirRetailData = xmLtoJsonParser.getPerfiosRetailResponse(perfiosResponse);
				EODBalances eodBalances = pirRetailData.getEODBalances();
				EODBalance eodbalance = eodBalances.getEODBalance().isEmpty() == false
						? eodBalances.getEODBalance().get(0)
						: new EODBalance();

				MonthlyDetails monthlyDetails = pirRetailData.getMonthlyDetails();
				com.hdfcbank.elengine.domain.response.perfios.MonthlyDetail monthlyDetail = monthlyDetails
						.getMonthlyDetail().isEmpty() == false ? monthlyDetails.getMonthlyDetail().get(0)
								: new com.hdfcbank.elengine.domain.response.perfios.MonthlyDetail();

				ScoringDetails scoringDetails = pirRetailData.getScoringDetails();
				Detail detail = scoringDetails.getDetail().isEmpty() == false ? scoringDetails.getDetail().get(0)
						: new Detail();

				com.hdfcbank.elengine.domain.response.perfios.SummaryInfo summaryInfo = pirRetailData.getSummaryInfo();

				Xns xns = pirRetailData.getXns();

				Xn xn = xns.getXn().isEmpty() == false ? xns.getXn().get(0) : new Xn();

				String blbre1bResponse = redisUtils
						.get(RedisConstants.NTB_BLBRE1B + mobileNo + RedisConstants.US + tranRefNumber);
				BlBre1bResponse blBre1bResponse = xmLtoJsonParser.parseBlBre1bResponse(blbre1bResponse);

				Bre1bOutput blBre1bResponse1 = BlBre2aAutoMapper.INSTANCE.mapBlBre1bResponse(blBre1bResponse);

				List<Bre1bOutput> list = new ArrayList<Bre1bOutput>();
				list.add(blBre1bResponse1);

				initBlbre2aApplication = BlBre2aAutoMapper.INSTANCE.mapInitBlbre2aApplication(pirRetailData, eodbalance,
						monthlyDetail, detail, summaryInfo, xns, xn, list, new StandardVariables(), posidexOutData);
				initBlbre2aApplication.setLosCibAccdetailSrop(cib_accdetail);
				initBlbre2aApplication.setLosEqAccdetailsSrop(eqAccdetailsSrops);
				initBlbre2aApplication.setLosHmBasePriAcctypeSrop(hmBasePriAcctypeSrops);
				initBlbre2aApplication.setLosMbReqStatus(losMbReqStatus);
				initBlbre2aApplication.setLosMergedPastenqSrop(mergedSrops);
				initBlbre2aApplication.setLosMergedTradelinesSrop(mergedTradelinesSrops);
				initBlbre2aApplication.setLosMergedPaymenthistSrop(mergedPaymenthistSrops);

			}

			String apirequest = objectMapper.writeValueAsString(initBlbre2aApplication);
			String response = "";
			OffsetDateTime creationTime = OffsetDateTime.now();
			String status = "";
				status = ApiResponseType.initiated.toString();
				try {
					log.info("blbre2a api request {}", apirequest);
					org.json.simple.JSONObject jsonObject = openBankapiConnector
							.processBREApiRequest(apirequest.toString(), bre2aUrl.trim());
					response = jsonObject.toString();
					log.info("blbre2a api response {}", response);
				} catch (Exception e) {
					throw e;
				}
			 
			if (StringUtils.isNotBlank(response)) {
				redisUtils.set(RedisConstants.NTB_BLBRE2A + request.mobileNo + RedisConstants.US + request.ackid,
						response);
				BlBre2AResponse blBre2AResponse = objectMapper.readValue(response, BlBre2AResponse.class);
				if (!Objects.isNull(blBre2AResponse) && blBre2AResponse.status == AppConstants.ACE_BRESUCCESS_CODE) {
					status = ApiResponseType.success.toString();
					request.setProductId(initiateBlBrebApp.productCode);
					request.setField1(initiateBlBrebApp.partnerJourneyId);
				} else {
					status = ApiResponseType.failure.toString();
					request.setProductId(initiateBlBrebApp.productCode);
					request.setField1(initiateBlBrebApp.partnerJourneyId);
				}
				redisUtils.set(RedisConstants.NTB_BLBRE2C_SUC + request.mobileNo + RedisConstants.US + request.ackid,
						status);
				this.prepareCallBackRequest(request, BreServiceType.GetIncomeBasedOffer.toString(), response);
			} else {
				status = ApiResponseType.failure.toString();
			}
            BreServiceEntity breServiceEntity = new BreServiceEntity(request.getMobileNo(),
                    objectMapper.writeValueAsString(initBlbre2aApplication), response, creationTime,
                    OffsetDateTime.now(), request.getProductId(), BreServiceType.blbre2a, status, request.ackid);
            if (Objects.nonNull(breServiceEntity)) {
                this.breRepository.save(breServiceEntity);
            }
		}
		return ApiResponse.success(true);
	}

	@Override
	public ApiResponse<Object> initPerfiosDebitScore(@Valid InBreServices request) throws Exception {

		String mobileNo = request.getMobileNo();
		String tranRefNumber = request.getAckid();
		InitiateBlBrebApp initiateBlBrebApp = null;

		String pqgcoffer = getPqgcOffer(request);
		log.info("pqgcoffer {}", pqgcoffer);
		if (pqgcoffer.equalsIgnoreCase("N")) {

			String requestString = redisUtils
					.get(RedisConstants.BUREAU_REQ + request.getMobileNo() + RedisConstants.US + request.getAckid());
			log.info("InitiateBlBrebApp {}", requestString);
			if (StringUtils.isNotBlank(requestString)) {
				initiateBlBrebApp = objectMapper.readValue(requestString, InitiateBlBrebApp.class);
			}

			String employmentType = initiateBlBrebApp.employmentType;

			if (employmentType.equalsIgnoreCase(EmploymentType.SEB.toString())) {

				String perfiosResponse = redisUtils.get(RedisConstants.PERFIOS_RETRIVE_DATA + mobileNo + RedisConstants.US + tranRefNumber);

				List<LAPSummaryInfo> lapSummaryInfos = new ArrayList<LAPSummaryInfo>();
				com.hdfcbank.elengine.domain.response.perfios.sme.PIRData pirSmeData = xmLtoJsonParser
						.getPerfiosSmeResponse(perfiosResponse);
				
				LAPOUTPUTDetails lapoutputDetails = pirSmeData.getLAPOUTPUTDetails();
				String perfiosTransactionId = pirSmeData.customerInfo.perfiosTransactionId;

				lapSummaryInfos.add(lapoutputDetails.getAccount1() != null ? lapoutputDetails.getAccount1().getLAPSummaryInfo()
								: null);
				lapSummaryInfos
						.add(lapoutputDetails.getAccount2() != null ? lapoutputDetails.getAccount1().getLAPSummaryInfo()
								: null);
				lapSummaryInfos
						.add(lapoutputDetails.getAccount3() != null ? lapoutputDetails.getAccount1().getLAPSummaryInfo()
								: null);
				lapSummaryInfos
						.add(lapoutputDetails.getAccount4() != null ? lapoutputDetails.getAccount1().getLAPSummaryInfo()
								: null);
				lapSummaryInfos
						.add(lapoutputDetails.getAccount5() != null ? lapoutputDetails.getAccount1().getLAPSummaryInfo()
								: null);

				log.info("lapSummaryInfos size {}", lapSummaryInfos.size());
				lapSummaryInfos = lapSummaryInfos.stream().filter(x -> x != null).collect(Collectors.toList());
				log.info("lapSummaryInfos size after filter null {}", lapSummaryInfos.size());
				List<PerfiosSmeUrlgenDtl> perfiosSmeUrlgenDtls = new ArrayList<PerfiosSmeUrlgenDtl>();
				lapSummaryInfos.stream().forEach(data -> perfiosSmeUrlgenDtls
						.add(getPerfiosSmeUrlgenDtl(data, perfiosTransactionId, tranRefNumber)));

				List<PerfsmeMonthlydtl> perfsmeMonthlydtls = new ArrayList<PerfsmeMonthlydtl>();
				List<com.hdfcbank.elengine.domain.response.perfios.sme.MonthlyDetails> monthlyDetails = new ArrayList<com.hdfcbank.elengine.domain.response.perfios.sme.MonthlyDetails>();
				pirSmeData.getAccountAnalysis().parallelStream()
						.forEach(data -> monthlyDetails.add(data.getMonthlyDetails()));
				monthlyDetails.parallelStream().forEach(data -> setMonthlyDetails(data, perfsmeMonthlydtls));
				log.info("perfsmeMonthlydtls size {}", perfsmeMonthlydtls.size());

				List<PerfiosNetFigureDetail> figureDetails = new ArrayList<PerfiosNetFigureDetail>();

				if (pirSmeData.getPAEBACDetails().getSummaryInfo1() != null) {
					pirSmeData.getPAEBACDetails().getSummaryInfo1().getPerfiosNetFigure1().getPerfiosNetFigureDetails()
							.parallelStream().forEach(data -> figureDetails.add(data));
				}
				if (pirSmeData.getPAEBACDetails().getSummaryInfo2() != null) {
					pirSmeData.getPAEBACDetails().getSummaryInfo2().getPerfiosNetFigure2().getPerfiosNetFigureDetails()
							.parallelStream().forEach(data -> figureDetails.add(data));
				}
				if (pirSmeData.getPAEBACDetails().getSummaryInfo3() != null) {
					pirSmeData.getPAEBACDetails().getSummaryInfo3().getPerfiosNetFigure3().getPerfiosNetFigureDetails()
							.parallelStream().forEach(data -> figureDetails.add(data));
				}
				if (pirSmeData.getPAEBACDetails().getSummaryInfo4() != null) {
					pirSmeData.getPAEBACDetails().getSummaryInfo4().getPerfiosNetFigure4().getPerfiosNetFigureDetails()
							.parallelStream().forEach(data -> figureDetails.add(data));
				}
				if (pirSmeData.getPAEBACDetails().getSummaryInfo5() != null) {
					pirSmeData.getPAEBACDetails().getSummaryInfo5().getPerfiosNetFigure5().getPerfiosNetFigureDetails()
							.parallelStream().forEach(data -> figureDetails.add(data));
				}

				List<PerfsmePeabacNetfigureDtl> perfsmePeabacNetfigureDtls = new ArrayList<PerfsmePeabacNetfigureDtl>();
				figureDetails.parallelStream()
						.forEach(data -> perfsmePeabacNetfigureDtls.add(getPeabacNetfigureDtl(data)));

				List<PerfsmeSummaryinfo> perfsmeSummaryinfos = new ArrayList<PerfsmeSummaryinfo>();
				List<SummaryInfo> summaryInfos = new ArrayList<SummaryInfo>();
				pirSmeData.getAccountAnalysis().parallelStream()
						.forEach(data -> summaryInfos.add(data.getSummaryInfo()));
				summaryInfos.parallelStream().forEach(data -> perfsmeSummaryinfos.add(getPerfsmeSummaryinfo(data)));
				summaryInfos.parallelStream()
						.forEach(data -> perfsmeSummaryinfos.add(getPerfsmeSummaryAverageinfo(data)));

				List<PerfsmeXnDtl> perfsmeXnDtls = new ArrayList<PerfsmeXnDtl>();
				List<HighValueCreditXns> highValueCreditXns = new ArrayList<HighValueCreditXns>();
				List<HighValueDebitXns> highValueDebitXns = new ArrayList<HighValueDebitXns>();

				pirSmeData.getAccountAnalysis().parallelStream()
						.forEach(data -> highValueCreditXns.add(data.getHighValueCreditXns()));
				highValueCreditXns.parallelStream().forEach(data -> setPerfsmeCreditXnDtl(data, perfsmeXnDtls));
				pirSmeData.getAccountAnalysis().parallelStream()
						.forEach(data -> highValueDebitXns.add(data.getHighValueDebitXns()));
				highValueDebitXns.parallelStream().forEach(data -> setPerfsmeDebitXnDtl(data, perfsmeXnDtls));

				InitBlBre2bApplication initBlBre2bApplication = BlBre2bAutoMapper.INSTANCE
						.mapBre2bApplication(pirSmeData.getPAEBACDetails().getStandardVariables());
				initBlBre2bApplication.setPerfiosSmeUrlgenDtl(perfiosSmeUrlgenDtls);
				initBlBre2bApplication.setPerfsmeMonthlydtl(perfsmeMonthlydtls);
				initBlBre2bApplication.setPerfsmePeabacNetfigureDtl(perfsmePeabacNetfigureDtls);
				initBlBre2bApplication.setPerfsmeSummaryinfo(perfsmeSummaryinfos);
				initBlBre2bApplication.setPerfsmeXnDtl(perfsmeXnDtls);

				String apirequest = objectMapper.writeValueAsString(initBlBre2bApplication);
				String response = "";
				OffsetDateTime creationTime = OffsetDateTime.now();
				String status = "";
					status = ApiResponseType.initiated.toString();
					try {
						log.info("blbre2b api request {}", apirequest);
						org.json.simple.JSONObject jsonObject = openBankapiConnector
								.processBREApiRequest(apirequest.toString(), bre2bUrl.trim());
						response = jsonObject.toString();
						log.info("blbre2b api response {}", response);
					} catch (Exception e) {
						throw e;
					}
				 
				if (StringUtils.isNotBlank(response)) {
					redisUtils.set(RedisConstants.NTB_BLBRE2B + request.mobileNo + RedisConstants.US + request.ackid,
							response);
					BlBre2bResponse perfliosdebitscoreResponse = xmLtoJsonParser
							.parsePerfliosdebitscoreResponse(response);
					if (!Objects.isNull(perfliosdebitscoreResponse)
							&& perfliosdebitscoreResponse.status == AppConstants.ACE_BRESUCCESS_CODE) {
						status = ApiResponseType.success.toString();
						request.setProductId(initiateBlBrebApp.productCode);
					} else {
						status = ApiResponseType.failure.toString();
						request.setProductId(initiateBlBrebApp.productCode);
						request.setField1(initiateBlBrebApp.partnerJourneyId);
						this.prepareCallBackRequest(request, BreServiceType.GetIncomeBasedOffer.toString(), response);
					}
				} else {
					status = ApiResponseType.failure.toString();
				}

                BreServiceEntity breServiceEntity = new BreServiceEntity(request.getMobileNo(),
                        objectMapper.writeValueAsString(initBlBre2bApplication), response, creationTime,
                        OffsetDateTime.now(), request.getProductId(), BreServiceType.blbre2b, status, request.ackid);
                if (Objects.nonNull(breServiceEntity)) {
                    this.breRepository.save(breServiceEntity);
                }
			}
		}
		return ApiResponse.success(true);
	}

	@Override
	public ApiResponse<Object> initBlBre2CApplication(@Valid InBreServices request) throws Exception {

		String mobileNo = request.getMobileNo();
		String tranRefNumber = request.getAckid();
		String posidexOutput = "";
		String pqgcoffer = getPqgcOffer(request);
		log.info("pqgcoffer {}", pqgcoffer);
		if (pqgcoffer.equalsIgnoreCase("N")) {

			InitiateBlBrebApp initiateBlBrebApp = null;
			String requestString = redisUtils
					.get(RedisConstants.BUREAU_REQ + request.getMobileNo() + RedisConstants.US + request.getAckid());
			if (StringUtils.isNotBlank(requestString)) {
				initiateBlBrebApp = objectMapper.readValue(requestString, InitiateBlBrebApp.class);
			}

			String blappResponse = redisUtils
					.get(RedisConstants.NTB_BLAPP + mobileNo + RedisConstants.US + tranRefNumber);
			String ftnrResponse = redisUtils
					.get(RedisConstants.NTB_FTNR + mobileNo + RedisConstants.US + tranRefNumber);
			String blbre2bResponse = redisUtils
					.get(RedisConstants.NTB_BLBRE2B + mobileNo + RedisConstants.US + tranRefNumber);
			String hunterResponse = redisUtils
					.get(RedisConstants.NTB_HUNTER + mobileNo + RedisConstants.US + tranRefNumber);

			String blbre1bResponse = redisUtils
					.get(RedisConstants.NTB_BLBRE1B + mobileNo + RedisConstants.US + tranRefNumber);

			BlResponse blResponse = xmLtoJsonParser.parseBlResponse(blappResponse);

			FtnrResponse ftnrResponseobj = xmLtoJsonParser.parseFtnrResponse(ftnrResponse);

			BlBre2bResponse perfliosdebitscoreResponse = xmLtoJsonParser
					.parsePerfliosdebitscoreResponse(blbre2bResponse);

			HunterResponse hunterResponseObj = xmLtoJsonParser.parseHunterResponse(hunterResponse);

			ResultBlock resultBlock = null;
			if (!Objects.isNull(hunterResponseObj.getEnvelope())) {
				resultBlock = hunterResponseObj.getEnvelope().getBody().getMatchResponse().getMatchResult()
						.getResultBlock();
			} else {
				resultBlock = new ResultBlock();
			}

			String currentDate = CommonUtility.getDate(AppConstants.DATE_FMT_ddMMyyyy2);

			IpaScorecard ipaScorecard = new IpaScorecard();
			StpFailReason failReason = new StpFailReason();
			List<StpFailReason> failReasons = new ArrayList<StpFailReason>();
			failReasons.add(failReason);
			ipaScorecard.setStpFailReason(failReasons);
			List<IpaScorecard> ipaScorecards = new ArrayList<IpaScorecard>();
			ipaScorecards.add(ipaScorecard);

			BlBre1bResponse bre1bResponse = xmLtoJsonParser.parseBlBre1bResponse(blbre1bResponse);

			Bre1bOutput blBre1bResponse1 = BlBre2aAutoMapper.INSTANCE.mapBlBre1bResponse(bre1bResponse);

			List<Bre1bOutput> blBre1bResponses = new ArrayList<Bre1bOutput>();
			blBre1bResponses.add(blBre1bResponse1);

			posidexOutput = redisUtils
					.get(RedisConstants.NTB_DEDUPE_OUTPUT + mobileNo + RedisConstants.US + tranRefNumber);
			PosidexOutData[] posidexOutDatas = xmLtoJsonParser.parsePosidexOutput(posidexOutput);

			List<LosInputFromsa> inputFromsas = new ArrayList<>();
			if (!Objects.isNull(posidexOutDatas)) {
				Supplier<Stream<PosidexOutData>> supplier = () -> Stream.of(posidexOutDatas);
				supplier.get().forEach(data -> inputFromsas.add(getLosData(data)));
				log.info("out array count {}", inputFromsas.size());
			} else {
				inputFromsas.add(getLosData(new PosidexOutData()));
			}
			String cibilResponse = redisUtils
					.get(MBServiceType.CIBIL.toString() + mobileNo + RedisConstants.US + tranRefNumber);
			log.info("cibilResponse {}", cibilResponse.length());
			List<LosCibAccdetailSrop> cib_accdetail = new ArrayList<>();
			CibilSropDomainList[] sropDomainLists = xmLtoJsonParser.parseCibilResponse(cibilResponse);
			if (!Objects.isNull(sropDomainLists)) {
				Supplier<Stream<CibilSropDomainList>> cibilsupplier = () -> Stream.of(sropDomainLists);
				cibilsupplier.get().forEach(data -> cib_accdetail.add(getCibilAccSropData(data)));
				log.info("cib_accdetail out array count {}", cib_accdetail.size());
			} else {
				cib_accdetail.add(getCibilAccSropData(new CibilSropDomainList()));
			}
			String equifaxResponse = redisUtils
					.get(MBServiceType.EQUIFAX.toString() + mobileNo + RedisConstants.US + tranRefNumber);
			EquifaxSropDomain[] equifaxSropDomains = xmLtoJsonParser.parseEquifaxResponse(equifaxResponse);
			List<LosEqAccdetailsSrop> eqAccdetailsSrops = new ArrayList<>();
			if (!Objects.isNull(equifaxSropDomains)) {
				Supplier<Stream<EquifaxSropDomain>> equifaxsupplier = () -> Stream.of(equifaxSropDomains);
				equifaxsupplier.get().forEach(data -> eqAccdetailsSrops.add(getEqLosEqAccdetailsSrop(data)));
				log.info("equifax out array count {}", eqAccdetailsSrops.size());
			} else {
				eqAccdetailsSrops.add(getEqLosEqAccdetailsSrop(new EquifaxSropDomain()));
			}

			String crifHighMarkResponse = redisUtils
					.get(MBServiceType.HIGHMARK.toString() + mobileNo + RedisConstants.US + tranRefNumber);

			ChmBaseSropDomainList1[] chmBaseSropDomainList1 = xmLtoJsonParser
					.parseCrifHighMarkResponse(crifHighMarkResponse);
			List<com.hdfcbank.elengine.domain.request.bre.blbre1b.LosHmBasePriAcctypeSrop> hmBasePriAcctypeSrops = new ArrayList<com.hdfcbank.elengine.domain.request.bre.blbre1b.LosHmBasePriAcctypeSrop>();
			if (!Objects.isNull(chmBaseSropDomainList1)) {
				Supplier<Stream<ChmBaseSropDomainList1>> crifHmsupplier = () -> Stream.of(chmBaseSropDomainList1);
				crifHmsupplier.get().forEach(data -> hmBasePriAcctypeSrops.add(getLosHmBasePriAcctypeSrop_bre2c(data)));
				log.info("crifhighmark out array count {}", hmBasePriAcctypeSrops.size());
			} else {
				hmBasePriAcctypeSrops.add(getLosHmBasePriAcctypeSrop_bre2c(new ChmBaseSropDomainList1()));
			}
			String eotLog = redisUtils
					.get(MBServiceType.MBEOT.toString() + mobileNo + RedisConstants.US + tranRefNumber);
			MBEoTRequestType mbEoTRequestType = xmLtoJsonParser.parseEotResponse(eotLog);
			List<LosMbReqStatus> losMbReqStatus = new ArrayList<LosMbReqStatus>();
			if (!Objects.isNull(mbEoTRequestType)) {
				LosMbReqStatus mbReqStatus = getLosMbReqStatus(mbEoTRequestType);
				losMbReqStatus.add(mbReqStatus);
			} else {
				MultiBureauEoTRequest mbEoTFailureRequestType = xmLtoJsonParser.parseEotFailureResponse(eotLog);
				if (!Objects.isNull(mbEoTFailureRequestType)) {
					LosMbReqStatus mbReqStatus = getLosMbFailureReqStatus(mbEoTFailureRequestType);
					losMbReqStatus.add(mbReqStatus);
				}else {
					LosMbReqStatus mbReqStatus = getLosMbReqEmptyStatus(tranRefNumber);
					losMbReqStatus.add(mbReqStatus);
				}
			}

			String mbMergedScoreLog = redisUtils
					.get(MBServiceType.MERGED_SCORE.toString() + mobileNo + RedisConstants.US + tranRefNumber);
			MergedSropDomain[] mergedSropDomains = xmLtoJsonParser.parseMergedResponse(mbMergedScoreLog);
			List<com.hdfcbank.elengine.domain.request.bre.blbre1b.LosMergedPastenqSrop> mergedSrops = new ArrayList<com.hdfcbank.elengine.domain.request.bre.blbre1b.LosMergedPastenqSrop>();
			List<LosMergedPaymenthistSrop> mergedPaymenthistSrops = new ArrayList<LosMergedPaymenthistSrop>();
			List<LosMergedTradelinesSrop> mergedTradelinesSrops = new ArrayList<LosMergedTradelinesSrop>();
			if (!Objects.isNull(mergedSropDomains)) {
				Supplier<Stream<MergedSropDomain>> mergedScoresupplier = () -> Stream.of(mergedSropDomains);
				mergedScoresupplier.get().forEach(data -> mergedSrops.add(getLosMergedPastenqSrop_bre2c(data)));
				mergedScoresupplier.get()
						.forEach(data -> mergedPaymenthistSrops.add(getLosMergedPaymenthistSrop(data)));
				mergedScoresupplier.get().forEach(data -> mergedTradelinesSrops.add(getLosMergedTradelinesSrop(data)));
			} else {
				mergedSrops.add(getLosMergedPastenqSrop_bre2c(new MergedSropDomain()));
				mergedPaymenthistSrops.add(getLosMergedPaymenthistSrop(new MergedSropDomain()));
				mergedTradelinesSrops.add(getLosMergedTradelinesSrop(new MergedSropDomain()));
			}

			InitBlbre2cApplication initBlbre2cApplication = BlBre2cAutoMapper.INSTANCE.mapInitBlbre2cApplication(
					currentDate, request, resultBlock, blResponse, ipaScorecards, blBre1bResponses, ftnrResponseobj,
					perfliosdebitscoreResponse);

			String employmentType = initiateBlBrebApp.employmentType;

			String perfiosResponse = redisUtils
					.get(RedisConstants.PERFIOS_RETRIVE_DATA + mobileNo + RedisConstants.US + tranRefNumber);

			if (employmentType.equalsIgnoreCase(EmploymentType.SEB.toString())
					|| employmentType.equalsIgnoreCase(EmploymentType.SEP.toString())) {
				// sme
				log.info("sme");
				List<LAPSummaryInfo> lapSummaryInfos = new ArrayList<LAPSummaryInfo>();
				com.hdfcbank.elengine.domain.response.perfios.sme.PIRData pirSmeData = xmLtoJsonParser
						.getPerfiosSmeResponse(perfiosResponse);
				LAPOUTPUTDetails lapoutputDetails = pirSmeData.getLAPOUTPUTDetails();
				String perfiosTransactionId = pirSmeData.customerInfo.perfiosTransactionId;
				lapSummaryInfos
						.add(lapoutputDetails.getAccount1() != null ? lapoutputDetails.getAccount1().getLAPSummaryInfo()
								: null);
				lapSummaryInfos
						.add(lapoutputDetails.getAccount2() != null ? lapoutputDetails.getAccount1().getLAPSummaryInfo()
								: null);
				lapSummaryInfos
						.add(lapoutputDetails.getAccount3() != null ? lapoutputDetails.getAccount1().getLAPSummaryInfo()
								: null);
				lapSummaryInfos
						.add(lapoutputDetails.getAccount4() != null ? lapoutputDetails.getAccount1().getLAPSummaryInfo()
								: null);
				lapSummaryInfos
						.add(lapoutputDetails.getAccount5() != null ? lapoutputDetails.getAccount1().getLAPSummaryInfo()
								: null);

				log.info("lapSummaryInfos size {}", lapSummaryInfos.size());
				lapSummaryInfos = lapSummaryInfos.stream().filter(x -> x != null).collect(Collectors.toList());
				log.info("lapSummaryInfos size after filter null {}", lapSummaryInfos.size());
				List<PerfiosSmeUrlgenDtl> perfiosSmeUrlgenDtls = new ArrayList<PerfiosSmeUrlgenDtl>();
				lapSummaryInfos.stream().forEach(data -> perfiosSmeUrlgenDtls
						.add(getPerfiosSmeUrlgenDtl(data, perfiosTransactionId, tranRefNumber)));

				List<PerfsmeMonthlydtl> perfsmeMonthlydtls = new ArrayList<PerfsmeMonthlydtl>();
				List<com.hdfcbank.elengine.domain.response.perfios.sme.MonthlyDetails> monthlyDetails = new ArrayList<com.hdfcbank.elengine.domain.response.perfios.sme.MonthlyDetails>();
				pirSmeData.getAccountAnalysis().parallelStream()
						.forEach(data -> monthlyDetails.add(data.getMonthlyDetails()));
				monthlyDetails.parallelStream().forEach(data -> setMonthlyDetails(data, perfsmeMonthlydtls));
				log.info("perfsmeMonthlydtls size {}", perfsmeMonthlydtls.size());

				List<PerfiosNetFigureDetail> figureDetails = new ArrayList<PerfiosNetFigureDetail>();

				if (pirSmeData.getPAEBACDetails().getSummaryInfo1() != null) {
					pirSmeData.getPAEBACDetails().getSummaryInfo1().getPerfiosNetFigure1().getPerfiosNetFigureDetails()
							.parallelStream().forEach(data -> figureDetails.add(data));
				}
				if (pirSmeData.getPAEBACDetails().getSummaryInfo2() != null) {
					pirSmeData.getPAEBACDetails().getSummaryInfo2().getPerfiosNetFigure2().getPerfiosNetFigureDetails()
							.parallelStream().forEach(data -> figureDetails.add(data));
				}
				if (pirSmeData.getPAEBACDetails().getSummaryInfo3() != null) {
					pirSmeData.getPAEBACDetails().getSummaryInfo3().getPerfiosNetFigure3().getPerfiosNetFigureDetails()
							.parallelStream().forEach(data -> figureDetails.add(data));
				}
				if (pirSmeData.getPAEBACDetails().getSummaryInfo4() != null) {
					pirSmeData.getPAEBACDetails().getSummaryInfo4().getPerfiosNetFigure4().getPerfiosNetFigureDetails()
							.parallelStream().forEach(data -> figureDetails.add(data));
				}
				if (pirSmeData.getPAEBACDetails().getSummaryInfo5() != null) {
					pirSmeData.getPAEBACDetails().getSummaryInfo5().getPerfiosNetFigure5().getPerfiosNetFigureDetails()
							.parallelStream().forEach(data -> figureDetails.add(data));
				}

				List<PerfsmePeabacNetfigureDtl> perfsmePeabacNetfigureDtls = new ArrayList<PerfsmePeabacNetfigureDtl>();
				figureDetails.parallelStream()
						.forEach(data -> perfsmePeabacNetfigureDtls.add(getPeabacNetfigureDtl(data)));

				List<PerfsmeSummaryinfo> perfsmeSummaryinfos = new ArrayList<PerfsmeSummaryinfo>();
				List<SummaryInfo> summaryInfos = new ArrayList<SummaryInfo>();
				pirSmeData.getAccountAnalysis().parallelStream()
						.forEach(data -> summaryInfos.add(data.getSummaryInfo()));
				summaryInfos.parallelStream().forEach(data -> perfsmeSummaryinfos.add(getPerfsmeSummaryinfo(data)));
				summaryInfos.parallelStream()
						.forEach(data -> perfsmeSummaryinfos.add(getPerfsmeSummaryAverageinfo(data)));

				List<PerfsmeXnDtl> perfsmeXnDtls = new ArrayList<PerfsmeXnDtl>();
				List<HighValueCreditXns> highValueCreditXns = new ArrayList<HighValueCreditXns>();
				List<HighValueDebitXns> highValueDebitXns = new ArrayList<HighValueDebitXns>();

				pirSmeData.getAccountAnalysis().parallelStream()
						.forEach(data -> highValueCreditXns.add(data.getHighValueCreditXns()));
				highValueCreditXns.parallelStream().forEach(data -> setPerfsmeCreditXnDtl(data, perfsmeXnDtls));
				pirSmeData.getAccountAnalysis().parallelStream()
						.forEach(data -> highValueDebitXns.add(data.getHighValueDebitXns()));
				highValueDebitXns.parallelStream().forEach(data -> setPerfsmeDebitXnDtl(data, perfsmeXnDtls));

				initBlbre2cApplication = BlBre2cAutoMapper.INSTANCE.mapInitBlbre2cApplication(initBlbre2cApplication,
						pirSmeData, pirSmeData.getPAEBACDetails().getStandardVariables(), blBre1bResponses);
				initBlbre2cApplication.setPerfiosSmeUrlgenDtl(perfiosSmeUrlgenDtls);
				initBlbre2cApplication.setPerfsmeMonthlydtl(perfsmeMonthlydtls);
				initBlbre2cApplication.setPerfsmePeabacNetfigureDtl(perfsmePeabacNetfigureDtls);
				initBlbre2cApplication.setPerfsmeSummaryinfo(perfsmeSummaryinfos);
				initBlbre2cApplication.setPerfsmeXnDtl(perfsmeXnDtls);

			} else {
				PIRData pirRetailData = xmLtoJsonParser.getPerfiosRetailResponse(perfiosResponse);
				EODBalances eodBalances = pirRetailData.getEODBalances();
				EODBalance eodbalance = eodBalances.getEODBalance().isEmpty() == false
						? eodBalances.getEODBalance().get(0)
						: new EODBalance();

				MonthlyDetails monthlyDetails = pirRetailData.getMonthlyDetails();
				com.hdfcbank.elengine.domain.response.perfios.MonthlyDetail monthlyDetail = monthlyDetails
						.getMonthlyDetail().isEmpty() == false ? monthlyDetails.getMonthlyDetail().get(0)
								: new com.hdfcbank.elengine.domain.response.perfios.MonthlyDetail();

				ScoringDetails scoringDetails = pirRetailData.getScoringDetails();
				Detail detail = scoringDetails.getDetail().isEmpty() == false ? scoringDetails.getDetail().get(0)
						: new Detail();

				com.hdfcbank.elengine.domain.response.perfios.SummaryInfo summaryInfo = pirRetailData.getSummaryInfo();

				Xns xns = pirRetailData.getXns();

				Xn xn = xns.getXn().isEmpty() == false ? xns.getXn().get(0) : new Xn();

				initBlbre2cApplication = BlBre2cAutoMapper.INSTANCE.mapBlbre2cApplication(initBlbre2cApplication,
						pirRetailData, eodbalance, monthlyDetail, detail, summaryInfo, xns, xn,
						new StandardVariables());

			}

			initBlbre2cApplication.setLosCibAccdetailSrop(cib_accdetail);
			initBlbre2cApplication.setLosEqAccdetailsSrop(eqAccdetailsSrops);
			initBlbre2cApplication.setLosHmBasePriAcctypeSrop(hmBasePriAcctypeSrops);
			initBlbre2cApplication.setLosInputFromsas(inputFromsas);
			initBlbre2cApplication.setLosMbReqStatus(losMbReqStatus);
			initBlbre2cApplication.setLosMergedPastenqSrop(mergedSrops);
			initBlbre2cApplication.setLosMergedPaymenthistSrop(mergedPaymenthistSrops);
			initBlbre2cApplication.setLosMergedTradelinesSrop(mergedTradelinesSrops);

			String apirequest = objectMapper.writeValueAsString(initBlbre2cApplication);
			String response = "";
			OffsetDateTime creationTime = OffsetDateTime.now();
			String status = "";
				status = ApiResponseType.initiated.toString();
				try {
					log.info("blbre2c api request {}", apirequest);
					org.json.simple.JSONObject jsonObject = openBankapiConnector
							.processBREApiRequest(apirequest.toString(), bre2cUrl.trim());
					response = jsonObject.toString();
					log.info("blbre2c api response {}", response);
				} catch (Exception e) {
					throw e;
				}
			 
			if (StringUtils.isNotBlank(response)) {
				redisUtils.set(RedisConstants.NTB_BLBRE2C + request.mobileNo + RedisConstants.US + request.ackid,
						response);
				BlBre2CResponse blBre2CResponse = objectMapper.readValue(response, BlBre2CResponse.class);
				if (!Objects.isNull(blBre2CResponse) && blBre2CResponse.status == AppConstants.ACE_BRESUCCESS_CODE) {
					status = ApiResponseType.success.toString();
				} else {
					status = ApiResponseType.failure.toString();
				}
				redisUtils.set(RedisConstants.NTB_BLBRE2C_SUC + request.mobileNo + RedisConstants.US + request.ackid,
						status);
				request.setProductId(initiateBlBrebApp.productCode);
				request.setField1(initiateBlBrebApp.partnerJourneyId);
				this.prepareCallBackRequest(request, BreServiceType.GetIncomeBasedOffer.toString(), response);
			} else {
				status = ApiResponseType.failure.toString();
			}

            BreServiceEntity breServiceEntity = new BreServiceEntity(request.getMobileNo(),
                    objectMapper.writeValueAsString(initBlbre2cApplication), response, creationTime,
                    OffsetDateTime.now(), request.getProductId(), BreServiceType.blbre2c, status, request.ackid);
            if (Objects.nonNull(breServiceEntity)) {
                this.breRepository.save(breServiceEntity);
            }
        }
		return ApiResponse.success(true);
	}

 	@Override
	public String multibureau(String request) throws Exception {
		log.info("multibureau callaback {}", request);
		GenericResponse genericResponse = null;
		GenericFailureResponse genericFailureResponse = null;
		String response = "";
		String operationType = "";
		String acknowledgementId = "";
		String tranRefNo = "";
		String mobileNumber = "";
		String status = "";
		String productCode = "";
		try {

			JSONObject json = org.json.XML.toJSONObject(request);
			log.info("converted json {}" + json);
			ObjectMapper objectMapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES,
					false);
			objectMapper.configure(DeserializationFeature.READ_UNKNOWN_ENUM_VALUES_AS_NULL, true);
			objectMapper.configure(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT, true);
			try {
				genericResponse = objectMapper.readValue(json.toString(), GenericResponse.class);
				if (genericResponse.soapenvEnvelope.soapenvBody.multiBureauResponse != null) {
					status = genericResponse.soapenvEnvelope.soapenvBody.multiBureauResponse.response.finished.status;
					log.info("genericResponse {}", status);
					acknowledgementId = genericResponse.soapenvEnvelope.soapenvBody.multiBureauResponse.response.acknowledgementId;
					tranRefNo = genericResponse.soapenvEnvelope.soapenvBody.multiBureauResponse.response.header.applicationId;
					operationType = genericResponse.soapenvEnvelope.soapenvBody.multiBureauResponse.response.finished.bureau;
				} else if (genericResponse.soapenvEnvelope.soapenvBody.multiBureauEoTRequest != null) {
					status = genericResponse.soapenvEnvelope.soapenvBody.multiBureauEoTRequest.status.content;
					acknowledgementId = genericResponse.soapenvEnvelope.soapenvBody.multiBureauEoTRequest.acknowledgementId.content;
					tranRefNo = genericResponse.soapenvEnvelope.soapenvBody.multiBureauEoTRequest.header.applicationId;
					operationType = RedisConstants.MBEOT_WOUN;
				}
				log.info("operationType {}", operationType);
				if (operationType.equalsIgnoreCase("CRIF HIGHMARK")) {
					operationType = MBServiceType.HIGHMARK.toString();
				}
				mobileNumber = redisUtils.get(RedisConstants.NTB_MOBILE_NO + String.valueOf(tranRefNo));
				this.saveMbCalBacksintoRedis(mobileNumber, tranRefNo, status, operationType);
				productCode = redisUtils.get(RedisConstants.PRODUCTCODE + mobileNumber + RedisConstants.US + tranRefNo);

				MbCallbackRequest callbackRequest = MbCallbackRequest.toMbCallbackRequest(
						String.valueOf(acknowledgementId), commonUtility.returnBureauStatus(status));
				response = new XmlMapper().writeValueAsString(callbackRequest);
				 
                MBEntity mbEntity = new MBEntity(mobileNumber, request, response, OffsetDateTime.now(), OffsetDateTime.now(),
                        productCode, MBServiceType.valueOf(operationType), status, String.valueOf(tranRefNo));
                if (Objects.nonNull(mbEntity)) {
                    multiBureauRepository.save(mbEntity);
                }
				redisUtils.set(operationType + mobileNumber + RedisConstants.US + tranRefNo, request.toString());
				return response;
			} catch (Exception e) {
				log.error("multibureau failure response exc {}", e);
				genericFailureResponse = objectMapper.readValue(json.toString(), GenericFailureResponse.class);
				status = genericFailureResponse.soapenvEnvelope.soapenvBody.multiBureauResponse.response.reject.status;
				log.info("genericFailureResponse {}", status);
				acknowledgementId = genericFailureResponse.soapenvEnvelope.soapenvBody.multiBureauResponse.response.acknowledgementId;
				tranRefNo = genericFailureResponse.soapenvEnvelope.soapenvBody.multiBureauResponse.response.header.applicationId;
				mobileNumber = redisUtils.get(RedisConstants.NTB_MOBILE_NO + String.valueOf(tranRefNo));
				productCode = redisUtils.get(RedisConstants.PRODUCTCODE + mobileNumber + RedisConstants.US + tranRefNo);
				MbCallbackRequest callbackRequest = MbCallbackRequest.toMbCallbackRequest(
						String.valueOf(acknowledgementId), commonUtility.returnBureauStatus(status));
				response = new XmlMapper().writeValueAsString(callbackRequest);
				operationType = genericFailureResponse.soapenvEnvelope.soapenvBody.multiBureauResponse.response.reject.bureau;
                MBEntity mbEntity = new MBEntity(mobileNumber, request, response, OffsetDateTime.now(), OffsetDateTime.now(),
                        productCode, MBServiceType.valueOf(operationType), status, String.valueOf(tranRefNo));
                if (Objects.nonNull(mbEntity)) {
                    multiBureauRepository.save(mbEntity);
                }
				redisUtils.set(operationType + mobileNumber + RedisConstants.US + tranRefNo, request.toString());
				return response;
			}

		} catch (Exception e) {
			log.error("multibureau failure exc {}", e);
		}
		log.info("call back response {}", response);
		return null;
	}

	@Override
	public String multibureaumerge(String mergerequest) throws Exception {
		log.info("multibureaumerge callaback {}", mergerequest);
		GenericResponse genericResponse = null;
		GenericFailureResponse genericFailureResponse = null;
		String response = "";
		String operationType = "";
		String acknowledgementId = "";
		String tranRefNo = "";
		String mobileNumber = "";
		String productCode = "";
		try {
			JSONObject json = org.json.XML.toJSONObject(mergerequest);
			log.info("converted mergerequest json {}" + json);
			ObjectMapper objectMapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES,
					false);
			objectMapper.configure(DeserializationFeature.READ_UNKNOWN_ENUM_VALUES_AS_NULL, true);
			objectMapper.configure(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT, true);
			try {
				genericResponse = objectMapper.readValue(json.toString(), GenericResponse.class);
				String status = genericResponse.soapenvEnvelope.soapenvBody.multiBureauResponse.response.status;
				log.info("generic multibureaumerge Response {}", status);
				acknowledgementId = genericResponse.soapenvEnvelope.soapenvBody.multiBureauResponse.response.acknowledgementId;
				tranRefNo = genericResponse.soapenvEnvelope.soapenvBody.multiBureauResponse.response.header.applicationId;
				mobileNumber = redisUtils.get(RedisConstants.NTB_MOBILE_NO + String.valueOf(tranRefNo));
				operationType = genericResponse.soapenvEnvelope.soapenvBody.multiBureauResponse.response.finished.bureau;
				this.saveMbCalBacksintoRedis(mobileNumber, tranRefNo, status, operationType);
				productCode = redisUtils.get(RedisConstants.PRODUCTCODE + mobileNumber + RedisConstants.US + tranRefNo);
				MergedbureauCallbackRequest callbackRequest = MergedbureauCallbackRequest.toMbCallbackRequest(
						String.valueOf(acknowledgementId), commonUtility.returnBureauStatus(status));
				response = new XmlMapper().writeValueAsString(callbackRequest);

                MBEntity mbEntity = new MBEntity(mobileNumber, mergerequest, response, OffsetDateTime.now(), OffsetDateTime.now(),
                        productCode, MBServiceType.valueOf(operationType), status, String.valueOf(tranRefNo));
                if (Objects.nonNull(mbEntity)) {
                    multiBureauRepository.save(mbEntity);
                }
				redisUtils.set(operationType + mobileNumber + RedisConstants.US + tranRefNo, mergerequest.toString());
				return response;
			} catch (Exception e) {
				log.error("multibureaumerge failure response exc {}", e);
				genericFailureResponse = objectMapper.readValue(json.toString(), GenericFailureResponse.class);
				String status = genericFailureResponse.soapenvEnvelope.soapenvBody.multiBureauResponse.response.status;
				log.info("generic multibureaumerge FailureResponse {}", status);
				acknowledgementId = genericFailureResponse.soapenvEnvelope.soapenvBody.multiBureauResponse.response.acknowledgementId;
				tranRefNo = genericFailureResponse.soapenvEnvelope.soapenvBody.multiBureauResponse.response.header.applicationId;
				mobileNumber = redisUtils.get(RedisConstants.NTB_MOBILE_NO + String.valueOf(tranRefNo));
				productCode = redisUtils.get(RedisConstants.PRODUCTCODE + mobileNumber + RedisConstants.US + tranRefNo);
				MergedbureauCallbackRequest callbackRequest = MergedbureauCallbackRequest.toMbCallbackRequest(
						String.valueOf(acknowledgementId), commonUtility.returnBureauStatus(status));
				response = new XmlMapper().writeValueAsString(callbackRequest);
				operationType = genericFailureResponse.soapenvEnvelope.soapenvBody.multiBureauResponse.response.reject.bureau;
                MBEntity mbEntity = new MBEntity(mobileNumber, mergerequest, response, OffsetDateTime.now(), OffsetDateTime.now(),
                        productCode, MBServiceType.valueOf(operationType), status, String.valueOf(tranRefNo));
                if (Objects.nonNull(mbEntity)) {
                    multiBureauRepository.save(mbEntity);
                }
				redisUtils.set(operationType + mobileNumber + RedisConstants.US + tranRefNo, mergerequest.toString());
				return response;
			}

		} catch (Exception e) {
			log.error("multibureaumerge failure exc {}", e);
		}
		log.info("call back response {}", response);
		return null;
	}

	private void saveMbCalBacksintoRedis(String mobileNumber, String applicationId, String respStatus,
			String bureauName) {
		long multiCBCount = 0;
		if (respStatus.equals("-1") || respStatus.equals("-4") || respStatus.equals("END-OF-TXN")) {

			String callBackCountKey = RedisConstants.MULTICALLBACKS + mobileNumber + RedisConstants.US + applicationId;
			log.info("callBackCountKey {}", callBackCountKey);
			redisUtils.sadd(callBackCountKey, bureauName);
			multiCBCount = redisUtils.scard(callBackCountKey);
			log.info("multiCBCount {}", multiCBCount);
		}
	}

	private List<PerfsmeMonthlydtl> setMonthlyDetails(
			com.hdfcbank.elengine.domain.response.perfios.sme.MonthlyDetails monthlyDetails,
			List<PerfsmeMonthlydtl> perfsmeMonthlydtls) {
		monthlyDetails.getMonthlyDetail().parallelStream()
				.forEach(data -> perfsmeMonthlydtls.add(getPerfsmeMonthlydtl(data)));
		return perfsmeMonthlydtls;
	}

	private List<PerfsmeXnDtl> setPerfsmeDebitXnDtl(HighValueDebitXns highValueDebitXns,
			List<PerfsmeXnDtl> perfsmeXnDtls) {
		highValueDebitXns.getHighValueDebitXn().parallelStream()
				.forEach(data -> perfsmeXnDtls.add(getPerfsmeXnDtl(data)));
		return perfsmeXnDtls;
	}

	private PerfsmeXnDtl getPerfsmeXnDtl(HighValueDebitXn highValueDebitXn) {
		return BlBre2aSmeAutoMapper.INSTANCE.mapPerfsmeDebitXnDtl(highValueDebitXn);
	}

	private List<PerfsmeXnDtl> setPerfsmeCreditXnDtl(HighValueCreditXns highValueCreditXns,
			List<PerfsmeXnDtl> perfsmeXnDtls) {
		highValueCreditXns.getHighValueCreditXn().parallelStream()
				.forEach(data -> perfsmeXnDtls.add(getPerfsmeXnDtl(data)));
		return perfsmeXnDtls;
	}

	private PerfsmeXnDtl getPerfsmeXnDtl(HighValueCreditXn highValueCreditXn) {
		return BlBre2aSmeAutoMapper.INSTANCE.mapPerfsmeCreditXnDtl(highValueCreditXn);
	}

	private PerfsmeSummaryinfo getPerfsmeSummaryinfo(SummaryInfo summaryInfo) {
		return BlBre2aSmeAutoMapper.INSTANCE.mapPerfsmeSummaryinfo(summaryInfo);
	}

	private PerfsmeSummaryinfo getPerfsmeSummaryAverageinfo(SummaryInfo summaryInfo) {
		return BlBre2aSmeAutoMapper.INSTANCE.mapPerfsmeSummaryAverageinfo(summaryInfo);
	}

	private PerfsmePeabacNetfigureDtl getPeabacNetfigureDtl(PerfiosNetFigureDetail perfiosNetFigureDetail) {
		return BlBre2aSmeAutoMapper.INSTANCE.mapPeabacNetfigureDtl(perfiosNetFigureDetail);
	}

	private PerfsmeMonthlydtl getPerfsmeMonthlydtl(MonthlyDetail monthlyDetail) {
		return BlBre2aSmeAutoMapper.INSTANCE.mapPerfsmeMonthlydtl(monthlyDetail);
	}

	private PerfiosSmeUrlgenDtl getPerfiosSmeUrlgenDtl(LAPSummaryInfo lapSummaryInfo, String perfiosTxnId,
			String appId) {
		return BlBre2aSmeAutoMapper.INSTANCE.mapPerfiosSmeUrlgenDtl(perfiosTxnId, appId, lapSummaryInfo);
	}

	private BlBre1bApplication getBlBre1bApplication(InitiateBlBrebApp request) {
		return BlBre1bAutoMapper.INSTANCE.mapBlBre1bApplication(request);
	}

	private BlBre1bApplication getBlBre1bApplication(BlBre1bApplication bre1bApplication, ResultBlock resultBlock,
			CibilSropDomainList sropDomainList, BlResponse blResponse, FtnrResponse ftnrResponseobj) {
		return BlBre1bAutoMapper.INSTANCE.mapBlBre1bApplication(bre1bApplication, resultBlock, sropDomainList,
				blResponse, ftnrResponseobj);
	}

	private LosMergedTradelinesSrop getLosMergedTradelinesSrop(MergedSropDomain mergedSropDomain) {
		return FtnrAutoMapper.INSTANCE.mapLosMergedTradelinesSrop(mergedSropDomain);
	}

	private LosMergedPaymenthistSrop getLosMergedPaymenthistSrop(MergedSropDomain mergedSropDomain) {
		return FtnrAutoMapper.INSTANCE.mapLosMergedPaymenthistSrop(mergedSropDomain);
	}

	private LosMergedPastenqSrop getLosMergedPastenqSrop(MergedSropDomain mergedSropDomain) {
		return FtnrAutoMapper.INSTANCE.mapLosMergedPastenqSrop(mergedSropDomain);
	}

	private com.hdfcbank.elengine.domain.request.bre.blbre1b.LosMergedPastenqSrop getLosMergedPastenqSrop_bre2c(
			MergedSropDomain mergedSropDomain) {
		return BlBre2cAutoMapper.INSTANCE.mapLosMergedPastenqSrop(mergedSropDomain);
	}

	private LosMbReqStatus getLosMbReqStatus(MBEoTRequestType mbEoTRequestType) {
		return FtnrAutoMapper.INSTANCE.mapLosMbReqStatus(mbEoTRequestType);
	}

	private LosMbReqStatus getLosMbReqEmptyStatus(String ackId) {
		return FtnrAutoMapper.INSTANCE.mapLosMbReqEmptyStatus(ackId);
	}

	private LosMbReqStatus getLosMbFailureReqStatus(MultiBureauEoTRequest mbEoTRequestType) {
		return FtnrAutoMapper.INSTANCE.mapLosMbReqFailureStatus(mbEoTRequestType);
	}

	private LosInputFromsa getLosData(PosidexOutData data) {
		return FtnrAutoMapper.INSTANCE.mapPosidexOutBodytoLosInputFromsa(data);
	}

	private LosCibAccdetailSrop getCibilAccSropData(CibilSropDomainList sropDomainList) {
		return FtnrAutoMapper.INSTANCE.mapMbCibiltoLosCibAccdetailSrop(sropDomainList);
	}

	private LosEqAccdetailsSrop getEqLosEqAccdetailsSrop(EquifaxSropDomain equifaxSropDomain) {
		return FtnrAutoMapper.INSTANCE.mapMbEquitoLosEqAccdetailsSrop(equifaxSropDomain);
	}

	private LosHmBasePriAcctypeSrop getLosHmBasePriAcctypeSrop(ChmBaseSropDomainList1 chmBaseSropDomainList1) {
		return FtnrAutoMapper.INSTANCE.mapMBHmtoLosHmBasePriAcctypeSrop(chmBaseSropDomainList1);
	}

	// bre 2c
	private com.hdfcbank.elengine.domain.request.bre.blbre1b.LosHmBasePriAcctypeSrop getLosHmBasePriAcctypeSrop_bre2c(
			ChmBaseSropDomainList1 chmBaseSropDomainList1) {
		return BlBre2cAutoMapper.INSTANCE.mapMBHmtoLosHmBasePriAcctypeSrop(chmBaseSropDomainList1);
	}

	public void prepareCallBackRequest(InBreServices req, String action, String breResponse) {
		try {
			if (StringUtils.isBlank(req.field1)) {
				String partnerJourneyId = redisUtils
						.get(RedisConstants.PARTNER_JOURNEYID + req.getMobileNo() + RedisConstants.US + req.getAckid());
				req.setField1(partnerJourneyId);
			}
			brecallBackUrl = redisUtils.get(RedisConstants.BRE_CALBACK_URL + req.productId);
			log.info("product id {} brecallBackUrl {}", req.productId, brecallBackUrl);
			this.initBreCallBack(ContextParam.toContextParam(req.productId, req.field1, req.ackid), breResponse,
					ResponseParam.toResponseParam(action), brecallBackUrl);
		} catch (IOException e) {
			log.error("Exception while calling bre callback {}", e);
		}
	}

	private void initBreCallBack(ContextParam contextparam, String responsestring, ResponseParam responseParam,
			String callBackUrl) throws IOException {
		CallbackRequest callbackRequest = CallbackRequest.toCallbackRequest(contextparam, responsestring,
				responseParam);
		String apiRequest = new ObjectMapper().writeValueAsString(callbackRequest);
		log.info("bre callback request {}", apiRequest);
		connection.initiateCallBack(apiRequest, callBackUrl);
	}

 
	public String getPqgcOffer(InBreServices request) {
		String incomeOfferReq = redisUtils
				.get(RedisConstants.INCOMEOFFER_REQ + request.getMobileNo() + RedisConstants.US + request.getAckid());
		if (StringUtils.isNotBlank(incomeOfferReq)) {
			InitIncomeOffer incomeOffer;
			try {
				incomeOffer = new ObjectMapper().readValue(incomeOfferReq, InitIncomeOffer.class);
				return incomeOffer.pqgcOffer;
			} catch (Exception e) {
				log.error("Exception {}", e);
			}
		}
		return "";
	}
	
	public String returnErrorResponse(String acknowledgementId,String status) {
		MbCallbackRequest callbackRequest = MbCallbackRequest.toMbCallbackRequest(
				String.valueOf(acknowledgementId), commonUtility.returnBureauStatus(status));
		try {
			String response = new XmlMapper().writeValueAsString(callbackRequest);
			return response;
		} catch (Exception e) {
			// TODO: handle exception
		}
		return null;
	}

	@SuppressWarnings("unused")
	private void deleteCacheDetails(String mobileNumber, String tranRefNumber) {
		Set<String> set = new HashSet<String>();
		set.add(RedisConstants.NTB_MULTI_BUREAU + mobileNumber + RedisConstants.US + tranRefNumber);
		set.add(RedisConstants.NTB_DEDUPE_INPUT + mobileNumber + RedisConstants.US + tranRefNumber);
		set.add(RedisConstants.NTB_DEDUPE_PUBLISH + mobileNumber + RedisConstants.US + tranRefNumber);
		set.add(RedisConstants.NTB_DEDUPE_OUTPUT + mobileNumber + RedisConstants.US + tranRefNumber);
		set.add(RedisConstants.NTB_HUNTER + mobileNumber + RedisConstants.US + tranRefNumber);

		set.add(MBServiceType.MBINPUT.toString() + mobileNumber + RedisConstants.US + tranRefNumber);
		set.add(MBServiceType.CIBIL.toString() + mobileNumber + RedisConstants.US + tranRefNumber);
		set.add(MBServiceType.EQUIFAX.toString() + mobileNumber + RedisConstants.US + tranRefNumber);
		set.add(MBServiceType.EXPERIAN.toString() + mobileNumber + RedisConstants.US + tranRefNumber);
		set.add(MBServiceType.HIGHMARK.toString() + mobileNumber + RedisConstants.US + tranRefNumber);
		set.add(MBServiceType.MERGED_SCORE.toString() + mobileNumber + RedisConstants.US + tranRefNumber);
		set.add(MBServiceType.MBEOT.toString() + mobileNumber + RedisConstants.US + tranRefNumber);

		set.add(RedisConstants.PERFIOS_RETRIVE_DATA + mobileNumber + RedisConstants.US + tranRefNumber);

		// bl bre responses
		set.add(RedisConstants.NTB_BLAPP + mobileNumber + RedisConstants.US + tranRefNumber);
		set.add(RedisConstants.NTB_FTNR + mobileNumber + RedisConstants.US + tranRefNumber);
		set.add(RedisConstants.NTB_BLBRE1B + mobileNumber + RedisConstants.US + tranRefNumber);
		set.add(RedisConstants.NTB_BLBRE2A + mobileNumber + RedisConstants.US + tranRefNumber);
		set.add(RedisConstants.NTB_BLBRE2B + mobileNumber + RedisConstants.US + tranRefNumber);
		set.add(RedisConstants.NTB_BLBRE2C + mobileNumber + RedisConstants.US + tranRefNumber);
		set.add(RedisConstants.NTB_BLBRE3A + mobileNumber + RedisConstants.US + tranRefNumber);
		set.add(RedisConstants.NTB_BLBRE3B + mobileNumber + RedisConstants.US + tranRefNumber);
		// pl bre responses
		set.add(RedisConstants.NTB_EXPBRE1 + mobileNumber + RedisConstants.US + tranRefNumber);
		set.add(RedisConstants.NTB_EXPBRE2 + mobileNumber + RedisConstants.US + tranRefNumber);
		set.add(RedisConstants.NTB_EXPBRE3 + mobileNumber + RedisConstants.US + tranRefNumber);
		try {
			Set<String> deletedSet = new HashSet<>();
			log.info("cachedata added size {}", set.size());
			if (Objects.nonNull(set)) {
				Iterator<String> iterator = set.iterator();
				while (iterator.hasNext()) {
					String string = (String) iterator.next();
					if(redisUtils.del(string) > 0) {
						deletedSet.add(string);
					}
				}
				log.info("cachedata deleted size {}", deletedSet.size());
			}

		} catch (Exception e) {
			log.error("exception {}", e);
		}
	}

 }