package com.hdfcbank.elengine.domain.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Data;

@JsonPropertyOrder({ "ackId", "productCode", "mobileNumber", "ca_name_match_perc", "dr_name_match_perc",
		"appoffice_gst_match_perc", "appresi_gst_match_perc", "appoffice_pan_match_perc", "appresi_pan_match_perc",
		"appoffice_karza_electricity_match_perc", "appresi_karza_electricity_match_perc", "appresi_kyc_match_perc",
		"appoff_appresi_match_perc", "karzaowner_appname_match_perc", "pincode_kyc", "address_from_electricitybill",
		"customer_name", "name_from_electricitybill", "address_from_gst", "name_from_gst", "gst_registration_date",
		"assessment_year", "address_kyc", "mci_status_code", "mci_request_id", "mci_result", "mci_emailid",
		"mci_eligbletovote", "mci_doctoreducationid", "mci_doctregistrationno", "mci_registrationdateprevious",
		"mci_photo", "mci_parentname", "mci_universityid_view", "mci_regdate", "mci_birthdate", "mci_restoredstatus",
		"mci_universityid", "mci_college", "mci_yearofpassing", "mci_addressline1", "mci_salutation",
		"mci_economicstatus", "mci_monthofpass", "mci_othersubject", "mci_city", "mci_restoredon", "mci_uprnno",
		"mci_middlename", "mci_registrationnoprevious", "mci_trasanctionstatus", "mci_monthandyearofpass", "mci_state",
		"mci_yearinfo", "mci_role", "mci_removedon", "mci_catagory", "mci_addressline2", "mci_registrationno",
		"mci_officeaddress", "mci_smcnameprevious", "mci_registrationdate", "mci_addlqualuniv3", "mci_addlqualuniv2",
		"mci_addlqualuniv1", "mci_passoutcollege", "mci_birthdatestr", "mci_birthplace", "mci_addlqualyear3",
		"mci_addlqualyear1", "mci_smcids", "mci_doctorid", "mci_statemedicalcouncil", "mci_removedstatus",
		"mci_remarks", "mci_nationality", "mci_checkexistinguser", "mci_pincode", "mci_uprnnoprevious", "mci_phoneno",
		"mci_gender", "mci_firstname", "mci_stateid", "mci_isnewdoctor", "mci_doctordegree", "mci_university",
		"mci_addlqualyear2", "mci_smcname", "mci_smcid", "mci_adharno", "mci_addlqual3", "mci_addlqual2",
		"mci_addlqual1", "mci_lastname", "mci_catagory_view", "mci_bloodgroup", "mci_country", "mci_homeaddress",
		"mci_collegeid", "mci_address", "mci_regnno", "icai_essentials", "icai_membernumber", "icai_id",
		"icai_patronid", "icai_result", "icai_status", "icai_name", "icai_address", "icai_splitaddress", "icai_state",
		"icai_district", "icai_city", "icai_pincode", "icai_country", "icai_addressline", "icai_date_of_commencement",
		"email_otp_tag", "ekyc_dob", "ekyc_Name_Score", "email_Name_Score", "coId", "appRTerm", "monthlyIncome",
		"loanAmount" })
@Data
public class InitiateBre3App {
	@JsonProperty("ackId")
	public String ackId;
	@JsonProperty("productCode")
	public String productCode;
	@JsonProperty("mobileNumber")
	public String mobileNumber;
	@JsonProperty("ca_name_match_perc")
	public Float caNameMatchPerc;
	@JsonProperty("dr_name_match_perc")
	public Float drNameMatchPerc;
	@JsonProperty("appoffice_gst_match_perc")
	public Float appofficeGstMatchPerc;
	@JsonProperty("appresi_gst_match_perc")
	public Float appresiGstMatchPerc;
	@JsonProperty("appoffice_pan_match_perc")
	public Float appofficePanMatchPerc;
	@JsonProperty("appresi_pan_match_perc")
	public Float appresiPanMatchPerc;
	@JsonProperty("appoffice_karza_electricity_match_perc")
	public Float appofficeKarzaElectricityMatchPerc;
	@JsonProperty("appresi_karza_electricity_match_perc")
	public Float appresiKarzaElectricityMatchPerc;
	@JsonProperty("appresi_kyc_match_perc")
	public Float appresiKycMatchPerc;
	@JsonProperty("appoff_appresi_match_perc")
	public Float appoffAppresiMatchPerc;
	@JsonProperty("karzaowner_appname_match_perc")
	public Float karzaownerAppnameMatchPerc;
	@JsonProperty("pincode_kyc")
	public String pincodeKyc;
	@JsonProperty("address_from_electricitybill")
	public String addressFromElectricitybill;
	@JsonProperty("customer_name")
	public String customerName;
	@JsonProperty("name_from_electricitybill")
	public String nameFromElectricitybill;
	@JsonProperty("address_from_gst")
	public String addressFromGst;
	@JsonProperty("name_from_gst")
	public String nameFromGst;
	@JsonProperty("gst_registration_date")
	public String gstRegistrationDate;
	@JsonProperty("assessment_year")
	public Integer assessmentYear;
	@JsonProperty("address_kyc")
	public String addressKyc;
	@JsonProperty("mci_status_code")
	public String mciStatusCode;
	@JsonProperty("mci_request_id")
	public String mciRequestId;
	@JsonProperty("mci_result")
	public String mciResult;
	@JsonProperty("mci_emailid")
	public String mciEmailid;
	@JsonProperty("mci_eligbletovote")
	public String mciEligbletovote;
	@JsonProperty("mci_doctoreducationid")
	public String mciDoctoreducationid;
	@JsonProperty("mci_doctregistrationno")
	public String mciDoctregistrationno;
	@JsonProperty("mci_registrationdateprevious")
	public String mciRegistrationdateprevious;
	@JsonProperty("mci_photo")
	public String mciPhoto;
	@JsonProperty("mci_parentname")
	public String mciParentname;
	@JsonProperty("mci_universityid_view")
	public String mciUniversityidView;
	@JsonProperty("mci_regdate")
	public String mciRegdate;
	@JsonProperty("mci_birthdate")
	public String mciBirthdate;
	@JsonProperty("mci_restoredstatus")
	public Boolean mciRestoredstatus;
	@JsonProperty("mci_universityid")
	public String mciUniversityid;
	@JsonProperty("mci_college")
	public String mciCollege;
	@JsonProperty("mci_yearofpassing")
	public String mciYearofpassing;
	@JsonProperty("mci_addressline1")
	public String mciAddressline1;
	@JsonProperty("mci_salutation")
	public String mciSalutation;
	@JsonProperty("mci_economicstatus")
	public String mciEconomicstatus;
	@JsonProperty("mci_monthofpass")
	public String mciMonthofpass;
	@JsonProperty("mci_othersubject")
	public String mciOthersubject;
	@JsonProperty("mci_city")
	public String mciCity;
	@JsonProperty("mci_restoredon")
	public String mciRestoredon;
	@JsonProperty("mci_uprnno")
	public String mciUprnno;
	@JsonProperty("mci_middlename")
	public String mciMiddlename;
	@JsonProperty("mci_registrationnoprevious")
	public String mciRegistrationnoprevious;
	@JsonProperty("mci_trasanctionstatus")
	public String mciTrasanctionstatus;
	@JsonProperty("mci_monthandyearofpass")
	public String mciMonthandyearofpass;
	@JsonProperty("mci_state")
	public String mciState;
	@JsonProperty("mci_yearinfo")
	public String mciYearinfo;
	@JsonProperty("mci_role")
	public String mciRole;
	@JsonProperty("mci_removedon")
	public String mciRemovedon;
	@JsonProperty("mci_catagory")
	public String mciCatagory;
	@JsonProperty("mci_addressline2")
	public String mciAddressline2;
	@JsonProperty("mci_registrationno")
	public String mciRegistrationno;
	@JsonProperty("mci_officeaddress")
	public String mciOfficeaddress;
	@JsonProperty("mci_smcnameprevious")
	public String mciSmcnameprevious;
	@JsonProperty("mci_registrationdate")
	public String mciRegistrationdate;
	@JsonProperty("mci_addlqualuniv3")
	public String mciAddlqualuniv3;
	@JsonProperty("mci_addlqualuniv2")
	public String mciAddlqualuniv2;
	@JsonProperty("mci_addlqualuniv1")
	public String mciAddlqualuniv1;
	@JsonProperty("mci_passoutcollege")
	public String mciPassoutcollege;
	@JsonProperty("mci_birthdatestr")
	public String mciBirthdatestr;
	@JsonProperty("mci_birthplace")
	public String mciBirthplace;
	@JsonProperty("mci_addlqualyear3")
	public String mciAddlqualyear3;
	@JsonProperty("mci_addlqualyear1")
	public String mciAddlqualyear1;
	@JsonProperty("mci_smcids")
	public String mciSmcids;
	@JsonProperty("mci_doctorid")
	public Integer mciDoctorid;
	@JsonProperty("mci_statemedicalcouncil")
	public String mciStatemedicalcouncil;
	@JsonProperty("mci_removedstatus")
	public Boolean mciRemovedstatus;
	@JsonProperty("mci_remarks")
	public String mciRemarks;
	@JsonProperty("mci_nationality")
	public String mciNationality;
	@JsonProperty("mci_checkexistinguser")
	public Boolean mciCheckexistinguser;
	@JsonProperty("mci_pincode")
	public String mciPincode;
	@JsonProperty("mci_uprnnoprevious")
	public String mciUprnnoprevious;
	@JsonProperty("mci_phoneno")
	public String mciPhoneno;
	@JsonProperty("mci_gender")
	public String mciGender;
	@JsonProperty("mci_firstname")
	public String mciFirstname;
	@JsonProperty("mci_stateid")
	public String mciStateid;
	@JsonProperty("mci_isnewdoctor")
	public Boolean mciIsnewdoctor;
	@JsonProperty("mci_doctordegree")
	public String mciDoctordegree;
	@JsonProperty("mci_university")
	public String mciUniversity;
	@JsonProperty("mci_addlqualyear2")
	public String mciAddlqualyear2;
	@JsonProperty("mci_smcname")
	public String mciSmcname;
	@JsonProperty("mci_smcid")
	public Integer mciSmcid;
	@JsonProperty("mci_adharno")
	public String mciAdharno;
	@JsonProperty("mci_addlqual3")
	public String mciAddlqual3;
	@JsonProperty("mci_addlqual2")
	public String mciAddlqual2;
	@JsonProperty("mci_addlqual1")
	public String mciAddlqual1;
	@JsonProperty("mci_lastname")
	public String mciLastname;
	@JsonProperty("mci_catagory_view")
	public String mciCatagoryView;
	@JsonProperty("mci_bloodgroup")
	public String mciBloodgroup;
	@JsonProperty("mci_country")
	public String mciCountry;
	@JsonProperty("mci_homeaddress")
	public String mciHomeaddress;
	@JsonProperty("mci_collegeid")
	public String mciCollegeid;
	@JsonProperty("mci_address")
	public String mciAddress;
	@JsonProperty("mci_regnno")
	public String mciRegnno;
	@JsonProperty("icai_essentials")
	public String icaiEssentials;
	@JsonProperty("icai_membernumber")
	public String icaiMembernumber;
	@JsonProperty("icai_id")
	public String icaiId;
	@JsonProperty("icai_patronid")
	public String icaiPatronid;
	@JsonProperty("icai_result")
	public String icaiResult;
	@JsonProperty("icai_status")
	public String icaiStatus;
	@JsonProperty("icai_name")
	public String icaiName;
	@JsonProperty("icai_address")
	public String icaiAddress;
	@JsonProperty("icai_splitaddress")
	public String icaiSplitaddress;
	@JsonProperty("icai_state")
	public String icaiState;
	@JsonProperty("icai_district")
	public String icaiDistrict;
	@JsonProperty("icai_city")
	public String icaiCity;
	@JsonProperty("icai_pincode")
	public String icaiPincode;
	@JsonProperty("icai_country")
	public String icaiCountry;
	@JsonProperty("icai_addressline")
	public String icaiAddressline;
	@JsonProperty("icai_date_of_commencement")
	public String icaiDateOfCommencement;
	@JsonProperty("email_otp_tag")
	public String emailOtpTag;
	@JsonProperty("ekyc_dob")
	public String ekycDob;
	@JsonProperty("ekyc_Name_Score")
	public String ekycNameScore;
	@JsonProperty("email_Name_Score")
	public String emailNameScore;
	@JsonProperty("coId")
	public String coId;
	@JsonProperty("appRTerm")
	public String appRTerm;
	@JsonProperty("monthlyIncome")
	public String monthlyIncome;
	@JsonProperty("loanAmount")
	public String loanAmount;
	 
}
