package com.hdfcbank.elengine.config;

import org.springframework.stereotype.Component;

import lombok.Getter;
@Component
@Getter
public class PropertiesConfig {
	
//	@Value("${hdfc.product.code}")
//	private String hdfcProductCode;

}
