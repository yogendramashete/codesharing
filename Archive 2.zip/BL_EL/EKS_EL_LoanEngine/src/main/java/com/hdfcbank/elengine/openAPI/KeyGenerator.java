package com.hdfcbank.elengine.openAPI;

import java.security.SecureRandom;

/**
 * Random key generator
 * 
 * @author Madhura Oak
 */
public class KeyGenerator  {
	private static final int a = 'a';
	private static final int z = 'z';
	private static final int A = 'A';
	private static final int Z = 'Z';
	private static final int ZERO = '0';
	private static final int NINE = '9';
	
	SecureRandom secureRandom = new SecureRandom();
	
	
	/**
	 * Generates a secure random key of length keySize
	 * @param key size
	 * @return random value
	 */
	public byte[] generateKey(int keySize) {
		SecureRandom secureRandom = new SecureRandom();
		byte[] array = new byte[keySize];
		secureRandom.nextBytes(array);
		return array;
	}
	
	/**
	 * Generates an alphanumeric random key 
	 * @param key size
	 * @return random value
	 */
	public String generateAlphaNumericKey(int keySize) {
		StringBuilder key = new StringBuilder();
		while(key.length() < keySize) {
			int ch = secureRandom.nextInt(128);
			//is within range
			if((ch <= Z && ch >= A) || (ch <= z && ch >= a) || (ch <= NINE && ch >= ZERO)) {
				key.append((char)ch);
			}
		}
		return key.toString();
	}

}
