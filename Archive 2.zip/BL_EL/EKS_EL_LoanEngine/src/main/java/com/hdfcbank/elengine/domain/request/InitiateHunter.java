package com.hdfcbank.elengine.domain.request;


import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class InitiateHunter {

    @NotBlank(message = "name may not be blank")
    @Pattern(regexp = "^[a-zA-Z ]*$",message = "enter proper Name")
    private String name;
    @NotBlank(message = "dob may not be blank")
    @Pattern(regexp = "^\\d{4}-\\d{2}-\\d{2}",message = "enter proper Dob")
    private String dob;
    @NotBlank(message = "mobilenumber may not be blank")
    @Pattern(regexp="(^$|[0-9]{10})",message = "mobile number must be 10 digit")
    private String mobileNumber;
    @NotBlank(message = "pannumber may not be blank")
    @Pattern(regexp = "^[a-zA-Z0-9]*$",message = "enter proper panNumber")
    private String panNumber;
    @NotBlank(message = "transaction reference number may not be blank")
    @Pattern(regexp = "\\d+", message = "enter proper tranRefNumber")
    private String tranRefNumber;
    @NotBlank(message = "productCode may not be blank")
    @Pattern(regexp = "^[a-zA-Z]*$",message = "enter proper product code")
    private String productCode;
    @NotBlank(message = "customerID may not be blank")
    @Pattern(regexp = "\\d+",message = "enter proper customerId")
    private String customerID;
    @NotBlank(message = "pincode may not be blank")
    @Pattern(regexp = "\\d+",message = "enter proper pincode")
    private String pinCode;
    @NotBlank(message = "firstName may not be blank")
    @Pattern(regexp = "^[a-zA-Z]*$",message = "enter proper firstname")
    private String firstName;
    @NotBlank(message = "lastname may not be blank")
    @Pattern(regexp = "^[a-zA-Z]*$",message = "enter proper lastName")
    private String lastName;
    @Pattern(regexp = "\\d+",message = "enter proper partnerJourneyId")
    private String partnerJourneyId;
}
