package com.hdfcbank.elengine.domain.enums;

public enum ConstitutionType {

	SEB(15), SEP(15), SD(16);

	private final int code;

	private ConstitutionType(int code) {
		this.code = code;
	}

	public int toInt() {
		return code;
	}

	public String toString() {
		return String.valueOf(code);
	}
}
