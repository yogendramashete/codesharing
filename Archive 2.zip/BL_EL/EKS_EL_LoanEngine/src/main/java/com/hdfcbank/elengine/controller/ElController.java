package com.hdfcbank.elengine.controller;

import com.hdfcbank.elengine.domain.request.InitiateHunter;
import com.hdfcbank.elengine.domain.request.InitiateMBRequest;
import com.hdfcbank.elengine.domain.request.InitiatePerfios;
import com.hdfcbank.elengine.domain.request.InitiatePosidexDedupe;
import com.hdfcbank.elengine.domain.request.common.InBreServices;
import com.hdfcbank.elengine.service.ElServices;
import com.hdfcbank.elengine.util.ApiResponse;
import com.hdfcbank.elengine.util.CommonUtility;
import io.micrometer.core.annotation.Timed;
import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

@RestController
@Slf4j
@Tag(name = "ElController")
@OpenAPIDefinition(tags = {
@Tag(name = "ElController", description = "this controller handles multibureau,posidex dedupe and hunter services") })
@RequestMapping(path = "/elservices")
public class ElController {

	@Autowired
	private ElServices elServices;

	@Autowired
	private CommonUtility commonUtility;

	@Operation(summary = "Customer multibureau will initiate")
	@PostMapping(value = "/init-mb",produces = MediaType.APPLICATION_JSON_VALUE , consumes = MediaType.APPLICATION_JSON_VALUE)
	@Timed("MB")
	public ApiResponse<Boolean> initiateMultiBuereau(@Valid @RequestBody InitiateMBRequest request) throws Exception {
		log.info("req {}", request);
		return this.elServices.initiateMultiBureu(request);
	}

	@Operation(summary = "Customer Posidex dedupe in will initiate")
	@PostMapping(value = "/init-posidexdedupe",produces = MediaType.APPLICATION_JSON_VALUE , consumes = MediaType.APPLICATION_JSON_VALUE)
	@Timed("POSIDEXDEDUPE")
	public ApiResponse<Boolean> initiatePosidexDedupe(@Valid @RequestBody InitiatePosidexDedupe request)
			throws Exception {
		log.info("req {}", request);
		return this.elServices.initiatePosidexDedupe(request);
	}

	@Operation(summary = "Customer Posidex dedupe Publish will initiate")
	@PostMapping(value = "/init-posidexdedupepublish",produces = MediaType.APPLICATION_JSON_VALUE , consumes = MediaType.APPLICATION_JSON_VALUE)
	@Timed("POSIDEXPUBLISH")
	public ApiResponse<Boolean> initiatePosidexDedupePublish(@Valid @RequestBody InitiatePosidexDedupe request)
			throws Exception {
		return this.elServices.publishPosidexDedupe(request);
	}

	@Operation(summary = "Customer hunter will initiate")
	@PostMapping(value = "/init-hunter",produces = MediaType.APPLICATION_JSON_VALUE , consumes = MediaType.APPLICATION_JSON_VALUE)
	@Timed("HUNTER")
	public ApiResponse<Boolean> initiateHunter(@Valid @RequestBody InitiateHunter request) throws Exception {
		log.info("req {}", request);
		return this.elServices.initiateHunter(request);
	}

	@Operation(summary = "Customer initiate bl application")
	@PostMapping(value = "/init-blapp",produces = MediaType.APPLICATION_JSON_VALUE , consumes = MediaType.APPLICATION_JSON_VALUE)
	@Timed("BLAPP")
	public ApiResponse<Boolean> initiateBlApplication(@Valid @RequestBody InBreServices request) throws Exception {
		return this.elServices.initiateBlApplication(request);
	}

	@Operation(summary = "Customer initiate ftnr application")
	@PostMapping(value = "/init-ftnr",produces = MediaType.APPLICATION_JSON_VALUE , consumes = MediaType.APPLICATION_JSON_VALUE)
	@Timed("FTNR")
	public ApiResponse<Object> initiateFtnrApplication(@Valid @RequestBody InBreServices request) throws Exception {
		return this.elServices.initiateFtnrApplication(request);
	}

	@Operation(summary = "Customer initiate bl_bre_1b application")
	@PostMapping(value = "/init-blbre1b",produces = MediaType.APPLICATION_JSON_VALUE , consumes = MediaType.APPLICATION_JSON_VALUE)
	@Timed("BLBRE1B")
	public ApiResponse<Object> initiateblBre1BApplication(@Valid @RequestBody InBreServices request) throws Exception {
		return this.elServices.initiateBlbre1BApplication(request);
	}

	@Operation(summary = "Multibureau callbacks will receive on this api.")
	@PostMapping(value = "/multibureau", produces = MediaType.APPLICATION_XML_VALUE)
	@Timed("MULTIBUREAU_CALLBACK")
	public String multibureau(@RequestBody String request) throws Exception {
		if (commonUtility.getValidate(request)) {
			return this.elServices.multibureau(request);
		}
		return this.elServices.returnErrorResponse(null,null);
	}

	@Operation(summary = "Multibureau callbacks will receive on this api.")
	@PostMapping(value = "/multibureaumerge", produces = MediaType.APPLICATION_XML_VALUE)
	@Timed("MULTIBUREAU_MERGECALBACK")
	public String multibureaumerge(@RequestBody String request) throws Exception {
		if (commonUtility.getValidate(request)) {
			return this.elServices.multibureaumerge(request);
		}
		return this.elServices.returnErrorResponse(null,null);
	}

	@Operation(summary = "Customer perfios data retreive")
	@PostMapping(value = "/get-perfios-txndata",produces = MediaType.APPLICATION_JSON_VALUE , consumes = MediaType.APPLICATION_JSON_VALUE)
	@Timed("RETRIEVEPERFIOS")
	public ApiResponse<Object> retrievePerfios(@Valid @RequestBody InitiatePerfios request) throws Exception {
		return this.elServices.getPerfiosData(request);
	}

	@Operation(summary = "Customer initiate bl_bre_2a application")
	@PostMapping(value = "/init-blbre2a",produces = MediaType.APPLICATION_JSON_VALUE , consumes = MediaType.APPLICATION_JSON_VALUE)
	@Timed("BLBRE2A")
	public ApiResponse<Object> initiateblBre2AApplication(@Valid @RequestBody InBreServices request) throws Exception {
		return this.elServices.initiateBlBre2AApplication(request);
	}

	@Operation(summary = "Customer initiate perfiosDebitScore application")
	@PostMapping(value = "/init-blbre2b",produces = MediaType.APPLICATION_JSON_VALUE , consumes = MediaType.APPLICATION_JSON_VALUE)
	@Timed("BLBRE2B")
	public ApiResponse<Object> initPerfiosDebitScoreApplication(@Valid @RequestBody InBreServices request)
			throws Exception {
		return this.elServices.initPerfiosDebitScore(request);
	}

	@Operation(summary = "Customer initiate bl_bre_2c application")
	@PostMapping(value = "/init-blbre2c",produces = MediaType.APPLICATION_JSON_VALUE , consumes = MediaType.APPLICATION_JSON_VALUE)
	@Timed("BLBRE2C")
	public ApiResponse<Object> initBlBre2CApplication(@Valid @RequestBody InBreServices request) throws Exception {
		return this.elServices.initBlBre2CApplication(request);
	}
 
}
