package com.hdfcbank.elengine.service.impl;

import java.io.IOException;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hdfcbank.elengine.client.UrlConnection;
import com.hdfcbank.elengine.constant.RedisConstants;
import com.hdfcbank.elengine.domain.entity.BureauConfig;
import com.hdfcbank.elengine.domain.enums.BreServiceType;
import com.hdfcbank.elengine.domain.request.InitIncomeOffer;
import com.hdfcbank.elengine.domain.request.callback.CallbackRequest;
import com.hdfcbank.elengine.domain.request.callback.ContextParam;
import com.hdfcbank.elengine.domain.request.callback.ResponseObject;
import com.hdfcbank.elengine.domain.request.callback.ResponseParam;
import com.hdfcbank.elengine.domain.request.common.InBreServices;
import com.hdfcbank.elengine.exception.CallBackException;
import com.hdfcbank.elengine.repository.BureauConfigRepository;
import com.hdfcbank.elengine.service.ElCallbacks;
import com.hdfcbank.elengine.util.RedisUtils;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class ElCallbacksImpl implements ElCallbacks {
	@Autowired
	RedisUtils redisUtils;

	@Autowired
	UrlConnection connection;

	@Autowired
	ObjectMapper objectMapper;

	@Value("${bre.init.url}")
	private String INIT_BRE_URL;

	@Value("${bre.callback.url}")
	private String brecallBackUrl;

	@Autowired
	BureauConfigRepository bureauConfigRepository;

	@Override
	@Async
	public void checkMbCallbacks(InBreServices request) {
		log.info("checkMbCallbacks {}", request);
		long multiCBCount = 0;
		String mobileNumber = request.getMobileNo();
		String tranRefNumber = request.getAckid();
		String callBackCountKey = RedisConstants.MULTICALLBACKS + mobileNumber + RedisConstants.US + tranRefNumber;
		multiCBCount = redisUtils.scard(callBackCountKey);
		log.info("callBackCountKey {} count {}", callBackCountKey, multiCBCount);
		String productCode = request.getProductId();

		List<BureauConfig> data = bureauConfigRepository.findByProductid(productCode);
		long mbOutCnt = 0;
		log.info("bureaue congfig data {}", data);
		for (BureauConfig bureauConfig : data) {
			if (bureauConfig.getDatatype().equalsIgnoreCase("mbout")
					&& bureauConfig.getIsactive().equalsIgnoreCase("Y")) {
				mbOutCnt++;
			}
		}

//		if(!redisUtils.exists(RedisConstants.BRE_CALBACK_URL+productCode)) {
		for (BureauConfig bureauConfig : data) {
			if (bureauConfig.getDatatype().equalsIgnoreCase("breclback")) {
				String value = bureauConfig.getDatavalue().trim();
				redisUtils.set(RedisConstants.BRE_CALBACK_URL + productCode, value);
			}
		}
//		}

		log.info("mbOutCnt {}", mbOutCnt);
		if (multiCBCount == mbOutCnt || multiCBCount > mbOutCnt) {
			// call to initiate zeebe method for bre initiation
			InitIncomeOffer incomeOffer = new InitIncomeOffer("", tranRefNumber, request.getProductId(), mobileNumber,
					"");
			String apiReq = "";
			try {
				apiReq = objectMapper.writeValueAsString(incomeOffer);
				connection.initiateCallBack(apiReq, INIT_BRE_URL);
			} catch (JsonProcessingException e) {
				log.error("JsonProcessingException {}", e);
			} catch (IOException e) {
				log.error("IOException {}", e);
			}
		} else {
			throw new CallBackException("multibureau callback count less than 3");
		}
	}

	@Override
	public void initBreCallBacks(InBreServices request) {
		log.info("initBreCallBacks {}", request);
		// call to BRE for callbacks issue...
		try {
			/*
			 * as per the bank team requested we are initiating bre if Mb callbacks not
			 * received as well.
			 */
			if (request.getProductId().equalsIgnoreCase("BL")) {
				InitIncomeOffer incomeOffer = new InitIncomeOffer("", request.getAckid(), request.getProductId(),
						request.getMobileNo(), "");
				String apiReq = "";
				apiReq = objectMapper.writeValueAsString(incomeOffer);
				connection.initiateCallBack(apiReq, INIT_BRE_URL);
			} else {
				this.prepareCallBackRequest(request, BreServiceType.GetBureauOffer.toString(),
						objectMapper.writeValueAsString(
								new ResponseObject("multibureau callback counts not reached expected", "500")));
			}
		} catch (Exception e) {
			log.error("JsonProcessingException in initBreCallBacks {}", e);
		}
	}

	public void prepareCallBackRequest(InBreServices req, String action, String breResponse) {
		try {
			if (StringUtils.isBlank(req.field1)) {
				String partnerJourneyId = redisUtils
						.get(RedisConstants.PARTNER_JOURNEYID + req.getMobileNo() + RedisConstants.US + req.getAckid());
				req.setField1(partnerJourneyId);
			}
			brecallBackUrl = redisUtils.get(RedisConstants.BRE_CALBACK_URL + req.productId);
			log.info("product id {} brecallBackUrl {}", req.productId, brecallBackUrl);
			this.initBreCallBack(ContextParam.toContextParam(req.productId, req.field1, req.ackid), breResponse,
					ResponseParam.toResponseParam(action), brecallBackUrl);
		} catch (IOException e) {
			log.error("Exception while calling bre callback {}", e);
		}
	}

	private void initBreCallBack(ContextParam contextparam, String responsestring, ResponseParam responseParam,
			String callBackUrl) throws IOException {
		CallbackRequest callbackRequest = CallbackRequest.toCallbackRequest(contextparam, responsestring,
				responseParam);
		String apiRequest = new ObjectMapper().writeValueAsString(callbackRequest);
		log.info("bre callback request {}", apiRequest);
		connection.initiateCallBack(apiRequest, callBackUrl);
	}

	boolean checkBreEligibility(String productId, long cbRecvCnt) {
		long mbOutCnt = 0;
		if (!redisUtils.exists(RedisConstants.MULTI_BUREAU_CB_CNT + productId)) {
			List<BureauConfig> data = bureauConfigRepository.findByProductid(productId);
			log.info("bureaue congfig data {}", data);
			for (BureauConfig bureauConfig : data) {
				if (bureauConfig.getDatatype().equalsIgnoreCase("mbout")
						&& bureauConfig.getIsactive().equalsIgnoreCase("Y")) {
					mbOutCnt++;
				}
				redisUtils.set(RedisConstants.MULTI_BUREAU_CB_CNT + productId, String.valueOf(mbOutCnt));
			}
		} else {
			mbOutCnt = Long.valueOf(redisUtils.get(RedisConstants.MULTI_BUREAU_CB_CNT + productId));
		}

		return false;
	}

}
