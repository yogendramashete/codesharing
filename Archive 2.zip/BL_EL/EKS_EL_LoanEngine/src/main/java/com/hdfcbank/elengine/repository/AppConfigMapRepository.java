package com.hdfcbank.elengine.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.hdfcbank.elengine.domain.entity.AppConfigMap;

@Repository
public interface AppConfigMapRepository extends JpaRepository<AppConfigMap, Integer>  {
	
	List<AppConfigMap> findByChannelid(String channelid);
	 
	 AppConfigMap findByDatakeyAndIsactive(String datakey,String isactive);
}
