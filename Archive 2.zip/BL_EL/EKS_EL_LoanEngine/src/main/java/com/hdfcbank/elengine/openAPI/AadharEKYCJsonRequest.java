package com.hdfcbank.elengine.openAPI;

public class AadharEKYCJsonRequest {

	private String RequestEncryptedValue;
	private String SymmetricKeyEncryptedValue;
	private String plainRequest; 
	
	public String getRequestEncryptedValue() {
		return RequestEncryptedValue;
	}
	public void setRequestEncryptedValue(String requestEncryptedValue) {
		RequestEncryptedValue = requestEncryptedValue;
	}
	public String getSymmetricKeyEncryptedValue() {
		return SymmetricKeyEncryptedValue;
	}
	public void setSymmetricKeyEncryptedValue(String symmetricKeyEncryptedValue) {
		SymmetricKeyEncryptedValue = symmetricKeyEncryptedValue;
	}
	public String getPlainRequest() {
		return plainRequest;
	}
	public void setPlainRequest(String plainRequest) {
		this.plainRequest = plainRequest;
	}
}
