package com.hdfcbank.elengine.service;

import javax.validation.Valid;

import com.hdfcbank.elengine.domain.request.InitiateHunter;
import com.hdfcbank.elengine.domain.request.InitiateMBRequest;
import com.hdfcbank.elengine.domain.request.InitiatePerfios;
import com.hdfcbank.elengine.domain.request.InitiatePosidexDedupe;
import com.hdfcbank.elengine.domain.request.common.InBreServices;
import com.hdfcbank.elengine.util.ApiResponse;

public interface ElServices {

	ApiResponse<Boolean> initiateMultiBureu(@Valid InitiateMBRequest request)  throws Exception;

	ApiResponse<Boolean> initiatePosidexDedupe(@Valid InitiatePosidexDedupe request)  throws Exception;

	ApiResponse<Boolean> publishPosidexDedupe(@Valid InitiatePosidexDedupe request)  throws Exception;

	ApiResponse<Boolean> initiateHunter(@Valid InitiateHunter request)  throws Exception;

	ApiResponse<Boolean> initiateBlApplication(@Valid InBreServices request)  throws Exception;

	ApiResponse<Object> initiateFtnrApplication(@Valid InBreServices request)  throws Exception;

	ApiResponse<Object> initiateBlbre1BApplication(@Valid InBreServices request)  throws Exception;
	
	ApiResponse<Object> getPerfiosData(@Valid InitiatePerfios request)  throws Exception;
	
	ApiResponse<Object> initiateBlBre2AApplication(@Valid InBreServices request)  throws Exception;
	
	ApiResponse<Object> initPerfiosDebitScore(@Valid InBreServices request)  throws Exception;
	
	ApiResponse<Object> initBlBre2CApplication(@Valid InBreServices request)  throws Exception;
	
	String  multibureau(String request) throws Exception;
	
	String  multibureaumerge(String mergerequest) throws Exception;
	
	String returnErrorResponse(String ackId,String status)  throws Exception;
 


}
