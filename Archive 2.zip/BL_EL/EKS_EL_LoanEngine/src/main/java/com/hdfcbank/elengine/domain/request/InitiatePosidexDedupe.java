package com.hdfcbank.elengine.domain.request;

import javax.validation.constraints.NotBlank;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class InitiatePosidexDedupe {

	@NotBlank(message = "name may not be blank")
	private String name;
	@NotBlank(message = "dob may not be blank")
	private String dob;
	@NotBlank(message = "address may not be blank")
	private String address;
	@NotBlank(message = "city may not be blank")
	private String city;
	@NotBlank(message = "state may not be blank")
	private String state;
	@NotBlank(message = "zipcode may not be blank")
	private String zipCode;
	@NotBlank(message = "mobilenumber may not be blank")
	private String mobileNumber;
	@NotBlank(message = "pannumber may not be blank")
	private String panNumber;
	@NotBlank(message = "transaction reference number may not be blank")
	private String tranRefNumber;
	@NotBlank(message = "productCode may not be blank")
	private String productCode;
	@NotBlank(message = "customerID may not be blank")
	private String customerID;
	private String partnerJourneyId;
}
