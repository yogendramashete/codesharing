package com.hdfcbank.elengine.util;


import java.io.Serializable;
import java.util.Collections;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

public class ErrorResponse implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	int code;
	int errorCode;
	String message;
	List<String> errors;
	
	@JsonCreator
	public ErrorResponse(@JsonProperty("status_code") int code,
			             @JsonProperty("error_code") int error_code,
			              @JsonProperty("message") String message,
			              @JsonProperty("errors") List<String> errors) {
		this.code =  code;
		this.errorCode = error_code;
		this.message =  message;
		this.errors =  errors;
	}
	
	public ErrorResponse(int code, Object object, String message2, List<String> emptyList) {
		
	}
	
	public ErrorResponse(int code ,String message) {
		this(code,null,message,Collections.emptyList());
	}
    
	public ErrorResponse(int code ,String message,List<String> errorCodes) {
		this(code,null,message,errorCodes);
	}
	
	public ErrorResponse(int code ,String errorCode,String message) {
		this(code,errorCode,message,Collections.emptyList());
	}
	
}
