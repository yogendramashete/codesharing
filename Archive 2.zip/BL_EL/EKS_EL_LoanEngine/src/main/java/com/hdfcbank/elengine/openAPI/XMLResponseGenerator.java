package com.hdfcbank.elengine.openAPI;

import java.io.FileInputStream;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.util.ResourceBundle;

import javax.xml.crypto.MarshalException;
import javax.xml.crypto.dsig.XMLSignatureException;

import org.xml.sax.SAXException;

public class XMLResponseGenerator {
	private static final String INVALID_SIGNATURE = "Invalid Digital Signature";
	private static final String JKS = "JKS";
	private static final String CONFIG = "Config";
	private static String clientKeyStoreFilePath;
	private static String clientKeyStorePassword;
	private static String clientKeyAlias;	
	
	static {
		ResourceBundle bundle = ResourceBundle.getBundle(CONFIG);
		clientKeyStoreFilePath = bundle.getString("clientKeyStoreFilePath");
		clientKeyStorePassword = bundle.getString("clientKeyStorePassword");
		clientKeyAlias = bundle.getString("clientKeyAlias");
	}
	

	/**
	 * Return XML response as String after validating the digital signature. If digital signature is invalid then an exception is thrown by this method. 
	 * This method returns response XML as String after removing Signature element from original response.   
	 * @param jsonResponse
	 * @param privateKey
	 * @return responseXML
	 * @throws MarshalException
	 * @throws XMLSignatureException
	 * @throws SAXException
	 */
	public String generate(String jsonResponse) throws Exception {
		String responseXML = null;
		
		//create JsonResponse object from response string
		JsonResponseReader responseReader = new JsonResponseReader();
		JsonResponse response = responseReader.read(jsonResponse);
		
		String encodedKey = response.getGWSymmetricKeyEncryptedValue();

		//decode symmetric key
		Base64EncoderDecoder decoder = new Base64EncoderDecoder();
		byte[] encryptedKey = decoder.decode(encodedKey.getBytes());
		//Logger.info(new String(encryptedKey));
				
		//get private key from key store
		KeyStore ks = KeyStore.getInstance(JKS);
		ks.load(new FileInputStream(clientKeyStoreFilePath), clientKeyStorePassword.toCharArray());			
		KeyStore.PrivateKeyEntry privateKeyEntry = (KeyStore.PrivateKeyEntry) ks.getEntry(clientKeyAlias, new KeyStore.PasswordProtection(clientKeyStorePassword.toCharArray()));
		PrivateKey privateKey = privateKeyEntry.getPrivateKey();
		
		//decrypt symmetric key using private key
		RSAEncrypterDecrypter rsaEncryptDecrypt = new RSAEncrypterDecrypter();				
		byte[] decryptedKey = rsaEncryptDecrypt.decrypt(encryptedKey, privateKey);		
		
		//decrypt response using symmetric key
		AESEncrypterDecrypter decrypter = new AESEncrypterDecrypter();
		String encodedResponse = response.getResponseSignatureEncryptedValue();
		byte[] encryptedResponse = decoder.decode(encodedResponse.getBytes());
		
		byte[] decryptedResponse = decrypter.decrypt(encryptedResponse,decryptedKey);
		String responseXMLWithSignature = new String(decryptedResponse);
		
		//validate XML signature
		XMLDigitalSignature signature = new XMLDigitalSignature();
		if(signature.validate(responseXMLWithSignature)) {
			responseXML = signature.removeSignature(responseXMLWithSignature);
		}
		else {
			throw new Exception(INVALID_SIGNATURE);
		}
		return responseXML;
	}
	
}
