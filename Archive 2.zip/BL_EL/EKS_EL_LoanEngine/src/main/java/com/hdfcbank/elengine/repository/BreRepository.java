package com.hdfcbank.elengine.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.hdfcbank.elengine.domain.entity.BreServiceEntity;

@Repository
public interface BreRepository extends JpaRepository<BreServiceEntity, Integer>{

}
