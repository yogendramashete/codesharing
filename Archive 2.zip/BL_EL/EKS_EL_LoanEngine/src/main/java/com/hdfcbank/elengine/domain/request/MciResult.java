package com.hdfcbank.elengine.domain.request;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Data;

//@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({

})
@Data
public class MciResult {


}