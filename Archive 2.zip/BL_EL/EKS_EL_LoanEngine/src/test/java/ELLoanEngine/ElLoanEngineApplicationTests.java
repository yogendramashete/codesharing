package ELLoanEngine;

import org.junit.jupiter.api.Test;

//@SpringBootTest
class ElLoanEngineApplicationTests {

	@Test
	void contextLoads() {
	}

}
