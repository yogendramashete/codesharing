package com.hdfcbank.assetengine.workflow.model;

import javax.validation.constraints.Max;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import lombok.Builder;
import lombok.Data;
import lombok.ToString;

@Data
@ToString
@Builder
public class ContextParam {

	/*
	 * private String partnerJourneyID; private String bankJourneyID; //process id
	 * private String partnerID; private String productName; private String
	 * channelID;
	 */
	private String step;
	// private String nextStep;

	// @NotNull(message = "partnerJourneyID cannot be null")
	// @Max(value=50)
	@NotBlank(message = "partnerJourneyID cannot be empty or null")
	@Size(max = 50, message = "partnerJourneyID must be less than 50 characters")
	private String partnerJourneyID;

	@NotBlank(message = "bankJourneyID cannot be null")
	// @Max(value=50)
	private String bankJourneyID;

	@NotBlank(message = "partnerID cannot be null")
	// @Max(value=50)
	private String partnerID;

	@NotBlank(message = "productName cannot be null")
	// @Max(value=50)
	private String productName;

	@NotBlank(message = "channelID cannot be null")
	// @Max(value=50)
	private String channelID;

}
