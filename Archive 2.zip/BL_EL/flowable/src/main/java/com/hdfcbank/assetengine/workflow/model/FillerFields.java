package com.hdfcbank.assetengine.workflow.model;

import lombok.Data;

@Data
public class FillerFields {

	private String filler1;
	private String filler2;
	private String filler3;
	private String filler4;
	private String filler5;
	private String filler6;
	private String filler7;
	private String filler8;
	private String filler9;
	private String filler10;
	
}
