package com.hdfcbank.assetengine.workflow.model;

import javax.validation.Valid;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Request {
	@Valid
	private ContextParam contextParam;

}
