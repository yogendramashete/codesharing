package com.hdfcbank.assetengine.workflow.util;

public class JsonUtil {

	//public static Map<String, Object> objectToMap();

	/*public static <T> convertObjToMap(Object obj,) {
		ObjectMapper mapper = new ObjectMapper();
		return mapper.convertValue(obj, Map.class);
		
	}*/
}
