package com.hdfcbank.assetengine.workflow.task;

import java.util.Map;

import org.flowable.engine.delegate.DelegateExecution;
import org.flowable.engine.delegate.JavaDelegate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.retry.support.RetryTemplate;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.hdfcbank.assetengine.workflow.model.ConnectionModel;

import lombok.extern.log4j.Log4j2;

@Component("retryRestAPIDelegate")
@Log4j2
public class RetryRestAPIDelegate implements JavaDelegate {

	@Autowired
	private RetryTemplate retryTemplate;

	@Autowired
	private RestTemplate restTemplate;

	@Autowired
	private Map<String, ConnectionModel> stepAPIMapper;

	@Override
	public void execute(DelegateExecution execution) {

		String apiURl = stepAPIMapper.get(execution.getCurrentActivityId()).getApiURL();
		log.info("getCurrentActivityId" + execution.getCurrentActivityId());
		Map<String, Object> request = (Map<String, Object>) execution.getVariable(execution.getCurrentActivityId());
		HttpEntity<Map<String, Object>> requestEntity = new HttpEntity<>(request);
		// ResponseEntity<String> response = restTemplate.exchange(apiURl, HttpMethod.POST, requestEntity, String.class);
		retryTemplate.execute(context -> {
		      this.restTemplate.exchange(apiURl, HttpMethod.POST, requestEntity, String.class);
		      return true;
		    });

		
		//execution.setVariable("Response_"+execution.getCurrentActivityId(), response.getBody());
	}

}
