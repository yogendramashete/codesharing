package com.hdfcbank.assetengine.workflow.config;

import java.util.Map;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.retry.backoff.FixedBackOffPolicy;
import org.springframework.retry.policy.SimpleRetryPolicy;
import org.springframework.retry.support.RetryTemplate;
import org.springframework.web.client.RestTemplate;

import com.hdfcbank.assetengine.workflow.model.ConnectionModel;

@Configuration
public class EngineWorkflowConfiguration {

	@Bean
	public RestTemplate restTemplate() {
	return new RestTemplate();
	}
	
	@Bean("stepAPIMapper")
	public Map<String,ConnectionModel> stepAPIMapper(){
		return Map.of(
				//Demo API
				"customerServiceAPI", new ConnectionModel("https://develbl.snapwork.com/loansdev/InitiateCustomerIdentification"),
				"offerAPI", new ConnectionModel("https://develbl.snapwork.com/loansdev/VerifyOTPAndGetDemogDetails"),
				//UTA API
				"CustomerIdentification_call", new ConnectionModel("https://develbl.snapwork.com/loansdev/InitiateCustomerIdentification"),
				//"CustomerIdentification_call", new ConnectionModel("http://localhost:8082/initiateCustomerIdentification"),
				"OTPAndGetDemogDetails_call", new ConnectionModel("https://develbl.snapwork.com/loansdev/VerifyOTPAndGetDemogDetails"),
				"PANEnquiry_call", new ConnectionModel("https://develbl.snapwork.com/loansdev/api/v2/PANEnquiry"),
				"MCIData_call", new ConnectionModel("https://develbl.snapwork.com/loansdev/api/v2/getMCIData"),
				"ElectricityData_call", new ConnectionModel("https://develbl.snapwork.com/loansdev/api/v2/getElectricityData"),
				"EmailValidation_call", new ConnectionModel("https://develbl.snapwork.com/loansdev/generateEmailOTP"),
				"InitiateEKyc_call", new ConnectionModel("https://develbl.snapwork.com/loansdev/api/v2/InitiateEKyc"),
				"InitiateIncomeUpload_call", new ConnectionModel("https://develbl.snapwork.com/loansdev/InitiateIncomeUpload")
				
				);
	}
	
	@Bean("tetantBPMNMapper")
	public Map<String,String> tetantBPMNMapper(){
		return Map.of("HDFCBANK","journeyworkflow",
					   "HDFCBANK_UAT","bl-engine-workflow_v1");
	}
	
	@Bean
    public RetryTemplate retryTemplate() {
        RetryTemplate retryTemplate = new RetryTemplate();

        FixedBackOffPolicy fixedBackOffPolicy = new FixedBackOffPolicy();
        fixedBackOffPolicy.setBackOffPeriod(2000l);
        retryTemplate.setBackOffPolicy(fixedBackOffPolicy);

        SimpleRetryPolicy retryPolicy = new SimpleRetryPolicy();
        retryPolicy.setMaxAttempts(5);
        retryTemplate.setRetryPolicy(retryPolicy);

        retryTemplate.registerListener(new DefaultListenerSupport());
        return retryTemplate;
    }
	
}
