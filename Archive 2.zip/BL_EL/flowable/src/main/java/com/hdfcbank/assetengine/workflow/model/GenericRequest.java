package com.hdfcbank.assetengine.workflow.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class GenericRequest extends Request {

	private RequestString requestString;

}
