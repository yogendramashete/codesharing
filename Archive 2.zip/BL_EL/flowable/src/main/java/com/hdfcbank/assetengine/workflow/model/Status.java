package com.hdfcbank.assetengine.workflow.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Status {

	private String responseCode;
	private String errorCode;
	private String errorDesc;
}
