package com.hdfcbank.assetengine.workflow.controller;

import java.util.List;

import javax.validation.Valid;

import org.flowable.engine.history.HistoricActivityInstance;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hdfcbank.assetengine.workflow.model.ContextParam;
import com.hdfcbank.assetengine.workflow.model.GenericRequest;
import com.hdfcbank.assetengine.workflow.model.Request;
import com.hdfcbank.assetengine.workflow.model.Response;
import com.hdfcbank.assetengine.workflow.model.request.CustomerIdentificationRequest;
import com.hdfcbank.assetengine.workflow.model.request.OTPAndGetDemogDetailsRequest;
import com.hdfcbank.assetengine.workflow.model.request.PANEnquiryRequest;
import com.hdfcbank.assetengine.workflow.service.BLWorkflowService;

import lombok.extern.log4j.Log4j2;

@RestController
@RequestMapping("/bl-workflow")
@Log4j2
public class BLWorkflowController {

	@Autowired
	private BLWorkflowService blWorkflowService;

	@PostMapping(value = "/startProcess", consumes = "application/json", produces = "application/json")
	public Response startProcessInstance(@RequestBody @Valid Request request) {
		log.info("contextParam ", request.toString());
		return blWorkflowService.startProcess(request);
	}
	@PostMapping(value = "/startProcess1")
	public Response startProcessInstance1(@RequestBody @Valid ContextParam request) {
		log.info("contextParam 11", request.toString());
		return blWorkflowService.startProcess(request);
	}
	@PostMapping(value = "/progressJourney")
	public Response progressJourney(@RequestBody GenericRequest request) {
		return blWorkflowService.progressJourney(request);
	}

	@PostMapping(value = "/progressJourney/CustomerIdentification")
	public Response getCustomerIdentification(@RequestBody CustomerIdentificationRequest request) {
		return blWorkflowService.progressJourney(request);
	}

	@PostMapping(value = "/progressJourney/OTPAndGetDemogDetails")
	public Response getOTPAndGetDemogDetails(@RequestBody OTPAndGetDemogDetailsRequest request) {
		return blWorkflowService.progressJourney(request);
	}

	@PostMapping(value = "/progressJourney/PANEnquiry")
	public Response getPANEnquiry(@RequestBody PANEnquiryRequest request) {
		return blWorkflowService.progressJourney(request);
	}

	@GetMapping("/getProcessByInstanceId/{processId}")
	public List<HistoricActivityInstance> getProcessByProcessInstanceId(@PathVariable("processId") String processId) {
		return blWorkflowService.getProcess(processId);
	}
}
