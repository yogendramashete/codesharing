package com.hdfcbank.assetengine.workflow;

import org.flowable.engine.RepositoryService;
import org.flowable.engine.RuntimeService;
import org.flowable.engine.TaskService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.retry.annotation.EnableRetry;

import com.hdfcbank.assetengine.workflow.service.WorkflowService;


@SpringBootApplication(proxyBeanMethods = false)
@EnableRetry
public class WorkflowApplication {

	public static void main(String[] args) {
		SpringApplication.run(WorkflowApplication.class, args);
	}


	@Bean
    public CommandLineRunner init(final RepositoryService repositoryService,
                                  final RuntimeService runtimeService,
                                  final TaskService taskService,
                                  final WorkflowService workflowService) {

        return new CommandLineRunner() {
            @Override
            public void run(String... strings) throws Exception {
              
            	System.out.println("Number of process definitions : "+ repositoryService.createProcessDefinitionQuery().count());
               System.out.println("Number of tasks : " + taskService.createTaskQuery().count());
               
                /*runtimeService.startProcessInstanceByKey("oneTaskProcess");
                
                System.out.println("Number of tasks after process start: "
                    + taskService.createTaskQuery().count());
                    */
            	/*
            	ProcessInstance pi = 
            			runtimeService.startProcessInstanceByKey("javaServiceDelegation",
            					Map.of("input","zzdd"));
            	Execution execution = runtimeService.createExecutionQuery()
            			.processInstanceId(pi.getId()).activityId("waitState").singleResult();
               System.out.println(
            		   runtimeService.getVariable(execution.getId(), "input"));
            		   
            	Map <String, Object> map = Map.of("partnerJourneyID" , "123", "product" ,"BL");
            	ProcessInstance pid  =workflowService.startProcess(map);
            
            	Map <String, Object> map1 = Map.of( 
            			"contextParam" ,
            			Map.of("step","customerServiceAPI"));
            	workflowService.progressJourney(map1, pid.getProcessInstanceId());
            	
            	Map <String, Object> map2 = Map.of( 
            			"contextParam" ,
            			Map.of("step","offerAPI"));
            	workflowService.progressJourney(map2, pid.getProcessInstanceId());
            	*/
            	
            }
        };
	}
	
}
