package com.hdfcbank.assetengine.workflow.controller;

import java.util.Map;

import org.flowable.engine.runtime.ProcessInstance;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hdfcbank.assetengine.workflow.model.Request;
import com.hdfcbank.assetengine.workflow.model.Response;
import com.hdfcbank.assetengine.workflow.service.WorkflowService;


@RestController
@RequestMapping("/api/v1/engineworkflow")
public class EngineWorkflowController {
	private final String BANK_JOURNET_ID = "bankJourneyID";
	

	
	@Autowired
	private WorkflowService workflowService;

	/*
	 * context param JSON
	 * {
        "partnerJourneyID": "77701",
        "bankJourneyID": "772701",
        "partnerID": "HDFCBANK",
        "productName": "AL",
        "channelID": "ADOBE"
    }
	 * */
	@PostMapping(value = "/startjourney")
	public String startProcessInstance(@RequestBody Map<String, Object> contextParam){
		System.out.println("contextParam "+ contextParam);
		return workflowService.startProcess(contextParam).getProcessInstanceId();
	}

	@PostMapping(value = "/progressjourney")
	public String progressJourney(@RequestBody Map<String, Object> requestParam) {
		return workflowService.progressJourney(requestParam, 
				(String)((Map<String,String>)(requestParam.get("contextParam"))).get(BANK_JOURNET_ID));
	}
	
	/*@PostMapping(value = "/startJourney")
	public Response startProcessInstance1(@RequestBody Map<String, Object> contextParam) {
		System.out.println("contextParam "+ contextParam);
		ProcessInstance pi= workflowService.startProcessJourney(contextParam);
		//System.out.println(workflowService.);
		return Response.builder().bankJourneyID(pi.getProcessInstanceId()).build();
	}*/
	
	@GetMapping("/getProcess/{processId}")
	public String getProcess(@PathVariable("processId") String processId) {
	//	workflowService.getProcess(processId).getActivityId();
		return workflowService.getProcess(processId).getActivityId();
	}
	
	@PostMapping(value = "/startJourney/customerIdentification")
	public Response customerIdentificationAPI(@RequestBody Request contextParam) {
		System.out.println("contextParam "+ contextParam);
		
		return null;
	}

}
