package com.hdfcbank.assetengine.workflow.service;

import java.util.Map;

import org.flowable.engine.runtime.Execution;
import org.flowable.engine.runtime.ProcessInstance;

public interface WorkflowService {

	ProcessInstance startProcess(Map<String, Object> contextParam);
	String progressJourney(Map<String, Object> stepVariables, String processID);
	ProcessInstance startProcessJourney(Map<String, Object> contextParam);
	Execution getProcess(String processId);
}
