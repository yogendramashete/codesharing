package com.hdfcbank.assetengine.workflow.task;

import java.util.Map;

import org.flowable.engine.delegate.DelegateExecution;
import org.flowable.engine.delegate.JavaDelegate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.hdfcbank.assetengine.workflow.constant.AppConstant;
import com.hdfcbank.assetengine.workflow.exception.WorkflowException;
import com.hdfcbank.assetengine.workflow.model.ConnectionModel;

import lombok.extern.log4j.Log4j2;

@Component("restServiceDelegate")
@Log4j2
public class RestAPIDelegate implements JavaDelegate {

	@Autowired
	private RestTemplate restTemplate;

	@Autowired
	private Map<String, ConnectionModel> stepAPIMapper;

	private static final String VARIABLE_NAME = "input";

	@Override
	public void execute(DelegateExecution execution){
		/*
		 * String var = (String) execution.getVariable(VARIABLE_NAME); var =
		 * var.toUpperCase();
	 */
		//String mapperKey=execution.getCurrentActivityId().concat(AppConstant.CALL_SUFFIX);
		//log.info("mapperKey is "+mapperKey);
		String apiURl = stepAPIMapper.get(execution.getCurrentActivityId()).getApiURL();
		
		log.info("restTemplate response key id" + AppConstant.RESPONSE_KEY.concat(execution.getCurrentActivityId()));
		Map<String, Object> request = (Map<String, Object>) execution.getVariable(execution.getCurrentActivityId());
	    HttpEntity<Map<String, Object>> requestEntity = new HttpEntity<>(request);
		ResponseEntity<String> response = restTemplate.exchange(apiURl, HttpMethod.POST, requestEntity, String.class);
		/*if(true) {
			throw new WorkflowException(response.getBody());
		}*/
		/*try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		log.info("after rest call");
		execution.setVariable(AppConstant.RESPONSE_KEY.concat(execution.getCurrentActivityId()), response.getBody());

	}

}
