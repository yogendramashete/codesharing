package com.hdfcbank.assetengine.workflow.constant;

public class AppConstant {
	
	public static final String PARTNER_JOURNEY_ID = "partnerJourneyID";
	public static final String API_STEP_ID = "step";
	public static final String TENANT_ID = "partnerID";
	public static final String RESPONSE_KEY = "response_"; 
	public static final String LAST_SIGNAL_EVENT = "workflowCompleted"; 
	public static final String CALL_SUFFIX="_call";
}
