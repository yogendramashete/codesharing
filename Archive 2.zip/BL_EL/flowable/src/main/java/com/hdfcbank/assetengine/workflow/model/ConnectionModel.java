package com.hdfcbank.assetengine.workflow.model;

public class ConnectionModel {
private String apiURL;


public ConnectionModel(String apiURL) {
	super();
	this.apiURL = apiURL;
}

public String getApiURL() {
	return apiURL;
}

public void setApiURL(String apiURL) {
	this.apiURL = apiURL;
}

}
