package com.hdfcbank.assetengine.workflow.model;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class Response {
	
	private String bankJourneyID;
	private String nextStep;
	private String responseString;
}
