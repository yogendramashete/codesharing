package com.hdfcbank.assetengine.workflow.service;

import java.util.List;

import org.flowable.engine.history.HistoricActivityInstance;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;

import com.hdfcbank.assetengine.workflow.exception.WorkflowException;
import com.hdfcbank.assetengine.workflow.model.ContextParam;
import com.hdfcbank.assetengine.workflow.model.Request;
import com.hdfcbank.assetengine.workflow.model.Response;

public interface BLWorkflowService {

	Response startProcess(Request request) throws WorkflowException;

	@Retryable(value = RuntimeException.class, maxAttemptsExpression = "${retry.maxAttempts}", backoff = @Backoff(delayExpression = "${retry.maxDelay}"))
	Response progressJourney(Request request) throws WorkflowException;

	List<HistoricActivityInstance> getProcess(String processId) throws WorkflowException;
	
	Response startProcess(ContextParam request) throws WorkflowException;

}
