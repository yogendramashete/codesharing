package com.hdfcbank.blengine.flowable.blworkflow;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BlWorkflowApplicationTests {

	@Test
	void contextLoads() {
	}

}
