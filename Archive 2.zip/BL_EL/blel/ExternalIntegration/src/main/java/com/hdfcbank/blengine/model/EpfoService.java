package com.hdfcbank.blengine.model;

import com.hdfcbank.blengine.bean.epfo.request.EpfoDataRequest;
import com.hdfcbank.blengine.bean.epfo.response.EpfoDataResponse;
import com.hdfcbank.blengine.exception.BLEngineException;

import javax.validation.Valid;

public interface EpfoService {

	EpfoDataResponse getEpfoDataUpdated(@Valid EpfoDataRequest request) throws BLEngineException;

}
