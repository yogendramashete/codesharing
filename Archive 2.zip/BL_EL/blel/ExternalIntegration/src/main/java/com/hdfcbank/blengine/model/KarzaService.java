package com.hdfcbank.blengine.model;

import com.hdfcbank.blengine.bean.getElectricityData.GetElectricityDataRequest;
import com.hdfcbank.blengine.bean.getElectricityData.GetElectricityDataResponse;
import com.hdfcbank.blengine.exception.BLEngineException;

public interface KarzaService {
	
	GetElectricityDataResponse getElectricityData(GetElectricityDataRequest request) throws BLEngineException;


}
