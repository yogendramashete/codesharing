package com.hdfcbank.blengine.dao;

import com.hdfcbank.blelengine.util.CommonUtility;
import com.hdfcbank.blengine.exception.BLEngineException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
public class Commondao {

	public static final Logger logger = LoggerFactory.getLogger(Commondao.class);

	@Autowired
	JdbcTemplate jdbcTemplate;


	@Value("${sql.query.getappconfigparameters}")
	private String getappconfigparameters;

	@Value("${sql.query.insertloanappjourneydetails}")
	private String insertloanAppJourneyDetails;

	@Value("${sql.query.updateloanappjourneydetails}")
	private String updateloanappjourneydetails;

	@Value("${sql.query.getloanappinfo}")
	private String getloanappinfo;

	@Value("${sql.query.updateloanappinfo}")
	private String updateloanappinfo;

	@Value("${sql.query.updateEPFOloanAppJourneyData}")
	private String updateEPFOloanAppJourneyData;

	@Value("${sql.query.updateICAILoanAppJourneyData}")
	private String updateICAILoanAppJourneyData;

	@Value("${sql.query.updateMCILoanAppJourneyData}")
	private String updateMCILoanAppJourneyData;

	@Value("${sql.query.updateKarzaLoanAppJourneyData}")
	private String updateKarzaLoanAppJourneyData;






	public int updateLoanAppJourneyDetails(String stepName, double stepID, long bankJourneyId, String response,
			String result, String errorCode, String errorMessage) {
		int count = 0;

		try {
			count = jdbcTemplate.update(updateloanappjourneydetails,
					new Object[] { response, result, errorCode, errorMessage, bankJourneyId, stepID, stepName });
			logger.info("stepName updateLoanAppJourneyDetails  result count::{}", count);
		} catch (Exception e) {
			logger.info("updateLoanAppJourneyDetails Exception ::{} ", CommonUtility.getPrintStackTrace(e));
		}
		return count;
	}

	public int insertLoanAppJourneyDetails(String stepName, String requestType, double stepID, int stepLevel,
			long bankJourneyId, String API, String request, String redirectionToPartnerURL) {

		String result = "";
		String response = "";

		int count = 0;
		try {

			count = jdbcTemplate.update(insertloanAppJourneyDetails, new Object[] { bankJourneyId, stepID, stepName,
					stepLevel, requestType, API, request, response, result, redirectionToPartnerURL });
			logger.info("insertLoanAppJourneyDetails count  :: {}" , count);

        } catch (DuplicateKeyException e){
            //TODO - Do what you want

            throw new BLEngineException("Duplicate Record Found with  BanKJourneyID "+bankJourneyId);

		}
		return count;
	}





	public String updateLoanAppInfo(String status, String channelId, String productCode, String tenantId,
			long bankJourneyId, String partnerJourneyId) {
		logger.info("getLoanAppInfo :: ");

		int recordUpdated = 0;

		String isUpdate = "false";

		try {

			logger.info("ChannelId {},  ProductCode{}, Tenant_ID{}, -BankJourneyId{}, -PartnerJourneyId {}", channelId,
					productCode, tenantId, bankJourneyId, partnerJourneyId);

			Boolean recordFound = jdbcTemplate.queryForObject(getloanappinfo, Boolean.class, channelId, productCode,
					tenantId, bankJourneyId, partnerJourneyId);
			logger.info("recordFound {} ", recordFound);

			if (Boolean.TRUE.equals(recordFound)) {

				recordUpdated = jdbcTemplate.update(updateloanappinfo, status, channelId, productCode, tenantId,
						bankJourneyId, partnerJourneyId);
				logger.info("recordUpdated {}", recordUpdated);

				isUpdate = "true";

			}
			logger.info("getLoanAppInfo isUpdate :: {} ", isUpdate);
		} catch (BLEngineException exe) {

			throw new BLEngineException(exe.getMessage());
		}
		return isUpdate;
	}


	public int updateEPFOloanAppJourneyData( long bankJourneyId, String emplrScore, String isEmployed,String isNameExact)

	{		int count = 0;

		try {
			count = jdbcTemplate.update(updateEPFOloanAppJourneyData, new Object[]{emplrScore , isEmployed, isNameExact, bankJourneyId});
			logger.info("count::" + count);
		} catch (Exception e) {
			throw new BLEngineException(e.getMessage());
		}

		return count;
	}

	public void updateICAIloanAppJourneyData(long bankJourneyId, String nameMatchScore) {

		try {
			jdbcTemplate.update(updateICAILoanAppJourneyData, new Object[]{nameMatchScore, bankJourneyId});
		} catch (Exception e) {
			throw new BLEngineException(e.getMessage());
		}

	}

	public void updateMCIloanAppJourneyData(long bankJourneyId, String nameMatchScore) {

		try {
			jdbcTemplate.update(updateMCILoanAppJourneyData, new Object[]{nameMatchScore, bankJourneyId});
		} catch (Exception e) {
			throw new BLEngineException(e.getMessage());
		}

	}

	public void updateKarzaloanAppJourneyData(long bankJourneyId, String nameMatchScore, String resiAddressNatchPercentage) {

		try {
			logger.info("inside updateKarzaloanAppJourneyData:: {}",bankJourneyId);
			logger.info("inside nameMatch Score:: {}",nameMatchScore);
			logger.info("inside resi AddressMatch Percentage:: {}",resiAddressNatchPercentage);
			jdbcTemplate.update(updateKarzaLoanAppJourneyData, new Object[]{nameMatchScore, resiAddressNatchPercentage, bankJourneyId});
		} catch (Exception e) {
			logger.error("Exception :: " + e.getMessage());
			throw new BLEngineException(e.getMessage());
		}

	}

	public String getAPIConfigParameters(String channelid, String dataname, String datakey) {
		logger.info("get  API Constant Parameters :: ");
		List<String> apiConstantslist = null;
		String isactive = "Y";
		String apiConfig = "";

		try {

			apiConstantslist = jdbcTemplate.queryForList(getappconfigparameters,
					new Object[] { channelid, dataname, datakey, isactive }, String.class);
			if (!apiConstantslist.isEmpty()) {
				apiConfig = apiConstantslist.get(0);
			}
			logger.info("apiConfig  datakey::" + datakey + apiConfig);

		} catch (Exception exe) {
			//exe.printStackTrace();
			logger.info("Exception :: " + exe);
		}
		return apiConfig;
	}


	public boolean recordFoundLoanAppInfo(String channelId, String productCode, String tenantId,
										  long bankJourneyId, String partnerJourneyId) {
		logger.info("getLoanAppInfo :: ");

		String isUpdate = "false";

		Boolean recordFound;
		try {

			logger.info("ChannelId {},  ProductCode{}, Tenant_ID{}, -BankJourneyId{}, -PartnerJourneyId {}", channelId,
					productCode, tenantId, bankJourneyId, partnerJourneyId);

			recordFound = jdbcTemplate.queryForObject(getloanappinfo, Boolean.class, channelId, productCode,
					tenantId, bankJourneyId, partnerJourneyId);
			logger.info("recordFound {} ", recordFound);

		} catch (BLEngineException exe) {

			throw new BLEngineException(exe.getMessage());
		}
		return recordFound;
	}

	public Map<String, Object> getJourneyRecordLoanAppInfo(String channelid, String bankJourneyId, String partnerJourneyId) {

		List<Map<String, Object>> loanAppinfoList = null;
		Map<String, Object>  loanAppInfo = null;

		String query = "select customerfirstname, customermiddlename, customerlastname, mobileno, panno, permanentaddressline1,permanentaddressline2, permanentaddressline3, permanentaddresscity, permanentaddressstate, permanentaddresspincode, bankname, bankaccountno, employmenttype, nameofbiz, occupation, nameofemployer, maritalstatus, religion,personalemailaddress, natureofbusiness, purposeofloan, preferredcontactlocation, officephonenumber, workemail, workemailverification, customer_consent, officeorbusinessaddrline1, officeorbusinessaddrline2, officeorbusinessaddrline3, officeorbusinesspincode, officeorbusinesscity, officeorbusinessstate, officeorbusinessphoneno, resiaddresstype, addressline1, addressline2, addressline3, city, state, pincode from loanappinfo where  channelid =? and bankjourneyid= ?and partnerjourneyid= ?";

		try {
			loanAppinfoList = jdbcTemplate.queryForList(query, new Object[] { channelid, Long.parseLong(bankJourneyId), partnerJourneyId });
			logger.info("leaddata ::" + loanAppinfoList.size());
			if(loanAppinfoList.size() !=0) {
				loanAppInfo = loanAppinfoList.get(0);
			}

		} catch (Exception exe) {
			logger.info("Exception :: " + exe);
		}
		logger.info("loanAppInfo list:: {}",loanAppInfo);
		return loanAppInfo;
	}

}
