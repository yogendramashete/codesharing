package com.hdfcbank.blengine.constants;

public class RedisConstants {
	
		
	public final static String CHECKOFFER_EXISTING_CUSTOMER = "CHECKOFFER_EXISTING_CUSTOMER_";
	public final static String CHECKOFFER_MARITALSTATUS = "CHECKOFFER_MARITALSTATUS_";
	public final static String CHECKOFFER_PINCODE = "CHECKOFFER_PINCODE_";
	public final static String CHECKOFFER_FIRSTNAME = "CHECKOFFER_FIRSTNAME_";
	public final static String CHECKOFFER_LASTNAME = "CHECKOFFER_LASTNAME_";
	public final static String OTP_GEN_DOB = "OTP_GEN_DOB_";
	public final static String OTP_GEN_PAN = "OTP_GEN_PAN_";
	
	public final static String NTB_ENTITY_VALIDATION = "NTB_ENTITY_VALIDATION_";
	
	
	//public static String CHECKOFFER_OFFER_AVAILABLE = "CHECKOFFER_OFFER_AVAILABLE_";
	//public static String CHECKOFFER_EXISTING_CUSTOMER = "CHECKOFFER_EXISTING_CUSTOMER_";
		
	public final static String BRE1_IS_INITIATED = "BRE1_IS_INITIATED_";
	public final static String BRE1_INITIATED_TIME = "BRE1_INITIATED_TIME_";
	public final static String MULTI_BUREAU_ACK = "MULTIBUREAU_ACK_";
	public final static String MULTI_BUREAU_MERGE_ACK = "MULTIBUREAUMERGE_ACK_";
	public final static String NTB_MOBILE_NO = "NTB_MOBILE_NO_";
	public final static String NTB_TRAN_REF_NO = "NTB_TRAN_REF_NO_";
	public final static String ETB_MOBILE_NO = "ETB_MOBILE_NO_";
	public final static String ETB_TRAN_REF_NO = "ETB_TRAN_REF_NO_";
	public final static String GENERATE_AADHAR_URL_REQ = "GENERATE_AADHAR_URL_REQ_";
	public final static String TEN_SEC_ETB_MOBILE_NO = "TEN_SEC_ETB_MOBILE_NO_";
	public final static String TEN_SEC_ETB_TRAN_REF_NO = "TEN_SEC_ETB_TRAN_REF_NO_";
	public final static String CIBIL = "CIBIL_";
	public final static String MERGED_SCORE = "MERGED_SCORE_";
	public final static String NTB_JOURNEY_INPUT = "NTB_JOURNEY_INPUT_";
	public final static String NTB_TRUSTING_SOCIAL = "NTB_TRUSTING_SOCIAL_";
	public final static String NTB_PAN_VALIDATION = "NTB_PAN_VALIDATION_";
	public final static String NTB_NAME_MATCH = "NTB_NAME_MATCH_";
	public final static String NTB_DEDUPE_OUTPUT = "NTB_DEDUPE_OUTPUT_";
	public final static String NTB_EMAIL_VALIDATION = "NTB_EMAIL_VALIDATION_";
	public final static String NTB_HUNTER = "NTB_HUNTER_";
	public final static String MBEOT = "MBEOT_";
	public final static String MBEOT_WOUN = "MBEOT";
	public final static String NTB_ADDRESS = "NTB_ADDRESS_";
	public final static String NSDL_INVALIDCOUNT = "NSDL_INVALIDCOUNT_";
	public final static String NTB_PAN_TRANREF_MOB = "NTB_PAN_TRANREF_MOB_";
	public final static String POXIDEX_RETRY_COUNT = "POXIDEX_RETRY_COUNT_";
	public final static String ETB_POSIDEX_PUBLISH = "ETB_POSIDEX_PUBLISH_";
	public final static String ADD_REF_DOCUMENTS_API = "ADD_REF_DOCUMENTS_API_";
	public final static String ADD_REF_DOCUMENTS_API_REQ = "ADD_REF_DOCUMENTS_API_REQ_";
	public final static String ETB_ADD_REF_DOCUMENTS_API = "ETB_ADD_REF_DOCUMENTS_API_";
	public final static String DOC_UPLOAD_DOCUMENTS_API = "DOC_UPLOAD_DOCUMENTS_API_";
	public final static String ETB_DOC_UPLOAD_DOCUMENTS_API = "ETB_DOC_UPLOAD_DOCUMENTS_API_";
	public final static String COM_DOC_UPLOAD_DOCUMENTS_API = "COM_DOC_UPLOAD_DOCUMENTS_API_";
	public final static String ETB_COM_DOC_UPLOAD_DOCUMENTS_API = "ETB_COM_DOC_UPLOAD_DOCUMENTS_API_";
	public final static String BRE1 = "BRE1_";
	public final static String BRE2 = "BRE2_";
	public final static String ETB_BRE2 = "ETB_BRE2_";
	public final static String BRE3 = "BRE3_";
	public final static String CIF = "CIF_";
	public final static String PERFIOS_RETRIVE_DATA = "PERFIOS_RETRIVE_DATA_";
	public final static String DOC_PERFIOS_RETRIVE_DATA = "DOC_PERFIOS_RETRIVE_DATA_";
	public final static String CP_DATA = "CP_DATA_";
	public final static String CIF_DATA = "CIF_DATA_";
	public final static String MULTICALLBACKS = "MULTICALLBACKS_";
	public final static String AADHAR_OTP_VALDN = "AADHAR_OTP_VALDN_";
	public final static String AADHAR_CALLBACK_RESP = "AADHAR_CALLBACK_RESP_";
	public final static String ADD_MATCH_SCORE = "ADDRESS_MATCH_SCORE_";
	public final static int EXPIRE_KEY = 15000;
	public final static String ADD_REF_RETRY_COUNT = "ADD_REF_RETRY_COUNT_";
	public final static String ETB_ADD_REF_RETRY_COUNT = "ETB_ADD_REF_RETRY_COUNT_";
	public final static String DOC_UPLOAD_RETRY_COUNT = "DOC_UPLOAD_RETRY_COUNT_";
	public final static String ETB_DOC_UPLOAD_RETRY_COUNT = "ETB_DOC_UPLOAD_RETRY_COUNT_";
	public final static String COM_DOC_RETRY_COUNT = "COM_DOC_RETRY_COUNT_";
	public final static String ETB_COM_DOC_RETRY_COUNT = "ETB_COM_DOC_RETRY_COUNT_";
	public final static String INSTALLMENT_MODE = "INSTALLMENT_MODE_";
	public final static String NTB = "ECS";
	public final static String ETB = "SI";
	public final static String EMAIL_VALIDATION_REQ = "EMAIL_VALIDATION_REQ_";
	public final static String CHECKOFFER_RESPONSE = "CHECKOFFER_RESPONSE_";
	public final static String NTBEMPLOYEMENTS_REQUEST = "NTBEMPLOYEMENTS_REQUEST_";
	public final static String NTBPERSONAL_REQUEST = "NTBPERSONAL_REQUEST_";
	public final static String CAR_DEALER_DETAILS_REQUEST = "CAR_DEALER_DETAILS_REQUEST_";
	public final static String CAR_DEALER_DETAILS_RESPONSE = "CAR_DEALER_DETAILS_RESPONSE_";
	
	public final static String NTB_OTHER_DETAILS_REQUEST = "NTB_OTHER_DETAILS_REQUEST_";
	
	public final static String ETB_OTHER_DETAILS_REQUEST = "ETB_OTHER_DETAILS_REQUEST_";
	public final static String GETREVISED_ROI_CHARGES_RESPONSE = "GETREVISED_ROI_CHARGES_RESPONSE_";
	
	
	
	
	public final static String INJECTION_STATUS_RETRY_COUNT = "INJECTION_STATUS_RETRY_COUNT_";
	public final static String ETB_INJECTION_STATUS_RETRY_COUNT = "ETB_INJECTION_STATUS_RETRY_COUNT_";

	public final static String US = "_";
	public final static int CTA_CALL_COUNT = 5;
	public final static String NTB_DL_AUTHENTICATION = "NTB_DL_AUTHENTICATION_";
	public final static String NTB_EB_AUTHENTICATION = "NTB_EB_AUTHENTICATION_";
	public final static String NTB_MCI_AUTHENTICATION = "NTB_MCI_AUTHENTICATION_";
	public final static String NTB_LPG_AUTHENTICATION = "NTB_LPG_AUTHENTICATION_";
	public final static String NTB_MB_AUTHENTICATION = "NTB_MB_AUTHENTICATION_";
	public final static String NTB_VID_AUTHENTICATION = "NTB_VID_AUTHENTICATION_";
	public final static String NTB_OPERATION_TYPE = "OPERATIONTYPE";

	/////////////////// BRE//////////////////////
	public final static String BRE_INITIATED = "Initiated";
	public final static String BRE_FAIL = "Fail";
	public final static String BRE_SUCCESS = "Success";
	public final static String BRE_REQUEST_OBJECT = "BRE_REQUEST_OBJECT_";

	public final static String BRE2_CALL_STATUS = "BRE2_CALL_STATUS_";
	public final static String ETB_BRE2_CALL_STATUS = "ETB_BRE2_CALL_STATUS_";
	public final static String BRE2_CALL_DATA = "BRE2_CALL_DATA_";
	public final static String ETB_BRE2_CALL_DATA = "ETB_BRE2_CALL_DATA_";
	public final static String BRE2_PERFIOS_CUST_NAME = "BRE2_PERFIOS_CUST_NAME_";
	public final static String BRE2_PERFIOS_CUST_NAME_SCORE = "BRE2_PERFIOS_CUST_NAME_SCORE_";
	public final static String BRE2_REQUEST_OBJECT = "BRE2_REQUEST_OBJECT";
	public final static String ETB_BRE2_REQUEST_OBJECT = "ETB_BRE2_REQUEST_OBJECT";
	public final static String BRE2_ACCOUNT_NUMBER = "BRE2_ACCOUNT_NUMBER_";

	public final static String BRE3_CALL_STATUS = "BRE3_CALL_STATUS_";
	public final static String BRE3_CALL_DATA = "BRE3_CALL_DATA_";
	public final static String BRE3_REQUEST_OBJECT = "BRE3_REQUEST_OBJECT_";
	public final static String BRE3_EKYC_CUST_NAME = "BRE3_KYC_CUST_NAME_";
	public final static String BRE3_EKYC_CUST_NAME_SCORE = "BRE3_KYC_CUST_NAME_SCORE_";

	public final static String BRE3_PERFIOS_OPRTATION = "BRE3_PERFIOS_OPRTATION_";
	public final static String BRE3_KYC_OPRTATION = "BRE3_KYC_OPRTATION_";
	public final static String BRE3_NAMEMATCH_OPERATION = "BRE3_NAMEMATCH_OPERATION_";
	public final static String EKYC_PHOTO = "EKYC_PHOTO_";

	public final static String NTB_EKYC_NAME_MATCH = "NTB_EKYC_NAME_MATCH";
	public final static String NTB_PAN_NAME_MATCH_SCORE = "NTB_PAN_NAME_MATCH_SCORE_";
	public final static String NTB_PAN_TARGET_NAME = "NTB_PAN_TARGET_NAME_";

	/* JOURNEY STAGING */
	public final static String EMPLOYMENT_STAGE = "EMPLOYMENT_STAGE_";
	public final static String PRINCIPLE_LOAN_OFFER = "PRINCIPLE_LOAN_OFFER_";
	public final static String PERFIOS_STAGE = "PERFIOS_STAGE_";
	public final static String CAR_DEALER_SECTION = "CAR_DEALER_SECTION_";
	public final static String KYC_STAGE = "KYC_STAGE_";
	public final static String DIGITAL_DISBURSEMENT = "DIGITAL_DISBURSEMENT_";
	public final static String BTR_REF_NUMBER = "BTR_REF_NUMBER_";
	public final static String LEAD_STATUS_DATA = "LEAD_STATUS_DATA_";
	public final static String LEADINSTA_REF_NUM = "LEADINSTA_REF_NUM_";
	public final static String LEADINSTA_SNAP_REF_NUM = "LEADINSTA_SNAP_REF_NUM_";
	public final static String VCIP_STAGE = "VCIP_STAGE_";
	public final static String VCIP_PROFILEID = "VCIP_PROFILEID_";
	public final static String VCIP_SATAUS_UNIQUEID = "VCIP_SATAUS_UNIQUEID_";
	public final static String VCIP_EXPIRE = "VCIP_EXPIRE_";
	/* JOURNEY STAGING */

	public final static String PAN_NAME_SCORE = "Pan_Name_Score_";
	public final static String EKYC_NAME_SCORE = "Ekyc_Name_Score_";
	public final static String PERFIOS_NAME_SCORE = "Perfios_Name_Score_";
	public final static String MERGED_NAME_SCORE = "Merged_Name_Score_";
	public final static String SET_POSTAL_CODE = "SET_POSTAL_CODE_";

	public final static String VCIP_REFERENCE_ID = "VCIP_REFERENCE_ID_";
	public final static String VCIP_STATUS = "VCIP_STATUS_";
	// APPLNLOSFILLERSFILLERTEXT8 status tags
	public final static String BRE_APIS_STATUS = "BRE_APIS_STATUS_";
	public final static String BRE_APIS_TIME = "BRE_APIS_TIME_";
	/* WB With Mobile */
	public final static String BRE_APIS_STATUS_WM = "BRE_APIS_STATUS_WM_";
	public final static String BRE_APIS_TIME_WM = "BRE_APIS_TIME_WM_";

	/////////// NTB Journey Code////////////////////
	public final static String NTB_JOURNY_DATA = "NTB_JOURNY_DATA_";
	public final static String STAMP_DUTY_DATA = "STAMP_DUTY_DATA_";
	public final static String LOAN_CALC_API_RESP = "LOAN_CALC_API_RESP_";
	public final static String INJECTION_API_REQ = "INJECTION_API_REQ_";
	public final static String DIGITAL_DISBURSEMENT_PDF_DATA = "DIGITAL_DISBURSEMENT_PDF_DATA_";

	public final static String EKYC_OTPGEN_COUNT = "OTPGENCNT_";
	public final static String EKYC_OTPVERIFY_COUNT = "OTPVERIFYCNT_";
	public final static String ACKNOWLEDGEMENT_ID = "ACKNOWLEDGEMENT_ID_";
	///////////////// 03022021//////////////////
	public final static String JWT_TOKEN_RANDOM_ID = "jwttokenrandomid_";
	public final static String BTRN_REF_NO = "BTrnRefNo_";
	public final static String CUST_LOANS = "CustLoans_";
	public final static String CUTOMER_STAGING = "CutomerStaging_";
	public final static String NTB_MULTI_BUREAU = "NTB_MULTI_BUREAU_";
	public final static String BRECALL_STATUS = "BRECALL_STATUS";
	public final static String BRECALL_DATA = "BRECALL_DATA";
	public final static String NTB_DEDUPE_INPUT = "NTB_DEDUPE_INPUT_";
	public final static String POSIDEX_FILENAME = "POSIDEX_FILENAME_";
	public final static String ETB_POSIDEX_FILENAME = "ETB_POSIDEX_FILENAME_";
	public final static String NTB_DEDUPE_PUBLISH = "NTB_DEDUPE_PUBLISH_";
	public final static String NTB_OTP_GENERATION = "NTB_OTP_GENERATION_";
	public final static String NTB_RESEND_OTP = "NTB_RESEND_OTP_";
	public final static String NTB_PERFIOS_NAME_MATCH = "NTB_PERFIOS_NAME_MATCH_";
	public final static String NTB_ADDRESS_MATCH = "NTB_ADDRESS_MATCH_";
	public final static String TRUSTING_SOCIAL_BEARER_TOKEN = "trusting_social_bearer_token_";
	public final static String USER_NAME = "USER_NAME_";
	public final static String PINCODE = "PINCODE_";

	/* IMPS */
	public final static String BATCH_NUM_NEXT_COUNT = "BATCH_NUM_NEXT_COUNT_";

	// Perfios call back check
	public final static String PERFIOS_CALLBACK_STATUS = "PERFIOS_CALLBACK_STATUS_";

	// Email otp
	public final static String EMAIL_OTP_TAG = "EMAIL_OTP_TAG_";
	public final static String NTB_CUSTOMER_NAME = "NTB_CUSTOMER_NAME_";
	public final static String LEAD_NUMBAR = "LEAD_NUMBAR_";
	/* Document */
	public final static String FIN_DOC_ADD_REF_FILLER1 = "FIN_DOC_ADD_REF_FILLER1_";
	public final static String FIN_DOC_ADD_REF_FILLER2 = "FIN_DOC_ADD_REF_FILLER2_";
	public final static String FIN_DOC_CIBIL_ACK_NO = "FIN_DOC_CIBIL_ACK_NO_";
	public final static String FIN_DOC_ADD_REF_COUNT = "FIN_DOC_ADD_REF_COUNT_";
	public final static String FIN_DOC_SOURCE_UNIQUE_ID = "FIN_DOC_SOURCE_UNIQUE_ID_";
	public final static String NTB_PERFIOS_DESTINATION = "NTB_PERFIOS_DESTINATION_";

	public final static String PERFIOS_GENERATE_URL_REQUEST = "PERFIOS_GENERATE_URL_REQUEST_";
	public final static String ETB_PERFIOS_GENERATE_URL_REQUEST = "ETB_PERFIOS_GENERATE_URL_REQUEST_";
	public final static String ETB_DOC_GENERATE_PERFIOS_URL_REQ = "ETB_DOC_GENERATE_PERFIOS_URL_REQ_";
	public final static String EKYC_GENERATE_URL_REQUEST = "EKYC_GENERATE_URL_REQUEST_";
	
	
	public final static String OFFER_INDICATION_RESPONSE = "OFFER_INDICATION_RESPONSE_";

	public final static String LOS_DOCUMENT_CONSTITUTION = "LOS_DOCUMENT_CONSTITUTION_";
	public final static String COMPLETE_DOC_RESP = "COMPLETE_DOC_RESP_";
	public final static String ETB_COMPLETE_DOC_RESP = "ETB_COMPLETE_DOC_RESP_";
	public final static String INJECTION_REQUEST = "INJECTION_REQUEST_";

	public final static String TRACK_YOUR_LOAN_STR_REF_NO = "TRACK_YOUR_LOAN_STR_REF_NO_";

	public final static String ADD_REFERENCE_REQ = "ADD_REFERENCE_REQ_";
	public final static String ETB_ADD_REFERENCE_REQ = "ETB_ADD_REFERENCE_REQ_";
	public final static String TRACK_STARUS_RESP = "TRACK_STARUS_RESP_";
	public final static String ETB_TRACK_STARUS_RESP = "ETB_TRACK_STARUS_RESP_";

	public final static String APPLY_FOR_LOAN_REQUEST = "APPLY_FOR_LOAN_REQUEST_";
	public final static String APPLY_FOR_LOAN_RESPONSE = "APPLY_FOR_LOAN_RESPONSE_";

	public final static String ETB_APPLY_FOR_LOAN_REQUEST = "ETB_APPLY_FOR_LOAN_REQUEST_";
	public final static String ETB_APPLY_FOR_LOAN_RESPONSE = "ETB_APPLY_FOR_LOAN_RESPONSE_";

	public final static String COMP_DOCUMENT_RESP = "COMP_DOCUMENT_RESP_";
	public final static String ETB_COMP_DOCUMENT_RESP = "ETB_COMP_DOCUMENT_RESP_";
	public final static String OTPVERIFYCNT = "OTPVERIFYCNT_";
	public final static String OTPGENFLAG = "OTPGENFLAG_";
	public final static String OTPGENCNT = "OTPGENCNT_";
	public final static String OTP_GEN_REQUEST = "OTP_GEN_REQUEST_";
	
	public final static String ADDRESS = "ADDRESS";
	public final static String CITY = "CITY";
	public final static String STATE = "STATE";
	public final static String LEADINSTA_OBJ = "LEADINSTA_OBJ_";
	public final static String LEADINSTA_STATE = "LEADINSTA_STATE_";
	public final static String MCI_COUNCIL_NAME = "MCI_COUNCIL_NAME_";
	public final static String MCI_REG_NO = "MCI_REG_NO_";

}
