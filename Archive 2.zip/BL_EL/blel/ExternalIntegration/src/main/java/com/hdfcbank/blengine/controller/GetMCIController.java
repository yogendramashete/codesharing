package com.hdfcbank.blengine.controller;

import com.hdfcbank.blengine.bean.getMCIData.GetMCIDataRequest;
import com.hdfcbank.blengine.bean.getMCIData.GetMCIDataResponse;
import com.hdfcbank.blengine.exception.BLEngineException;
import com.hdfcbank.blengine.model.GetMCIService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

@Validated
@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping("/api/v2")

public class GetMCIController {
    public final static Logger logger = LoggerFactory.getLogger(GetMCIController.class);

    @Autowired
    private GetMCIService getMCIService;

    @RequestMapping("/getMCIData")
    public ResponseEntity<GetMCIDataResponse> getMCIData(@Valid @RequestBody GetMCIDataRequest request) {

        GetMCIDataResponse response =null;

        try {

            response = getMCIService.getMCIData(request);
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (BLEngineException exe) {
            logger.error("getMCIData Exception :: "+ exe);
            return new ResponseEntity<>(response, HttpStatus.OK);

        }

    }

}
