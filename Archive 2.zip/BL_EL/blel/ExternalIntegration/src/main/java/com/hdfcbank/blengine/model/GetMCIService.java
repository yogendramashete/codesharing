package com.hdfcbank.blengine.model;

import com.hdfcbank.blengine.bean.getMCIData.GetMCIDataRequest;
import com.hdfcbank.blengine.bean.getMCIData.GetMCIDataResponse;
import com.hdfcbank.blengine.exception.BLEngineException;

public interface GetMCIService {
    GetMCIDataResponse getMCIData(GetMCIDataRequest request) throws BLEngineException;
}
