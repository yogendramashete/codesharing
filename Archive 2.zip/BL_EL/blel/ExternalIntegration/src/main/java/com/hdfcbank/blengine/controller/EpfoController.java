package com.hdfcbank.blengine.controller;

import com.hdfcbank.blengine.bean.epfo.request.EpfoDataRequest;
import com.hdfcbank.blengine.bean.epfo.response.EpfoDataResponse;
import com.hdfcbank.blengine.exception.BLEngineException;
import com.hdfcbank.blengine.model.EpfoService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

@Slf4j
@Validated
@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping("/api/v2")
public class EpfoController {
	

	 @Autowired
	 
	 private EpfoService epfoService;
	 
	 @RequestMapping("/getEpfoData")
	 public ResponseEntity<EpfoDataResponse> getEpfoData(@Valid @RequestBody EpfoDataRequest request) {
	        EpfoDataResponse response =null;
	        try {
	            response = epfoService.getEpfoDataUpdated(request);
	            return new ResponseEntity<>(response, HttpStatus.OK);
	        } catch (BLEngineException exe) {
	            log.error("getEpfoData Exception {} ", exe);
	            return new ResponseEntity<>(response, HttpStatus.OK);

	        }

	    }
}
