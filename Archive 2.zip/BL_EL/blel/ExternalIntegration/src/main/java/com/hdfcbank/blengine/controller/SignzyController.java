package com.hdfcbank.blengine.controller;

import com.hdfcbank.blengine.bean.getICAIData.GetICAIDataRequest;
import com.hdfcbank.blengine.bean.getICAIData.GetICAIDataResponse;
import com.hdfcbank.blengine.model.SignzyModel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping("/api/v2")
public class SignzyController {
    public final static Logger logger = LoggerFactory.getLogger(SignzyController.class);

    @Autowired
    SignzyModel signzyModel;

//	@Value("${FAILURE_STATUS_CODE}")
//	String FAILURE_STATUS_CODE;

//	@Value("${FAILURE_INVALID_REQUEST}")
//	String FAILURE_INVALID_REQUEST;

//	@Value("${FAILURE_ERROR_MESSAGE}")
//	String FAILURE_ERROR_MESSAGE;

    @RequestMapping("/getICAIData")
    public ResponseEntity<GetICAIDataResponse> getICAIData(@Valid @RequestBody GetICAIDataRequest request) {
        GetICAIDataResponse response = null;

        logger.info("Controller Request :: " + request);
        try {
            response = signzyModel.getICAIData(request);
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception exe) {
            logger.error("Get ICIAIData Exception :: " + exe);
            return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
        }
    }

}
