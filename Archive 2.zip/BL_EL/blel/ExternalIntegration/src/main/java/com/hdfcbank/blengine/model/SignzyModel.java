package com.hdfcbank.blengine.model;

import com.hdfcbank.blengine.bean.getICAIData.GetICAIDataRequest;
import com.hdfcbank.blengine.bean.getICAIData.GetICAIDataResponse;
import com.hdfcbank.blengine.exception.BLEngineException;


public interface SignzyModel {

	GetICAIDataResponse getICAIData(GetICAIDataRequest request)throws BLEngineException;

	}

	

