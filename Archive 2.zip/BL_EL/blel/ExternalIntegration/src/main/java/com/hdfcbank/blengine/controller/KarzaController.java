package com.hdfcbank.blengine.controller;

import com.hdfcbank.blengine.bean.getElectricityData.GetElectricityDataRequest;
import com.hdfcbank.blengine.bean.getElectricityData.GetElectricityDataResponse;
import com.hdfcbank.blengine.exception.BLEngineException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.hdfcbank.blengine.model.KarzaService;

import javax.validation.Valid;

@Validated
@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping("/api/v2")
public class KarzaController {
	public final static Logger logger = LoggerFactory.getLogger(KarzaController.class);

   @Autowired
   private KarzaService karzaService;

	
	@RequestMapping("/getElectricityData")
	public ResponseEntity<GetElectricityDataResponse> getElectricityData(@Valid @RequestBody GetElectricityDataRequest request) {
		GetElectricityDataResponse response =null;
		
		try {
			
			response = karzaService.getElectricityData(request);
			return new ResponseEntity<>(response, HttpStatus.OK);
		} catch (BLEngineException exe) {
			logger.error("getElectricityBillAuthentication Exception :: " + exe);
			return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
			
		}
	}

	
}
