package com.hdfcbank.blengine.model;

import com.hdfcbank.blengine.bean.breCallback.BreCallbackRequest;
import com.hdfcbank.blengine.bean.breCallback.BreCallbackResponse;
import com.hdfcbank.blengine.exception.BLEngineException;



public interface BrecallbackService {

    BreCallbackResponse breCallback(BreCallbackRequest request)  throws BLEngineException;



}