package com.hdfcbank.blengine.controller;


import com.hdfcbank.blengine.exception.BLEngineException;
import com.hdfcbank.blengine.bean.stpNonSTPDecision.STPNonSTPDecisionRequest;
import com.hdfcbank.blengine.bean.stpNonSTPDecision.STPNonSTPDecisionResponse;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.hdfcbank.blengine.model.STPNonSTPDecisionService;

import javax.validation.Valid;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@Validated
    public class STPNonSTPDecisionController {

        public static final Logger logger = LoggerFactory.getLogger(STPNonSTPDecisionController.class);

        @Autowired
        private STPNonSTPDecisionService sTPNonSTPDecisionModel;


        @RequestMapping("/api/v2/GetSTPNonSTPDecision")
        public ResponseEntity<STPNonSTPDecisionResponse> GetSTPNonSTPDecision( @Valid
            @RequestBody STPNonSTPDecisionRequest request){

            STPNonSTPDecisionResponse response = null;

        try {
            response = sTPNonSTPDecisionModel.getSTPNonSTPDecision(request);
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (BLEngineException exe) {
            logger.error("exception occured :: {}", ExceptionUtils.getStackTrace(exe));
            return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
        }


    }
    }