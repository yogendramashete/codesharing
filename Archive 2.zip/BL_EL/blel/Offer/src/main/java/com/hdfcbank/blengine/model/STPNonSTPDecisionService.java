package com.hdfcbank.blengine.model;


import com.hdfcbank.blengine.exception.BLEngineException;
import com.hdfcbank.blengine.bean.stpNonSTPDecision.STPNonSTPDecisionRequest;
import com.hdfcbank.blengine.bean.stpNonSTPDecision.STPNonSTPDecisionResponse;


public interface STPNonSTPDecisionService {

    STPNonSTPDecisionResponse getSTPNonSTPDecision(STPNonSTPDecisionRequest request)  throws BLEngineException;



    }
