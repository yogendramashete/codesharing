package com.hdfcbank.blengine.model;


import com.hdfcbank.blengine.bean.getBureauOffer.GetBureauOfferRequest;
import com.hdfcbank.blengine.bean.getBureauOffer.GetBureauOfferResponse;
import com.hdfcbank.blengine.exception.BLEngineException;



public interface GetBureauOfferService {

        GetBureauOfferResponse getBureauOffer(GetBureauOfferRequest request)  throws BLEngineException;



    }
