package com.hdfcbank.blengine.model;



import com.hdfcbank.blengine.exception.BLEngineException;
import com.hdfcbank.blengine.bean.initiateIncomeUpload.InitiateIncomeUploadRequest;
import com.hdfcbank.blengine.bean.initiateIncomeUpload.InitiateIncomeUploadResponse;


public interface InitiateIncomeUploadService {

    InitiateIncomeUploadResponse initiateIncomeUpload(InitiateIncomeUploadRequest request)  throws BLEngineException;



    }
