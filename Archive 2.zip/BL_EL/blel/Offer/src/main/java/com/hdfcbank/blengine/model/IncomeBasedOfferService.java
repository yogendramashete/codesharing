package com.hdfcbank.blengine.model;



import com.hdfcbank.blengine.exception.BLEngineException;
import com.hdfcbank.blengine.bean.incomeBasedOffer.IncomeBasedOfferRequest;
import com.hdfcbank.blengine.bean.incomeBasedOffer.IncomeBasedOfferResponse;


public interface IncomeBasedOfferService {

    IncomeBasedOfferResponse getIncomeBasedOffer(IncomeBasedOfferRequest request)  throws BLEngineException;



    }
