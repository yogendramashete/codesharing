package com.hdfcbank.blengine;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;


@Configuration
//@EnableAutoConfiguration(exclude={DataSourceAutoConfiguration.class})
//@PropertySources({
//		@PropertySource("classpath:application-${spring.profiles.active}.yaml"),
//		@PropertySource("classpath:application-info.properties"),
//		@PropertySource("classpath:application-sql.properties")})
@SpringBootApplication(scanBasePackages = "com.hdfcbank")
public class HdfcLoansApplication {
	static {
		System.setProperty("jdk.tls.maxHandshakeMessageSize", "60000");
	}
	public static void main(String[] args) {


		SpringApplication.run(HdfcLoansApplication.class, args);
	}






}
