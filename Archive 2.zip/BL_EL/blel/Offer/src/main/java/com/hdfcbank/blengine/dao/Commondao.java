package com.hdfcbank.blengine.dao;

import com.hdfcbank.blelengine.util.CommonUtility;
import com.hdfcbank.blengine.bean.getBureauOffer.GetBureauOfferReq;
import com.hdfcbank.blengine.bean.incomeBasedOffer.IncomeBasedOfferReq;
import com.hdfcbank.blengine.exception.BLEngineException;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Repository
public class Commondao {

	public static final Logger logger = LoggerFactory.getLogger(Commondao.class);

	@Autowired
	JdbcTemplate jdbcTemplate;

	@Value("${sql.query.insertloanAppOfferDetails}")
	private String insertloanAppOfferDetails;


	@Value("${sql.query.getappconfigparameters}")
	private String getappconfigparameters;

	@Value("${sql.query.getEmploymentType}")
	private String getEmploymentType;

	@Value("${sql.query.getCustomerFistName}")
	private String getCustomerFistName;

	@Value("${sql.query.updateBureauloanappjourneydata}")
	private String updateBureauloanappjourneydata;

	@Value("${sql.query.updateLoanappjourneydata}")
	private String updateLoanappjourneydata;


	@Value("${sql.query.insertloanappjourneydetails}")
	private String insertloanAppJourneyDetails;


	@Value("${sql.query.insertloanappinfo}")
	private String insertloanappinfo;

	@Value("${sql.query.updateloanappjourneydetails}")
	private String updateloanappjourneydetails;

	@Value("${sql.query.getloanappinfo}")
	private String getloanappinfo;

	@Value("${sql.query.updateloanappinfo}")
	private String updateloanappinfo;

	@Value("${sql.query.updateloanappinfoInitiateIncome}")
	private String updateloanappinfoInitiateIncome;


	@Value("${sql.query.updatebureauofferloaninfo}")
	private String updatebureauofferloaninfo;


	@Value("${sql.query.updateincomeofferloaninfo}")
	private String updateincomeofferloaninfo;

	@Value("${sql.query.getEmailValFlag}")
	private String getEmailValFlagFromLoanAppJourneyData;

	@Value("${sql.query.updateResiPanEquifaxAddrMatchLoanAppJourneyData}")
	private String updateResiPanEquifaxAddrMatchLoanAppJourneyData;

	public int updateLoanAppJourneyDetails(String stepName, double stepID, long bankJourneyId, String response,
			String result, String errorCode, String errorMessage) {
		int count = 0;

		try {
			count = jdbcTemplate.update(updateloanappjourneydetails,
					new Object[] { response, result, errorCode, errorMessage, bankJourneyId, stepID, stepName });
			logger.info("stepName updateLoanAppJourneyDetails  result count::{}", count);
		} catch (Exception e) {
			logger.info("updateLoanAppJourneyDetails Exception ::{} ", CommonUtility.getPrintStackTrace(e));
		}
		return count;
	}

	public int insertLoanAppJourneyDetails(String stepName, String requestType, double stepID, int stepLevel,
			long bankJourneyId, String API, String request, String redirectionToPartnerURL) {

		String result = "";
		String response = "";

		int count = 0;
		try {

			count = jdbcTemplate.update(insertloanAppJourneyDetails, new Object[] { bankJourneyId, stepID, stepName,
					stepLevel, requestType, API, request, response, result, redirectionToPartnerURL });
			logger.info("insertLoanAppJourneyDetails count  :: {}" , count);

        } catch (DuplicateKeyException e){
            //TODO - Do what you want

            throw new BLEngineException("Duplicate Record Found with  BanKJourneyID "+bankJourneyId);

		}
		return count;
	}


	public int updateBureauOfferLoanAppJourneyData( String ackId, long bankJourneyId) {
		int count = 0;

		try {
			count = jdbcTemplate.update(updateBureauloanappjourneydata, new Object[]{ackId , bankJourneyId});
			logger.info("count::" + count);
		} catch (Exception e) {
			throw new BLEngineException(e.getMessage());
		}

		return count;
	}

	public void updateLoanAppJourneyData( String perfiosurl, long bankJourneyId) {

		try {
			jdbcTemplate.update(updateLoanappjourneydata, new Object[]{perfiosurl , bankJourneyId});
		} catch (Exception e) {
			throw new BLEngineException(e.getMessage());
		}
	}


	public int insertLoanAppInfo(String partnerJourneyId, long bankJourneyId, String tenantId, String channelId,
			String productCode, String mobileNo, String PANNO) {
		logger.info("insertLoanAppJourneyData  :: ");

		String status = "InitiateCustomerIdentification";

		int count = 0;
		try {
			count = jdbcTemplate.update(insertloanappinfo, new Object[] { channelId, productCode, tenantId,
					bankJourneyId, partnerJourneyId, status, mobileNo, PANNO });
			logger.info("insertLoanAppJourneyData count  :: " + count);

        } catch (BLEngineException exe) {
            throw new BLEngineException(exe.getMessage());
        }
        return count;
    }



	public String updateInitiateIncomeLoanAppInfo(String returnurl, String status, String channelId, String productCode, String tenantId,
									long bankJourneyId, String partnerJourneyId) {
		logger.info("getLoanAppInfo :: ");

		int recordUpdated = 0;

		String isUpdate = "false";

		try {

			logger.info("ChannelId {},  ProductCode{}, Tenant_ID{}, -BankJourneyId{}, -PartnerJourneyId {}", channelId,
					productCode, tenantId, bankJourneyId, partnerJourneyId);

			Boolean recordFound = jdbcTemplate.queryForObject(getloanappinfo, Boolean.class, channelId, productCode,
					tenantId, bankJourneyId, partnerJourneyId);
			logger.info("recordFound {} ", recordFound);

			if (Boolean.TRUE.equals(recordFound)) {

				recordUpdated = jdbcTemplate.update(updateloanappinfoInitiateIncome, returnurl, status, channelId, productCode, tenantId,
						bankJourneyId, partnerJourneyId);
				logger.info("recordUpdated {}", recordUpdated);

				isUpdate = "true";

			}
			logger.info("getLoanAppInfo isUpdate :: {} ", isUpdate);
		} catch (BLEngineException exe) {

			throw new BLEngineException(exe.getMessage());
		}
		return isUpdate;
	}
	public String updateLoanAppInfo(String status, String channelId, String productCode, String tenantId,
			long bankJourneyId, String partnerJourneyId) {
		logger.info("getLoanAppInfo :: ");

		int recordUpdated = 0;

		String isUpdate = "false";

		try {

			logger.info("ChannelId {},  ProductCode{}, Tenant_ID{}, -BankJourneyId{}, -PartnerJourneyId {}", channelId,
					productCode, tenantId, bankJourneyId, partnerJourneyId);

			Boolean recordFound = jdbcTemplate.queryForObject(getloanappinfo, Boolean.class, channelId, productCode,
					tenantId, bankJourneyId, partnerJourneyId);
			logger.info("recordFound {} ", recordFound);

			if (Boolean.TRUE.equals(recordFound)) {

				recordUpdated = jdbcTemplate.update(updateloanappinfo, status, channelId, productCode, tenantId,
						bankJourneyId, partnerJourneyId);
				logger.info("recordUpdated {}", recordUpdated);

				isUpdate = "true";

			}
			logger.info("getLoanAppInfo isUpdate :: {} ", isUpdate);
		} catch (BLEngineException exe) {

			throw new BLEngineException(exe.getMessage());
		}
		return isUpdate;
	}



	public String updateBureauOfferLoanAppInfo(String Status, String ChannelId, String ProductCode, String Tenant_ID,
											  long BankJourneyId, String PartnerJourneyId, GetBureauOfferReq getBureauOfferReq ) {
		logger.info("getLoanAppInfo ::{} ");

		List<String> loanAppInfoList = null;
		String loanAppInfo = "";
		int updateCount = 0;
		String isUpdate = "";

		try {

			loanAppInfoList = jdbcTemplate.queryForList(getloanappinfo,
					new Object[] { ChannelId, ProductCode, Tenant_ID, BankJourneyId, PartnerJourneyId }, String.class);

			logger.info("loanAppInfoList.size() :: " + loanAppInfoList.size());

			if (!loanAppInfoList.isEmpty() && loanAppInfoList.size() == 1) {
				loanAppInfo = loanAppInfoList.get(0);

				logger.info("getLoanAppInfo before update :: ");
				SimpleDateFormat formatter=new SimpleDateFormat("dd-MM-yyyy");
				Date dob = null;
				try {
					dob = formatter.parse(getBureauOfferReq.getDob());
				} catch (ParseException e) {
					logger.info("updateBureauOfferLoanAppInfo Exception ::{} ", e.getMessage());
				}
				updateCount = jdbcTemplate.update(updatebureauofferloaninfo , new Object[] {getBureauOfferReq.getAccountNumber(), getBureauOfferReq.getCustomerID(),
																							getBureauOfferReq.getSalutation(), Status, getBureauOfferReq.getFirstName(),
						getBureauOfferReq.getMiddleName(),getBureauOfferReq.getLastName(),getBureauOfferReq.getResiAddressLine1(),getBureauOfferReq.getResiAddressLine2(),
						getBureauOfferReq.getResiAddressLine3(), getBureauOfferReq.getGender(),getBureauOfferReq.getEmploymentType(), getBureauOfferReq.getResiAddressCity(),
						getBureauOfferReq.getResiAddressState(), Integer.parseInt(getBureauOfferReq.getResiPincode()), dob, getBureauOfferReq.getLgCode(), getBureauOfferReq.getSmCode(),
						getBureauOfferReq.getBranchCode(), getBureauOfferReq.getSeCode(), getBureauOfferReq.getAgentCode(), getBureauOfferReq.getAssistedJourney(), ChannelId, ProductCode,
						Tenant_ID, BankJourneyId, PartnerJourneyId });
				logger.info("updateOtp row" + updateCount);
				if (updateCount > 0) {
					logger.info("getLoanAppInfo isUpdate :: " + isUpdate);
					isUpdate = "true";

				}

			} else if (!loanAppInfoList.isEmpty() && loanAppInfoList.size() >= 1) {

				isUpdate = "Duplicate records Found";

			} else {
				isUpdate = "false";
			}
			logger.info("getLoanAppInfo isUpdate :: " + isUpdate);
		} catch (BLEngineException exe) {
			throw new BLEngineException("Invalid Input");
		}
		return isUpdate;
	}

	public String updateCallbackLoanAppInfo(String Status,  long bankJourneyId) {
		logger.info("getLoanAppInfo ::{} ");

		List<String> loanAppInfoList = null;
		String loanAppInfo = "";
		int updateCount = 0;
		String isUpdate = "";
		String getQuery="select count(*) from loanAppInfo where bankjourneyid=?";
		String updateQuery="update  public.loanappinfo set status=?, dateupdated=now() where bankjourneyid=?  ";

		try {

			loanAppInfoList = jdbcTemplate.queryForList(getQuery,
					new Object[] { bankJourneyId }, String.class);

			logger.info("loanAppInfoList.size() :: " + loanAppInfoList.size());

			if (!loanAppInfoList.isEmpty() && loanAppInfoList.size() == 1) {
				loanAppInfo = loanAppInfoList.get(0);

				logger.info("getLoanAppInfo before update :: ");
				SimpleDateFormat formatter=new SimpleDateFormat("dd-MM-yyyy");
				Date dob = null;

				updateCount = jdbcTemplate.update(updateQuery , new Object[] {Status, bankJourneyId});
				logger.info("updateOtp row" + updateCount);
				if (updateCount > 0) {
					logger.info("getLoanAppInfo isUpdate :: " + isUpdate);
					isUpdate = "true";

				}

			} else if (!loanAppInfoList.isEmpty() && loanAppInfoList.size() >= 1) {

				isUpdate = "Duplicate records Found";

			} else {
				isUpdate = "false";
			}
			logger.info("getLoanAppInfo isUpdate :: " + isUpdate);
		} catch (BLEngineException exe) {
			throw new BLEngineException("Invalid Input");
		}
		return isUpdate;
	}

	public String getAPIConfigParameters(String channelid, String dataname, String datakey) {
		logger.info("get  API Constant Parameters :: ");
		List<String> apiConstantslist = null;
		String isactive = "Y";
		String apiConfig = "";

		try {

			apiConstantslist = jdbcTemplate.queryForList(getappconfigparameters,
					new Object[] { channelid, dataname, datakey, isactive }, String.class);
			if (!apiConstantslist.isEmpty()) {
				apiConfig = apiConstantslist.get(0);
			}
			logger.info("apiConfig  datakey::" + datakey + apiConfig);

		} catch (Exception exe) {
			//exe.printStackTrace();
			logger.info("Exception :: " + exe);
		}
		return apiConfig;
	}

	public String getEmploymentTypeFromLoanAppInfo(String tenantId, long bankJourneyId, String partnerJourneyId) {
		logger.info("get  API Constant Parameters :: ");
		List<String> employmentTypelist = null;
		String isactive = "Y";
		String employmentType = "";

		try {

			employmentTypelist = jdbcTemplate.queryForList(getEmploymentType,
					new Object[] { tenantId, bankJourneyId, partnerJourneyId }, String.class);
			if (!employmentTypelist.isEmpty()) {
				employmentType = employmentTypelist.get(0);
			}
			logger.info("apiConfig  employmentType::" + employmentType );

		} catch (Exception exe) {
			//exe.printStackTrace();
			logger.info("Exception :: " + exe);
		}
		return employmentType;
	}

	public String getCustomerNameFromLoanAppInfo(String tenantId, long bankJourneyId, String partnerJourneyId) {
		logger.info("get  API Constant Parameters :: ");
		List<String> customerFirstNamelist = null;
		String isactive = "Y";
		String customerFirstName = "";

		try {

			customerFirstNamelist = jdbcTemplate.queryForList(getCustomerFistName,
					new Object[] { tenantId, bankJourneyId, partnerJourneyId }, String.class);
			if (!customerFirstNamelist.isEmpty()) {
				customerFirstName = customerFirstNamelist.get(0);
			}
			logger.info("apiConfig  customerFirstName::" + customerFirstName );

		} catch (Exception exe) {
			//exe.printStackTrace();
			logger.info("Exception :: " + exe);
		}
		return customerFirstName;
	}



	public Map<String, Object> getJourneyRecordLoanAppInfo(String channelid, String bankJourneyId, String partnerJourneyId) {

		List<Map<String, Object>> loanAppinfoList = null;
		Map<String, Object>  loanAppInfo = null;

		String query = "select mobileno, panno, permanentaddressline1,permanentaddressline2, permanentaddressline3, permanentaddresscity, permanentaddressstate, permanentaddresspincode, bankname, bankaccountno, employmenttype, nameofbiz, occupation, nameofemployer, maritalstatus, religion,personalemailaddress, natureofbusiness, purposeofloan, preferredcontactlocation, officephonenumber, workemail, workemailverification, customer_consent, officeorbusinessaddrline1, officeorbusinessaddrline2, officeorbusinessaddrline3, officeorbusinesspincode, officeorbusinesscity, officeorbusinessstate, officeorbusinessphoneno, resiaddresstype, loanamount, assistedjourney, agentcode, reffirstname, refmiddlename, reflastname, refmobileno from loanappinfo where  channelid =? and bankjourneyid= ?and partnerjourneyid= ?";

		try {
			loanAppinfoList = jdbcTemplate.queryForList(query, new Object[] { channelid, Long.parseLong(bankJourneyId), partnerJourneyId });
			logger.info("leaddata ::" + loanAppinfoList.size());
			if(loanAppinfoList.size() !=0) {
				loanAppInfo = loanAppinfoList.get(0);
			}
			  
		} catch (Exception exe) {
			logger.info("Exception :: " + exe);
		}
		
  		return loanAppInfo;
	}

	public Map<String, Object> getJourneyRecordLoanAppJourneyDetails(String stepname, String bankJourneyId) {

		List<Map<String, Object>> loanAppJourneyList;
		Map<String, Object>  loanAppJourneyDetails = null;

		String query = "select response from loanappjourneydetails where  bankjourneyid= ?and stepname= ?";

		try {
			loanAppJourneyList = jdbcTemplate.queryForList(query, new Object[] { Long.parseLong(bankJourneyId), stepname });
			logger.info("leaddata ::" + loanAppJourneyList.size());
			if(loanAppJourneyList.size() !=0) {
				loanAppJourneyDetails = loanAppJourneyList.get(0);
				//logger.info("leaddata ::" + loanAppJourneyList.get(0).toString());
			}
		} catch (Exception exe) {
			logger.info("Exception :: " + exe);
		}
		
		
		return loanAppJourneyDetails;
	}

	public boolean recordFoundLoanAppInfo(String channelId, String productCode, String tenantId,
										  long bankJourneyId, String partnerJourneyId) {
		logger.info("getLoanAppInfo :: ");

		String isUpdate = "false";

		Boolean recordFound;
		try {

			logger.info("ChannelId {},  ProductCode{}, Tenant_ID{}, -BankJourneyId{}, -PartnerJourneyId {}", channelId,
					productCode, tenantId, bankJourneyId, partnerJourneyId);

			recordFound = jdbcTemplate.queryForObject(getloanappinfo, Boolean.class, channelId, productCode,
					tenantId, bankJourneyId, partnerJourneyId);
			logger.info("recordFound {} ", recordFound);

		} catch (BLEngineException exe) {

			throw new BLEngineException(exe.getMessage());
		}
		return recordFound;
	}

	public int insertLoanAppOfferDetails(long bankJourneyId, HashMap inputOfferDetails)
	{
		logger.info("insertLoanAppOfferDetails  :: ");

		int count = 0;
		try {
			count = jdbcTemplate.update(insertloanAppOfferDetails,
					new Object[]{bankJourneyId, inputOfferDetails.get("offerStage"),inputOfferDetails.get("stpNonSTP"),inputOfferDetails.get("offerTenure"),inputOfferDetails.get("offerAmount"),inputOfferDetails.get("emi"),inputOfferDetails.get("rateOfInterest"),inputOfferDetails.get("procFeesPer"),inputOfferDetails.get("failedReason"), inputOfferDetails.get("hardReject") });
			logger.info("insertLoanAppJourneyData count  :: " + count);

		} catch (BLEngineException e) {
			//TODO - Do what you want

			throw new BLEngineException(e.getMessage());

		}
		return count;
	}

	public String updateIncomebasedLoanAppInfo(String Status, String ChannelId, String ProductCode, String Tenant_ID,
											   long BankJourneyId, String PartnerJourneyId, IncomeBasedOfferReq incomeBasedOfferReq) {
		logger.info("getLoanAppInfo ::{} ");

		List<String> loanAppInfoList = null;
		String loanAppInfo = "";
		int updateCount = 0;
		String isUpdate = "";

		try {

			loanAppInfoList = jdbcTemplate.queryForList(getloanappinfo,
					new Object[] { ChannelId, ProductCode, Tenant_ID, BankJourneyId, PartnerJourneyId }, String.class);

			logger.info("loanAppInfoList.size() :: " + loanAppInfoList.size());

			if (!loanAppInfoList.isEmpty() && loanAppInfoList.size() == 1) {
				loanAppInfo = loanAppInfoList.get(0);

				logger.info("getLoanAppInfo before update :: ");
				SimpleDateFormat formatter=new SimpleDateFormat("dd-MM-yyyy");

				updateCount = jdbcTemplate.update(updateincomeofferloaninfo , new Object[] {Status, ChannelId, ProductCode, Tenant_ID, BankJourneyId, PartnerJourneyId });
				logger.info("updateOtp row" + updateCount);
				if (updateCount > 0) {
					logger.info("getLoanAppInfo isUpdate :: " + isUpdate);
					isUpdate = "true";

				}

			} else if (!loanAppInfoList.isEmpty() && loanAppInfoList.size() >= 1) {

				isUpdate = "Duplicate records Found";

			} else {
				isUpdate = "false";
			}
			logger.info("getLoanAppInfo isUpdate :: " + isUpdate);
		} catch (BLEngineException exe) {
			throw new BLEngineException("Invalid Input");
		}
		return isUpdate;
	}


	public String updateStpNonStpLoanAppInfo(String Status, String ChannelId, String ProductCode, String Tenant_ID,
											   long BankJourneyId, String PartnerJourneyId) {
		logger.info("getLoanAppInfo ::{} ");

		List<String> loanAppInfoList = null;
		String loanAppInfo = "";
		int updateCount = 0;
		String isUpdate = "";

		try {

			loanAppInfoList = jdbcTemplate.queryForList(getloanappinfo,
					new Object[] { ChannelId, ProductCode, Tenant_ID, BankJourneyId, PartnerJourneyId }, String.class);

			logger.info("loanAppInfoList.size() :: " + loanAppInfoList.size());

			if (!loanAppInfoList.isEmpty() && loanAppInfoList.size() == 1) {
				loanAppInfo = loanAppInfoList.get(0);

				logger.info("getLoanAppInfo before update :: ");
				SimpleDateFormat formatter=new SimpleDateFormat("dd-MM-yyyy");

				updateCount = jdbcTemplate.update(updateincomeofferloaninfo , new Object[] {Status, ChannelId, ProductCode, Tenant_ID, BankJourneyId, PartnerJourneyId });
				logger.info("updateOtp row" + updateCount);
				if (updateCount > 0) {
					logger.info("getLoanAppInfo isUpdate :: " + isUpdate);
					isUpdate = "true";

				}

			} else if (!loanAppInfoList.isEmpty() && loanAppInfoList.size() >= 1) {

				isUpdate = "Duplicate records Found";

			} else {
				isUpdate = "false";
			}
			logger.info("getLoanAppInfo isUpdate :: " + isUpdate);
		} catch (BLEngineException exe) {
			throw new BLEngineException("Invalid Input");
		}
		return isUpdate;
	}


	public boolean breStatesMasterCheck(String state) {

		logger.info("breStatesMasterCheck :: ");
		List<String> list = null;
		Boolean recordFound = false;
		try {
			logger.info("-state {}", state);
			String upperCaseState = state.toUpperCase();
			logger.info("upperCaseState {} ", upperCaseState);

			list = jdbcTemplate.queryForList("select state_name from bre_state_master where state_name = ?",
					new Object[] {  upperCaseState }, String.class);
			logger.info("recordFound :: " + list);
			if (!list.isEmpty()) {
				recordFound = true;
			}
		} catch (Exception exe) {
			logger.info("breStatesMasterCheck Exception :: " + CommonUtility.getPrintStackTrace(exe));
		}
		return recordFound;
	}

	public String getEmailValFlagFromLoanAppJourneyData(long bankJourneyId) {
		logger.info("get EmailValFlag From LoanAppJourneyData :: ");
		List<String> list = null;
		String emailFlag = "";

		try {

			list = jdbcTemplate.queryForList(getEmailValFlagFromLoanAppJourneyData,
					new Object[] { bankJourneyId }, String.class);
			if (!list.isEmpty()) {
				emailFlag = list.get(0);
			}
			logger.info("EmailValFlag value::" + emailFlag );

		} catch (Exception exe) {
			//exe.printStackTrace();
			logger.info("Exception :: " + exe);
		}
		return emailFlag;
	}

	public void updateResiAddrMatchWithPanEquifaxAddrloanAppJourneyData(long bankJourneyId, String resiAddressMatchPercentageEquifax) {

		try {
			logger.info("inside update ResiAddrMatch With OfficeAddr loanAppJourneyData:: {}",bankJourneyId);
			logger.info("Resi AddressMatch with Pan Equifax Percentage:: {}",resiAddressMatchPercentageEquifax);
			jdbcTemplate.update(updateResiPanEquifaxAddrMatchLoanAppJourneyData, new Object[]{ resiAddressMatchPercentageEquifax, bankJourneyId});
		} catch (Exception e) {
			logger.error("Exception :: " + e.getMessage());
			throw new BLEngineException(e.getMessage());
		}

	}




}
