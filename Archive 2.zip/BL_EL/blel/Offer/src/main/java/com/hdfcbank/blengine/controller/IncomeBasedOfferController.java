package com.hdfcbank.blengine.controller;


import com.hdfcbank.blengine.exception.BLEngineException;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.hdfcbank.blengine.bean.incomeBasedOffer.IncomeBasedOfferRequest;
import com.hdfcbank.blengine.bean.incomeBasedOffer.IncomeBasedOfferResponse;
import com.hdfcbank.blengine.model.IncomeBasedOfferService;

import javax.validation.Valid;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@Validated
    public class IncomeBasedOfferController {

        public static final Logger logger = LoggerFactory.getLogger(IncomeBasedOfferController.class);

        @Autowired
        private IncomeBasedOfferService incomeBasedOfferModel;


        @RequestMapping("/api/v2/GetIncomeBasedOffer")
        public ResponseEntity<IncomeBasedOfferResponse> GetIncomeBasedOffer ( @Valid
            @RequestBody IncomeBasedOfferRequest request){

            IncomeBasedOfferResponse response = null;

        try {
            response = incomeBasedOfferModel.getIncomeBasedOffer(request);
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (BLEngineException exe) {
            logger.error("exception occured :: {}", ExceptionUtils.getStackTrace(exe));
            return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
        }


    }
    }