package com.hdfcbank.blengine.constants;

public class AppConstants {


    public final static String channel = "Adobe";
    public final static String DATE_PATTERN  = "DD/MM/YYYY";
    public final static String initiateCustomererrorCode = "Error_code";
    public final static String initiateCustomererrorMsg = "Error_msg";
    public final static String initiateCustomerstepId = "1.0";
    public final static String initiateCustomerstepLevel = "1";
    public final static String verifyOTPStepId = "2.0";
    public final static String pannamematchAPI = "Offer-NAMEMATCH";
    public final static String verifyOTPStepLevel = "1";
    public final static String panEnquiryStepId = "3.0";
    public final static String panEnquiryStepLevel = "1";
    public final static String panEnquiryOperationModel1 = "1";
    public final static String panEnquiryOperationModel2 = "2";
    public final static String panEnquiryOperationModel3 = "3";
    public final static String panEnquiryOperationModel4 = "4";
    public final static String panEnquiryOperationModel5 = "5";
    public final static String panEnquiryOperationModel6 = "6";
    public final static String panEnquiryOperationModel7 = "7";
    public final static String equifaxoperationType = "EquiFaxAPI";
    public final static String getBureauJourneyId="GETBUREAUJOURNEYID";
    public final static String getBureauAccountNumber="getBureauAccountNo";

    public final static String KEY = "datakey";
    public final static String VALUE = "datavalue";



    public final static String existingCustomer = "Existing_Customer";
    public final static String initiateLabel = "InitiateCustomerIdentification";


	public final static String cifResponseCodeFieldName = "CIF_RespCode";


    public final static String insertFintech = "InitiateCustomerIdentification-FintechOffer";
    public final static String insertVerifyDemog = "VerifyOTPAndGetDemogDetails-FintechDemographic";
    public final static String IS_ENC = "Y";

    public final static String offerAvailableFieldName = "OFFER_AVAILABLE";
    public final static String getBureauOfferBRE1API = "GetBureauOffer-BRE1";
    public final static String getIncomeBasedOfferBRE2API = "GetIncomeBasedOffer-BRE2";
    public final static String getSTPNonSTPDecisionAPIBRE3API = "GetStpNonStpDecision-BRE3";
    public final static String tenantID = "HDFC";
    public final static String saveAddDetailsAPI = "SaveAdditionalDetails";
    public final static String getBureauOfferAPI = "GetBureauOffer";
    public final static String getIncomeBasedOfferAPI = "GetIncomeBasedOffer";
    public final static String initiateIncomeUploadAPI = "InitiateIncomeUpload";
    public final static String getSTPNonSTPDecisionAPI = "GetSTPNonSTPDecision";
    public final static String panEnquiryAPI = "PANEnquiry";
    public final static String panValidationAPI = "PANEnquiry-PAN";
    public final static String equifaxAPI = "PANEnquiry-Equifax";
    public final static String gstnAPI = " PANEnquiry-GSTN";

    public final static String BRE1_CALL_BACK = "BRE1_Callback_From_EL_Server";
    public final static String BRE2_CALL_BACK = "BRE2_Callback_From_EL_Server";
    public final static String BRE3_CALL_BACK = "BRE3_Callback_From_EL_Server";
    public final static String BRE1_CALL_BACK_BACKEND= "BRE1Callback_backend_to_FrontEnd";
    public final static String BRE2_CALL_BACK_BACKEND= "BRE2Callback_backend_to_FrontEnd";
    public final static String BRE3_CALL_BACK_BACKEND= "BRE3Callback_backend_to_FrontEnd";

    public final static String initiateIncomeUploadPerfiosAPI = "InitiateIncomeUpload-Perfios";
    public final static int PERFIOS_START_MINUS = 1;
    public final static int PERFIOS_END_MINUS = 6;



    public final static String verifyOTPAPI = "VerifyOTPAndGetDemogDetails";

	public final static String documentUploadAPI = "DocumentUpload";

    public final static String API_SUCCESS = "SUCCESS";
    public final static String API_FAIL = "FAIL";
    public static final String ENCRYPTION_ALGO = "RSA/ECB/PKCS1Padding";
    public static final String DIGEST_ALGO = "SHA-1";



    public final static String dbRecordUnavilable = "Record does not exist in LoanAppInfo table";
    public final static String backEndAPIDetailsNotFound = "Customer data is not available";

	public final static String dbErrorOccured = "Error Occurred while updating the details in DB";
	public final static String trueConstant = "true";
	public final static String falseConstant = "false";
	public final static String stepIdSaveAdditionalDetails = "2.0";
	public final static String stepIdSGetBureauOffer = "2.0";
    public final static String stepIdSGetSTPNonSTPDecision = "2.0";
    public final static String stepIdSGetIncomeBasedOffer = "2.0";
    public final static String getStepLevelGetIncomeBasedOffer = "1";
	public final static String stepIdDocumentUpload = "1.1f";
	public final static String requestType = "IN";
	public final static String stepLevelSaveAdditionalDetails = "1";
	public final static String stepLevelGetBureauOffer = "1";
    public final static String stepLevelSTPNonSTPDecision = "1";
    public final static String stepLevelGetIncomeBasedOffer = "1";
	public final static String stepLevelDocumentUpload = "1";

    public final static String stepIdInitiateIncomeUpload= "2.0";
    public final static String steplevelInitiateIncomeUpload = "1";

	public final static String dataKey = "DOCUMENT_SAVE_PATH";
	public final static String documentName = "WaerBill";

    public final static String panNumberConstant = "PAN_NO";
    public final static String dobConstant = "DOB";
    public final static String mobileNoConstant = "MOBILE_NO";
    public final static String isNameExact = "isNameExact";
    public final static String isNameUnique = "isNameUnique";
    public final static String isEmployed = "isEmployed";
    public final static String isRecent = "isRecent";
    public final static String txnRefNoConstant = "txnRefNo";
    public final static String dobGetBureauOffer = "DOB_GETBUREAU_OFFER";
    public final static String fullNameGetBureauOffer = "fullNamegetBureauOffer";
    public final static String addressGetBureauOffer = "addressgetBureauOffer";

    public final static String NAME_MATCH_REQUEST_BANK_CODE = "08";
    public final static String NAME_MATCH_REQUEST_CHANNEL = "APIGW";
    public final static String NAME_MATCH_REQUEST_TRANSACTION_BRANCH = "089999";
    public final static String NAME_MATCH_REQUEST_USER_ID = "DevUser01";
    public final static String NAME_MATCH_REQUEST_TRANSACTING_PARTY_CODE = "50000045";

    public final static String custIdConstant = "CUST_ID";
    public final static String sasIdConstant = "SAS_ID";
    public final static String Asterisk = "*";
    public final static String offerAmountConstant = "VERIFYOTP_OFFER_AMT";
    public final static String behavScore2Constant = "VERIFYOTP_BEHAVSCORE2";

    public final static String behavScore4Constant = "VERIFYOTP_BEHAVSCORE4";
    public final static String internalDebitScoreConstant = "VERIFYOTP_INTERNAL_DEBSCORE";
    public final static String internalDebitScoreBandConstant = "VERIFYOTP_INTERNAL_DEBSCOREBAND";
    public final static String verifyOtpZipcodeConstant = "VERIFYOTP_ZIPCODE";
}
