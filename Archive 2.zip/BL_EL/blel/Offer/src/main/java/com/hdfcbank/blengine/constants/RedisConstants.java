package com.hdfcbank.blengine.constants;

public class RedisConstants {


public final static String US = "_";
    public final static String EQUIFAX_ADDRESS = "EQUIFAX_ADDRESS_";
}
