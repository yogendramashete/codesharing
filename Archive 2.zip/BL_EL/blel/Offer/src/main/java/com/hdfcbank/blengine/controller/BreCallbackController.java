package com.hdfcbank.blengine.controller;

import com.hdfcbank.blengine.bean.breCallback.BreCallbackRequest;
import com.hdfcbank.blengine.bean.breCallback.BreCallbackResponse;
import com.hdfcbank.blengine.bean.getBureauOffer.GetBureauOfferRequest;
import com.hdfcbank.blengine.bean.getBureauOffer.GetBureauOfferResponse;
import com.hdfcbank.blengine.exception.BLEngineException;
import com.hdfcbank.blengine.model.BrecallbackService;
import com.hdfcbank.blengine.model.GetBureauOfferService;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@Validated
public class BreCallbackController {

    public static final Logger logger = LoggerFactory.getLogger(BreCallbackController.class);

    @Autowired
    private BrecallbackService breCallbackService;


    @RequestMapping("/api/v2/BreCallback")
    public ResponseEntity<BreCallbackResponse> BreCallback (@Valid @RequestBody BreCallbackRequest request){

        BreCallbackResponse response = null;
logger.info("test1");
        try {
            response = breCallbackService.breCallback(request);
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (BLEngineException exe) {
            logger.error("exception occured :: {}", ExceptionUtils.getStackTrace(exe));
            return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
        }


    }
}