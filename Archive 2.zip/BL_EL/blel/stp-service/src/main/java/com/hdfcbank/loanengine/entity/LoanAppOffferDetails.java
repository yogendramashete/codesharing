package com.hdfcbank.loanengine.entity;

import java.time.OffsetDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "loanappofferdetails")
@NoArgsConstructor
@Getter
@Data
public class LoanAppOffferDetails {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name =  "srno")
	private Integer srno;
	
	@Column(name =  "offertenure")
	private String offertenure;
	
	@Column(name = "offeramount")
	private String offeramount;
	
	@Column(name = "emi")
	private String emi;
	
	@Column(name = "roi")
	private String roi;
	
	@Column(name = "procfeesper")
	private String procfeesper;
	
	@Column(name = "bankjourneyid")
	private long bankjourneyid;

	@Column(name = "stp_nonstp")
	private String stpNonstp;

	@Column(name = "offerstage")
	private String offerstage;
}
