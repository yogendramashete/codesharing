package com.hdfcbank.openAPI;

/**
 * Json Request
 * @author Ajay
 *
 */
public class LeadStatusJsonRequest {

	private String RequestEncryptedValue;
	private String SymmetricKeyEncryptedValue;
	private String Scope;
	private String TransactionId;
	private String OAuthTokenValue;

	
	public String getRequestEncryptedValue() {
		return RequestEncryptedValue;
	}
	public void setRequestEncryptedValue(String requestEncryptedValue) {
		RequestEncryptedValue = requestEncryptedValue;
	}
	public String getSymmetricKeyEncryptedValue() {
		return SymmetricKeyEncryptedValue;
	}
	public void setSymmetricKeyEncryptedValue(String symmetricKeyEncryptedValue) {
		SymmetricKeyEncryptedValue = symmetricKeyEncryptedValue;
	}
	public String getScope() {
		return Scope;
	}
	public void setScope(String scope) {
		Scope = scope;
	}
	public String getTransactionId() {
		return TransactionId;
	}
	public void setTransactionId(String transactionId) {
		TransactionId = transactionId;
	}
	public String getOAuthTokenValue() {
		return OAuthTokenValue;
	}
	public void setOAuthTokenValue(String oAuthTokenValue) {
		OAuthTokenValue = oAuthTokenValue;
	}

}
