package com.hdfcbank.openAPI;

import com.google.gson.Gson;

/**
 * Get Json Response object from String json response
 * 
 * @author Madhura Oak
 *
 */
public class JsonResponseReader {
	private Gson gson = new Gson();

	/**
	 * Get json response
	 * 
	 * @param jsonResponse
	 * @return
	 */
	public JsonResponse read(String jsonResponse) {
		JsonResponse response = gson.fromJson(jsonResponse, JsonResponse.class);
		return response;
	}


	public LeadStatusJsonResponse leadRead(String jsonResponse) {
		LeadStatusJsonResponse response = gson.fromJson(jsonResponse, LeadStatusJsonResponse.class);
		return response;
	}



}
