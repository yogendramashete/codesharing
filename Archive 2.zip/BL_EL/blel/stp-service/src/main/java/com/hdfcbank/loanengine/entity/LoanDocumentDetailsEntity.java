package com.hdfcbank.loanengine.entity;

import java.sql.Date;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Table(name = "loandocumentdetails")
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Data
public class LoanDocumentDetailsEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "srno")
	private Integer srno;

	@Column(name = "bankjourneyid", nullable = true)
	private String bankjourneyid;

	@Column(name = "documentsrno", nullable = true)
	private String documentsrno;

	@Column(name = "txnsrno", nullable = true)
	private Integer txnsrno;

	@Column(name = "documentstoragepathonserver", nullable = true)
	private String documentstoragepathonserver;

	@Column(name = "parentdocid", nullable = true)
	private String parentdocid;

	@Column(name = "childdocid", nullable = true)
	private String childdocid;

	@Column(name = "documenttype", nullable = true)
	private String documenttype;

	@Column(name = "filename", nullable = true)
	private String filename;

	@Column(name = "filedata", nullable = true)
	private String filedata;

	@Column(name = "flgreupload", nullable = true)
	private String flgreupload;

	@Column(name = "flgfinalupload", nullable = true)
	private String flgfinalupload;

	@Column(name = "filetype", nullable = true)
	private String filetype;

	@Column(name = "filler1", nullable = true)
	private String filler1;

	@Column(name = "filler2", nullable = true)
	private String filler2;

	@Column(name = "filler3", nullable = true)
	private String filler3;

	@Column(name = "filler4", nullable = true)
	private String filler4;

	@Column(name = "filler5", nullable = true)
	private String filler5;
}
