package com.hdfcbank.loanengine.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;

@Entity
@Table(name="stamp_duty_detail_master")
@NamedQuery(name="StampDutyDetailMaster.findAll", query="SELECT s FROM StampDutyDetailMaster s")
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Data
public class StampDutyDetailMaster implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name =  "id")
	private Integer id;

	@Column(name =  "cow")
	private Double cow;

	@Column(name =  "infra")
	private Double infra;

	@Column(name =  "maxloanvalue")
	private Double maxloanvalue;

	@Column(name =  "maxsd")
	private Double maxsd;

	@Column(name =  "minloanvalue")
	private Double minloanvalue;

	@Column(name =  "minsd")
	private Double minsd;

	@Column(name =  "poa")
	private Double poa;

	@Column(name =  "sdtype")
	private String sdtype;

	@Column(name =  "state")
	private String state;

	@Column(name =  "type")
	private String type;

	@Column(name =  "valueper")
	private Double valueper;

}