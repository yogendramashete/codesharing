package com.hdfcbank.loanengine.repository;

import com.hdfcbank.loanengine.entity.CityMasterEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.hdfcbank.loanengine.entity.LoanAppInfo;

import java.util.Optional;

@Repository
public interface LoanAppInfoRepository extends JpaRepository<LoanAppInfo, Integer>{

	LoanAppInfo findByBankjourneyidAndPartnerjourneyid(long bankJourneyId, String partnerJourneyId);

	//@Query("update  public.loanappinfo set status=?, dateupdated=now(), deviceid=? where  bankjourneyid=? and partnerjourneyid=?")
	//String updateLoanAppInfo(String status, String deviceid, String bankjourneyid, String partnerjourneyid);
}
