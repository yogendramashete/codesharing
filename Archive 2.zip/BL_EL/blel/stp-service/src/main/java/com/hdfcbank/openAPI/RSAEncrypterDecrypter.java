package com.hdfcbank.openAPI;

import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

public class RSAEncrypterDecrypter {
	private static final String RSA_ECB_PKCS1PADDING = "RSA/ECB/PKCS1Padding";
	private static final String RSA = "RSA";

	/**
	 * Encrypt data using RSA/ECB/PKCS1Padding
	 * @param data to be encrypted
	 * @param public key used for encryption
	 * @return encrypted result
	 */
	public byte[] encrypt(byte[] data, PublicKey key) {
		byte[] encryptedValue = null;
		try {
			Cipher cipher = Cipher.getInstance(RSA_ECB_PKCS1PADDING); 
			cipher.init(Cipher.ENCRYPT_MODE,key);
			encryptedValue = cipher.doFinal(data);
		}
		catch(NoSuchAlgorithmException exp) {
			//TODO handle exception
			exp.printStackTrace();
		}
		catch(NoSuchPaddingException exp) {
			//TODO handle exception
			exp.printStackTrace();
		}
		catch(IllegalBlockSizeException exp) {
			//TODO handle exception
			exp.printStackTrace();
		}
		catch(BadPaddingException exp) {
			//TODO handle exception
			exp.printStackTrace();
		}
		catch(InvalidKeyException exp) {
			//TODO handle exception
			exp.printStackTrace();
		}
		return encryptedValue;
	}
	
	/**
	 * Decrypt data using RSA/ECB/PKCS1Padding 
	 * @param data to be decrypted
	 * @param private key used for decryption
	 * @return decrypted result
	 */
	public byte[] decrypt(byte[] data, PrivateKey key) {
		byte[] decryptedValue = null;
		try {
			Cipher cipher = Cipher.getInstance(RSA_ECB_PKCS1PADDING); 
			cipher.init(Cipher.DECRYPT_MODE, key);
			decryptedValue = cipher.doFinal(data);
		}
		catch(NoSuchAlgorithmException exp) {
			//TODO handle exception
			exp.printStackTrace();
		}
		catch(NoSuchPaddingException exp) {
			//TODO handle exception
			exp.printStackTrace();
		}
		catch(IllegalBlockSizeException exp) {
			//TODO handle exception
			exp.printStackTrace();
		}
		catch(BadPaddingException exp) {
			//TODO handle exception
			exp.printStackTrace();
		}
		catch(InvalidKeyException exp) {
			//TODO handle exception
			exp.printStackTrace();
		}
		return decryptedValue;
	}	
	
}
