package com.hdfcbank.loanengine.util;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;


@Component
public class PennyDropUtil {
    public final static Logger logger = LoggerFactory.getLogger(PennyDropUtil.class);
    static List<String> Salutation = new ArrayList<>(
            Arrays.asList("Mrs.", "Mr.", "Shri.", "Sri.", "Smt.", "Dr.", "CA.", "Adv.", "Er.", "Master.", "Miss", "M/S",
                    "MS", "Miss.", "Mrs", "Mr", "Shri", "Sri", "Smt", "Dr", "CA", "Adv", "Er", "Master"));

    public static double getNamesMatchPercent(String name1, String name2) {
        logger.info("getNamesMatchPercent :: name1 : " + name1 + " name2 : " + name2);
        double matchPercent = 0;
        try {
            /* Logic 3(a) */
            name1 = removeSalutation(name1);
            name2 = removeSalutation(name2);
            /* Logic 3(a) */

            if (StringUtils.isNotBlank(name1) && StringUtils.isNotBlank(name2)) {
                name1 = name1.replace(".", " ");
                name2 = name2.replace(".", " ");
                String[] name1Arr = new String[1];
                String[] name2Arr = new String[1];

                if (name1.contains(" ")) {
                    name1Arr = name1.split("\\s+");
                } else {
                    name1Arr[0] = name1;
                }

                if (name2.contains(" ")) {
                    name2Arr = name2.split("\\s+");

                } else {
                    name2Arr[0] = name2;
                }

                logger.info("name1Arr :: " + name1Arr.length + " name2Arr :: " + name2Arr.length);
                boolean isLogic1Succ = false;
                if (name1Arr.length >= 2 && name2Arr.length >= 2) {
                    /* Logic 1 */
                    isLogic1Succ = pennyDropLogic1(name1Arr, name2Arr);
                    logger.info("isLogic1Succ :: " + isLogic1Succ);
                    /* Logic 1 */

                }

                /* Logic 2 */
                if (!isLogic1Succ) {
                    matchPercent = pennyDropLogic2(name1, name2);
                } else {
                    matchPercent = 100;
                }
                /* Logic 2 */
            } else {
                logger.info("Blank :: name1 :: " + name1 + " name2 :: " + name2);
            }
        } catch (Exception exe) {
            logger.info("getNamesMatchPercent Exception :: " + CommonUtility.getPrintStackTrace(exe));
        }
        return matchPercent;
    }

    private static boolean pennyDropLogic1(String[] name1Arr, String[] name2Arr) {
        boolean isLogic1Succ = true;
        boolean isAnyNameSucc = false;

        try {

            for (int i = 0; i < name1Arr.length; i++) {
                logger.info("pennyDropLogic1 :: name1 :: " + name1Arr[i] + " name2 :: " + name2Arr[i]);
                // Added below if because taking name1 as base so to avoid the AOB exe
                if (name2Arr.length >= i) {
                    if (!name1Arr[i].equals(name2Arr[i])) {
                        isLogic1Succ = false;
                        break;
                    }
                } else {
                    isLogic1Succ = false;
                    break;
                }

            }

            if (isLogic1Succ) {
                logger.info("Full match :: ");
            }

            if (!isLogic1Succ) {

                List<String> name1List = new LinkedList<String>(Arrays.asList(name1Arr));

                for (int j = 0; j < name1Arr.length; j++) {
                    if (name2Arr.length >= j) {
                        if (!isAnyNameSucc) {
                            if (name1List.stream().anyMatch(name2Arr[j]::equalsIgnoreCase)) {
                                name1List.remove(name2Arr[j]);
                                isAnyNameSucc = true;
                                break;
                            }
                        }
                    } else {
                        break;
                    }
                }

                if (isAnyNameSucc) {
                    boolean isInitialMatchSucc = false;
                    for (String name1Obj : name1List) {

                        for (int k = 0; k < name2Arr.length; k++) {

                            if (name1Obj.substring(0, 1).equals(name2Arr[k].substring(0, 1))) {
                                isInitialMatchSucc = true;
                                break;
                            } else {
                                isInitialMatchSucc = false;
                            }
                        }

                        if (isInitialMatchSucc) {
                            break;
                        }
                    }
                    if (isInitialMatchSucc) {
                        isLogic1Succ = isInitialMatchSucc;
                        logger.info("Partial match :: ");
                    }
                } else {
                    logger.info("isAnyNameSucc :: " + isAnyNameSucc);
                }

            }

        } catch (Exception exe) {
            isLogic1Succ = false;
            logger.info("pennyDropLogic1 Exception :: " + CommonUtility.getPrintStackTrace(exe));
        }
        return isLogic1Succ;
    }

    private static double pennyDropLogic2(String name1, String name2) {
        boolean isLogic2Succ = false;
        double matchPercentage = 0;
        try {
            name1 = name1.replaceAll(" ", "");
            name2 = name2.replaceAll(" ", "");
            logger.info("pennyDropLogic2 :: name1 :: " + name1 + " name2 :: " + name2);
            char[] name1Char = name1.toCharArray();
            char[] name2Char = name2.toCharArray();

            double maxLength = Math.max(name1Char.length, name2Char.length);
            double matchCount = 0;
            int j = 0;
            for (int i = 0; i < name1Char.length; i++) {
                if (name2Char.length >= i) {
                    if (String.valueOf(name1Char[i]).equalsIgnoreCase(String.valueOf(name2Char[j]))) {
                        matchCount++;
                        j++;
                        if (name2Char.length == j) {
                            break;
                        }
                    }
                } else {
                    break;
                }
            }

            matchPercentage = (matchCount / maxLength) * 100;
            matchPercentage = Math.round(matchPercentage);
            logger.info("matchCount :: " + matchCount + " maxLength :: " + maxLength + " matchPercentage :: "
                    + matchPercentage);
            /*
             * if (matchPercentage >= 70) { isLogic2Succ = true; }
             */

        } catch (Exception exe) {
            logger.info("pennyDropLogic2 Exception :: " + CommonUtility.getPrintStackTrace(exe));
        }
        return matchPercentage;
    }

    private static String removeSalutation(String name) {
        try {

            for (String value : Salutation) {
                if (name.length() >= value.length()) {
                    if (name.substring(0, value.length()).equalsIgnoreCase(value.toString())) {
                        name = name.substring(value.length());
                        break;
                    }
                }

            }
            name = name.replaceAll("\u00A0", "").trim();
        } catch (Exception exe) {
            logger.info("removeSalutation Exception :: " + CommonUtility.getPrintStackTrace(exe));
        }
        return name;
    }

    public static void main(String[] args) {
        String name1 = "G MURTHY KRISHNASARMA";
        String name2 = "G.MURTHY";
        double score = new PennyDropUtil().getNamesMatchPercent(name1, name2);
        // double score = new PennyDropUtil().pennyDropLogic2(name1, name2);
        System.out.println("score :: " + score);
        name1 = name1.replace(".", " ");
        System.out.println("name1 :: " + name1);
    }

}
