package com.hdfcbank.loanengine.entity;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Table(name = "loanappjourneydetails")
@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class LoanAppJourneyDetailsEntity {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name =  "srno")
	private Integer srno;
	
	@Column(name =  "bankjourneyid")
	private long bankjourneyid;
	
	@Column(name =  "stepid")
	private double stepid;

	@Column(name =  "steplevel")
	private int steplevel;
	
	@Column(name = "stepname")
	private String stepname;
	
	@Column(name = "requesttype")
	private String requesttype;
	
	@Column(name = "api")
	private String api;
	
	@Column(name = "processinititiationtime")
	private Timestamp processinititiationtime;

	@Column(name = "processcompletiontime")
	private Timestamp processcompletiontime;
	
	@Column(name = "request")
	private String request;
	
	@Column(name = "response")
	private String response;
	
	@Column(name = "result")
	private String result;

	@Column(name = "redirectiontopartnerurl")
	private String redirectiontopartnerurl;
	
	@Column(name = "errorcode")
	private String errorcode;

	@Column(name = "errormsg")
	private String errormsg;

	
	public LoanAppJourneyDetailsEntity(String stepname, String requesttype, double stepid, int steplevel,
	        long bankjourneyid, String api, String request, String redirectiontopartnerurl, String response,Timestamp processinittime, Timestamp processcompletiontime, String result, String errorCode, String errorMessage) {
		
		super();
		this.bankjourneyid = bankjourneyid;
		this.stepid = stepid;
		this.stepname = stepname;
		this.steplevel = steplevel;
		this.requesttype = requesttype;
		this.api = api;
		this.request = request;
		this.redirectiontopartnerurl = redirectiontopartnerurl;
		this.response = response;
		this.processcompletiontime = processcompletiontime;
		this.processinititiationtime = processinittime;
		this.result = result;
		this.errorcode=errorCode;
		this.errormsg=errorMessage;
	}
	
}
