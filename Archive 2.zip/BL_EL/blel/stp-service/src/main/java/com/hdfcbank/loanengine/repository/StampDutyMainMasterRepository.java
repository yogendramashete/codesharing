package com.hdfcbank.loanengine.repository;

import com.hdfcbank.loanengine.entity.LoanDocumentDetailsEntity;
import com.hdfcbank.loanengine.entity.StampDutyMainMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface StampDutyMainMasterRepository extends JpaRepository<StampDutyMainMaster, Integer> {
}
