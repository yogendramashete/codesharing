package com.hdfcbank.loanengine.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.hdfcbank.loanengine.entity.LoanAppJourneyDetailsEntity;
import com.hdfcbank.loanengine.enums.LoanAppJourneyDetailsServiceType;

@Repository
public interface LoanAppJourneyDetailsRepository extends JpaRepository<LoanAppJourneyDetailsEntity, Integer>{

    LoanAppJourneyDetailsEntity findBybankjourneyid(long bankJourneyId);

	
}
