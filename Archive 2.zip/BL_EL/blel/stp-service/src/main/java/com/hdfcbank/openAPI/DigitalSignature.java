package com.hdfcbank.openAPI;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.security.InvalidKeyException;
import java.security.KeyFactory;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Security;
import java.security.Signature;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;
import java.util.Enumeration;

import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

 
/**
 * Digitally sign data with private key of client. Verify the digitally signed data with public key of client.
 * @author Madhura Oak
 *
 */
public class DigitalSignature {
	public final static Logger logger = LoggerFactory.getLogger(DigitalSignature.class);
	private static final String RSA_SHA_256 = "SHA256withRSA";
	private static final String RSA = "RSA";
	static String certificatePath  =

			"D:/hdfcautocircle/openapiuat.hdfcbank.com_updated/openapiuat.hdfcbank.com/techepoch_com.pfx";
	private static final String privateKeyString = 
			"MIIEuwIBADANBgkqhkiG9w0BAQEFAASCBKUwggShAgEAAoIBAEzsyk45o1S3xieG2+K6myNBhBfhiY+FQVRGbgqjMUZncaz4PHVZ8yhooqsYMKKMz0+CRh4pm7Aho1rYZpSV6YvfZ0yu5UORNC9wFQu/eZKmcTAwigOxEuCkheM44Z/bz79C8iSwuMRfsVccN0/Ppd9M4NYaRsgMzGX17RZMG6z542Az344+9ePoMjUf1x/YX3Z+TXayWuMk1BOnKuLWhQFzCt4bjoEigm79S/H/u1zbrNw3Uck+vgxdjgS5geFsJfiphqvzBCdg2qeBk7l4uHM2kYd5UUEz+vSrzUiuWz0FRApFVZn4oxEU54bkO/SF6DJPkDU84tHRWIRxtHbhVm0CAwEAAQKCAQAtnH18Eor48Zqp1znL3w+bwP4c1tsk4UNSQAyBfC/8aduqTuoyPuqBvEEvp8E2sL0/jKQcwFkS/28Hr6ZrVdRL3mQ2wMEp5hAGTLP96kOgo9YbV7yN4dGqp4LHrvOBQOmWo5BGFw8HSSIy34UgaqQUmlX6PUxY09XiYwZ4IRqL3lz79B2faOVmY95gwXQnAcbGEX7Q+AJGioVkSVuNsGBF9lCddVhfpsHx4Dwl5ErAnCDkrYUy/xEB74E78803pENm2kjB8RGOsTk1S/LImv5g7j9TjM6rdyqZ+H4GOvPKGqLickO5BrMh9k93YO6t9oNU8wf5i73dPXNuGdCEq8GhAoGBAIzF5JfaMESJmlzYDYmdsHENEZOCH+s0EO5oQO6B/wXBwFyex/bxdwKBwcYqSdk+XA7PN6DwctDOLUMeIc5PlEEm6dETc+1+O7hiHs7Pj8n2WpjWc7dhH6zV/6cyQ6IMBbK4qFmtfuA2G2owTvETAeR9JijDcxu7AvFOOCAy2AiZAoGBAIvj74VX0rYFjiVxNI3REQoq8W8o3jqKx5VHRW3XD/7NScwSh2g6HkpRDS7YV5KtEYeo4tLHIEPoMXHA1/PK286IGRVqXnSL9/YOWxtes7bn7AmmbyhqlbfDRxICaNbRIMplYEFpRJAJ0y9CnoCFPMcA5pHz2UofeVDV6hyRD3z1AoGAZw5w3SJkd6htE08wCfEhPIIevehjSaMiSgaUkocklahUFPpA1e3L/E/V9ib7TUkzx7u3s+CTjX2C8UHb6dekZ1X/koo1MkZZnhBnEWwujeIGTSGiMTuvHq7DrDlF/hnjCgXZaV10Jtw1kbWv9Ri/J/DewLTlTgXIj7N9r0TJlvECgYAlMbCQop4quWVm/Sd9AXZnXq2c4Z/cruOMBEwofUMKe2jAsrh/9Nvy5IP9zZXTMOL1T+knI7yncYgb96szbd9tlXAd6o88q659JKoCp/ZejmGK2064z0YJewldd3iKjUYLqlKicavCJGqbKTpdb4+OVeX4Ln66n42w+X9qowMcNQKBgH11ZhOP6ZVvbfv0xPLzxjX8OPkvq7wWHWWgt6cLodTf9lJyO5UAAXo0ltJIX4GXhxEbsNHXoAVnVdXT29eXi6ktfm+QwmSbGZ1R9G0ENKfGS5gcbBGbFXgLa8A+LHQzaQ/BtxuMHdPssnsilCczJINDMRlGdeRCJLhfdHTzdZfp";
	private static final String publicKeyString =
			"MIIBITANBgkqhkiG9w0BAQEFAAOCAQ4AMIIBCQKCAQBM7MpOOaNUt8YnhtviupsjQYQX4YmPhUFURm4KozFGZ3Gs+Dx1WfMoaKKrGDCijM9PgkYeKZuwIaNa2GaUlemL32dMruVDkTQvcBULv3mSpnEwMIoDsRLgpIXjOOGf28+/QvIksLjEX7FXHDdPz6XfTODWGkbIDMxl9e0WTBus+eNgM9+OPvXj6DI1H9cf2F92fk12slrjJNQTpyri1oUBcwreG46BIoJu/Uvx/7tc26zcN1HJPr4MXY4EuYHhbCX4qYar8wQnYNqngZO5eLhzNpGHeVFBM/r0q81Irls9BUQKRVWZ+KMRFOeG5Dv0hegyT5A1POLR0ViEcbR24VZtAgMBAAE=";



	/**
	 * Get private key located at file path
	 * @param private key file path
	 * @return private key
	 */
	private PrivateKey getPrivateKey(String privateKeyFilePath) throws IOException, NoSuchAlgorithmException, InvalidKeySpecException {
		logger.info("privateKeyFilePath :"+privateKeyFilePath);
		byte[] keyBytes = Files.readAllBytes(new File(privateKeyFilePath).toPath());
		PKCS8EncodedKeySpec spec = new PKCS8EncodedKeySpec(keyBytes);
		KeyFactory kf = KeyFactory.getInstance(RSA);
		return kf.generatePrivate(spec);
	}

	private PrivateKey getPrivateKeyfile(String privateKeyFilePath) throws IOException, NoSuchAlgorithmException, InvalidKeySpecException, KeyStoreException, NoSuchProviderException, CertificateException, UnrecoverableKeyException {
		PrivateKey key = null;
		try {

			KeyStore keystore = KeyStore.getInstance("PKCS12");
			keystore.load(this.getClass().getClassLoader().getResourceAsStream(privateKeyFilePath), "snap123".toCharArray());
			Enumeration aliases = keystore.aliases();
			logger.info("aliases :"+aliases);
			String keyAlias = "";
			while (aliases.hasMoreElements()) {
				keyAlias = (String) aliases.nextElement();
			}
			logger.info("key alias :"+keyAlias);
			key = (PrivateKey)keystore.getKey(keyAlias, "snap123".toCharArray());

		} catch (Exception e) {
			logger.info("exception :: "+e);
		}
		return key;
	}
	/**
	 * Public key file path
	 * @param publicKeyFilePath
	 * @return public key
	 */
	private PublicKey getPublicKey(String publicKeyFilePath) throws IOException, NoSuchAlgorithmException, InvalidKeySpecException {
		byte[] keyBytes = Files.readAllBytes(new File(publicKeyFilePath).toPath());
		X509EncodedKeySpec spec = new X509EncodedKeySpec(keyBytes);
		KeyFactory kf = KeyFactory.getInstance(RSA);
		return kf.generatePublic(spec);
	}

	public static PrivateKey getPrivateKeyFromString(String base64PrivateKey){
		PrivateKey privateKey = null;
		PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(Base64.getDecoder().decode(base64PrivateKey.getBytes()));
		KeyFactory keyFactory = null;
		try {
			keyFactory = KeyFactory.getInstance("RSA");
			if(keyFactory != null) {
				privateKey = keyFactory.generatePrivate(keySpec);
			}
		} catch (Exception e) {
			logger.info("exception :: "+e);
		}
		return privateKey;
	}

	public static PublicKey getPublicKeyFromString(String base64PublicKey){
		PublicKey publicKey = null;
		try{
			X509EncodedKeySpec keySpec = new X509EncodedKeySpec(Base64.getDecoder().decode(base64PublicKey.getBytes()));
			KeyFactory keyFactory = KeyFactory.getInstance("RSA");
			publicKey = keyFactory.generatePublic(keySpec);
			return publicKey;
		} catch (NoSuchAlgorithmException e) {
			logger.info("exception :: "+e);
		} catch (InvalidKeySpecException e) {
			logger.info("exception :: "+e);
		}
		return publicKey;
	}


	/**
	 * Sign data using the private key stored at file path 
	 * @param data to be digitally signed
	 * @param privateKeyFilePath
	 * @return digitally signed data 
	 * @throws InvalidKeyException 
	 */
	public byte[] sign(String data, String privateKeyFilePath,String privateKeypassword) throws InvalidKeyException {
		byte[] returnVal = null;
		try {
			logger.info("privatekey file path :"+privateKeyFilePath);
			logger.info("privatekey file password :"+privateKeypassword);
			java.security.Security.addProvider(new org.bouncycastle.jce.provider.BouncyCastleProvider());

			Signature signature = Signature.getInstance(RSA_SHA_256);
			PrivateKey privateKey = privateKey(privateKeyFilePath,privateKeypassword);
			logger.info("private key :"+privateKey);
			signature.initSign(privateKey);
			signature.update(data.getBytes());
			returnVal = signature.sign();
		}

		catch (Exception e) {
			logger.info("exception :: "+e);
		}

		return returnVal;
	}


	public boolean verify(byte[] data, byte[] signature, String publicKeyFilePath) throws InvalidKeyException {
		boolean verified = false;
		try {
			Signature rsa = Signature.getInstance(RSA_SHA_256);
			PublicKey publicKey = getPublicKeyFromString(publicKeyString); 
			//					getPublicKey(publicKeyFilePath);
			rsa.initVerify(publicKey);
			rsa.update(data);
			verified = rsa.verify(signature);
		}catch (Exception e) {
			logger.info("exception :: "+e);
		}
		return verified;
	}

	public static PrivateKey privateKey(String privateKeyPath, String privateKeypassword) {
		PrivateKey privateKey = null;
		try {

			Security.addProvider(new BouncyCastleProvider());
			java.security.KeyStore keystore = java.security.KeyStore.getInstance("PKCS12");

			try(FileInputStream fileInputStream = new FileInputStream(privateKeyPath)) {
				keystore.load(fileInputStream, privateKeypassword.toCharArray());
			}

			String alias = keystore.aliases().nextElement();
			privateKey = (PrivateKey) keystore.getKey(alias, privateKeypassword.toCharArray());
//			logger.info("privateKey :: " + privateKey);
		} catch (Exception e) {
			logger.error("exception :: "+e);
		}
		return privateKey;
	}

}
