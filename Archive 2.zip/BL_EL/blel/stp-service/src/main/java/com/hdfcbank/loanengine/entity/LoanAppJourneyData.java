package com.hdfcbank.loanengine.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Table(name = "loanappjourneydata")
@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class LoanAppJourneyData {

    @Id
    @Column(name = "bankjourneyid", nullable = true)
    private long bankjourneyid;

    @Column(name = "offer_available", nullable = true)
    private String offer_available;

    @Column(name = "existing_customer", nullable = true)
    private String existing_customer;

    @Column(name = "offertype", nullable = true)
    private String offertype;

    @Column(name = "offeramount", nullable = true)
    private String offeramount;

    @Column(name = "offer_tenure", nullable = true)
    private String offer_tenure;

    @Column(name = "pan_status", nullable = true)
    private String pan_status;

    @Column(name = "pan_title", nullable = true)
    private String pan_title;

    @Column(name = "pan_filler1", nullable = true)
    private String pan_filler1;

    @Column(name = "pan_filler2", nullable = true)
    private String pan_filler2;

    @Column(name = "pan_filler3", nullable = true)
    private String pan_filler3;

    @Column(name = "pan_filler4", nullable = true)
    private String pan_filler4;

    @Column(name = "pan_filler5", nullable = true)
    private String pan_filler5;

    @Column(name = "nm_namepercentage", nullable = true)
    private String nm_namepercentage;

    @Column(name = "aadharname", nullable = true)
    private String aadharname;

    @Column(name = "aadharrefno", nullable = true)
    private String aadharrefno;

    @Column(name = "aadhardob", nullable = true)
    private String aadhardob;

    @Column(name = "aadharaddrline1", nullable = true)
    private String aadharaddrline1;

    @Column(name = "aadharaddrline2", nullable = true)
    private String aadharaddrline2;

    @Column(name = "aadharaddrline3", nullable = true)
    private String aadharaddrline3;

    @Column(name = "aadharaddrpincode", nullable = true)
    private String aadharaddrpincode;

    @Column(name = "aadharaddrcity", nullable = true)
    private String aadharaddrcity;

    @Column(name = "aadharaddrstate", nullable = true)
    private String aadharaddrstate;

    @Column(name = "videokycurl", nullable = true)
    private String videokycurl;

    @Column(name = "disbursementurl", nullable = true)
    private String disbursementurl;

    @Column(name = "perfiosurl", nullable = true)
    private String perfiosurl;

    @Column(name = "ekycurl", nullable = true)
    private String ekycurl;

    @Column(name = "vkyc_status", nullable = true)
    private String vkyc_status;

    @Column(name = "accvalid_status", nullable = true)
    private String accvalid_status;

    @Column(name = "ekyc_status", nullable = true)
    private String ekyc_status;

    @Column(name = "profession", nullable = true)
    private String profession;

@Column(name = "tran_ref_number", nullable = true)
    private String tranrefNumber;

    @Column(name = "name_match_percent", nullable = true)
    private String nameMatchPercent;

    @Column(name = "is_name_match", nullable = true)
    private String isNameMatch;
}
