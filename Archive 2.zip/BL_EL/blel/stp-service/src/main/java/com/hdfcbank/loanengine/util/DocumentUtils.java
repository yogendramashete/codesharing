 package com.hdfcbank.loanengine.util;

 import com.hdfcbank.loanengine.domain.constant.AppConstants;
 import com.loopj.android.http.Base64;
 import lombok.extern.slf4j.Slf4j;
 import org.slf4j.Logger;
 import org.slf4j.LoggerFactory;
 import org.springframework.beans.factory.annotation.Autowired;
 import org.springframework.stereotype.Component;

 import javax.crypto.Cipher;
 import javax.crypto.Mac;
 import javax.crypto.spec.IvParameterSpec;
 import javax.crypto.spec.SecretKeySpec;
 import java.io.IOException;
 import java.io.UnsupportedEncodingException;
 import java.nio.file.DirectoryNotEmptyException;
 import java.nio.file.Files;
 import java.nio.file.NoSuchFileException;
 import java.nio.file.Paths;
 import java.security.InvalidKeyException;
 import java.security.MessageDigest;
 import java.security.NoSuchAlgorithmException;
 import java.security.SecureRandom;
 import java.text.SimpleDateFormat;
 import java.util.Calendar;
 import java.util.Date;
 import java.util.Random;

@Component
@Slf4j
public class DocumentUtils {
	private final static Logger logger = LoggerFactory.getLogger(DocumentUtils.class);


	@Autowired
	CommonUtility commonUtility;

	@Autowired
	RedisUtils redisUtils;

	 

	private final SecureRandom random = new SecureRandom();
	private char[] buf;
	private final int length = 20;

	@SuppressWarnings("unused")
	public DocumentUtils() {
		if (length < 1)
			throw new IllegalArgumentException("length < 1: " + length);
		buf = new char[length];
	}

	public void deleteFileFromPath(String path) {
		try {
			Files.delete(Paths.get(path));
		} catch (NoSuchFileException x) {
			logger.info("%s: no such" + " file or directory%n", path);
		} catch (DirectoryNotEmptyException x) {
			logger.info("%s not empty%n", path);
		} catch (IOException x) {
			// File permission problems are caught here.
			logger.info("deleteFileFromPath IOException " + CommonUtility.getPrintStackTrace(x));
		}
	}


	public String getUniqueReqId() {
		char[] symbols;
		StringBuilder tmp = new StringBuilder();
		for (char ch = '0'; ch <= '9'; ++ch)
			tmp.append(ch);
		for (char ch = 'A'; ch <= 'Z'; ++ch)
			tmp.append(ch);
		symbols = tmp.toString().toCharArray();
		for (int idx = 0; idx < buf.length; ++idx)
			buf[idx] = symbols[random.nextInt(symbols.length)];
		return new String(buf);
	}

	public static String getCurrentDateIn_yyyymmdd() {
		String month = "";
		String day = "";
		if ((DocumentUtils.getCurrentMonth() + 1) <= 9) {
			String monthStr = "" + (DocumentUtils.getCurrentMonth() + 1);
			if (monthStr.length() == 1)
				month = "00" + (DocumentUtils.getCurrentMonth() + 1);
			else
				month = "0" + (DocumentUtils.getCurrentMonth() + 1);
		} else {
			month = "0" + (DocumentUtils.getCurrentMonth() + 1);
		}
		if ((DocumentUtils.getCurrentDay()) <= 9) {
			String dateStr = "" + DocumentUtils.getCurrentDay();
			if (dateStr.length() == 1)
				day = "0" + DocumentUtils.getCurrentDay();
			else
				day = "" + DocumentUtils.getCurrentDay();
		} else {
			day = "" + DocumentUtils.getCurrentDay();
		}
		String date = DocumentUtils.getCurrentYear() + "" + month + "" + day;
		return date;
	}

	public static int getCurrentMonth() {
		return Calendar.getInstance().get(Calendar.MONTH);
	}

	public static int getCurrentDay() {
		return Calendar.getInstance().get(Calendar.DAY_OF_MONTH);
	}

	public static int getCurrentYear() {
		return Calendar.getInstance().get(Calendar.YEAR);
	}

	public String getRequestToken(String deviceUniqueId, String lastReceivedToken)
			throws UnsupportedEncodingException, NoSuchAlgorithmException, InvalidKeyException {
		String response2 = null;
		String keyToEncode = "";
		StringBuffer sb, sb2, sb3;
		try {
			String deviceUniqueIdWithUnderScroll = deviceUniqueId;
			// STEP 1 //Remove ‘_’ from ApplicationVariables.DEVICE_UNIQUE_ID for below code
			// only.
			log.info("deviceUniqueId :: " + deviceUniqueId);
			deviceUniqueId = deviceUniqueId.replace("_", "");
			log.info("deviceUniqueId :: " + deviceUniqueId);
			String keyString = deviceUniqueId + "." + getCurrentDateIn_yyyymmdd() + "." + lastReceivedToken;
			log.info("keyString :: " + keyString);
			final MessageDigest mDigest = MessageDigest.getInstance("SHA-256");
			byte[] result = mDigest.digest(keyString.getBytes());
			sb = new StringBuffer();
			for (int i = 0; i < result.length; i++) {
				sb.append(Integer.toString((result[i] & 0xff) + 0x100, 16).substring(1));
			}

			// STEP 2.1
			String string = "{\"alg\":\"HS256\",\"typ\":\"JWT\"}";
			byte[] result2 = mDigest.digest(string.getBytes());
			sb2 = new StringBuffer();
			for (int i = 0; i < result2.length; i++) {
				sb2.append(Integer.toString((result2[i] & 0xff) + 0x100, 16).substring(1));
			}

			// STEP 2.2
			String string1 = "{\"tokenId\":87241165,\"userId\":\"" + deviceUniqueIdWithUnderScroll
					+ "\",\"username\":\"Guest\",\"validity\":\"2016-05-07 17:07\"}";

			byte[] result3 = mDigest.digest(string1.getBytes());
			sb3 = new StringBuffer();
			for (int i = 0; i < result3.length; i++) {
				sb3.append(Integer.toString((result3[i] & 0xff) + 0x100, 16).substring(1));
			}
			// STEP 2.3
			keyToEncode = sb2.toString() + sb3.toString();
			// STEP 3 // sb.toString() should be assign to key and keyToEncode should be
			// assign to message in HMAC_SHA256 function
			// Removing (.) DOT
			response2 = sb2.toString() + sb3.toString() + HMAC_SHA256(sb.toString(), keyToEncode);
		} catch (Exception e) {
			logger.info("Exception :: "+CommonUtility.getPrintStackTrace(e));
		}
		return response2;
	}

	private static String HMAC_SHA256(String secret, String message) {
		String hash = "";
		try {
			Mac sha256_HMAC = Mac.getInstance("HmacSHA256");
			SecretKeySpec secret_key = new SecretKeySpec(secret.getBytes(), "HmacSHA256");
			sha256_HMAC.init(secret_key);
			hash = Base64.encodeToString(sha256_HMAC.doFinal(message.getBytes()), Base64.NO_WRAP);
		} catch (Exception e) {
			logger.info("Exception :: "+CommonUtility.getPrintStackTrace(e));
		}
		return hash.trim();
	}

	public String getEncryptedTextFor(String text, String filler1) throws Exception {
		log.info("getEncryptedTextFor :: ");
		log.info("text :: " + text + " filler1 :: " + filler1);
		text = filler1 + text + filler1;
		log.info("text :: " + text);

		Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
		byte[] keyBytes = new byte[16];
		String key = "HDFCBANK!@#987MOBAPP";
		byte[] b = key.getBytes("UTF-8");
		int len = b.length;
		if (len > keyBytes.length)
			len = keyBytes.length;
		System.arraycopy(b, 0, keyBytes, 0, len);
		SecretKeySpec keySpec = new SecretKeySpec(keyBytes, "AES");
		IvParameterSpec ivSpec = new IvParameterSpec(keyBytes);
		cipher.init(Cipher.ENCRYPT_MODE, keySpec, ivSpec);
		byte[] results = cipher.doFinal(text.getBytes("UTF-8"));
		// return HttpRequest.Base64.encodeBytes(results);
		return java.util.Base64.getEncoder().encodeToString(results);
	}

	public String getEncryptedTextFor(String text) throws Exception {
		logger.info("getEncryptedTextFor :: ");

		Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
		byte[] keyBytes = new byte[16];
		String key = "HDFCBANK!@#987MOBAPP";
		byte[] b = key.getBytes("UTF-8");
		int len = b.length;
		if (len > keyBytes.length)
			len = keyBytes.length;
		System.arraycopy(b, 0, keyBytes, 0, len);
		SecretKeySpec keySpec = new SecretKeySpec(keyBytes, "AES");
		IvParameterSpec ivSpec = new IvParameterSpec(keyBytes);
		cipher.init(Cipher.ENCRYPT_MODE, keySpec, ivSpec);
		byte[] results = cipher.doFinal(text.getBytes("UTF-8"));
		// return HttpRequest.Base64.encodeBytes(results);
		return java.util.Base64.getEncoder().encodeToString(results);
	}

	public String getDecryptedValueFor(String lastReceivedToken, String encryptedResponseField) {
		String decryptedValue = null;
		try {
			String decryptedString = getDecryptedTextFor(encryptedResponseField);
			if (decryptedString.contains(lastReceivedToken)) {
				decryptedValue = decryptedString.replaceAll(lastReceivedToken, "");
			} else {
				// This should never happen
				logger.info("======== WRONG DATA RECEIVED...");
			}
		} catch (Exception e) {
			logger.info("Exception :: "+CommonUtility.getPrintStackTrace(e));
		}
		return decryptedValue;
	}

	public String getDecryptedTextFor(String base64Str) throws Exception {
		byte[] keyBytes = new byte[16];
		String key = "HDFCBANK!@#987MOBAPP";
		byte[] b = key.getBytes("UTF-8");
		int len = b.length;
		if (len > keyBytes.length)
			len = keyBytes.length;
		System.arraycopy(b, 0, keyBytes, 0, len);
		SecretKeySpec keySpec = new SecretKeySpec(keyBytes, "AES");
		byte[] base64ToByteArray = Base64.decode(base64Str, Base64.DEFAULT);
		Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
		IvParameterSpec ivSpec = new IvParameterSpec(keyBytes);
		cipher.init(Cipher.DECRYPT_MODE, keySpec, ivSpec);
		String decryptedStr = new String(cipher.doFinal(base64ToByteArray), "UTF-8");
		return decryptedStr;
	}

	 
	public long getDifferenceInMinutes(String lastDateTimeStr) {
		long minutesDifference = 0;
		Date currentDateTime = null;
		Date lastDateTime = null;
		try {

			SimpleDateFormat simpleDateFormat = new SimpleDateFormat(AppConstants.DATE_FMT_yyyy_MM_dd_HHmmssSSS);

			String currentDateTimeStr = simpleDateFormat.format(new Date());

			currentDateTime = simpleDateFormat.parse(currentDateTimeStr);
			lastDateTime = simpleDateFormat.parse(lastDateTimeStr);

			logger.info("currentDateTimeStr :: " + currentDateTimeStr);
			logger.info("lastDateTimeStr :: " + lastDateTimeStr);

			long difference = currentDateTime.getTime() - lastDateTime.getTime();

			minutesDifference = difference / (60 * 1000);

//			minutesDifference = (DOCUMENTS_API_EXPIRE_TIME/60) - minutesDifference; 
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("getDifferenceInMinutes Exception:: " + CommonUtility.getPrintStackTrace(e));
		}
		return minutesDifference;
	}
	 
}
