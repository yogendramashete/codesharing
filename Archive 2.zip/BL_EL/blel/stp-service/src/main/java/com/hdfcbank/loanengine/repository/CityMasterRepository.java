package com.hdfcbank.loanengine.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.hdfcbank.loanengine.entity.CityMasterEntity;

@Repository
public interface CityMasterRepository extends JpaRepository<CityMasterEntity, Integer> {
//	@Query("select  city_id from bre_city_master  where city_name  = ?1")
	Optional<CityMasterEntity> findBycityname(String cityname);
}
