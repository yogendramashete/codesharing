package com.hdfcbank.loanengine.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.hdfcbank.loanengine.entity.LoanAppJourneyData;
import com.hdfcbank.loanengine.enums.LoanAppJourneyDataServiceType;

@Repository
public interface LoanAppJourneyDataRepository extends JpaRepository<LoanAppJourneyData, Integer>{

    LoanAppJourneyData findByBankjourneyid(long bankJourneyId);

    @Modifying
    @Query(value="UPDATE public.loanappjourneydata set tran_ref_number = ?, name_match_percent = ?, updated_at = now() where bankjourneyid = ?",  nativeQuery = true)
    int updateNameMatchDtlsLoanAppJourneyData(String tranrefNumber,String nameMatchPercent ,long bankjourneyid);

    @Modifying
    @Query(value="UPDATE public.loanappjourneydata set is_name_match = ? updated_at = now() where bankjourneyid = ?",  nativeQuery = true)
    int updateIsNameMatchInLoanAppJourneyData(String isNameMatch,long bankjourneyid);

}
