package com.hdfcbank.loanengine.entity;

import java.sql.Date;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Table(name = "loanappinfo")
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Data
public class LoanAppInfo {
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name =  "srno")
	private Integer srno;

	@Column(name =  "channelid")
	private String channelid;

	@Column(name =  "productcode")
	private String productcode;

	@Column(name =  "tenant_id")
	private String tenant_id;
	
	@Column(name =  "bankjourneyid")
	private long bankjourneyid;

	@Column(name =  "partnerjourneyid")
	private String partnerjourneyid;
	
	@Column(name =  "status")
	private String status;
	
	@Column(name = "dateupdated")
	private Timestamp dateupdated;

	@Column(name = "datecreated")
	private Timestamp datecreated;
	
	@Column(name =  "mobileno")
	private String mobileno;

	@Column(name =  "panno")
	private String panno;

	@Column(name =  "customerfirstname")
	private String customerfirstname;

	@Column(name =  "customerlastname")
	private String customerlastname;

	@Column(name =  "addressline1")
	private String addressline1;

	@Column(name =  "addressline2")
	private String addressline2;

	@Column(name =  "addressline3")
	private String addressline3;

	@Column(name =  "state")
	private String state;

	@Column(name =  "city")
	private String city;

	@Column(name =  "pincode")
	private Integer pincode;
	
	@Column(name = "gender")
	private String gender;
	
	@Column(name = "dob")
	private Date dob;
	
	
	@Column(name = "emailid")
	private String emailid;
	
	@Column(name = "permanentaddress")
	private String permanentaddress;
	
	@Column(name = "permanentaddressline1")
	private String permanentaddressline1;
	
	@Column(name = "permanentaddressline2")
	private String permanentaddressline2;
	
	@Column(name = "permanentaddressline3")
	private String permanentaddressline3;

	@Column(name = "permanentaddresspincode")
	private String permanentaddresspincode;

	@Column(name = "permanentaddresscity")
	public String permanentaddresscity;

	@Column(name = "permanentaddressstate")
	public String permanentaddressstate;

	@Column(name = "bankname")
	private String bankname;

	@Column(name = "bankaccountno")
	private String bankaccountno;

	@Column(name = "ifsccode")
	private String ifsccode;

	@Column(name = "employmenttype")
	public String employmenttype;

	@Column(name = "nameofbiz")
	private String nameofbiz;

	@Column(name = "occupation")
	private String occupation;

	@Column(name = "nameofemployer")
	private String nameofemployer;

	@Column(name = "maritalstatus")
	private String maritalstatus;

	@Column(name = "religion")
	private String religion;

	@Column(name = "caste")
	private String caste;

	@Column(name = "personalemailaddress")
	private String personalemailaddress;

	@Column(name = "natureofbusiness")
	private String natureofbusiness;

	@Column(name = "purposeofloan")
	private String purposeofloan;

	@Column(name = "preferredcontactlocation")
	private String preferredcontactlocation;

	@Column(name = "officephonenumber")
	private String officephonenumber;

	@Column(name = "workemail")
	private String workemail;

	@Column(name = "workemailverification")
	private String workemailverification;

	@Column(name = "customer_consent")
	private String customer_consent;

	@Column(name = "filler1")
	private String filler1;

	@Column(name = "filler2")
	private String filler2;

	@Column(name = "filler3")
	private String filler3;

	@Column(name = "filler4")
	private String filler4;

	@Column(name = "filler5")
	private String filler5;

	@Column(name = "filler6")
	private String filler6;

	@Column(name = "filler7")
	private String filler7;

	@Column(name = "filler8")
	private String filler8;

	@Column(name = "filler9")
	private String filler9;

	@Column(name = "filler10")
	private String filler10;

	@Column(name = "officeorbusinessaddrline1")
	private String officeorbusinessaddrline1;

	@Column(name = "officeorbusinessaddrline2")
	private String officeorbusinessaddrline2;

	@Column(name = "officeorbusinessaddrline3")
	private String officeorbusinessaddrline3;

	@Column(name = "officeorbusinesspincode")
	private String officeorbusinesspincode;

	@Column(name = "officeorbusinesscity")
	public String officeorbusinesscity;

	@Column(name = "officeorbusinessstate")
	public String officeorbusinessstate;

	@Column(name = "officeorbusinessphoneno")
	private String officeorbusinessphoneno;

	@Column(name = "resiaddresstype")
	private String resiaddresstype;

	@Column(name = "aadhaaraddrline1")
	private String aadhaaraddrline1;

	@Column(name = "aadhaaraddrline2")
	private String aadhaaraddrline2;

	@Column(name = "aadhaaraddrline3")
	private String aadhaaraddrline3;

	@Column(name = "aadhaaraddrpincode")
	private String aadhaaraddrpincode;

	@Column(name = "aadhaaraddrcity")
	private String aadhaaraddrcity;

	@Column(name = "reffirstname")
	private String reffirstname;

	@Column(name = "refmiddlename")
	private String refmiddlename;

	@Column(name = "reflastname")
	private String reflastname;

	@Column(name = "refmobileno")
	private String refmobileno;

	@Column(name = "branchname")
	private String branchname;

	@Column(name = "accounttype")
	private String accounttype;

	@Column(name = "aadhaaraddrstate")
	private String aadhaaraddrstate;

	@Column(name = "txnid")
	private String txnid;

	@Column(name = "statusdesc")
	private String statusdesc;

	@Column(name = "returnurl")
	private String returnurl;

    @Column(name = "customermiddlename")
    private String customermiddlename;

    @Column(name = "aadhaarrefno")
    private String aadhaarrefno;

    @Column(name = "rrnno")
    private String rrnno;

    @Column(name = "vcipreferenceid")
    private String vcipreferenceid;

    @Column(name = "accountno")
    private String accountno;

    @Column(name = "customerid")
    private String customerid;

    @Column(name = "lgcode")
    private String lgcode;

    @Column(name = "smcode")
    private String smcode;

    @Column(name = "branchcode")
    private String branchcode;

    @Column(name = "secode")
    private String secode;

    @Column(name = "emi")
    private String emi;

    @Column(name = "loanamount")
    private String loanamount;

    @Column(name = "educationalqualification")
    private String educationalqualification;

    @Column(name = "processingfees")
    private String processingfees;

    @Column(name = "product")
    private String product;

    @Column(name = "rateofinterest")
    private String rateofinterest;

    @Column(name = "tenure")
    private String tenure;

    @Column(name = "yearatcurrentaddress")
    private String yearatcurrentaddress;


	@Column(name = "micrcode")
	private String micrcode;

	@Column(name = "salutation")
	private String salutation;

	@Column(name = "deviceid")
	private String deviceid;

	@Column(name = "acknowledgeid")
	private String ackid;
	
}
