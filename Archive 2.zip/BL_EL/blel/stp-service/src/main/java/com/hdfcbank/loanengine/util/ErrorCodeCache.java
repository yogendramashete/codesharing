package com.hdfcbank.loanengine.util;

import java.util.Map;

public class ErrorCodeCache {

	public static Map<String, String> errorCodes = null;

	public static String getErrorCode(String key) {
		if(errorCodes != null)
			return errorCodes.get(key);
		return null;
	}

	public static void setErrorCodes(Map<String, String> hm) {
		errorCodes = hm;
	}
	
	
	
}
