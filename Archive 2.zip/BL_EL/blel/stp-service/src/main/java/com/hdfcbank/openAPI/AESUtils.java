package com.hdfcbank.openAPI;

import java.io.UnsupportedEncodingException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.KeySpec;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.DecoderException;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.binary.Hex;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.hdfcbank.loanengine.domain.constant.AppConstants;


@Component
public class AESUtils {

	private static final Logger logger = LoggerFactory.getLogger(AESUtils.class);

	private final Cipher cipher;
	static int iterationCount = 1000;
	static int keySize = 128;
	String iv = AppConstants.AES_IV;
	//String salt = AppConstants.AES_SALT;

	public AESUtils() {
		this(keySize, iterationCount);
	}
	public String getkeyFromArn() {

		String saltKey = "";
		String keyid ="";
		String saltKeyId = "";
		try {
			String arn = System.getenv("KMS_RESOURCE_ARN");
			logger.info("arn :: "+arn);
			String[] arrOfStr = arn.split("/");
			for(int i = 0; i <= arrOfStr.length;i++) {
				keyid = arrOfStr[1];
			}
			saltKeyId = keyid.replace("-", "");
		}catch(Exception e) {
			e.printStackTrace();
		}
		return saltKeyId;
	}
	public AESUtils(int keySize, int iterationCount) {
		try {
			cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");

		} catch (NoSuchAlgorithmException e) {
			logger.info("Exception :: " + e);
			throw failure(e);
		} catch (NoSuchPaddingException e) {
			logger.info("Exception :: " + e);
			throw failure(e);
		}
	}

	public String encrypt(String plaintext) {
		String salt = getkeyFromArn();
		return encrypt(salt, iv, plaintext);
	}

	public String encrypt(String key, String iv, String plaintext) {
		try {
			//logger.info("iv: " + iv);
			byte[] encrypted = doFinal(Cipher.ENCRYPT_MODE, generateKey(key), iv, plaintext.getBytes("UTF-8"));
			return base64(encrypted);
		} catch (UnsupportedEncodingException e) {
			throw failure(e);
		}
	}

	public String encrypt(String key, String plaintext) {
		try {
			String[] array = key.split("\\|");
			key = array[0];
			iv = array[1];

			byte[] encrypted = doFinal(Cipher.ENCRYPT_MODE, generateKey(key), iv, plaintext.getBytes("UTF-8"));
			return base64(encrypted);
		} catch (UnsupportedEncodingException e) {
			throw failure(e);
		}
	}

	public String encrypt(String salt, String iv, String passphrase, String plaintext) {
		try {
			SecretKey key = generateKey(salt, passphrase);
			logger.info("encrypt key hex: " + hex(key.getEncoded()));
			byte[] encrypted = doFinal(Cipher.ENCRYPT_MODE, key, iv, plaintext.getBytes("UTF-8"));
			return base64(encrypted);
		} catch (UnsupportedEncodingException e) {
			throw failure(e);
		}
	}

	public String decrypt(String ciphertext) {
		String salt = getkeyFromArn();
		return decrypt(salt, iv, ciphertext);
	}

	public String decrypt(String key, String iv, String ciphertext) {
		try {
			byte[] decrypted = doFinal(Cipher.DECRYPT_MODE, generateKey(key), iv, base64(ciphertext));
			return new String(decrypted, "UTF-8");
		} catch (UnsupportedEncodingException e) {
			throw failure(e);
		}
	}

	public String decrypt(String key, String ciphertext) {
		try {
			String[] array = key.split("\\|");
			key = array[0];
			iv = array[1];
			byte[] decrypted = doFinal(Cipher.DECRYPT_MODE, generateKey(key), iv, base64(ciphertext));
			return new String(decrypted, "UTF-8");
		} catch (UnsupportedEncodingException e) {
			throw failure(e);
		} catch (Exception e) {
			throw e;
		}
	}

	public String decrypt(String salt, String iv, String passphrase, String ciphertext) {
		try {
			SecretKey key = generateKey(salt, passphrase);
			logger.info("decrypt key hex: " + hex(key.getEncoded()));
			byte[] decrypted = doFinal(Cipher.DECRYPT_MODE, key, iv, base64(ciphertext));
			return new String(decrypted, "UTF-8");
		} catch (UnsupportedEncodingException e) {
			throw failure(e);
		}
	}

	private byte[] doFinal(int encryptMode, SecretKey key, String iv, byte[] bytes) {
		try {
			cipher.init(encryptMode, key, new IvParameterSpec(hex(iv)));
			return cipher.doFinal(bytes);
		} catch (InvalidKeyException e) {
			logger.info("Exception ::" + e);
			throw failure(e);
		} catch (InvalidAlgorithmParameterException e) {
			logger.info("Exception ::" + e);
			throw failure(e);
		} catch (IllegalBlockSizeException e) {
			logger.info("Exception ::" + e);
			throw failure(e);
		} catch (BadPaddingException e) {
			logger.info("Exception ::" + e);
			throw failure(e);
		}
	}

	private SecretKey generateKey(String key) {
		return new SecretKeySpec(hex(key), "AES");
	}

	public String generateHexKey(String salt, String passphrase) {
		SecretKey key = generateKey(salt, passphrase);
		return hex(key.getEncoded());
	}

	private SecretKey generateKey(String salt, String passphrase) {
		SecretKey key = null;
		try {
			SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1");
			KeySpec spec = new PBEKeySpec(passphrase.toCharArray(), hex(salt), iterationCount, keySize);
			key = new SecretKeySpec(factory.generateSecret(spec).getEncoded(), "AES");
		} catch (NoSuchAlgorithmException e) {
			logger.info("Exception ::" + e);
			throw failure(e);
		} catch (InvalidKeySpecException e) {
			logger.info("Exception ::" + e);
			throw failure(e);
		}
		return key;
	}

	public static String base64(byte[] bytes) {
		return new String(Base64.encodeBase64(bytes));
	}

	public static byte[] base64(String str) {
		return Base64.decodeBase64(str.getBytes());
	}

	public static String hex(byte[] bytes) {
		return new String(Hex.encodeHex(bytes));
	}

	public static byte[] hex(String str) {
		try {
			return Hex.decodeHex(str.toCharArray());
		} catch (DecoderException e) {
			throw new IllegalStateException(e);
		}
	}

	private IllegalStateException failure(Exception e) {
		return new IllegalStateException(e);
	}

	public static void main(String[] args) throws Exception {
		// Snapwork+Source name+ destination name => SnapworkEMAEMA
		//System.out.println("enc data : " + new AESUtils().encrypt("9836993787"));
		System.out.println("dec data : line no 214 " + new AESUtils().decrypt(""));
		//		// String enc=new AESUtils().encrypt("");
		//		// System.out.println("enc data :: "+enc);

		/*
		 * String dec = new AESUtils().decrypt( "MCtQ9mRUuKr/Wm8kOYBMug==");
		 * 
		 * File newTextFile = new
		 * File("C:\\Users\\Admin\\Documents\\AutoCircle\\Test\\Ency\\thetextfile2.txt")
		 * ;
		 * 
		 * FileWriter fw = new FileWriter(newTextFile); fw.write(dec); fw.close();
		 */

//		List<String> data = new ArrayList<String>();
//		data.add("1qaWXttTHBftb1hpM8dkGd5AFXUMQO7ibiiq3/YQaAcIjo0+sjuhW+zM4jAdwpN2xx8bPGmP62m7ZgIJ7QQ+MDgHxG8ilg5Hz2QwcquG2BZHwwKsUtlyuOTrmDvT6NL1mZSNT5b9seAxb1Mvvk+Uu3rDZUNCaPhn0ZZt5XBlgD9+ij08+d+foBPAmZwX1J0dKrbnC+g0KBbHZtBc2/56L1MF0P7eqOtGdHCtrPD2aCMsd6pWm12KfVyLK8HUQiThZCyVdbyM067ZQHlYqwDeIFU0W26wMm0JthyXE2BfukqFX6F8BcKcHYPCzH6EqWIgl86cKuVUFInV9SJLaPsPpC9PoM8i3ic9OhDAsparQJYP+zfbnlnfe+fs6urcWNswVPd8Sh0aOF9IWNnrJHyl49amVueCE3HwuNyNlDqClQHjSYVOmYCA4hGtDEmdQAVFFiPm7QfLjmuFWuyoINFyN+Zt9a9Smh0yxyJATDEsfjZ1fNXxLEEkV92R6E3mfy4OTVribGAsA/7622qV/EChN3Mthbbxh2tRd/I5keW8i3SnpOZyFLQRw/Mj8+GQ+LOT+JZlvwVnCxavMcGDNLmWAP0jdrJp7JJelJWG5MZZlf70VpQEP+1EDKis4F/pMM5XqOIcZosbgmUSsFOqDB1u/gb+Kz9ik+ydRTg211pO8Cn/+xB/5uqlqmg8D/1AUA2Erm5A52KSXlcMlP+MlJV/G0UtG7sSAix1a8dkcDQzfRbWWCVtMb+dfGg9RAmA/A8J4Dnp1deAGXAIGqYW9zwitcgQ7QYUDHYPGySerhYPEsB6YxzEvdJ7c2PCHI671m3+0MEeYm/wBUJ3fCkhtcwsyitpr44mZT4vaHm93UBBwCnnhFf/vpTBGlSAky8I++ImZhg5kdplXNXZmLcFjR33rt3dnXlbGAV00IYUShKaJRksjJfoKPuDV2uc12ls0hH7vcj1R0ZpeBXy2kcClEzNIY4PmI0K6zlmkO6mFGo+vonYl3h/TRF6KUJ2vorLoCMZieJHZUwhepcMdGdB4X4VOfegtkHJ2n+TuRmTPJEuoTdly6errPWA0AYI13Td6nFLDghZg66loW0h4OIJ4F/8gRvtUVYXePh6A0x5Pt/iQErR/6d8fmZVOCT8AgrdpdpCAk62nSy/V3KZR7fYWX6yi/3s6Rx1KecnYzbmJXTd5ouJfieAgUr8rK1BYj8cER9BgkLUPRZScVaCYaAD3Zr0DE4PyskdN65YoA0hwVIwt/WqMiX2sqNQykeA8sYd60eHy8nIedJoLzP/wohHf/QvxAID5mYVZW8hb0e63yuaPdG+1SF5EwiIQEWKQNjcfIyyMXTvrtkWTSCMTsQP9Mp6mTDBt8ZJfhkrB516C1CllYs=");
//		for (String d : data) {
//			System.out.println("dec data : " + new AESUtils().decrypt(d));
			// System.out.println("dec data : " + new AESUtils().encrypt(d));
		}
}
