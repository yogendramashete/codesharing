package com.hdfcbank.loanengine.util;

import org.json.XML;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.stereotype.Component;

import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

@Component
public class JSonParser {

	static JSONObject jsonObject = null;

	public JSonParser() {
		jsonObject = new JSONObject();
	}

	public static JSONObject parseString(String param) {
		JSONObject jsonObject = null;
		JSONParser jsonParser = null;
		try {
			jsonParser = new JSONParser();
			if (param != null) {
				jsonObject = (JSONObject) jsonParser.parse(param);
			}
		} catch (Exception e) {
			e.printStackTrace();
			jsonObject = null;
		} finally {
			jsonParser = null;
		}
		return jsonObject;
	}
	/*
	 * @SuppressWarnings("unused") public static JSONObject XmltoJson(String
	 * response) throws Exception { org.json.JSONObject xmlJSONObj = null;
	 * JSONObject jsonObject = null; try { xmlJSONObj = XML.toJSONObject(response);
	 * String reb = xmlJSONObj.toString(4); jsonObject =
	 * JSonParser.parseString(xmlJSONObj.toString()); } catch (Exception e) {
	 * e.printStackTrace(); throw e; } return jsonObject; }
	 */

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static JSONObject getProperJson(JSONObject jsonObject) throws Exception {
		JSONObject newjsonObject = new JSONObject();
		try {
			Set<String> set = jsonObject.entrySet();
			Iterator it = set.iterator();
			while (it.hasNext()) {
				Map.Entry<String, String> entry = (Entry<String, String>) it.next();
				String paramName = entry.getKey();
				String paramValue = entry.getValue();
				newjsonObject.put(paramName, "<![CDATA[" + paramValue + "]]>");
			}
		} catch (Exception e) {
			e.printStackTrace();
			return jsonObject;
		}
		return newjsonObject;
	}

	public JSONObject printJsonObject(JSONObject jsonObj) {

		for (Object key : jsonObj.keySet()) {
			// based on you key types
			String keyStr = (String) key;
			Object keyvalue = jsonObj.get(keyStr);
			// Print key and value
//	          Logger.info("key: "+ keyStr + " value: " + keyvalue);
			jsonObject.put(keyStr, keyvalue);
			// for nested objects iteration if required
			if (keyvalue instanceof JSONObject)
				printJsonObject((JSONObject) keyvalue);
		}
		return jsonObject;
	}

	@SuppressWarnings("unchecked")
	public JSONObject getBREData(String res) {
		JSONObject obj = new JSONObject();
		String arrayObj = "";
		try {

			JSonParser jSonParser = new JSonParser();
			JSONObject jsonObject = jSonParser.parseString(res);
			JSONObject jsonObject2 = new JSonParser().printJsonObject(jsonObject);
			JSONArray array = jsonObject2.get("item") == null ? new JSONArray() : (JSONArray) jsonObject2.get("item");
			for (int i = 0; i < array.size(); i++) {
				arrayObj = array.get(i).toString();
				if (arrayObj.contains("FINAL_ELIG")) {
					String arrayData[] = arrayObj.split("~");
					obj.put("FINAL_ELIG", arrayData[1]);
				} else if (arrayObj.contains("STP_WFLW")) {
					String arrayData[] = arrayObj.split("~");
					obj.put("STPPASS", arrayData[1]);
				} else if (arrayObj.contains("BUREU_ELIG")) {
					String arrayData[] = arrayObj.split("\\|");
					if (arrayData[1].contains("BUREU_INC")) {
						String arrayInData[] = arrayData[1].split("~");
						obj.put("BUREU_INC", arrayInData[1]);
					}

				} else if (arrayObj.contains("PERF_INC")) {
					String arrayData[] = arrayObj.split("\\|");
					if (arrayData[1].contains("PERF_INC")) {
						String arrayInData[] = arrayData[1].split("~");
						obj.put("PERF_INC", arrayInData[1]);
					}
				} else if (arrayObj.contains("FILLER5")) {
					String arrayData[] = arrayObj.split("~");
					obj.put("FILLER5", arrayData[1]);
				} else if (arrayObj.contains("FILLER2")) {
					String arrayData[] = arrayObj.split("~");
					obj.put("FILLER2", arrayData[1]);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return obj;
	}

	public static void main(String[] args) {
		try {
			String responseObj = "";
			responseObj = responseObj.replaceAll("S:", "").replaceAll("ns11:", "");
			org.json.JSONObject xmlTojsonObject = XML.toJSONObject(responseObj);
			org.json.JSONObject envelopeObj = (org.json.JSONObject) xmlTojsonObject.get("Envelope");
			org.json.JSONObject bodyObj = (org.json.JSONObject) envelopeObj.get("Body");
			org.json.JSONObject getOfferResponseObj = (org.json.JSONObject) bodyObj.get("getOfferResponse");
			org.json.JSONObject returnObj = (org.json.JSONObject) getOfferResponseObj.get("return");
			org.json.JSONObject responseBREObj = (org.json.JSONObject) returnObj.get("response");
			org.json.JSONObject hdfcOutObj = (org.json.JSONObject) responseBREObj.get("HDFCOUT");
			org.json.JSONObject fullProcessObj = (org.json.JSONObject) hdfcOutObj.get("FULLPROCESS");
			org.json.JSONObject bureauScoringResultTbl = (org.json.JSONObject) fullProcessObj
					.get("BUREAUSCORINGRESULTTABLE");
			System.out.println("bureauScoringResultTbl :: " + bureauScoringResultTbl);
			org.json.JSONObject json = new org.json.JSONObject(bureauScoringResultTbl.toString());
			System.out.println("json :: " + json);

			JSONObject test = new JSonParser().getBREData(json.toString());
			System.out.println("test :: " + test);
			org.json.JSONObject bre3CallObj = new org.json.JSONObject(test);
			int perfInc = Integer
					.parseInt(bre3CallObj.get("PERF_INC") == null ? "0" : bre3CallObj.get("PERF_INC").toString());
			int bureuInc = Integer
					.parseInt(bre3CallObj.get("BUREU_INC") == null ? "0" : bre3CallObj.get("BUREU_INC").toString());
			String filler14 = "0";
			if (perfInc > bureuInc) {
				filler14 = String.valueOf(perfInc);
			} else {
				filler14 = String.valueOf(bureuInc);
			}
			System.out.println("filler14 :: " + filler14);
			// new CsvFileGeneratorImpl().hdfcOutFieldsCsvGenerator("7021767777", "123456",
			// "BRE", xml);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
