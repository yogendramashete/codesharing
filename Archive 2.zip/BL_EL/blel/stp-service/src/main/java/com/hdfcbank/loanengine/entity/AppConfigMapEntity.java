package com.hdfcbank.loanengine.entity;

import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.time.OffsetDateTime;
@Entity
@Table(name = "appconfigmap")
@NoArgsConstructor
@Getter
@Data
public class AppConfigMapEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name =  "srno")
	private Integer srno;
	
	@Column(name =  "channelid")
	private String channelid;
	
	@Column(name = "dataname")
	private String dataname;
	
	@Column(name = "datakey")
	private String datakey;
	
	@Column(name = "datavalue")
	private String datavalue;
	
	@Column(name = "isactive")
	private String isactive;
	
	@Column(name = "datecreated")
	private OffsetDateTime datecreated;
	
	@Column(name = "datemodified")
	private OffsetDateTime datemodified;

	public AppConfigMapEntity(String channelid, String dataname, String datakey, String datavalue, String isactive, 
			OffsetDateTime datecreated, OffsetDateTime datemodified) {
		super();
		
		this.channelid = channelid;
		this.dataname = dataname;
		this.datakey = datakey;
		this.datavalue = datavalue;
		this.isactive = isactive;
		this.datecreated = datecreated;
		this.datemodified = datemodified;
	}
}
