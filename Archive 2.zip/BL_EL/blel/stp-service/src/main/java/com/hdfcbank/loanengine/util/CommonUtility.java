package com.hdfcbank.loanengine.util;

import com.hdfcbank.loanengine.domain.constant.AppConstants;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import java.io.*;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.nio.file.DirectoryNotEmptyException;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Paths;
import java.security.SecureRandom;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
 
 
@Service
public class CommonUtility {
	public final static Logger logger = LoggerFactory.getLogger(CommonUtility.class);

	@Autowired
	RedisUtils redisUtils;

	 

	static SecureRandom random = new SecureRandom();
	private char[] buf;
	private final int length = 20;

	@SuppressWarnings("unused")
	public  CommonUtility() {
		if (length < 1)
			throw new IllegalArgumentException("length < 1: " + length);
		buf = new char[length];
	}


	public String getUniqueReqId() {
		char[] symbols;
		StringBuilder tmp = new StringBuilder();
		for (char ch = '0'; ch <= '9'; ++ch)
			tmp.append(ch);
		for (char ch = 'A'; ch <= 'Z'; ++ch)
			tmp.append(ch);
		symbols = tmp.toString().toCharArray();
		for (int idx = 0; idx < buf.length; ++idx)
			buf[idx] = symbols[random.nextInt(symbols.length)];
		return new String(buf);
	}

	public String genRandomNumber(int length) {
		char[] digits = new char[length];
		digits[0] = (char) (random.nextInt(9) + '1');
		for (int i = 1; i < length; i++) {
			digits[i] = (char) (random.nextInt(10) + '0');
		}

		return new String(digits);
	}

	public HashMap<String, String> getParsingDetailsfrmString(String message) {
		HashMap<String, String> hashMap = new HashMap<String, String>();
		try {
			String arr[] = message.split("&");
			for (int i = 0; i < arr.length; i++) {
				String data = arr[i];
				String dataArray[] = data.split("=");
				if (dataArray.length > 1) {
					hashMap.put(dataArray[0], dataArray[1]);
				} else {
					hashMap.put(dataArray[0], "");
				}
			}

		} catch (Exception e) {
			logger.info("Exception :: " + CommonUtility.getPrintStackTrace(e));
		}
		return hashMap;
	}

	public static String changeDateFormat(String dateValue, String format, String targetDtFormat) {
		String formattedDate = "";
		try {

			DateFormat originalFormat = new SimpleDateFormat(format);
			DateFormat targetFormat = new SimpleDateFormat(targetDtFormat);
			Date date = originalFormat.parse(dateValue);
			formattedDate = targetFormat.format(date);
		} catch (Exception e) {
			return dateValue;
		}
		return formattedDate;

	}
	
	public static String changeDateFormat(String dateValue, String format) {
		String formattedDate = "";
		try {
		   String targetDtFormat = "dd/MM/yyyy HH:mm:ss";
			DateFormat originalFormat = new SimpleDateFormat(format);
			DateFormat targetFormat = new SimpleDateFormat(targetDtFormat);
			Date date = originalFormat.parse(dateValue+" 00:00:00");
			formattedDate = targetFormat.format(date);
		} catch (Exception e) {
			return dateValue;
		}
		return formattedDate;

	}

	public LocalDate getinterestStartDate() {
		LocalDate date = LocalDate.now();
		//	date = date.plusDays(46);
		int day = 0;
		try {
			System.out.println("get day of month:" + date.getDayOfMonth());
			if (date.getDayOfMonth() < 7) {
				date = date.plusMonths(1);
				date = date.plusDays(Long.valueOf(7) - date.getDayOfMonth());
			} else if (date.getDayOfMonth() > 6 && date.getDayOfMonth() < 21) {
				date = date.plusMonths(1);
				date = date.minusDays(date.getDayOfMonth() - Long.valueOf(7));
			} else {
				date = date.plusMonths(2).withDayOfMonth(5);
			}
			logger.info("emi start date :" + date);

		} catch (Exception e) {
			logger.info("Exception :: " + e.getMessage());
		}
		return date;
	}

	public boolean isWithInDueDate(String mobileNo, String tranRefNumber) {
		LocalDate date = LocalDate.now();
		//	date = date.plusDays(46);
		boolean isWithInDueDt = false;
		try {
			System.out.println("isWithInDueDate : " + date.getDayOfMonth());
			if (date.getDayOfMonth() < 7) {
				date = date.plusMonths(1);
				date = date.plusDays(Long.valueOf(7) - date.getDayOfMonth());
				isWithInDueDt = true;
			} else if (date.getDayOfMonth() > 6 && date.getDayOfMonth() < 21) {
				date = date.plusMonths(1);
				date = date.minusDays(date.getDayOfMonth() - Long.valueOf(7));
				isWithInDueDt = true;
			} else {
				date = date.plusMonths(2).withDayOfMonth(5);
				isWithInDueDt = false;
			}
			logger.info("emi start date :" + date);
//			redisUtils.set(RedisConstants.DIGITAL_DISBURSEMENT_DUEDATE + mobileNo + RedisConstants.US + tranRefNumber,date.toString());
		} catch (Exception e) {
			logger.info("Exception :: " + e.getMessage());
		}
		return isWithInDueDt;
	}

 
	public String Panreqverification(String key) {
		logger.info("inside Panreqverification ...");
		String value = "";
		try {
			HashMap<String, String> panvalidation = new HashMap<String, String>();
			panvalidation.put("1", "Success");
			panvalidation.put("2", "System error");
			panvalidation.put("3", "Authentication failure");
			panvalidation.put("4", "User not authorized");
			panvalidation.put("5", "No PANs entered");
			panvalidation.put("6", "User validity has expired");
			panvalidation.put("7", "Number of PANs exceeds the limit (5)");
			panvalidation.put("8", "Not enough balance");
			panvalidation.put("9", "Not an HTTPs request");
			panvalidation.put("10", "POST method method not used ");
			panvalidation.put("99", "In Case of any kind of error");
			panvalidation.put("E", "EXISTING AND VALID");
			panvalidation.put("F", "Marked as Fake");
			panvalidation.put("X", "Marked as Deactivated");
			panvalidation.put("D", "Deleted");
			panvalidation.put("N", "Record (PAN) Not Found in ITD Database/Invalid PAN");
			panvalidation.put("EA", "Existing and Valid but event marked as “Amalgamation” in ITD database");
			panvalidation.put("EC", "Existing and Valid but event marked as “Acquisition” in ITD database");
			panvalidation.put("ED", "Existing and Valid but event marked as “Death” in ITD database");
			panvalidation.put("EI", "Existing and Valid but event marked as “Dissolution” in ITD database");
			panvalidation.put("EL", "Existing and Valid but event marked as “Liquidated” in ITD database");
			panvalidation.put("EM", "Existing and Valid but event marked as “Merger” in ITD database");
			panvalidation.put("EP", "Existing and Valid but event marked as “Partition” in ITD database");
			panvalidation.put("ES", "Existing and Valid but event marked ");
			panvalidation.put("EU", "Existing and Valid but event marked as “Under Liquidation” in ITD database");

			value = panvalidation.get("EU");
			logger.info(value);

		} catch (Exception e) {
			logger.info("Exception :: " + CommonUtility.getPrintStackTrace(e));
		}
		return value;

	}

	public static String getDate(String pattern) {

		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);

		String date = simpleDateFormat.format(new Date());
		return date;

	}

	public static String formatDate(String date, String oldPattern, String newPattern) {

		DateTimeFormatter oldPatternDTFObj = DateTimeFormatter.ofPattern(oldPattern);
		DateTimeFormatter newPatternDTFObj = DateTimeFormatter.ofPattern(newPattern);
		LocalDate datetime = LocalDate.parse(date, oldPatternDTFObj);
		String convertedDt = datetime.format(newPatternDTFObj);

		return convertedDt;
	}
	
	public  static String formatDate(String date) {
		 String newPattern = "dd/MM/yyyy HH:mm:ss";
		if(StringUtils.isBlank(date)) {
			return "";
		}
         String oldPattern = "ddMMyyyy HH:mm:ss";
        
         DateTimeFormatter oldPatternDTFObj = DateTimeFormatter.ofPattern(oldPattern);
         DateTimeFormatter newPatternDTFObj = DateTimeFormatter.ofPattern(newPattern);
         LocalDateTime datetime = LocalDateTime.parse(date+" 00:00:00", oldPatternDTFObj);
         String convertedDt = datetime.format(newPatternDTFObj);

		return convertedDt;
	}
	
	public  static String formatDate(String date,String oldPattern) {
		 String newPattern = "dd/MM/yyyy HH:mm:ss";
		if(StringUtils.isBlank(date)) {
			return "";
		}
       
        DateTimeFormatter oldPatternDTFObj = DateTimeFormatter.ofPattern(oldPattern);
        DateTimeFormatter newPatternDTFObj = DateTimeFormatter.ofPattern(newPattern);
        LocalDateTime datetime = LocalDateTime.parse(date+" 00:00:00", oldPatternDTFObj);
        String convertedDt = datetime.format(newPatternDTFObj);

		return convertedDt;
	}

	public static String getTimeStamp() {
		Date date = new Date();
		String timeStamp = String.valueOf(date.getTime());
		// System.out.println("timeStamp :: " + timeStamp);
		return timeStamp;
	}

	public static String getPrintStackTrace(Throwable e) {
		final StringWriter sw = new StringWriter();
		final PrintWriter pw = new PrintWriter(sw);
		e.printStackTrace(pw);
		return sw.toString();
	}

	public static String fetchPinCodeFromAddress(String address) {
		String zip = "";
		Pattern zipPattern = Pattern.compile("(\\d{6})");
		Matcher zipMatcher = zipPattern.matcher(address);
		if (zipMatcher.find()) {
			zip = zipMatcher.group(1);
		}
		return zip;
	}

	public static String getGender(String salutation) {
		String gender = "";
		if (StringUtils.isNotBlank(salutation)) {
			if (salutation.equalsIgnoreCase("Mr")) {
				gender = "M";
			} else if (salutation.equalsIgnoreCase("Ms")) {
				gender = "F";
			} else if (salutation.equalsIgnoreCase("Mrs")) {
				gender = "F";
			} else if (salutation.equalsIgnoreCase("Mx")) {
				gender = "T";
			}
		}
		return gender;
	}

	public static String getGenderInitial(String gender) {
		if (gender.equalsIgnoreCase("Male")) {
			gender = "M";
		} else if (gender.equalsIgnoreCase("Female")) {
			gender = "F";
		} else if (gender.equalsIgnoreCase("Transgender")) {
			gender = "T";
		}
		return gender;
	}

	public String generateRandomNo(int length) {
		String randomNo = RandomStringUtils.randomAlphanumeric(length).toUpperCase();
		return randomNo;
	}

	public String getTimeDifference(String time1, String time2) {
		String timeDifference = "";
		try {
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
			Date date1 = format.parse(time1);
			Date date2 = format.parse(time2);
			long difference = (date2.getTime() - date1.getTime()) / 1000;
			timeDifference = String.valueOf(difference);
		} catch (Exception exe) {

			logger.info("getTimeDifference Exception :: " + CommonUtility.getPrintStackTrace(exe));
		}
		return timeDifference;
	}

	public long getTimeDiffLong(String time1, String time2) {
		long timeDifference = 0;
		try {
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
			Date date1 = format.parse(time1);
			Date date2 = format.parse(time2);
			timeDifference = (date2.getTime() - date1.getTime()) / 1000;
		} catch (Exception exe) {
			logger.info("getTimeDifference Exception :: " + CommonUtility.getPrintStackTrace(exe));
		}
		return timeDifference;
	}

	public static String genUserOtp(int length) {
		char[] digits = new char[length];
		digits[0] = (char) (random.nextInt(9) + '1');
		for (int i = 1; i < length; i++) {
			digits[i] = (char) (random.nextInt(10) + '0');
		}
		return new String(digits);
	}

	public static String getYearMinus(int yearsToSubtract) {
		String changedYear = "";
		try {
			LocalDate localDateObj = LocalDate.now();
			localDateObj = localDateObj.minusYears(yearsToSubtract);
			changedYear = String.valueOf(localDateObj.getYear());
		} catch (Exception e) {
			logger.info("Exception :: " + CommonUtility.getPrintStackTrace(e));
		}
		return changedYear;
	}

	 

	public String readImageFromPath(String imagePath) {
		String base64Image = "";
		File file = new File(imagePath);
		try (FileInputStream imageInFile = new FileInputStream(file)) {
			// Reading a Image file from file system
			byte imageData[] = new byte[(int) file.length()];
			long bytesLength = imageInFile.read(imageData);
			logger.info("readImageFromPath bytesLength :: " + bytesLength);
			base64Image = Base64.getEncoder().encodeToString(imageData);
		} catch (FileNotFoundException e) {
			logger.info("Image not found" + e);
		} catch (IOException ioe) {
			logger.info("Exception while reading the Image " + ioe);
		}
		return base64Image;
	}

	public String readImageFromPath(File file) {
		String base64Image = "";
		try (FileInputStream imageInFile = new FileInputStream(file)) {
			// Reading a Image file from file system
			byte imageData[] = new byte[(int) file.length()];
			long bytesLength = imageInFile.read(imageData);
			logger.info("readImageFromPath bytesLength :: " + bytesLength);
			base64Image = Base64.getEncoder().encodeToString(imageData);
		} catch (FileNotFoundException e) {
			logger.info("Image not found" + e);
		} catch (IOException ioe) {
			logger.info("Exception while reading the Image " + ioe);
		}
		return base64Image;
	}

	public void deleteFileFromPath(String path) {
		try {
			Files.delete(Paths.get(path));
		} catch (NoSuchFileException x) {
			logger.info("%s: no such" + " file or directory%n", path);
		} catch (DirectoryNotEmptyException x) {
			logger.info("%s not empty%n", path);
		} catch (IOException x) {
			// File permission problems are caught here.
			logger.info("deleteFileFromPath IOException " + getPrintStackTrace(x));
		}
	}


	public static double getIntrestRate(double loanAmt, double emiAmt, double tenure) {
		double intrestRate = 0;
		try {
			intrestRate = loanAmt * emiAmt * tenure / 100;

		} catch (Exception e) {
			logger.info("Exception :: " + CommonUtility.getPrintStackTrace(e));
		}
		return intrestRate;
	}

 
	public int getDateDaysDifference(String vcipLastDate) {
		int dateDaysDifference = 0;
		try {
			LocalDate currentDate = LocalDate.now();
			LocalDate vcipLastDtObj = LocalDate.parse(vcipLastDate);
			Period period = Period.between(vcipLastDtObj, currentDate);
			dateDaysDifference = Math.abs(period.getDays());
			logger.info("currentDate :: " + currentDate + " vcipLastDate :: " + vcipLastDate + " dateDaysDifference:: " + dateDaysDifference);
		} catch (Exception e) {
			logger.info("getDateDaysDifference Exception:: " + CommonUtility.getPrintStackTrace(e));
		}
		return dateDaysDifference;
	}
 
	public String getIpAddress(HttpServletRequest request) {

		final String LOCALHOST_IPV4 = "127.0.0.1";
		final String LOCALHOST_IPV6 = "0:0:0:0:0:0:0:1";

		String ipAddress = request.getHeader("X-Forwarded-For");
		logger.info("ipAddress X-Forwarded-For:: "+ipAddress);
		if(StringUtils.isEmpty(ipAddress) || "unknown".equalsIgnoreCase(ipAddress)) {
			ipAddress = request.getHeader("Proxy-Client-IP");
		}

		if(StringUtils.isEmpty(ipAddress) || "unknown".equalsIgnoreCase(ipAddress)) {
			ipAddress = request.getHeader("WL-Proxy-Client-IP");
		}

		if(StringUtils.isEmpty(ipAddress) || "unknown".equalsIgnoreCase(ipAddress)) {
			ipAddress = request.getRemoteAddr();
			logger.info("ipAddress remote:: "+ipAddress);
			if(LOCALHOST_IPV4.equals(ipAddress) || LOCALHOST_IPV6.equals(ipAddress)) {
				try {
					InetAddress inetAddress = InetAddress.getLocalHost();
					ipAddress = inetAddress.getHostAddress();
				} catch (UnknownHostException e) {
					e.printStackTrace();
				}
			}
		}

		if(!StringUtils.isEmpty(ipAddress)&& ipAddress.length() > 15 && ipAddress.indexOf(",") > 0) {
			ipAddress = ipAddress.substring(0, ipAddress.indexOf(","));
			logger.info("ipAddress:: "+ipAddress);
		}
		return ipAddress;
	}
	
	public String getBureauStatus(String status) {
		String returnStatus = "";
		try {
			switch (1) {
			case 1:
				if (status.equals("-1")) {
					returnStatus = "SUCCESS";
					break;
				}
			case 2:
				if (status.equals("-2")) {
					returnStatus = "ERROR";
					break;
				}
			case 3:
				if (status.equals("-3")) {
					returnStatus = "BUREAU-ERROR";
					break;
				}
			case 4:
				if (status.equals("-4")) {
					returnStatus = "NO-MATCH";
					break;
				}
			case 5:
				if (status.equals("END-OF-TXN")) {
					returnStatus = "SUCCESS";
					break;
				}
			default:
				returnStatus = status;
				break;
			}
		} catch (Exception e) {
			
		}
		return returnStatus;
	}

	public String returnBureauStatus(String status) {
		String returnStatus = "";
		try {
			switch (1) {
			case 1:
				if (status.equals("-1")) {
					returnStatus = "000";
					break;
				}
			case 2:
				if (status.equals("-2")) {
					returnStatus = "000";
					break;
				}
			case 3:
				if (status.equals("-3")) {
					returnStatus = "000";
					break;
				}
			case 4:
				if (status.equals("-4")) {
					returnStatus = "000";
					break;
				}
			case 5:
				if (status.equals("END-OF-TXN")) {
					returnStatus = "000";
					break;
				}
			default:
				returnStatus = "001";
				break;
			}

		} catch (Exception e) {
			logger.info("Exception :: "+CommonUtility.getPrintStackTrace(e));
		}
		return returnStatus;
	}
	
	
	public static int ageCalculator(String dob) throws ParseException {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern(AppConstants.DATE_FMT_ddMMyyyy2);
		LocalDate date1 = LocalDate.parse(dob, formatter);
		LocalDate today = LocalDate.now();
		LocalDate birthday = LocalDate.of(date1.getYear(), date1.getMonth(), date1.getDayOfMonth());
		Period period = Period.between(birthday, today);
		return period.getYears();
	}
	
	public static void main(String[] args) {
		System.out.println("converte date :"+formatDate("10122020", "ddMMyyyy HH:mm:ss"));
		
	}
}