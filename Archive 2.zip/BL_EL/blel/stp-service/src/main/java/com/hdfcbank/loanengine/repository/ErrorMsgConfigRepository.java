package com.hdfcbank.loanengine.repository;

import com.hdfcbank.loanengine.entity.ErrorMsgConfigEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ErrorMsgConfigRepository extends JpaRepository<ErrorMsgConfigEntity, Integer> {

    ErrorMsgConfigEntity findByBackenderrorcodeAndStepname(String backenderrorcode, String stepname);
}
