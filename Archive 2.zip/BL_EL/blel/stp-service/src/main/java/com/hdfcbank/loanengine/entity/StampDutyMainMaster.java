package com.hdfcbank.loanengine.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the stamp_duty_main_master database table.
 * 
 */
@Entity
@Table(name="stamp_duty_main_master")
@NamedQuery(name="StampDutyMainMaster.findAll", query="SELECT s FROM StampDutyMainMaster s")
@NoArgsConstructor
@AllArgsConstructor
@Data
public class StampDutyMainMaster implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private Integer id;

	private String car;

	@Column(name="is_active")
	private String isActive;

	private String isdetailmstavailable;

	private String sdtype;

	private String state;

	private String twl;
}