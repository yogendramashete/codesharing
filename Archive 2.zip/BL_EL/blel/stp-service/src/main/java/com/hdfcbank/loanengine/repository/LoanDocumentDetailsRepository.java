package com.hdfcbank.loanengine.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.hdfcbank.loanengine.entity.LoanDocumentDetailsEntity;

@Repository
public interface LoanDocumentDetailsRepository extends JpaRepository<LoanDocumentDetailsEntity, Integer>{

	List<LoanDocumentDetailsEntity> findByBankjourneyidAndTxnsrno(String bankJourneyId, Integer txnSrNo);
}
