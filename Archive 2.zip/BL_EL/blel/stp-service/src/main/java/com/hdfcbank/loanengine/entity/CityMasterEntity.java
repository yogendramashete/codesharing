package com.hdfcbank.loanengine.entity;

import java.time.OffsetDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "bre_city_master")
@NoArgsConstructor
@Getter
@Data
public class CityMasterEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name =  "srno")
	private Integer srno;
	
	@Column(name ="city_id")
	public String cityid;
	@Column(name ="city_name")
	public String cityname;
	@Column(name ="state_id")
	public Integer stateid;
	@Column(name ="state")
	public String state;
	
}
