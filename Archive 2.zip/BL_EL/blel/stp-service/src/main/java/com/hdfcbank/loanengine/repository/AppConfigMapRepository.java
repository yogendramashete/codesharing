package com.hdfcbank.loanengine.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.hdfcbank.loanengine.entity.AppConfigMapEntity;

@Repository
public interface AppConfigMapRepository extends JpaRepository<AppConfigMapEntity, Integer>{

	List<AppConfigMapEntity> findByChannelidAndDatanameAndIsactive(String ChannelId, String dataname, String isactive);

}
