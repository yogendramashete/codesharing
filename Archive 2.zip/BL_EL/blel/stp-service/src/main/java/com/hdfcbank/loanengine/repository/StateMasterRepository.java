package com.hdfcbank.loanengine.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.hdfcbank.loanengine.entity.StateMasterEntity;

@Repository
public interface StateMasterRepository extends JpaRepository<StateMasterEntity, Integer> {
//	@Query("select state_id from bre_state_master where state_name = ?1")
    Optional<StateMasterEntity> findBystate(String stateName);
}
