package com.hdfcbank.loanengine.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.hdfcbank.loanengine.entity.LoanAppOffferDetails;

@Repository
public interface LoanAppOfferRepository extends JpaRepository<LoanAppOffferDetails, Integer>{
	LoanAppOffferDetails findBybankjourneyid(Long bankJourneyId);

	LoanAppOffferDetails findByBankjourneyidAndOfferstage(Long bankJourneyId, String offerstage);
}
