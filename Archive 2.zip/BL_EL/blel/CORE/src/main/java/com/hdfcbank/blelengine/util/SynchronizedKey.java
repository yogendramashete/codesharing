package com.hdfcbank.blelengine.util;



import java.util.Date;


public class SynchronizedKey {
	byte[] seedSkey;
	String keyIdentifier;
	Date seedCreationDate;

	public SynchronizedKey(final byte[] seedSkey, final String keyIdentifier, final Date seedCreationDate) {
		this.seedSkey = seedSkey;
		this.keyIdentifier = keyIdentifier;
		this.seedCreationDate = seedCreationDate;
	}

	public String getKeyIdentifier() {
		return this.keyIdentifier;
	}

	public Date getSeedCreationDate() {
		return this.seedCreationDate;
	}

	public byte[] getSeedSkey() {
		return this.seedSkey;
	}
}
