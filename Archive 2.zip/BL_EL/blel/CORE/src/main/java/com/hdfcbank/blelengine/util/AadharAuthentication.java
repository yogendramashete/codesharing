package com.hdfcbank.blelengine.util;

import org.apache.commons.lang3.StringUtils;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class AadharAuthentication {

	public final static Logger logger = LoggerFactory.getLogger(AadharAuthentication.class);

	@Autowired
	OtpEkyc otpEkyc;

	@Value("${UIDAI_CERTIFICATE_PATH}")
	String UIDAI_CERTIFICATE_PATH;

	public String processAadharAuthRequest(final String otp, final String timestamp) {
		
		logger.info("processAadharAuthRequest :: " + "otp :: " + otp + " timestamp :: " + timestamp + " "
				+ UIDAI_CERTIFICATE_PATH);
		String response = "";
		final JSONObject json = new JSONObject();
		try {
			if (StringUtils.isNotBlank((CharSequence) otp) && StringUtils.isNotBlank((CharSequence) timestamp)) {
				response = otpEkyc.pidGeneration(timestamp, otp, UIDAI_CERTIFICATE_PATH);
			} else {
				final String errorMsg = "Invalid Request Parameters.";
				json.put("Msg", (Object) errorMsg);
				response = json.toString();
			}
			System.out.println("Aadhar OTP Authentication Backend Response :" + response);
		} catch (Exception exe) {
			//exe.printStackTrace();
			logger.info("Exception ::",exe);
		}
		return response;
	}

}
