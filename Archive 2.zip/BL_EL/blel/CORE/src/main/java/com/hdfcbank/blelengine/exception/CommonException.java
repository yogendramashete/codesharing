package com.hdfcbank.blelengine.exception;

import java.io.PrintWriter;
import java.io.StringWriter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hdfcbank.blelengine.util.PropertyManager;

@Service
public class CommonException {

	private static Logger logger = LoggerFactory.getLogger(CommonException.class);

	@Autowired
	PropertyManager prop;
	
	
	public String getPrintStackTrace(Throwable e) {
		final StringWriter sw = new StringWriter();
		final PrintWriter pw = new PrintWriter(sw);
		e.printStackTrace(pw);
		logger.error(sw.toString());
		return sw.toString();
	}
	
	public void printStackTraceForDAO(Throwable e) throws Exception {
		String errorcode = prop.getProperty("exception.exception");

		final StringWriter sw = new StringWriter();
		final PrintWriter pw = new PrintWriter(sw);
		e.printStackTrace(pw);
		logger.error(e.toString());
		throw new Exception(errorcode);

	}
	
	public String getPrintStackTraceForEncryption(Throwable e) {
		final StringWriter sw = new StringWriter();
		final PrintWriter pw = new PrintWriter(sw);
		e.printStackTrace(pw);
		logger.error(sw.toString());
		return sw.toString();
	}
	

}
