package com.hdfcbank.blelengine.openAPI;

import com.hdfcbank.blelengine.constants.AppConstants;
import lombok.extern.log4j.Log4j2;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;

@Log4j2
public class RSAEncrypterDecrypter {
	//private static final String RSA_ECB_PKCS1PADDING = "RSA/ECB/PKCS1Padding";
	private static final String RSA = "RSA";

	/**
	 * Encrypt data using RSA/ECB/PKCS1Padding
	 * @param data to be encrypted
	 * @param key key used for encryption
	 * @return encrypted result
	 */
	public byte[] encrypt(byte[] data, PublicKey key) {
		byte[] encryptedValue = null;
		try {
			Cipher cipher = Cipher.getInstance(AppConstants.RSA_ECB_PKCS1PADDING);
			cipher.init(Cipher.ENCRYPT_MODE,key);
			encryptedValue = cipher.doFinal(data);
		}
		catch(NoSuchAlgorithmException exp) {
			//TODO handle exception
			//exp.printStackTrace();
			log.info("NoSuchAlgorithmException ::" + exp);
		}
		catch(NoSuchPaddingException exp) {
			//TODO handle exception
			//exp.printStackTrace();
			log.info("NoSuchPaddingException ::" + exp);
		}
		catch(IllegalBlockSizeException exp) {
			//TODO handle exception
			//exp.printStackTrace();
			log.info("IllegalBlockSizeException ::" + exp);
		}
		catch(BadPaddingException exp) {
			//TODO handle exception
			//exp.printStackTrace();
			log.info("BadPaddingException ::" + exp);
		}
		catch(InvalidKeyException exp) {
			//TODO handle exception
			//exp.printStackTrace();
			log.info("InvalidKeyException ::" + exp);
		}
		return encryptedValue;
	}
	
	/**
	 * Decrypt data using RSA/ECB/PKCS1Padding 
	 * @param data to be decrypted
	 * @param key key used for decryption
	 * @return decrypted result
	 */
	public byte[] decrypt(byte[] data, PrivateKey key) {
		byte[] decryptedValue = null;
		try {
			Cipher cipher = Cipher.getInstance(AppConstants.RSA_ECB_PKCS1PADDING);
			cipher.init(Cipher.DECRYPT_MODE, key);
			decryptedValue = cipher.doFinal(data);
		}
		catch(NoSuchAlgorithmException exp) {
			//TODO handle exception
			//exp.printStackTrace();
			log.info("NoSuchAlgorithmException ::" + exp);
		}
		catch(NoSuchPaddingException exp) {
			//TODO handle exception
			//exp.printStackTrace();
			log.info("NoSuchPaddingException ::" + exp);
		}
		catch(IllegalBlockSizeException exp) {
			//TODO handle exception
			//exp.printStackTrace();
			log.info("IllegalBlockSizeException ::" + exp);
		}
		catch(BadPaddingException exp) {
			//TODO handle exception
			//exp.printStackTrace();
			log.info("BadPaddingException ::" + exp);
		}
		catch(InvalidKeyException exp) {
			//TODO handle exception
			//exp.printStackTrace();
			log.info("InvalidKeyException ::" + exp);
		}
		return decryptedValue;
	}	
	
}
