package com.hdfcbank.blelengine.util;

import java.security.MessageDigest;

import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Component;

@Log4j2
@Component
public class HashGenerator {
	public byte[] generateSha256Hash(final byte[] message) {
		final String algorithm = "SHA-256";
		final String SECURITY_PROVIDER = "BC";
		byte[] hash = null;
		try {
			final MessageDigest digest = MessageDigest.getInstance(algorithm, SECURITY_PROVIDER);
			digest.reset();
			hash = digest.digest(message);
		} catch (Exception e) {
			//e.printStackTrace();
			log.info("Exception ::",e);
		}
		return hash;
	}
}
