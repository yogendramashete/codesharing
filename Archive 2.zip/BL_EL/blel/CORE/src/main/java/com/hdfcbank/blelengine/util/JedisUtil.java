package com.hdfcbank.blelengine.util;

import java.util.Set;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.JedisPoolConfig;

@Component
public class JedisUtil {
	private final static Logger logger = LoggerFactory.getLogger(JedisUtil.class);

	@Value("${cache.redis.cluster.host}")
	String redisHost;

	@Value("${cache.redis.cluster.port}")
	String redisPort;

	// the jedis connection pool..
	// private static JedisPool pool = null;

	private static Jedis jedis = null;

	@PostConstruct
	public void init() {
		JedisPoolConfig poolConfig = new JedisPoolConfig();
		poolConfig.setMaxTotal(1000);
		JedisPool pool = new JedisPool(poolConfig,redisHost, Integer.parseInt(redisPort));
		jedis = pool.getResource();
	}

	public Set<String> getKeys(String keyPattern) {
		// Jedis jedis = pool.getResource();
		try {
			Set<String> keys = jedis.keys(keyPattern);
			return keys;
		} catch (Exception exe) {
			logger.info("getKeys Exception :: " + CommonUtility.getPrintStackTrace(exe));
		}
		return null;
	}
}
