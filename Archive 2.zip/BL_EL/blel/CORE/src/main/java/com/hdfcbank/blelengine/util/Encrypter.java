package com.hdfcbank.blelengine.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.security.GeneralSecurityException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.Provider;
import java.security.PublicKey;
import java.security.Security;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.TimeZone;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;

import com.hdfcbank.blelengine.constants.AppConstants;
import lombok.extern.log4j.Log4j2;
import org.bouncycastle.crypto.BlockCipher;
import org.bouncycastle.crypto.CipherParameters;
import org.bouncycastle.crypto.InvalidCipherTextException;
import org.bouncycastle.crypto.engines.AESEngine;
import org.bouncycastle.crypto.modes.GCMBlockCipher;
import org.bouncycastle.crypto.params.AEADParameters;
import org.bouncycastle.crypto.params.KeyParameter;
import org.bouncycastle.jce.provider.BouncyCastleProvider;

@Log4j2
public final class Encrypter {
	private static final String ASYMMETRIC_ALGO = "RSA/ECB/PKCS1Padding";
	private static final String JCE_PROVIDER = "BC";
	public static final int AES_KEY_SIZE_BITS = 256;
	public static final int IV_SIZE_BITS = 96;
	public static final int AAD_SIZE_BITS = 128;
	public static final int AUTH_TAG_SIZE_BITS = 128;
	private static final String CERTIFICATE_TYPE = "X.509";
	private PublicKey publicKey;
	private Date certExpiryDate;

	static {
		Security.addProvider((Provider) new BouncyCastleProvider());
	}

	public Encrypter(final String publicKeyFileName) {
		FileInputStream fileInputStream = null;
		try {
			final CertificateFactory certFactory = CertificateFactory.getInstance("X.509", "BC");
			fileInputStream = new FileInputStream(new File(publicKeyFileName));
			final X509Certificate cert = (X509Certificate) certFactory.generateCertificate(fileInputStream);
			this.publicKey = cert.getPublicKey();
			this.certExpiryDate = cert.getNotAfter();
		} catch (Exception e) {
			//e.printStackTrace();
			log.info("Exception" + e);
			throw new RuntimeException("Could not intialize encryption module", e);
		} finally {
			if (fileInputStream != null) {
				try {
					fileInputStream.close();
				} catch (IOException e2) {
					//e2.printStackTrace();
					log.info("IOException" + e2);
				}
			}
		}
		if (fileInputStream != null) {
			try {
				fileInputStream.close();
			} catch (IOException e2) {
				//e2.printStackTrace();
				log.info("IOException" + e2);
			}
		}
	}
	
	public Encrypter(final InputStream fileInputStream) {
		try {
			final CertificateFactory certFactory = CertificateFactory.getInstance("X.509", "BC");
			final X509Certificate cert = (X509Certificate) certFactory.generateCertificate(fileInputStream);
			this.publicKey = cert.getPublicKey();
			this.certExpiryDate = cert.getNotAfter();
		} catch (Exception e) {
			//e.printStackTrace();
			log.info("Exception" + e);
			throw new RuntimeException("Could not intialize encryption module", e);
		} finally {
			if (fileInputStream != null) {
				try {
					fileInputStream.close();
				} catch (IOException e2) {
					//e2.printStackTrace();
					log.info("IOException" + e2);
				}
			}
		}
		if (fileInputStream != null) {
			try {
				fileInputStream.close();
			} catch (IOException e2) {
				//e2.printStackTrace();
				log.info("IOException" + e2);
			}
		}
	}

	public byte[] generateSessionKey() throws NoSuchAlgorithmException, NoSuchProviderException {
		final KeyGenerator kgen = KeyGenerator.getInstance("AES", "BC");
		kgen.init(256);
		final SecretKey key = kgen.generateKey();
		final byte[] symmKey = key.getEncoded();
		return symmKey;
	}

	public byte[] encryptUsingPublicKey(final byte[] data) throws IOException, GeneralSecurityException {
		final Cipher pkCipher = Cipher.getInstance(AppConstants.AES_ECB, "BC");
		pkCipher.init(1, this.publicKey);
		final byte[] encSessionKey = pkCipher.doFinal(data);
		return encSessionKey;
	}

	public byte[] encryptUsingSessionKey(final boolean cipherOperation, final byte[] skey, final byte[] iv,
			final byte[] aad, final byte[] data) throws IllegalStateException, InvalidCipherTextException {
		final AEADParameters aeadParam = new AEADParameters(new KeyParameter(skey), 128, iv, aad);
		final GCMBlockCipher gcmb = new GCMBlockCipher((BlockCipher) new AESEngine());
		gcmb.init(cipherOperation, (CipherParameters) aeadParam);
		final int outputSize = gcmb.getOutputSize(data.length);
		final byte[] result = new byte[outputSize];
		final int processLen = gcmb.processBytes(data, 0, data.length, result, 0);
		gcmb.doFinal(result, processLen);
		return result;
	}

	public byte[] generateIv(final String ts) throws UnsupportedEncodingException {
		return this.getLastBits(ts, 12);
	}

	public byte[] generateAad(final String ts) throws UnsupportedEncodingException {
		return this.getLastBits(ts, 16);
	}

	private byte[] getLastBits(final String ts, final int bits) throws UnsupportedEncodingException {
		final byte[] tsInBytes = ts.getBytes("UTF-8");
		return Arrays.copyOfRange(tsInBytes, tsInBytes.length - bits, tsInBytes.length);
	}

	public Date getCertExpiryDate() {
		return this.certExpiryDate;
	}

	public String getCertificateIdentifier() {
		final SimpleDateFormat ciDateFormat = new SimpleDateFormat("yyyyMMdd");
		ciDateFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
		final String certificateIdentifier = ciDateFormat.format(this.certExpiryDate);
		return certificateIdentifier;
	}

}
