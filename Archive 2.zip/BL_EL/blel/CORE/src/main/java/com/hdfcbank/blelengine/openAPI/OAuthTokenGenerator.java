package com.hdfcbank.blelengine.openAPI;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.hdfcbank.blelengine.constants.AppConstants;
import com.hdfcbank.blelengine.dao.Comondao;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.KeyManager;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import java.io.*;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.Files;
import java.security.KeyStore;
import java.security.SecureRandom;

/**
 * Call HDFC Bank Oauth Service to generate OAuth Token. Service URL is
 * configured in Config.properties file.
 * 
 * @author Madhura Oak
 *
 */
@Service
public class OAuthTokenGenerator {
	public final static Logger logger = LoggerFactory.getLogger(DigitalSignature.class);

	@Autowired
	private Comondao commondao;

	@Value("${AUTHORIZATION}")
	String AUTHORIZATION;
	@Value("${BASIC}")
	String BASIC;
	@Value("${USERNAME}")
	String USERNAME;
	@Value("${PASSWORD}")
	String PASSWORD;

	@Value("${openbankapiconnector.blelpfxpath}")
	String BLELpfxPath;

	@Value("${openbankapiconnector.blelpfxpassword}")
	String BLELpfxPassword;

	@Value("${openbankapiconnector.blelkeystorepath}")
	String BLELkeyStorePath;

	@Value("${openbankapiconnector.blelkeystorepassword}")
	String BLELkeyStorePassword;

	@Value("${openbankapiconnector.bleltruststorepath}")
	String BLELtrustStorePath;

	@Value("${openbankapiconnector.bleltruststorepassword}")
	String BLELtrustStorePassword;

	@Value("${openbankapiconnector.blelclientscope}")
	String BLELclientScope;

	private static final String COLON = ":";

	@Value("${POST}")
	String POST;

	@Value("${CONTENT_TYPE}")
	String CONTENT_TYPE;

	@Value("${CONTENT_LENGTH}")
	String CONTENT_LENGTH;
	@Value("${FORM_URL_ENCODED}")
	String FORM_URL_ENCODED;
	@Value("${GRANT_TYPE}")
	String GRANT_TYPE;
	@Value("${CLIENT_CREDENTIALS}")
	String CLIENT_CREDENTIALS;
	@Value("${SCOPE}")
	String SCOPE;

	private static final String EQUALTO = "=";

	private static final String AND = "&";

	private static final String CLIENT_KEYSTORE_TYPE = "PKCS12";
	private static final String CLIENT_KEYSTORE_PATH = "ABS";

	@Value("${ACCESS_TOKEN}")
	String ACCESS_TOKEN;

	/**
	 * Call HDFC bank Oauth Service to get Oauth token.
	 * 
	 * @param clientId
	 * @param clientSecret
	 * @param scope
	 * @return Oauth token
	 * @throws IOException
	 */
	public String getOAuthToken(String clientId, String clientSecret, String scope) throws IOException {
		String oauthToken = null;
		HttpsURLConnection conn = null;
		try {
			logger.info("client Id :" + clientId);
			logger.info("client Secret :" + clientSecret);

			String oauthTokenServiceURLConstant = commondao.getAPIConfigParameters("Adobe", "common", "Open_API_UAT_Token_URL");


			//String oauthTokenServiceURL = OAUTH_TOKEN_SERVICE_URL;
			//logger.info("OAUTH_TOKEN_SERVICE_URL :" + OAUTH_TOKEN_SERVICE_URL);
			logger.info("Token generator url {} : {}" + oauthTokenServiceURLConstant);

			URL url = new URL(oauthTokenServiceURLConstant);
			conn = (HttpsURLConnection) url.openConnection();
			Base64EncoderDecoder encoder = new Base64EncoderDecoder();
			String encoded = encoder.encodeToString(clientId + COLON + clientSecret);
			conn.setRequestProperty(AUTHORIZATION, BASIC + encoded);
			conn.setRequestMethod(POST);
			conn.setRequestProperty(CONTENT_TYPE, FORM_URL_ENCODED);
			StringBuilder builder = new StringBuilder();
			builder.append(GRANT_TYPE).append(EQUALTO).append(CLIENT_CREDENTIALS).append(AND).append(SCOPE)
					.append(EQUALTO).append(scope);
			logger.info(builder.toString());
			conn.setRequestProperty(CONTENT_LENGTH, String.valueOf(builder.length()));
			conn.setConnectTimeout(10000);
			conn.setUseCaches(false);
			conn.setDoInput(true);
			conn.setDoOutput(true);
			PrintWriter writer = new PrintWriter(conn.getOutputStream());
			writer.write(builder.toString());
			writer.close();
			BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
			builder.delete(0, builder.length());
			String line = null;
			while ((line = reader.readLine()) != null) {
				builder.append(line);
			}
			JsonParser parser = new JsonParser();
			JsonObject jsonObject = (JsonObject) parser.parse(builder.toString());
			oauthToken = jsonObject.get(ACCESS_TOKEN).getAsString();
		} catch (MalformedURLException exp) {
			//exp.printStackTrace();
			logger.info("Exception :" + exp);
		} catch (Exception e) {
			//e.printStackTrace();
			logger.info("Exception :" + e);
			if (conn != null) {
				try (BufferedReader in = new BufferedReader(new InputStreamReader(conn.getErrorStream()))) {
					String inputLine;
					StringBuffer buffResp = new StringBuffer();

					while ((inputLine = in.readLine()) != null) {
						buffResp.append(inputLine);
					}
					logger.info("error stream :" + buffResp.toString());
					in.close();
				} catch (Exception e2) {
					//e2.printStackTrace();
					logger.info("Exception :" + e2);
				}
			}
		}
		return oauthToken;
	}

	public String getOAuthTokenBLEL(String clientId, String clientSecret, String scope) throws IOException {
		String oauthToken = "";

		logger.info("Token1");

		HttpsURLConnection conn = null;
		try {
			logger.info("client Id :" + clientId);
			logger.info("client Secret :" + clientSecret);
			String oauthTokenServiceURLConstant = commondao.getAPIConfigParameters("Adobe", "common", "oauthtokenegenerateurl");
			String oauthTokenServiceURL =oauthTokenServiceURLConstant +scope +"&grant_type=client_credentials";
			logger.info("OAUTH_TOKEN_SERVICE_URL :" + oauthTokenServiceURL);
			logger.info("scope :" + scope);

			KeyStore clientStore = KeyStore.getInstance("PKCS12");
			clientStore.load(new FileInputStream(BLELpfxPath), BLELpfxPassword.toCharArray());
			KeyManagerFactory kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
			kmf.init(clientStore, BLELpfxPassword.toCharArray());

			KeyManager[] kms = kmf.getKeyManagers();
			SSLContext sslContext = null;
			sslContext = SSLContext.getInstance("TLSv1.2");
			// sslContext.init(kms, null , null);
			// conn = (HttpsURLConnection) url.openConnection();

			sslContext.init(kmf.getKeyManagers(), null, null);

			URL url = new URL(oauthTokenServiceURL);
			conn = (HttpsURLConnection) url.openConnection();
			Base64EncoderDecoder encoder = new Base64EncoderDecoder();
			String encoded = encoder.encodeToString(clientId + COLON + clientSecret);

			conn.setRequestProperty(AUTHORIZATION, BASIC + encoded);
			conn.setRequestMethod(POST);
			conn.setRequestProperty(CONTENT_TYPE, FORM_URL_ENCODED);
			conn.setSSLSocketFactory(sslContext.getSocketFactory());

			StringBuilder builder = new StringBuilder();

			//builder.append("scope").append(EQUALTO).append(scope).append(AND).append(GRANT_TYPE).append(EQUALTO)
				//	.append(CLIENT_CREDENTIALS);

			logger.info(builder.toString());
			conn.setRequestProperty(CONTENT_LENGTH, "0");
			conn.setConnectTimeout(10000);
			conn.setUseCaches(false);
			conn.setDoInput(true);
			conn.setDoOutput(true);

			PrintWriter writer = new PrintWriter(conn.getOutputStream());
			writer.write(builder.toString());
			writer.close();

			BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
			builder.delete(0, builder.length());
			String line = null;

			while ((line = reader.readLine()) != null) {
				builder.append(line);
				logger.info(builder.toString());
			}

			JsonParser parser = new JsonParser();
			JsonObject jsonObject = (JsonObject) parser.parse(builder.toString());
			oauthToken = jsonObject.get(ACCESS_TOKEN).getAsString();
			logger.info(oauthToken + "oauthToken");
		} catch (MalformedURLException exp) {
			//exp.printStackTrace();
			logger.info("Exception :" + exp);
		} catch (Exception e) {
			//e.printStackTrace();
			logger.info("Exception :" + e);
			if (conn != null) {
				try (BufferedReader in = new BufferedReader(new InputStreamReader(conn.getErrorStream()))) {
					String inputLine;
					StringBuffer buffResp = new StringBuffer();

					while ((inputLine = in.readLine()) != null) {
						buffResp.append(inputLine);
					}
					logger.info("error stream :" + buffResp.toString());
					in.close();
				} catch (Exception e2) {
					//e2.printStackTrace();
					logger.info("Exception :" + e2);
				}
			}
		}
		finally {
			logger.info("Finally block executed");
		}
		return oauthToken;
	}

	private static SSLContext getSSLSocketFactory(String PFX_location, String PFX_Password) throws Exception {

		SSLContext context = null;
		File pKeyFile = new File(PFX_location);
		KeyManagerFactory keyManagerFactory = KeyManagerFactory.getInstance("SunX509");
		KeyStore keyStore = KeyStore.getInstance(CLIENT_KEYSTORE_TYPE);
		InputStream keyInput = Files.newInputStream(pKeyFile.toPath());
		keyStore.load(keyInput, PFX_Password.toCharArray());
		keyInput.close();
		keyManagerFactory.init(keyStore, PFX_Password.toCharArray());
		context = SSLContext.getInstance(AppConstants.sslv);
		context.init(keyManagerFactory.getKeyManagers(), null, new SecureRandom());
		return context;
	}
}
