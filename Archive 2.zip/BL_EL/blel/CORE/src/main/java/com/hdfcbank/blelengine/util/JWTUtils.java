package com.hdfcbank.blelengine.util;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import java.util.Calendar;
import java.util.Date;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import javax.xml.bind.DatatypeConverter;

import org.apache.commons.lang3.StringUtils;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.hdfcbank.blelengine.constants.RedisConstants;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwtBuilder;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

@Service
public class JWTUtils {

	private static Logger logger = LoggerFactory.getLogger(JWTUtils.class);
	
 	
	//@Value("${jwt.encryption.key}")
	//private String key;
	
	//@Value("${jwt.encryption.algorithm}")
	//private String algorithm;
	String key = "MKRYSBJGSGJSKDFH";
	String algorithm = "HmacSHA256";

	@Value("${JWT_TOKEN_EXPIRE_TIME}")
	private int JWT_TOKEN_EXPIRE_TIME;

	@Autowired
	private RedisUtils redisUtils;

	public String createJwtToken(String randomId) {

		try {
			// The JWT signature algorithm we will be using to sign the token
			SignatureAlgorithm signatureAlgorithm = SignatureAlgorithm.HS256;
			long nowMillis = System.currentTimeMillis();
			// We will sign our JWT with our ApiKey secret
			byte[] apiKeySecretBytes = DatatypeConverter.parseBase64Binary(key);
			Key signingKey = new SecretKeySpec(apiKeySecretBytes, signatureAlgorithm.getJcaName());
			// Let's set the JWT Claims
			Claims claims = Jwts.claims();
			claims.put("id", randomId);
			JwtBuilder builder = Jwts.builder().setClaims(claims).setIssuedAt(new Date(System.currentTimeMillis()))
					.signWith(signatureAlgorithm, signingKey);
			// if it has been specified, let's add the expiration
			Date dt = new Date();
			Calendar c = Calendar.getInstance();
			c.setTime(dt);
			c.add(Calendar.DATE, 30);
			// c.add(Calendar.MINUTE, 0);
			dt = c.getTime();
			builder.setExpiration(dt);

			// Builds the JWT and serializes it to a compact, URL-safe string
			return builder.compact();
		} catch (Exception e) {
			//e.printStackTrace();
			logger.info("Exception ::",e);
		}
		return "";
	}

	public String validateJwtToken(String token) {

		try {

			// First part of JWT token is header, second part payload and last part, the
			// signature
			// Each part is separated by a dot(.)
			String[] parts = token.split("\\.");

			if(parts.length != 3) {
				logger.info("validateJWTToken Invalid authorization token!");
			}

			// Initialise our Hash-message based Authentication code with the algorithm
			// (HMACSHA256 & Secret Key)
			Mac mac = Mac.getInstance(algorithm);
			SecretKeySpec secretKey = new SecretKeySpec(key.getBytes(StandardCharsets.UTF_8), algorithm);
			mac.init(secretKey);

			// These two parts, the header and payload, can be used to compute the signature
			// of the message, with our secret key
			String headerAndData = parts[0] + "." + parts[1];

			long timeA = System.nanoTime();
			// Compute the signature
			String computedSignature = new String(Base64.getUrlEncoder().withoutPadding()
					.encode(mac.doFinal(headerAndData.getBytes(StandardCharsets.UTF_8))));
			logger.info("computedSignature : "+ computedSignature);

			// Actual Verification
			boolean isVerified = parts[2].equals(computedSignature);
			logger.info("isVerified : "+ isVerified);

			long timeB = System.nanoTime();
			logger.info("validateJWTToken Elapsed time: " + (timeB - timeA));
			// Decode the payload (JSON String) which is the 2nd part
			String decodedPayload = new String(Base64.getDecoder().decode(parts[1]));
			logger.info(" validateJWTToken payload : "+decodedPayload);
			JSONObject obj = new JSONObject(decodedPayload);
			logger.info("obj : "+obj);
			String randomId = obj.has("id") ? obj.get("id").toString():"";
			logger.info("validateJWTToken payload id: "+decodedPayload);
			return randomId;
		} catch (Exception e) {
			//e.printStackTrace();
			logger.info("Exception ::"+e);
		}
		return null;

	}

	public String validateJwtTokenNew(String jwt) {
		// This line will throw an exception if it is not a signed JWS (as expected)
		String id = "";
		try {
		Claims claims = Jwts.parser().setSigningKey(DatatypeConverter.parseBase64Binary(key)).parseClaimsJws(jwt)
		.getBody();
		if (claims != null) {
		JSONObject obj = new JSONObject(claims);
		logger.info("obj : " + obj);
		id = obj.has("id") ? obj.get("id").toString() : "";
		}

		} catch (Exception e) {
		//e.printStackTrace();
			logger.info("Exception ::"+e);
		}

		return id;
		}


	public static void main(String[] args) throws InterruptedException {

		System.out.println("main...");
		String token = new JWTUtils().createJwtToken(
				"{\"autocircleId\":\"4\",\"gender\":\"male\",\"city\":\"khammam\",\"dobFormat\":\"\",\"residenceType\":\"hin\",\"offState\":\"maharastra\",\"custId\":\"805647\",\"state\":\"Telengana\",\"landmark\":\"Street\",\"email\":\"ravik@gmail.com\",\"profession\":\"developer\",\"address3 \":\"telengana\",\"pincode\":\"521232\",\"address1 \":\"IND\",\"offPincode\":\"685265\",\"address2\":\"AP\",\"employmentType\":\"salaried\",\"offCity\":\"mumbai\",\"panNo\":\"jdieb5247h\",\"mobile\":\"8008252936\",\"offLandmark\":\"mumbai\",\"offAddress3\":\"venodr\",\"offAddress2\":\"mumbai\",\"offAddress1\":\"mumbai\",\"phone\":\"586649\",\"dob\":\"\",\"name\":\"raviteja\",\"offPhone\":\"898532745\",\"maritalStatus\":\"single\"}");
		System.out.println("token : " + token);
		Thread.sleep(40000);
		String returntoken =	new JWTUtils().validateJwtToken(token);
		System.out.println("returntoken : "+ returntoken);

	}

	public boolean isSessionValid(String jwtToken, String randomNo) {
		boolean isSessionValid = false;
		try {
			if (StringUtils.isNotBlank(randomNo)) {
				if (StringUtils.isNotBlank(jwtToken)) {
					String randomId = validateJwtToken(jwtToken);
					String redisToken = redisUtils.get(RedisConstants.JWT_TOKEN_RANDOM_ID + randomId);
					if (jwtToken.equalsIgnoreCase(redisToken)) {
						redisUtils.expire(RedisConstants.JWT_TOKEN_RANDOM_ID + randomId, JWT_TOKEN_EXPIRE_TIME);
						isSessionValid = true;
					} else {
						logger.info("isSessionValid :: " + isSessionValid + " jwtToken :: " + jwtToken);
					}
				} else {
					logger.info("isSessionValidIsBlank :: ");
				}
			}else {
				isSessionValid = true;
				logger.info("randomNoIsBlank :: ");
			}
		} catch (Exception e) {
			logger.info("isSessionValid Exception :: " + CommonUtility.getPrintStackTrace(e));
		}
		return isSessionValid;
	}

}
