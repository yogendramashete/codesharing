package com.hdfcbank.blelengine.util;

import com.hdfcbank.blelengine.openAPI.JsonRequestGenerator;
import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

@Component
public class AadharUtil {

	public final static Logger logger = LoggerFactory.getLogger(AadharUtil.class);

	@Autowired
	AadharAuthentication aadharAuthentication;

	@Autowired
	JsonRequestGenerator JsonRequestGenerator;

	@Autowired
	CommonUtility commonUtility;

	@Value("${openbankapiconnector.pfxpath}")
	String pfxPath;

	@Value("${openbankapiconnector.pfxpassword}")
	String pfxPassword;

	public String genRandomNumber(int length) {
		Random random = ThreadLocalRandom.current();
		byte[] r = new byte[length]; // Means 2048 bit
		random.nextBytes(r);
		String randomString = Base64.encodeBase64String(r);
		return randomString;
	}


	public String getDoDocumentResponse(String errCode, String respStatus, String errMessage, String parentDocid,
			String childDocId, String flag) {
		StringBuilder doDocumentResp = new StringBuilder();
		String responseTime = CommonUtility.getDate("yyyy/MM/dd hh:mm:ss a");
		doDocumentResp.append(
				"<soap:Envelope xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\">");
		doDocumentResp.append("<soap:Body>");
		doDocumentResp.append("<doDocumentUpload_IDfyResponse xmlns=\"http://WS_DocumentUpload_IDfy.org/\">");
		doDocumentResp.append("<doDocumentUpload_IDfyResult>");
		doDocumentResp.append("<flag>0</flag>");
		doDocumentResp.append("<response_time>" + responseTime + "</response_time>");
		doDocumentResp.append("<response_status>" + respStatus + "</response_status>");
		doDocumentResp.append("<error_code>" + errCode + "</error_code>");
		doDocumentResp.append("<error_msg>" + errMessage + "</error_msg>");
		doDocumentResp.append("<Filler1/>");
		doDocumentResp.append("<Filler2/>");
		doDocumentResp.append("<Filler3/>");
		doDocumentResp.append("<parent_doc_id>" + parentDocid + "</parent_doc_id>");
		doDocumentResp.append("<child_doc_id>" + childDocId + "</child_doc_id>");
		doDocumentResp.append("</doDocumentUpload_IDfyResult>");
		doDocumentResp.append("</doDocumentUpload_IDfyResponse>");
		doDocumentResp.append("</soap:Body>");
		doDocumentResp.append("</soap:Envelope>");
		return doDocumentResp.toString();
	}

	public String getLeadUpdateResponse(String errCode, String respStatus, String errMessage) {
		StringBuilder doDocumentLeadUpdateResp = new StringBuilder();
		String responseTime = CommonUtility.getDate("yyyy/MM/dd hh:mm:ss a");
		doDocumentLeadUpdateResp.append(
				"<soap:Envelope xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\">");
		doDocumentLeadUpdateResp.append("<soap:Body>");
		doDocumentLeadUpdateResp
				.append("<LeadUpdate_IDfy_CaptureResponse xmlns=\"http://WS_DocumentUpload_IDfy.org/\">");
		doDocumentLeadUpdateResp.append("<LeadUpdate_IDfy_CaptureResult>");
		doDocumentLeadUpdateResp.append("<response_time>" + responseTime + "</response_time>");
		doDocumentLeadUpdateResp.append("<response_status>" + respStatus + "</response_status>");
		doDocumentLeadUpdateResp.append("<error_code>" + errCode + "</error_code>");
		doDocumentLeadUpdateResp.append("<error_msg>" + responseTime + "</error_msg>");
		doDocumentLeadUpdateResp.append("<Filler1></Filler1>");
		doDocumentLeadUpdateResp.append("<Filler2/>");
		doDocumentLeadUpdateResp.append("<Filler3/>");
		doDocumentLeadUpdateResp.append("<Ref_No/>");
		doDocumentLeadUpdateResp.append("</LeadUpdate_IDfy_CaptureResult>");
		doDocumentLeadUpdateResp.append("</LeadUpdate_IDfy_CaptureResponse>");
		doDocumentLeadUpdateResp.append("</soap:Body>");
		doDocumentLeadUpdateResp.append("</soap:Envelope>");
		return doDocumentLeadUpdateResp.toString();
	}


}
