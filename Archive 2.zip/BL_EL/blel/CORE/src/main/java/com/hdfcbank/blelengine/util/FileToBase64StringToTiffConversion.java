package com.hdfcbank.blelengine.util;

import com.hdfcbank.blelengine.constants.AppConstants;
import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.IOException;
import java.util.Base64;

@Service
public class FileToBase64StringToTiffConversion {
	public final static Logger logger = LoggerFactory.getLogger(FileToBase64StringToTiffConversion.class);
	//@Value("${VCIP_BASE_FOLDERNAME}")
	String VCIP_BASE_FOLDERNAME="/opt/hdfc/vcipfiles/";

	@Autowired
	private  RedisUtils redisUtils;

	public void fileToBase64StringConversion(String inputData, String inputFilePath, String mobileNumber,
			String tranRefNumber) throws IOException {
		try {
			String filePath = VCIP_BASE_FOLDERNAME + inputFilePath;
			logger.info("vcip file path :" + filePath);

			redisUtils.set("vcipfilePath" + mobileNumber + "*" + mobileNumber, filePath);

			File outputFile = new File(filePath);
			if (outputFile.getCanonicalPath().startsWith(filePath)) {
				byte[] decodedBytes = Base64.getDecoder().decode(inputData);
				FileUtils.writeByteArrayToFile(outputFile, decodedBytes);
			}
			
			if (AppConstants.IS_UAT) {
				String date = CommonUtility.getDate(AppConstants.DATE_FMT_ddMMyyyy2);
			//	s3AWSUtility.uploadFileToS3Bucket(outputFile,
			//			AppConstants.AWS_LOANS_FILE_LOCATION + date + "/" + mobileNumber + "/" + tranRefNumber);
			}
		} catch (Exception e) {
			logger.info("Exception :: "+CommonUtility.getPrintStackTrace(e));
		}
	}
}