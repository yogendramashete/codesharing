package com.hdfcbank.blelengine.util;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.KeySpec;
import java.util.ArrayList;
import java.util.Formatter;
import java.util.List;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.Mac;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.DecoderException;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.binary.Hex;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.hdfcbank.blelengine.constants.AppConstants;

@Component
public class AESUtils {

	private static final Logger logger = LoggerFactory.getLogger(AESUtils.class);

	private final Cipher cipher;
	static int iterationCount = 1000;
	static int keySize = 128;
	String iv = AppConstants.AES_IV;
	String salt = AppConstants.AES_SALT;

	public AESUtils() {
		this(keySize, iterationCount);
	}

	public AESUtils(int keySize, int iterationCount) {
		try {
			cipher = Cipher.getInstance(AppConstants.AES_CBC);

		} catch (NoSuchAlgorithmException e) {
			logger.info("Exception :: " + CommonUtility.getPrintStackTrace(e));
			throw failure(e);
		} catch (NoSuchPaddingException e) {
			logger.info("Exception :: " + CommonUtility.getPrintStackTrace(e));
			throw failure(e);
		}
	}

	public String encrypt(String plaintext) {

		return encrypt(salt, iv, plaintext);
	}

	public String encrypt(String key, String iv, String plaintext) {
		try {
			logger.info("iv: " + iv);
			byte[] encrypted = doFinal(Cipher.ENCRYPT_MODE, generateKey(key), iv, plaintext.getBytes("UTF-8"));
			return base64(encrypted);
		} catch (UnsupportedEncodingException e) {
			throw failure(e);
		}
	}

	public String encrypt(String key, String plaintext) {
		try {
			String[] array = key.split("\\|");
			key = array[0];
			iv = array[1];

			byte[] encrypted = doFinal(Cipher.ENCRYPT_MODE, generateKey(key), iv, plaintext.getBytes("UTF-8"));
			return base64(encrypted);
		} catch (UnsupportedEncodingException e) {
			throw failure(e);
		}
	}

	public String encrypt(String salt, String iv, String passphrase, String plaintext) {
		try {
			SecretKey key = generateKey(salt, passphrase);
			logger.info("encrypt key hex: " + hex(key.getEncoded()));
			byte[] encrypted = doFinal(Cipher.ENCRYPT_MODE, key, iv, plaintext.getBytes("UTF-8"));
			return base64(encrypted);
		} catch (UnsupportedEncodingException e) {
			throw failure(e);
		}
	}

	public String decrypt(String ciphertext) {

		return decrypt(salt, iv, ciphertext);
	}

	public String decrypt(String key, String iv, String ciphertext) {
		try {
			logger.info("iv: " + iv);
			byte[] decrypted = doFinal(Cipher.DECRYPT_MODE, generateKey(key), iv, base64(ciphertext));
			return new String(decrypted, "UTF-8");
		} catch (UnsupportedEncodingException e) {
			throw failure(e);
		}
	}

	public String decrypt(String key, String ciphertext) {
		try {
			String[] array = key.split("\\|");
			key = array[0];
			iv = array[1];
			byte[] decrypted = doFinal(Cipher.DECRYPT_MODE, generateKey(key), iv, base64(ciphertext));
			return new String(decrypted, "UTF-8");
		} catch (UnsupportedEncodingException e) {
			throw failure(e);
		} catch (Exception e) {
			throw e;
		}
	}

	public String decrypt(String salt, String iv, String passphrase, String ciphertext) {
		try {
			SecretKey key = generateKey(salt, passphrase);
			logger.info("decrypt key hex: " + hex(key.getEncoded()));
			byte[] decrypted = doFinal(Cipher.DECRYPT_MODE, key, iv, base64(ciphertext));
			return new String(decrypted, "UTF-8");
		} catch (UnsupportedEncodingException e) {
			throw failure(e);
		}
	}

	private byte[] doFinal(int encryptMode, SecretKey key, String iv, byte[] bytes) {
		try {
			cipher.init(encryptMode, key, new IvParameterSpec(hex(iv)));
			return cipher.doFinal(bytes);
		} catch (InvalidKeyException e) {
			logger.info("Exception ::" + CommonUtility.getPrintStackTrace(e));
			throw failure(e);
		} catch (InvalidAlgorithmParameterException e) {
			logger.info("Exception ::" + CommonUtility.getPrintStackTrace(e));
			throw failure(e);
		} catch (IllegalBlockSizeException e) {
			logger.info("Exception ::" + CommonUtility.getPrintStackTrace(e));
			throw failure(e);
		} catch (BadPaddingException e) {
			logger.info("Exception ::" + CommonUtility.getPrintStackTrace(e));
			throw failure(e);
		}
	}

	private SecretKey generateKey(String key) {
		return new SecretKeySpec(hex(key), "AES");
	}

	public String generateHexKey(String salt, String passphrase) {
		SecretKey key = generateKey(salt, passphrase);
		return hex(key.getEncoded());
	}

	private SecretKey generateKey(String salt, String passphrase) {
		SecretKey key = null;
		try {
			SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1");
			KeySpec spec = new PBEKeySpec(passphrase.toCharArray(), hex(salt), iterationCount, keySize);
			key = new SecretKeySpec(factory.generateSecret(spec).getEncoded(), "AES");
		} catch (NoSuchAlgorithmException e) {
			logger.info("Exception ::" + CommonUtility.getPrintStackTrace(e));
			throw failure(e);
		} catch (InvalidKeySpecException e) {
			logger.info("Exception ::" + CommonUtility.getPrintStackTrace(e));
			throw failure(e);
		}
		return key;
	}

	public static String base64(byte[] bytes) {
		return new String(Base64.encodeBase64(bytes));
	}

	public static byte[] base64(String str) {
		return Base64.decodeBase64(str.getBytes());
	}

	public static String hex(byte[] bytes) {
		return new String(Hex.encodeHex(bytes));
	}

	public static byte[] hex(String str) {
		try {
			return Hex.decodeHex(str.toCharArray());
		} catch (DecoderException e) {
			throw new IllegalStateException(e);
		}
	}

	private IllegalStateException failure(Exception e) {
		return new IllegalStateException(e);
	}
	
	
	public  String encryptMessage(String message)
	{
	    String sha1 = "";
	    StringBuffer sb;
	    try
	    {
	    	
	    	final MessageDigest mDigest = MessageDigest.getInstance("SHA-1");
			byte[] result = mDigest.digest(message.getBytes());
			sb = new StringBuffer();
			for (int i = 0; i < result.length; i++) {
				sb.append(Integer.toString((result[i] & 0xff) + 0x100, 16).substring(1));
			}
			
			sha1= HMAC_SHA256(sb.toString(),message);
	   /*     MessageDigest crypt = MessageDigest.getInstance("SHA-1");
	       // crypt.reset();
	        crypt.update(message.getBytes("UTF-8"));
	        sha1 = base64(crypt.digest());  */
	    }
	    catch(NoSuchAlgorithmException e) {
	   
	        //e.printStackTrace();
			logger.info("NoSuchAlgorithmException ::" +  e);
	    }
	  
	    return sha1;
	}
	
	public static String HMAC_SHA256(String secret, String message) {
		String hash = "";
		try {
			Mac sha256_HMAC = Mac.getInstance("HmacSHA1");
			SecretKeySpec secret_key = new SecretKeySpec(secret.getBytes(), "HmacSHA1");
			sha256_HMAC.init(secret_key);
			hash = com.loopj.android.http.Base64.encodeToString(sha256_HMAC.doFinal(message.getBytes()), com.loopj.android.http.Base64.NO_WRAP);
		} catch (Exception e) {
			logger.info("Exception :: "+CommonUtility.getPrintStackTrace(e));
		}
		return hash.trim();
	}

	private static String byteToHex(final byte[] hash)
	{
	    Formatter formatter = new Formatter();
	    for (byte b : hash)
	    {
	        formatter.format("%02x", b);
	    }
	    String result = formatter.toString();
	    formatter.close();
	    return result;
	}
	
	
	
	
	
	public static void main(String[] args) throws Exception {
		// Snapwork+Source name+ destination name => SnapworkEMAEMA
		FileWriter fw=null;
		try{
		System.out.println("enc data : " + new AESUtils().encrypt("9890245266"));
		//System.out.println("dec data : line no 214 " + new AESUtils().encrypt("7715843183"));
//		// String enc=new AESUtils().encrypt("");
//		// System.out.println("enc data :: "+enc);

		 String dec = new AESUtils().decrypt( "wQxV63KG4y0RJxVP3O84m1dS3fyKtPuDQQcFR1iNkuw7yyy2iHlzdYxg7NO5cHgz");
		 System.out.println(dec);
		 /*
		 File newTextFile = new
		 * File("C:\\Users\\Admin\\Documents\\AutoCircle\\Test\\Ency\\thetextfile2.txt")
		 * ;
		 *
		 * FileWriter fw = new FileWriter(newTextFile); fw.write(dec); fw.close();
		 */

	//	String dec = "tVP/KYCT2kX9x29SR9gNM9/NURmcUtv4MdF0pGEx/cHiSX2nVzv+oDIMMJ9FupJxui/u+6bwE5Zw9gbuYGH3DOcLf7Y/Ei+4c5h/Ril3LHJzg4YROb7I+1eD6ZmI7ePZFMo3kGrLO196d3lsxW8BNIg2m21HZ47nJs8D5zP7vyHCnDFTz93k0il1OBibFVybQT+/aLcsp3QeoyGwm9HAOwf/sKfEjcr6Ffx4swkVCnB0aMsnQ2XuUXZYgWzrwwpHcIvoDMJKfuK9puD1WxFa6J5e0gK9jnz/R6z94mCT/Wd1rmcF9OZidCGaVObuPJbtTbAmuVXYjvwj0amDKdRSZjvC6FtoHGWllpNELsnySy94BcDJrCF+7TQeNpDrJSBkcYghO8V+WqINtbziiZ0vB2db6ii6IC0dlUeVcPYVkhQviQOJfa7V95J3LnCNTydHZgpsTMwbLSm8SiXPu+e5oHJ8JnA8fyf2Jj0tUQX9JtfEFSDz0XLikTlSRp+1sdkvDJbDP9xxVvn3y2lZf92qWAIK1yYk7UQ/FlKFTym/mPKK+LIc9gQ/9bg1zEreV82RGoyi1yj4eBTuHKNe7zODQhZIY5/7Srk9GjkdS7xir672rSwbUu5Sm2aI2DYeJO8Ucef7aU5xouoHD/gf5V7ZPc28smDrvcdwG16W2qmLG5DycJqCAXvj5faCMtgBYYgFP2xAaeiu5yp/C5BMwB/8vss1FQ0K6pr2c4RKYWBz4nxXC+iEhXIZcdIl3sRUrlPiJlScot0JPsmEW0I4Iwtf4x+neoi6BdQhCw9P/7bfxaBx4B0d16HxdeX1wOnWcYl9dgD5wr5cVwKQKHNeroYl4NLRXT/32WIpdXFFXm5I9YH1pycuCsEEC7xvjmAi3OAfnL8SddkI6nGP9ncXIdr6VawJcJlc7ckCBGTrhNFc8K9TN9j4nqQy7Ayvq5nB088skLLG8YnZkZh5USA2GPn83B22DajmrIA3K6pc62CiXbIOpF3DiO4b24EiuEnJcefneDohQ0KTuZYs/J8zTy+9m1sg3KUEeFvBaZLhin3oKkE=";

		//dec = new AESUtils().decrypt(dec);
		//File newTextFile = new File("D:\\AAAAA\\thetextfile2.txt");
		//FileWriter fw = new FileWriter(newTextFile);
	//	fw.write(dec);
	//	fw.close();

		String msg="8888hdfc_loanengine00000009199466617750107031800000248falseH4Y4L3Q5Z5";
		msg = new AESUtils().encryptMessage(msg);

		File newTextFile = new File("D:\\AAAAA\\thetextfile2.txt");
		fw = new FileWriter(newTextFile);
		fw.write(msg);
		List<String> data = new ArrayList<String>();
		data.add("\"pc3oHV30S51gjpr64SLFvdwrTtZWdlKT9bVxWLdBkUSuM/L9zGCq6yOYVSWWYSuRgq6V6En+cKBHDtL5qhNq1CClIrHkBEsI9aDbuH122HP+iDJx8salbgPzSYGB10jY8sjg+Mgi/nPF5dRK36MQMLYi7xsvcCVjVlHWJ4ujMLxXEmwl6qKCph/nHHAi33am3Ak95xwvKuznVL+d3jkO6JCZCR4v/5KxBEbfbVJvU1P0oDRK8BPRQNRyah0S1CmIuM0ZJI1aqYnmkHfaHX5TBywDFn+8OFTw6fkvoOC820gHG4gE58BLDwd6u+pBUtJd0Fl/BViqbdWWLKZBqx0K4FXl+gC9Ornao1uww/QRi+QZgKQ6mSlYyvCUEbVnxmoUUvrXR2yXSlkLT2ith1gyyOWewNKiKH167s04NezR4apWmKsNOXBljmlIDWKYIBIWFJYl3kwYwjoayTKVPr/vnrI9O5qKng1mkKrHWimVDIpAf5PCKUUCr/sJAiqnjoPgaVdJ8p/OJlkMRFm5cWFZoN4IjZ+A8Bj5ON7a2bOd4fIfJjdbURD0OJRBMqy5gRh8wFd5P1KH2cqGRZZK7CYaP0/1l24vYWeFQdXWTA7VUDULp8OfyVzexsxF+Fb/h4M7CqCo2I4ESiVSxIqb8ghE4aJj+TQB+lYEbQTQGL5rsu0lpw+Q7YLhM+HSakCeQUepd3SqfeCmr0dVWfO4fv04f6noPHyXsqtQMJJOwSh+t9q1auzAzVEcQc+T5MR6e/nxbtEgzjsoBy3mBZkJ0nxytB29siKzv3FUQGrWKt9GJRariNkiR+l3lGKx8tlk3XJiyYPG26FMYuzeKU6OZ4bm1w==\"");

	//	System.out.println("dec data : " + new AESUtils().decrypt(data));
		//	// System.out.println("dec data : " + new AESUtils().encrypt(d));
		}catch (IOException e) {
			//e.printStackTrace();
			logger.info("IOException ::" +  e);

		}
		finally
		{
			if (fw != null) {
				fw.close();
			}

		}
		}
	}

	

