package com.hdfcbank.blelengine.util;

import com.github.jaiimageio.impl.plugins.tiff.TIFFImageWriterSpi;
import com.hdfcbank.blelengine.constants.AppConstants;
import com.hdfcbank.blelengine.constants.RedisConstants;
import com.hdfcbank.blelengine.dao.Comondao;
import com.itextpdf.text.*;
import com.itextpdf.text.html.WebColors;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import lombok.extern.log4j.Log4j2;
import org.apache.commons.lang3.StringUtils;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.rendering.PDFRenderer;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.imageio.IIOImage;
import javax.imageio.ImageIO;
import javax.imageio.ImageWriteParam;
import javax.imageio.ImageWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

@Component
@Log4j2
public class ApplicationFormGeneration {


    String date = CommonUtility.getDate("dd-MM-yyyy");
    @Autowired
    private Comondao commonDao;
    @Autowired
    private HeaderFooter event;
    @Autowired
    private RedisUtils redisUtils;
    @Autowired
    private S3AWSUtility s3AWSUtility;
    private int txnSrNo;

    private static PdfPTable setTableWidthToMax(PdfPTable table) {
        // PdfPTable table = new PdfPTable(length);

        table.setWidthPercentage(100);
        table.setSpacingBefore(0f);
        table.setSpacingAfter(0f);

        return table;
    }

    public void generatePDF(JSONObject reqObj) throws Exception {

        log.info("Inside generatePDF :: " + reqObj.toString());
        log.info("partnerJourneyID :: " + reqObj.get("partnerJourneyID").toString());
        log.info("bankJourneyId :: " + reqObj.get("bankJourneyId").toString());

        List<Map<String, Object>> pdfDetails = null;
        List<Map<String, Object>> pdfDetailsFromloandocumentdetails = null;
        Document document = new Document();
        PDDocument pddoc = null;

        String applicationformFileLocation = "";
        String parentDocId = "";
        String childDocId = "";
        String documentType = "";
        String fileType = "";

        try {

            if (StringUtils.isBlank(reqObj.get("partnerJourneyID").toString()) || StringUtils.isBlank(reqObj.get("bankJourneyId").toString())) {
                log.info("partnerJourneyID OR bankJourneyId can't be null.");

            }
            //DB Calls
            pdfDetails = commonDao.getPDFDetailsFromLoanAppInfoTable(reqObj.get("partnerJourneyID").toString(), reqObj.get("bankJourneyId").toString());

            //DB Calls to loandocumentdetails table

            //Dheeraj Code - loandocumentdetails
            pdfDetailsFromloandocumentdetails = commonDao.getPDFDetailsFromLoanDocumentdetailsTable(reqObj.get("bankJourneyId").toString());

            if (pdfDetails != null && pdfDetailsFromloandocumentdetails != null) {

                String envDomainName = reqObj.get("envDomainName").toString();

                //Checking Environment Domain
                if (envDomainName.equalsIgnoreCase(AppConstants.IDENTIFYPLEKSEnvironmentDomainName)) {
                    log.info("EKS PL Env::: " + envDomainName);
                    //Image to be saved in EKS Server
                    //EKS server path to be set
                    applicationformFileLocation = reqObj.get("applicationformFileLocation").toString();

                } else {
                    log.info("DEV EL BL Env::: " + envDomainName);
                    //Image to be saved in Local Server
                    applicationformFileLocation = reqObj.get("applicationformFileLocation").toString();

                }
                log.info("File Path::: " + applicationformFileLocation);

                parentDocId = reqObj.get("parentDocId").toString();
                childDocId = reqObj.get("childDocId").toString();
                documentType = reqObj.get("documentType").toString();
                fileType = reqObj.get("fileType").toString();


                String fileLocation = applicationformFileLocation;
                String fileName = reqObj.get("bankJourneyId").toString() + "_" + reqObj.get("partnerJourneyID").toString() + "_" + "applicationForm" + ".pdf";
                String filePath = fileLocation + date + "/" + reqObj.get("bankJourneyId").toString();
//                File file = new File(filePath);
//                file.mkdir();
                String tiffImageFilePath = fileLocation + date + "/" + reqObj.get("bankJourneyId").toString() + "/" + "tiff" + "/";
                File tiffFile = new File(tiffImageFilePath);
                if (!tiffFile.exists()) {
                    boolean tiffMkdir = false;
                    log.info("Tiff File Doesn't Exists:: " + tiffFile.exists());
                    //tiffMkdir = tiffFile.mkdir();
//                    Files.createDirectory(tiffFile.toPath());
                    Files.createDirectories(tiffFile.toPath());
                    // log.info("Tiff File MKDIR:: "+tiffMkdir);

                    log.info("Tiff File Doesn't Exists:: " + tiffFile.exists());
                } else {
                    log.info("Tiff File Exists:: ");
                }

                log.info("tiff ImageFilePath::" + tiffImageFilePath);
                String pdfFile = filePath + "/" + fileName;
                log.info("pdfFile path before PdfWriter::" + pdfFile);
                PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream(pdfFile));
                document.open();
                writer.setPageEvent(event);
                event.onEndPage(writer, document);
                populatePDF(document, pdfDetails, pdfDetailsFromloandocumentdetails, reqObj);
                log.info("PDF generated Successfully:: Location::" + pdfFile);
                document.close();

                try {
                    pddoc = PDDocument.load(new File(pdfFile));
                    String base64StringTiffImage = savePdfAsTiff(pddoc, reqObj.get("bankJourneyId").toString(), reqObj.get("partnerJourneyID").toString(), reqObj.get("envDomainName").toString(), tiffImageFilePath);

                    if (StringUtils.isNotBlank(base64StringTiffImage)) {

                        log.info("SuccessFully Created TIFF Image:: ");


                        if (envDomainName.equalsIgnoreCase(AppConstants.IDENTIFYPLEKSEnvironmentDomainName)) {

                            log.info("EKS PL Env::");

                            String tiffLocation = fileLocation + reqObj.get("bankJourneyId").toString() + "_" + reqObj.get("partnerJourneyID").toString() + "_" + "applicationForm" + ".tiff";
                            File s3TiffFile = new File(tiffLocation);
                            s3AWSUtility.uploadFileToS3Bucket(s3TiffFile, reqObj.get("targetLocationInS3Bucket").toString(), reqObj.get("awsS3Bucket").toString());
                        }

                        ++txnSrNo;
                        int docUploadCount = commonDao.insertLoanDocumentUploadDetails(reqObj.get("bankJourneyId").toString(), 0, txnSrNo, tiffImageFilePath, Integer.parseInt(parentDocId),
                                Integer.parseInt(childDocId), documentType, fileName, base64StringTiffImage, "", "", fileType, "", "",
                                "", "", "");

                        if (docUploadCount != 0) {
                            log.info("Image Details Saved in DB:: ");
                            redisUtils.set("APPLI_FORM_TIFF" + reqObj.get("bankJourneyId").toString() + "*" + reqObj.get("partnerJourneyID").toString(), base64StringTiffImage);
                            // response = "Success";
                        }
                    } else {
                        log.info("Error in creating TIFF Image:: ");
                        //  response = "Failure";
                    }

                } catch (IOException e) {
                    log.info("exce {}", e);
                }

            }

        } catch (Exception exe) {
            log.info("Inside catch generatePDF :: {}", exe.getMessage());
            exe.printStackTrace();

        }
    }

    private void populatePDF(Document document, List<Map<String, Object>> pdfDetails, List<Map<String, Object>> pdfDetailsFromloandocumentdetails, JSONObject reqObj) throws DocumentException {

        String custID = "";
        String custAccountNo = "";
        String custFname = "";
        String custMname = "";
        String custLname = "";
        String gender = "";
        String dob = "";
        String mobNo = "";
        String panNo = "";
        String emailId = "";
        String addr1 = "";
        String addr2 = "";
        String addr3 = "";
        String city = "";
        String state = "";
        String pincode = "";
        String resiAddrType = "";
        String adhaaraddr1 = "";
        String adhaaraddr2 = "";
        String adhaaraddr3 = "";
        String adhaarcity = "";
        String adhaarstate = "";
        String adhaarpincode = "";
        String paddr1 = "";
        String paddr2 = "";
        String paddr3 = "";
        String pcity = "";
        String pstate = "";
        String ppincode = "";
        String empType = "";
        String nameOfBiz = "";
        String empName = "";
        String natureOfBiz = "";
        String occupation = "";
        String oaddr1 = "";
        String oaddr2 = "";
        String oaddr3 = "";
        String ocity = "";
        String ostate = "";
        String opincode = "";
        String officePhoneNo = "";
        String officeEmailId = "";
        String turnover = "";
        String profitAfterTax = "";
        String depriciation = "";
        String monthlySalary = "";
        String obligations = "";
        String bankName = "";
        String bankAccNo = "";
        String ifsc = "";
        String micr = "";
        String branchName = "";
        String loanAmt = "";
        String tenure = "";
        String emi = "";
        String interestRate = "";
        String processingFee = "";
        String purposeOfLoan = "";
        String refFName = "";
        String refMName = "";
        String refLName = "";
        String refContact = "";
        String maritalStatus = "";
        String religion = "";
        String caste = "";
        String channel = "";
        String branchCode = "";
        String smCode = "";
        String seCode = "";
        String lgCode = "";
        String partnerJourneyId = "";
        String bankJourneyId = "";
        String gstin = "";
        String dsaCode = "";
        String lcCode = "";
        String salePromoCode = "";
        String preferredLocation = "";
        String mcistateMedicalCouncil = "";
        String mciregistrationNo = "";
        String icaiMembershipNumber = "";
        String electricityProvider = "";
        String electricityUniqueCustomerId = "";
        String electricityRelConOwner = "";
        String mciregistrationDate = "";
        String existingUser = "";

        Font catFont = new Font(Font.FontFamily.TIMES_ROMAN, 18, Font.BOLD);
        Font smallBlackBold = new Font(Font.FontFamily.TIMES_ROMAN, 12, Font.BOLD, BaseColor.BLACK);
        Font smallBlack = new Font(Font.FontFamily.TIMES_ROMAN, 12, Font.NORMAL, BaseColor.BLACK);
        Font smallerBlackBold = new Font(Font.FontFamily.TIMES_ROMAN, 10, Font.BOLD, BaseColor.BLACK);
        Font smallerBlack = new Font(Font.FontFamily.TIMES_ROMAN, 10, Font.NORMAL, BaseColor.BLACK);


        try {

            for (Map<String, Object> map : pdfDetails) {

                custFname = map.get("customerfirstname") == null ? "" : map.get("customerfirstname").toString().toUpperCase().trim();
                log.info("custFname {}", custFname);
                custMname = map.get("customermiddlename") == null ? "" : map.get("customermiddlename").toString().toUpperCase().trim();
                log.info("custMname {}", custMname);
                custLname = map.get("customerlastname") == null ? "" : map.get("customerlastname").toString().toUpperCase().trim();
                log.info("custLname {}", custLname);
                gender = map.get("gender") == null ? "" : map.get("gender").toString().toUpperCase().trim();
                log.info("gender {}", gender);
                dob = map.get("dob") == null ? "" : map.get("dob").toString().trim();
                //log.info("dob {}", dob);
                mobNo = map.get("mobileno") == null ? "" : map.get("mobileno").toString().trim();
                log.info("mobNo {}", mobNo);
                panNo = map.get("panno") == null ? "" : map.get("panno").toString().trim();
                log.info("panNo {}", panNo);
                emailId = map.get("personalemailaddress") == null ? "" : map.get("personalemailaddress").toString().toUpperCase().trim();
                log.info("emailId {}", emailId);
                addr1 = map.get("addressline1") == null ? "" : map.get("addressline1").toString().toUpperCase().trim();
                log.info("addr1 {}", addr1);
                addr2 = map.get("addressline2") == null ? "" : map.get("addressline2").toString().toUpperCase().trim();
                log.info("addr2 {}", addr2);
                addr3 = map.get("addressline3") == null ? "" : map.get("addressline3").toString().toUpperCase().trim();
                log.info("addr3 {}", addr3);
                city = map.get("city") == null ? "" : map.get("city").toString().toUpperCase().trim();
                log.info("city {}", city);
                state = map.get("state") == null ? "" : map.get("state").toString().toUpperCase().trim();
                log.info("state {}", state);
                pincode = map.get("pincode") == null ? "" : map.get("pincode").toString().trim();
                log.info("pincode {}", pincode);
                resiAddrType = map.get("resiaddresstype") == null ? "" : map.get("resiaddresstype").toString().toUpperCase().trim();
                log.info("resiAddrType {}", resiAddrType);
                adhaaraddr1 = map.get("aadhaaraddrline1") == null ? "" : map.get("aadhaaraddrline1").toString().toUpperCase().trim();
                log.info("adhaaraddr1 {}", adhaaraddr1);
                adhaaraddr2 = map.get("aadhaaraddrline2") == null ? "" : map.get("aadhaaraddrline2").toString().toUpperCase().trim();
                log.info("adhaaraddr2 {}", adhaaraddr2);
                adhaaraddr3 = map.get("aadhaaraddrline3") == null ? "" : map.get("aadhaaraddrline3").toString().toUpperCase().trim();
                log.info("adhaaraddr3 {}", adhaaraddr3);
                adhaarcity = map.get("aadhaaraddrcity") == null ? "" : map.get("aadhaaraddrcity").toString().toUpperCase().trim();
                log.info("adhaarcity {}", adhaarcity);
                adhaarstate = map.get("aadhaaraddrstate") == null ? "" : map.get("aadhaaraddrstate").toString().toUpperCase().trim();
                log.info("adhaarstate {}", adhaarstate);
                adhaarpincode = map.get("aadhaaraddrpincode") == null ? "" : map.get("aadhaaraddrpincode").toString().trim();
                log.info("adhaarpincode {}", adhaarpincode);
                paddr1 = map.get("permanentaddressline1") == null ? "" : map.get("permanentaddressline1").toString().toUpperCase().trim();
                log.info("paddr1 {}", paddr1);
                paddr2 = map.get("permanentaddressline2") == null ? "" : map.get("permanentaddressline2").toString().toUpperCase().trim();
                log.info("paddr2 {}", paddr2);
                paddr3 = map.get("permanentaddressline3") == null ? "" : map.get("permanentaddressline3").toString().toUpperCase().trim();
                log.info("paddr3 {}", paddr3);
                pcity = map.get("permanentaddresscity") == null ? "" : map.get("permanentaddresscity").toString().toUpperCase().trim();
                log.info("pcity {}", pcity);
                pstate = map.get("permanentaddressstate") == null ? "" : map.get("permanentaddressstate").toString().toUpperCase().trim();
                log.info("pstate {}", pstate);
                ppincode = map.get("permanentaddresspincode") == null ? "" : map.get("permanentaddresspincode").toString().trim();
                log.info("ppincode {}", ppincode);
                empType = map.get("employmenttype") == null ? "" : map.get("employmenttype").toString().toUpperCase().trim();
                log.info("empType {}", empType);
                nameOfBiz = map.get("nameofbiz") == null ? "" : map.get("nameofbiz").toString().toUpperCase().trim();
                log.info("nameOfBiz {}", nameOfBiz);
                empName = map.get("nameofemployer") == null ? "" : map.get("nameofemployer").toString().toUpperCase().trim();
                log.info("empName {}", empName);
                natureOfBiz = map.get("natureofbusiness") == null ? "" : map.get("natureofbusiness").toString().toUpperCase().trim();
                log.info("natureOfBiz {}", natureOfBiz);
                occupation = map.get("occupation") == null ? "" : map.get("occupation").toString().toUpperCase().trim();
                log.info("occupation {}", occupation);
                oaddr1 = map.get("officeorbusinessaddrline1") == null ? "" : map.get("officeorbusinessaddrline1").toString().toUpperCase().trim();
                log.info("officeorbusinessaddrline1 {}", oaddr1);
                oaddr2 = map.get("officeorbusinessaddrline2") == null ? "" : map.get("officeorbusinessaddrline2").toString().toUpperCase().trim();
                log.info("officeorbusinessaddrline2 {}", oaddr2);
                oaddr3 = map.get("officeorbusinessaddrline3") == null ? "" : map.get("officeorbusinessaddrline3").toString().toUpperCase().trim();
                log.info("officeorbusinessaddrline3 {}", oaddr3);
                ocity = map.get("officeorbusinesscity") == null ? "" : map.get("officeorbusinesscity").toString().toUpperCase().trim();
                log.info("officeorbusinesscity {}", ocity);
                ostate = map.get("officeorbusinessstate") == null ? "" : map.get("officeorbusinessstate").toString().toUpperCase().trim();
                log.info("officeorbusinessstate {}", ostate);
                opincode = map.get("officeorbusinesspincode") == null ? "" : map.get("officeorbusinesspincode").toString().trim();
                log.info("officeorbusinessPincode {}", opincode);
                officePhoneNo = map.get("officeorbusinessphoneno") == null ? "" : map.get("officeorbusinessphoneno").toString().trim();
                log.info("officePhoneNo {}", officePhoneNo);
                officeEmailId = map.get("workemail") == null ? "" : map.get("workemail").toString().toUpperCase().trim();
                log.info("officeEmailId {}", officeEmailId);
                turnover = map.get("turnover") == null ? "" : map.get("turnover").toString().trim();
                log.info("turnover {}", turnover);
                profitAfterTax = map.get("profittax") == null ? "" : map.get("profittax").toString().trim();
                log.info("profitAfterTax {}", profitAfterTax);
                depriciation = map.get("depreciation") == null ? "" : map.get("depreciation").toString().trim();
                log.info("depriciation {}", depriciation);
                monthlySalary = map.get("monthlysalary") == null ? "" : map.get("monthlysalary").toString().trim();
                log.info("monthlySalary {}", monthlySalary);
                obligations = map.get("obligation") == null ? "" : map.get("obligation").toString().toUpperCase().trim();
                log.info("obligation {}", obligations);
                bankName = map.get("bankname") == null ? "" : map.get("bankname").toString().toUpperCase().trim();
                log.info("bankName {}", bankName);
                bankAccNo = map.get("bankaccountno") == null ? "" : map.get("bankaccountno").toString().trim();
                log.info("bankAccNo {}", bankAccNo);
                ifsc = map.get("ifsccode") == null ? "" : map.get("ifsccode").toString().toUpperCase().trim();
                log.info("ifsc {}", ifsc);
                micr = map.get("micrcode") == null ? "" : map.get("micrcode").toString().trim();
                log.info("micr {}", micr);
                branchName = map.get("branchname") == null ? "" : map.get("branchname").toString().toUpperCase().trim();
                log.info("branchName {}", branchName);
                loanAmt = map.get("loanamount") == null ? "" : map.get("loanamount").toString().trim();
                log.info("loanAmt {}", loanAmt);
                tenure = map.get("tenure") == null ? "" : map.get("tenure").toString().toUpperCase().trim();
                log.info("tenure {}", tenure);
                emi = map.get("emi") == null ? "" : map.get("emi").toString().toUpperCase().trim();
                log.info("emi {}", emi);
                interestRate = map.get("rateofinterest") == null ? "" : map.get("rateofinterest").toString().trim();
                log.info("interestRate {}", interestRate);
                processingFee = map.get("processingfees") == null ? "" : map.get("processingfees").toString().trim();
                log.info("processingFee {}", processingFee);
                purposeOfLoan = map.get("purposeofloan") == null ? "" : map.get("purposeofloan").toString().toUpperCase().trim();
                log.info("purposeOfLoan {}", purposeOfLoan);
                refFName = map.get("reffirstname") == null ? "" : map.get("reffirstname").toString().toUpperCase().trim();
                log.info("reffirstname {}", refFName);
                refMName = map.get("refmiddlename") == null ? "" : map.get("refmiddlename").toString().toUpperCase().trim();
                log.info("refmiddlename {}", refMName);
                refLName = map.get("reflastname") == null ? "" : map.get("reflastname").toString().toUpperCase().trim();
                log.info("reflastname {}", refLName);
                refContact = map.get("refmobileno") == null ? "" : map.get("refmobileno").toString().trim();
                log.info("refContact {}", refContact);
                maritalStatus = map.get("maritalstatus") == null ? "" : map.get("maritalstatus").toString().toUpperCase().trim();
                log.info("maritalStatus {}", maritalStatus);
                religion = map.get("religion") == null ? "" : map.get("religion").toString().toUpperCase().trim();
                log.info("religion {}", religion);
                caste = map.get("caste") == null ? "" : map.get("caste").toString().toUpperCase().trim();
                log.info("caste {}", caste);
                channel = map.get("channelid") == null ? "" : map.get("channelid").toString().toUpperCase().trim();
                log.info("channel {}", channel);
                branchCode = map.get("branchcode") == null ? "" : map.get("branchcode").toString().toUpperCase().trim();
                log.info("branchCode {}", branchCode);
                smCode = map.get("smcode") == null ? "" : map.get("smcode").toString().toUpperCase().trim();
                log.info("smCode {}", smCode);
                seCode = map.get("secode") == null ? "" : map.get("secode").toString().toUpperCase().trim();
                log.info("seCode {}", seCode);
                lgCode = map.get("lgcode") == null ? "" : map.get("lgcode").toString().toUpperCase().trim();
                log.info("lgCode {}", lgCode);
                partnerJourneyId = map.get("partnerjourneyid") == null ? "" : map.get("partnerjourneyid").toString().trim();
                log.info("partnerJourneyId {}", partnerJourneyId);
                bankJourneyId = map.get("bankjourneyid") == null ? "" : map.get("bankjourneyid").toString().trim();
                log.info("bankJourneyId {}", bankJourneyId);

                //Changes added on 30th Nov,2022 by Dhruv
                //=======================================
                dsaCode = map.get("agentcode") == null ? "" : map.get("agentcode").toString().trim();
                log.info("dsaCode {}", dsaCode);

//                lcCode = map.get("bankjourneyid") == null ? "" : map.get("bankjourneyid").toString().trim();
//                log.info("lcCode {}", lcCode);

//                salePromoCode = map.get("salespromotion") == null ? "" : map.get("salespromotion").toString().trim();
//                log.info("salePromoCode {}", salePromoCode);

                preferredLocation = map.get("preferredcontactlocation") == null ? "" : map.get("preferredcontactlocation").toString().trim();
                log.info("preferredLocation {}", preferredLocation);
            }

            if (redisUtils.exists("existingCustomer" + bankJourneyId + "*" + partnerJourneyId)) {
                existingUser = redisUtils.get("existingCustomer" + bankJourneyId + "*" + partnerJourneyId);
            }
            if (existingUser.equalsIgnoreCase("Y")) {
                if (redisUtils.exists(AppConstants.custIdConstant + bankJourneyId + AppConstants.Asterisk + partnerJourneyId)) {
                    custID = redisUtils.get(AppConstants.custIdConstant + bankJourneyId + AppConstants.Asterisk + partnerJourneyId);
                }
                if (redisUtils.exists("ACC_NO" + bankJourneyId + AppConstants.Asterisk + partnerJourneyId)) {
                    custAccountNo = redisUtils.get("ACC_NO" + bankJourneyId + AppConstants.Asterisk + partnerJourneyId);
                }
            } else {
                custID = bankJourneyId;
                custAccountNo = bankAccNo;
            }

            log.info("existingCustomer from Redis:: {}", existingUser);
            log.info("custID from Redis:: {}", custID);
            log.info("custAccountNo from Redis:: {}", custAccountNo);


            if (redisUtils.exists("gstnResponse" + bankJourneyId + bankJourneyId)) {
                String gstnResponse = redisUtils.get("gstnResponse" + bankJourneyId + bankJourneyId);
                JSONParser parser = new JSONParser();
                JSONObject gstnResObject;
                JSONObject gstnRespObject;
                if (parser.parse(gstnResponse) instanceof JSONObject) {
                    log.info("GSTN Response is JSON Object::: ");
                    gstnResObject = (JSONObject) parser.parse(gstnResponse);
                    gstnRespObject = gstnResObject;
                } else {
                    log.info("GSTN Response is JSON Array::: ");
                    JSONArray gstnRespArray = (JSONArray) parser.parse(gstnResponse);
                    gstnRespObject = (JSONObject) gstnRespArray.get(0);
                }
                log.info("gstn Response exists:: {}", gstnRespObject);

                gstin = Optional.ofNullable(gstnRespObject.get("gstin")).orElse("").toString();
            } else {
                log.info("GSTN Response not present:: ");
            }

            if (StringUtils.isBlank(gstin)) {
                log.info("fetching GSTIN from getBureauOffer Request::");
                if (redisUtils.exists("gstnGetBureauOffer" + bankJourneyId + "*" + partnerJourneyId)) {
                    gstin = redisUtils.get("gstnGetBureauOffer" + bankJourneyId + "*" + partnerJourneyId);
                }
            }

            log.info("GSTIN from Redis:: {}", gstin);

            if (redisUtils.exists("mciResult" + partnerJourneyId + "_" + bankJourneyId)) {
                String mciResult = redisUtils.get("mciResult" + partnerJourneyId + "_" + bankJourneyId);
                if (!mciResult.equals("")) {
                    JSONParser parser = new JSONParser();
                    JSONObject mciJsonObj = (JSONObject) parser.parse(mciResult);

                    mcistateMedicalCouncil = mciJsonObj.get("stateMedicalCouncil") == null ? "" : mciJsonObj.get("stateMedicalCouncil").toString();
                    //mciregistrationNo = mciJsonObj.get("registrationNo") == null ? "" : mciJsonObj.get("registrationNo").toString();
                    mciregistrationDate = mciJsonObj.get("registrationDate") == null ? "" : mciJsonObj.get("registrationDate").toString();
                }
            }

            if (redisUtils.exists("MCI_REG_NO_" + partnerJourneyId + RedisConstants.US + bankJourneyId)) {
                mciregistrationNo = redisUtils.get("MCI_REG_NO_" + partnerJourneyId + RedisConstants.US + bankJourneyId);
            }

            log.info("mci stateMedicalCouncil from Redis:: " + mcistateMedicalCouncil);
            log.info("mci registrationNo from Redis:: " + mciregistrationNo);
            log.info("mci registrationDate from Redis:: " + mciregistrationDate);

            if (redisUtils.exists("ICAIMemberNumber" + bankJourneyId + "*" + partnerJourneyId)) {
                icaiMembershipNumber = redisUtils.get("ICAIMemberNumber" + bankJourneyId + "*" + partnerJourneyId);

            }
            log.info("icai MembershipNumber from Redis:: " + icaiMembershipNumber);

            if (redisUtils.exists("GETELEC_SERVICE_PROVIDER" + partnerJourneyId + RedisConstants.US + bankJourneyId)) {

                electricityProvider = redisUtils.get("GETELEC_SERVICE_PROVIDER" + partnerJourneyId + RedisConstants.US + bankJourneyId);
            }

            if (redisUtils.exists("GETELEC_CONSUMERID" + bankJourneyId + AppConstants.Asterisk + partnerJourneyId)) {

                electricityUniqueCustomerId = redisUtils.get("GETELEC_CONSUMERID" + bankJourneyId + AppConstants.Asterisk + partnerJourneyId);
            }
            //electricityRelConOwner

            if (redisUtils.exists("GETELEC_REL_CON_OWNER" + partnerJourneyId + RedisConstants.US + bankJourneyId)) {

                electricityRelConOwner = redisUtils.get("GETELEC_REL_CON_OWNER" + partnerJourneyId + RedisConstants.US + bankJourneyId);
            }

            if (redisUtils.exists("salesPromotion" + bankJourneyId + "*" + partnerJourneyId)) {
                salePromoCode = redisUtils.get("salesPromotion" + bankJourneyId + "*" + partnerJourneyId);
            }

            if (redisUtils.exists("GetBureauOffer_LCCode_" + bankJourneyId + "_" + partnerJourneyId)) {
                lcCode = redisUtils.get("GetBureauOffer_LCCode_" + bankJourneyId + "_" + partnerJourneyId);
            }

            if (StringUtils.isBlank(loanAmt)) {
                log.info("Fetching LoanAmount from Redis:: ");
                if (redisUtils.exists("loanAmount" + bankJourneyId + "*" + partnerJourneyId)) {
                    loanAmt = redisUtils.get("loanAmount" + bankJourneyId + "*" + partnerJourneyId);
                    log.info("LoanAmount from Redis:: " + loanAmt);
                }
            }
            if (StringUtils.isBlank(tenure)) {
                log.info("Fetching Tenure from Redis:: ");
                if (redisUtils.exists("tenure" + bankJourneyId + "*" + partnerJourneyId)) {
                    tenure = redisUtils.get("tenure" + bankJourneyId + "*" + partnerJourneyId);
                    log.info("Tenure from Redis:: " + tenure);
                }
            }
            if (StringUtils.isBlank(emi)) {
                log.info("Fetching EMI from Redis:: ");
                if (redisUtils.exists("emi" + bankJourneyId + "*" + partnerJourneyId)) {
                    emi = redisUtils.get("emi" + bankJourneyId + "*" + partnerJourneyId);
                    log.info("EMI from Redis:: " + emi);
                }
            }
            if (StringUtils.isBlank(processingFee)) {
                log.info("Fetching ProcessingFee from Redis:: ");
                if (redisUtils.exists("processingFees" + bankJourneyId + "*" + partnerJourneyId)) {
                    processingFee = redisUtils.get("processingFees" + bankJourneyId + "*" + partnerJourneyId);
                    log.info("ProcessingFee from Redis:: " + processingFee);
                }
            }
            if (StringUtils.isBlank(interestRate)) {
                log.info("Fetching InterestRate from Redis:: ");
                if (redisUtils.exists("roi" + bankJourneyId + "*" + partnerJourneyId)) {
                    interestRate = redisUtils.get("roi" + bankJourneyId + "*" + partnerJourneyId);
                    log.info("InterestRate from Redis:: " + interestRate);
                }
            }

            log.info("LC CODE from Redis:: " + lcCode);
            log.info("SalesPromoCode from Redis:: " + salePromoCode);
            log.info("electricityProvider from Redis:: " + electricityProvider);
            log.info("electricityUniqueConsumerID from Redis:: " + electricityUniqueCustomerId);
            log.info("electricityRelConOwner from Redis:: " + electricityRelConOwner);
            //=======================================

            Paragraph preface = new Paragraph();
            Paragraph centerHeader = new Paragraph();
            Paragraph appPara = new Paragraph();
            Paragraph tablePara = new Paragraph();
            Paragraph tablePara2 = new Paragraph();
            Paragraph tablePara3 = new Paragraph();
            Paragraph tablePara4 = new Paragraph();
            Paragraph img = new Paragraph();
            Paragraph tablePara5 = new Paragraph();
            Paragraph tablePara6 = new Paragraph();
            Paragraph tablePara7 = new Paragraph();
            Paragraph tablePara8 = new Paragraph();
            Paragraph tablePara9 = new Paragraph();
            Paragraph tablePara10 = new Paragraph();

            String applicantPhotograph = redisUtils.get("aadharPhoto" + bankJourneyId + "*" + partnerJourneyId);
            byte[] imageBytesimage = org.apache.commons.codec.binary.Base64.decodeBase64(AppConstants.HDFClogoImage);
            Image imageRight = Image.getInstance(imageBytesimage);
            imageRight.setAlignment(Image.LEFT);
            preface.add(imageRight);

            centerHeader.add(new Paragraph("Business Loans Digital Application Form", catFont));
            centerHeader.setAlignment(0);

            document.add(centerHeader);

            appPara.add(new Paragraph("Application No. - " + partnerJourneyId + " | " + bankJourneyId + "", smallBlackBold));
            appPara.add(new Paragraph("Application Date: " + date, smallBlackBold));

            document.add(appPara);
            byte[] decoded = null;
            if (StringUtils.isNotBlank(applicantPhotograph)) {
                decoded = org.apache.commons.codec.binary.Base64.decodeBase64(applicantPhotograph.getBytes());
            } else {
                //if Applicant Photograph is not present, placing an empty frame
                decoded = org.apache.commons.codec.binary.Base64.decodeBase64(AppConstants.emptyApplicantPhotograph.getBytes());
            }

            Image image = Image.getInstance(decoded);
            image.setAlignment(Image.LEFT);
            img.add(image);

            document.add(img);

            tablePara.add(new Paragraph("Personal Details", smallBlackBold));

            tablePara.add(new Paragraph(" "));
            document.add(tablePara);

            PdfPTable table = new PdfPTable(2);
            table = setTableWidthToMax(table);

            table.addCell("Customer ID");
            table.addCell(custID);
            table.addCell("Customer Account No.");
            table.addCell(custAccountNo);
            table.addCell("Full name");
            table.addCell(custFname + " " + custMname + " " + custLname);
            table.addCell("Gender");
            table.addCell(gender);
            table.addCell("Date of Birth");
            table.addCell(dob);
            table.addCell("Mobile No.");
            table.addCell(mobNo);
            table.addCell("PAN Number");
            table.addCell(panNo);
            table.addCell("Personal Email ID");
            table.addCell(emailId);
            table.addCell("Residence Address / Current Address");
            table.addCell(addr1 + "\r\n" + addr2 + "\r\n" + addr3 + "\r\n" + city + "\r\n" + state + "\r\n" + pincode + "\r\n" + "");
            table.addCell("Residence Address Type");
            table.addCell(resiAddrType);
            table.addCell("Aadhaar Address");
            table.addCell(adhaaraddr1 + "\r\n" + adhaaraddr2 + "\r\n" + adhaaraddr3 + "\r\n" + adhaarcity + "\r\n" + adhaarstate + "\r\n" + adhaarpincode + "\r\n" + "");
            table.addCell("Permanent Address");
            table.addCell(paddr1 + "\r\n" + paddr2 + "\r\n" + paddr3 + "\r\n" + pcity + "\r\n" + pstate + "\r\n" + ppincode + "\r\n" + "");

            document.add(table);
            document.add(Chunk.NEWLINE);

            tablePara2.add(new Paragraph("Employment Details", smallBlackBold));
            tablePara2.add(new Paragraph(" "));

            document.add(tablePara2);
            PdfPTable table2 = new PdfPTable(2);
            table2 = setTableWidthToMax(table2);

            table2.addCell("Employment Type");
            table2.addCell(empType);
            table2.addCell("Name of Business");
            table2.addCell(nameOfBiz);
            table2.addCell("Employer Name");
            table2.addCell(empName);
            table2.addCell("Nature of Business");
            table2.addCell(natureOfBiz);
            table2.addCell("Occupation");
            table2.addCell(occupation);
            table2.addCell("GSTN ID");
            table2.addCell(gstin); //need to check
            table2.addCell("Office Address");
            table2.addCell(oaddr1 + "\r\n" + oaddr2 + "\r\n" + oaddr3 + "\r\n" + ocity + "\r\n" + ostate + "\r\n" + opincode + "\r\n" + "");
            table2.addCell("Office Phone No.");
            table2.addCell(officePhoneNo);
            table2.addCell("Office Email ID");
            table2.addCell(officeEmailId);
            document.add(table2);

            document.add(Chunk.NEWLINE);

            PdfPTable preferredCommunicationAddr = new PdfPTable(2);
            preferredCommunicationAddr = setTableWidthToMax(preferredCommunicationAddr);
            preferredCommunicationAddr.addCell("Preferred Communication Address");

            if (preferredLocation.equalsIgnoreCase("O")) {
                log.info("PreferredLocation is :: " + preferredLocation);
                preferredCommunicationAddr.addCell(oaddr1 + "\r\n" + oaddr2 + "\r\n" + oaddr3 + "\r\n" + ocity + "\r\n" + ostate + "\r\n" + opincode + "\r\n" + "");
            } else {
                log.info("PreferredLocation is :: " + preferredLocation);
                preferredCommunicationAddr.addCell(addr1 + "\r\n" + addr2 + "\r\n" + addr3 + "\r\n" + city + "\r\n" + state + "\r\n" + pincode + "\r\n" + "");
            }

            document.add(preferredCommunicationAddr);
            //document.add(tablePara4);

            document.add(Chunk.NEWLINE);

            tablePara4.add(new Paragraph("Income Related Details", smallBlackBold));
            tablePara4.add(new Paragraph(" "));

            document.add(tablePara4);
            PdfPTable table4 = new PdfPTable(2);
            table4 = setTableWidthToMax(table4);

            table4.addCell("Annual Turnover");
            table4.addCell(turnover);
            table4.addCell("PAT/ Net Annual Income");
            table4.addCell("");
            table4.addCell("Depreciation");
            table4.addCell(depriciation);
            table4.addCell("Net Monthly Salary");
            table4.addCell(monthlySalary);
            table4.addCell("Monthly Obligations");
            table4.addCell(obligations);
            document.add(table4);

            document.add(Chunk.NEWLINE);

            tablePara5.add(new Paragraph("Bank Details", smallBlackBold));
            tablePara5.add(new Paragraph(" "));

            document.add(tablePara5);
            PdfPTable table5 = new PdfPTable(2);
            table5 = setTableWidthToMax(table5);

            table5.addCell("Bank Name");
            table5.addCell(bankName);
            table5.addCell("Bank Account Number");
            table5.addCell(bankAccNo);
            table5.addCell("IFSC Code");
            table5.addCell(ifsc);
            table5.addCell("MICR Code");
            table5.addCell(micr);
            table5.addCell("Branch Name");
            table5.addCell(branchName);
            document.add(table5);

            document.add(Chunk.NEWLINE);

            tablePara6.add(new Paragraph("Loan Details", smallBlackBold));
            tablePara6.add(new Paragraph(" "));

            document.add(tablePara6);
            PdfPTable table6 = new PdfPTable(2);
            table6 = setTableWidthToMax(table6);

            table6.addCell("Loan Amount");
            table6.addCell(loanAmt);
            table6.addCell("Loan Tenure");
            table6.addCell(tenure);
            table6.addCell("EMI Amount");
            table6.addCell(emi);
            table6.addCell("Interest Rate");
            table6.addCell(interestRate);
            table6.addCell("Processing Fee");
            table6.addCell(processingFee);
            table6.addCell("Purpose of Loan");
            table6.addCell(purposeOfLoan);
            document.add(table6);

            document.add(Chunk.NEWLINE);

            tablePara7.add(new Paragraph("Additional Employment Details", smallBlackBold));
            tablePara7.add(new Paragraph(" "));

            document.add(tablePara7);
            PdfPTable table7 = new PdfPTable(2);
            table7 = setTableWidthToMax(table7);

            table7.addCell("Name of Medical Council");
            table7.addCell(mcistateMedicalCouncil);
            table7.addCell("Medical Registration No.");
            table7.addCell(mciregistrationNo);
            table7.addCell("Year of Registration");
            table7.addCell(mciregistrationDate);
            table7.addCell("ICAI Membership No.");
            table7.addCell(icaiMembershipNumber);
            table7.addCell("Name of Electricity Board");
            table7.addCell(electricityProvider);
            table7.addCell("Unique Customer ID");
            table7.addCell(electricityUniqueCustomerId);
            table7.addCell("Relationship with Connection Owner");
            table7.addCell(electricityRelConOwner);
            document.add(table7);

            document.add(Chunk.NEWLINE);

            tablePara3.add(new Paragraph("Additional Details", smallBlackBold));
            tablePara3.add(new Paragraph(" "));

            document.add(tablePara3);
            PdfPTable table3 = new PdfPTable(2);
            table3 = setTableWidthToMax(table3);

            table3.addCell("Reference Name");
            table3.addCell(refFName + " " + refMName + " " + refLName);
            table3.addCell("Reference Contact No.");
            table3.addCell(refContact);
            table3.addCell("Marital Status");
            table3.addCell(maritalStatus);
            table3.addCell("Religion");
            table3.addCell(religion);
            table3.addCell("Caste");
            table3.addCell(caste);
            document.add(table3);

            document.add(Chunk.NEWLINE);
            document.add(Chunk.NEWLINE);
            tablePara8.add(new Paragraph("Bank Use Section", smallBlackBold));
            tablePara8.add(new Paragraph(" "));

            document.add(tablePara8);
            PdfPTable table8 = new PdfPTable(2);
            table8 = setTableWidthToMax(table8);

            table8.addCell("Channel");
            table8.addCell(channel);
            table8.addCell("Branch Code");
            table8.addCell(branchCode);
            table8.addCell("DSA Code");
            table8.addCell(dsaCode);
            table8.addCell("SM Code");
            table8.addCell(smCode);
            table8.addCell("SE Code");
            table8.addCell(seCode);
            table8.addCell("LG Code");
            table8.addCell(lgCode);
            table8.addCell("LC Code");
            table8.addCell(lcCode);
            table8.addCell("Sales Promo Code");
            table8.addCell(salePromoCode);
            document.add(table8);

            document.add(Chunk.NEWLINE);

            tablePara9.add(new Paragraph("Document Upload", smallBlackBold));
            tablePara9.add(new Paragraph(AppConstants.BANKUSESECTION, smallBlack));
            tablePara9.add(new Paragraph(" "));

            log.info("line 862:: ");

            String checkMark = AppConstants.checkMarkImage;
            byte[] checkMarkBytes = org.apache.commons.codec.binary.Base64.decodeBase64(checkMark);
            Image imageCheckMark = Image.getInstance(checkMarkBytes);

            PdfPCell cell = new PdfPCell();

            document.add(tablePara9);
            PdfPTable table9 = new PdfPTable(2);
            table9 = setTableWidthToMax(table9);

            imageCheckMark.setAlignment(0);
            imageCheckMark.scalePercent(15);

            cell.addElement(imageCheckMark); //add this for checkmark

            table9.addCell("Photograph");
            log.info("line 879:: ");
            if (StringUtils.isNotBlank(applicantPhotograph)) {
                table9.addCell(cell);
            } else {
                table9.addCell("");
            }
            Set<String> set = new HashSet<>();
            log.info("Before FOR Loop:: ");
            for (Map<String, Object> map1 :
                    pdfDetailsFromloandocumentdetails) {
                set.add(map1.get("parentdocid") == null ? "" : map1.get("parentdocid").toString());
                log.info("Parent Doc ID:: " + set.toString());
            }
            log.info("Before KYC Block:: ");
            table9.addCell("KYC Document");
            boolean kYCDocument = false;
            for (String str :
                    set) {
                if (kYCDocument == true)
                    break;
                if (reqObj.get("appConfigMapKYC1").toString().substring(0, reqObj.get("appConfigMapKYC1").toString().indexOf("|"))
                        .equalsIgnoreCase(str) || reqObj.get("appConfigMapKYC2").toString().substring(0, reqObj.get("appConfigMapKYC2").toString().indexOf("|"))
                        .equalsIgnoreCase(str) || reqObj.get("appConfigMapKYC3").toString().substring(0, reqObj.get("appConfigMapKYC3").toString().indexOf("|"))
                        .equalsIgnoreCase(str) || reqObj.get("appConfigMapKYC4").toString().substring(0, reqObj.get("appConfigMapKYC4").toString().indexOf("|"))
                        .equalsIgnoreCase(str) || reqObj.get("appConfigMapKYC5").toString().substring(0, reqObj.get("appConfigMapKYC5").toString().indexOf("|"))
                        .equalsIgnoreCase(str)) {
                    kYCDocument = true;
                    table9.addCell(cell);
                }
            }

            if (kYCDocument == false) {
                table9.addCell("");
            }
            log.info("After KYC Block:: " + kYCDocument);
            table9.addCell("Income Proof");
            boolean appConfigMapIncomeProof = false;
            log.info("Here in appConfigMapIncomeProof1", reqObj.get("appConfigMapIncomeProof1").toString());
            log.info("Here in appConfigMapIncomeProof1----", reqObj.get("appConfigMapIncomeProof1"));
            log.info("Here in appConfigMapIncomeProof1 substring", reqObj.get("appConfigMapIncomeProof1").toString().substring(0, reqObj.get("appConfigMapIncomeProof1").toString().indexOf("|")));
            log.info("Here in appConfigMapIncomeProof1 substring length", reqObj.get("appConfigMapIncomeProof1").toString().substring(0, reqObj.get("appConfigMapIncomeProof1").toString().indexOf("|")).length());

            log.info("Here in appConfigMapIncomeProof2", reqObj.get("appConfigMapIncomeProof2").toString());
            log.info("Here in appConfigMapIncomeProof2 substring", reqObj.get("appConfigMapIncomeProof2").toString().substring(0, reqObj.get("appConfigMapIncomeProof2").toString().indexOf("|")));
            log.info("Here in appConfigMapIncomeProof2 substring length", reqObj.get("appConfigMapIncomeProof2").toString().substring(0, reqObj.get("appConfigMapIncomeProof2").toString().indexOf("|")).length());

            log.info("Here in appConfigMapIncomeProof3", reqObj.get("appConfigMapIncomeProof3").toString());
            log.info("Here in appConfigMapIncomeProof3 substring", reqObj.get("appConfigMapIncomeProof3").toString().substring(0, reqObj.get("appConfigMapIncomeProof3").toString().indexOf("|")));
            log.info("Here in appConfigMapIncomeProof3 substring length", reqObj.get("appConfigMapIncomeProof3").toString().substring(0, reqObj.get("appConfigMapIncomeProof3").toString().indexOf("|")).length());
            log.info("setts is :{}",set);
            log.info("reqObj is :{}",reqObj);
            for (String str :
                    set) {
                log.info("strs length :{} strhere is  :{}", str.length(),str);
                if (appConfigMapIncomeProof == true)
                    break;
                if (reqObj.get("appConfigMapIncomeProof1").toString().substring(0, reqObj.get("appConfigMapIncomeProof1").toString().indexOf("|"))
                        .equalsIgnoreCase(str) || reqObj.get("appConfigMapIncomeProof2").toString().substring(0, reqObj.get("appConfigMapIncomeProof2").toString().indexOf("|"))
                        .equalsIgnoreCase(str) || reqObj.get("appConfigMapIncomeProof3").toString().substring(0, reqObj.get("appConfigMapIncomeProof3").toString().indexOf("|"))
                        .equalsIgnoreCase(str)) {
                    appConfigMapIncomeProof = true;
                    table9.addCell(cell);
                }
            }
            if (appConfigMapIncomeProof == false) {
                table9.addCell("");
            }


            log.info("After IncomeProof Block:: " + appConfigMapIncomeProof);
            //table9.addCell("Business Ownership Proof");
            //table9.addCell("");
            table9.addCell("Business Continuity Proof");
            boolean appConfigMapBussinessContinuProof = false;
            for (String str :
                    set) {
                if (appConfigMapBussinessContinuProof == true)
                    break;
                if (reqObj.get("appConfigMapBussinessContinuProof1").toString().substring(0, reqObj.get("appConfigMapBussinessContinuProof1").toString().indexOf("|"))
                        .equalsIgnoreCase(str) || reqObj.get("appConfigMapBussinessContinuProof2").toString().substring(0, reqObj.get("appConfigMapBussinessContinuProof2").toString().indexOf("|"))
                        .equalsIgnoreCase(str) || reqObj.get("appConfigMapBussinessContinuProof3").toString().substring(0, reqObj.get("appConfigMapBussinessContinuProof3").toString().indexOf("|"))
                        .equalsIgnoreCase(str)) {
                    appConfigMapBussinessContinuProof = true;
                    table9.addCell(cell);
                }
            }
            if (appConfigMapBussinessContinuProof == false) {
                table9.addCell("");
            }
            log.info("After BussinessContinuProof Block:: " + appConfigMapBussinessContinuProof);
            table9.addCell("Professional Qualification Document");
            boolean appConfigMapQualificationCertificate = false;
            for (String str :
                    set) {
                if (appConfigMapQualificationCertificate == true)
                    break;
                if (reqObj.get("appConfigMapQualificationCertificate").toString().substring(0, reqObj.get("appConfigMapQualificationCertificate").toString().indexOf("|"))
                        .equalsIgnoreCase(str)) {
                    appConfigMapQualificationCertificate = true;
                    table9.addCell(cell);
                }
            }
            if (appConfigMapQualificationCertificate == false) {
                table9.addCell("");
            }
            log.info("After QualificationCertificate Block:: " + appConfigMapQualificationCertificate);

            table9.addCell("Government Registration Proof");
            boolean appConfigMapGovtRegProof = false;
            for (String str :
                    set) {
                if (appConfigMapGovtRegProof == true)
                    break;
                if (reqObj.get("appConfigMapGovtRegProof").toString().substring(0, reqObj.get("appConfigMapGovtRegProof").toString().indexOf("|"))
                        .equalsIgnoreCase(str)) {
                    appConfigMapGovtRegProof = true;
                    table9.addCell(cell);
                }
            }
            if (appConfigMapGovtRegProof == false) {
                table9.addCell("");
            }
            log.info("After GovtRegProof Block:: " + appConfigMapGovtRegProof);
            table9.addCell("Udhyam Registration Certificate");
            boolean appConfigMapUdyamRegCertificate = false;
            for (String str :
                    set) {
                if (appConfigMapUdyamRegCertificate == true)
                    break;
                if (reqObj.get("appConfigMapUdyamRegCertificate").toString().substring(0, reqObj.get("appConfigMapUdyamRegCertificate").toString().indexOf("|"))
                        .equalsIgnoreCase(str)) {
                    appConfigMapUdyamRegCertificate = true;
                    table9.addCell(cell);
                }
            }
            if (appConfigMapUdyamRegCertificate == false) {
                table9.addCell("");
            }
            log.info("After UdyamRegCertificate Block:: " + appConfigMapUdyamRegCertificate);
            document.add(table9);

            document.newPage();

            document.add(Chunk.NEWLINE);

            tablePara10.add(new Paragraph("A. Key Fact and Charges", smallBlackBold));
            tablePara10.add(new Paragraph(" "));
            document.add(tablePara10);
            PdfPTable table10 = new PdfPTable(2);
            table10 = setTableWidthToMax(table10);

            Phrase pr = new Phrase("SCHEDULE-CUM-KEY FACT STATEMENT", smallerBlackBold);
            Phrase pr1 = new Phrase(AppConstants.LOANDETAILS, smallerBlackBold);
            Phrase pr2 = new Phrase(AppConstants.CHARGES, smallerBlackBold);

            PdfPCell cellHeading = new PdfPCell(pr);
            PdfPCell cellHeading1 = new PdfPCell(pr1);
            PdfPCell cellHeading2 = new PdfPCell(pr2);
            BaseColor myColor = WebColors.getRGBColor("D3D3D3");

            cellHeading.setBackgroundColor(myColor);
            cellHeading.setColspan(2);
            cellHeading.setHorizontalAlignment(Element.ALIGN_CENTER);
            cellHeading.setVerticalAlignment(Element.ALIGN_CENTER);
            table10.addCell(cellHeading);

            table10.addCell("Date of Application");
            table10.addCell(date);
            table10.addCell("Name of Borrower");
            table10.addCell(custFname + " " + custMname + " " + custLname);

            cellHeading1.setBackgroundColor(myColor);
            cellHeading1.setColspan(2);
            cellHeading1.setHorizontalAlignment(Element.ALIGN_LEFT);
            table10.addCell(cellHeading1);

            table10.addCell("Loan Amount");
            table10.addCell("Rs. " + loanAmt);
            table10.addCell("Loan Tenure");
            table10.addCell(tenure + " Months");
            table10.addCell("Installment Frequency");
            table10.addCell("MONTHLY");
            table10.addCell("EMI Scheme ( Advance / Arrears)");
            table10.addCell("ARREARS");
            table10.addCell("Interest Rate - (monthly reducing) ( Fixed Rate)");
            table10.addCell(interestRate + "% Per Annum");
            table10.addCell("EMI Amount");
            table10.addCell("Rs. " + emi);
            cellHeading2.setBackgroundColor(myColor);
            cellHeading2.setColspan(2);
            cellHeading2.setHorizontalAlignment(Element.ALIGN_LEFT);
            table10.addCell(cellHeading2);
            table10.addCell(AppConstants.LOANPROCESSING + "");
            table10.addCell("Rs. " + processingFee);
            table10.addCell("Loan Prepayment Charges for part or full prepayment");
            table10.addCell(AppConstants.FORECLOSURE + "");
            table10.addCell("Cheque/SI/ECS return charges (without prejudice to the civil and criminal rights and remedies of the Bank for the dishonor):");
            table10.addCell("Rs. 450/- per instance");

            table10.addCell("Stamp Duty & Other Statutory Charges");
            table10.addCell("As per applicable laws of the state");
            table10.addCell("Overdue EMI interest");
            table10.addCell("2% per month subject to a minimum amount of Rs. 200/-");
            table10.addCell("Legal/Incidental Charges");
            table10.addCell("At actuals");
            table10.addCell("Duplicate Amortization/ Repayment Schedule");
            table10.addCell("₹ 50/- per instance");
            table10.addCell("Repayment mode change charges");
            table10.addCell("₹ 500/-");
            table10.addCell("Loan Cancellation & Rebooking Charges");
            table10.addCell(AppConstants.NIL + "");
            table10.addCell("Details of security/collateral obtained");
            table10.addCell("NIL");
            table10.addCell("Date on which annual outstanding balance statement will be issued");
            table10.addCell("31st May");
            table10.addCell("CIC Report Copy Charges");
            table10.addCell("Rs. 50/- per copy");
            table10.addCell("Legal repossession and Incidental Charges");
            table10.addCell("At actual");

            document.add(table10);
            document.add(Chunk.NEWLINE);

            Phrase bottomPhrase = new Phrase(AppConstants.BOTTOMPARA, smallerBlack);

            PdfPCell cellBottom = new PdfPCell(bottomPhrase);
//			cellBottom.setBackgroundColor(myColor);
            cellBottom.setColspan(1);
            cellBottom.setHorizontalAlignment(Element.ALIGN_LEFT);
            PdfPTable table11 = new PdfPTable(1);
            table11 = setTableWidthToMax(table11);
            table11.addCell(cellBottom);
            document.add(table11);
            document.add(Chunk.NEWLINE);

            Paragraph bHeadingPara = new Paragraph("B.	MOST IMPORTANT TERMS AND CONDITIONS", smallBlackBold);

            Paragraph bPara = new Paragraph(AppConstants.TERMSANDCONDITION + "", smallerBlack);

            document.add(bHeadingPara);
            document.add(bPara);

        } catch (Exception e) {
            e.printStackTrace();
            log.info("Exception in ApplicationForm Generation:: " + e.getMessage());
        }

    }

    private String savePdfAsTiff(PDDocument pdf, String bankJoruneyId, String partnerJourneyId, String envDomainName, String applicationformFileLocation) throws IOException {

        String base64String = "";


        try {
            log.info("inside savePdfAsTiff::");
            log.info("inside savePdfAsTiff:: TiffFilePath Location:: " + applicationformFileLocation);
            //Checking Environment Domain
            if (envDomainName.equalsIgnoreCase(AppConstants.IDENTIFYPLEKSEnvironmentDomainName)) {
                log.info("EKS PL Env::: " + envDomainName);


            } else {
                log.info("DEV EL BL Env::: " + envDomainName);
                //Image to be saved in Local Server


            }
            File file = new File(applicationformFileLocation + bankJoruneyId + "_" + partnerJourneyId + "_" + "applicationForm" + ".tiff");
            Path filePart = Paths.get(file.toString());
            String normalized_path = filePart.normalize().toString();

            int default_dpi = 100;
            PDFRenderer ren = new PDFRenderer(pdf);
            TIFFImageWriterSpi tiffSpi = new TIFFImageWriterSpi();
            ImageWriter writer = tiffSpi.createWriterInstance();
            writer.setOutput(ImageIO.createImageOutputStream(new File(applicationformFileLocation + bankJoruneyId + "_" + partnerJourneyId + "_" + "applicationForm" + ".tiff")));
            ImageWriteParam params = writer.getDefaultWriteParam();
            params.setCompressionMode(ImageWriteParam.MODE_EXPLICIT);
            params.setCompressionType("Deflate");
            writer.prepareWriteSequence(null);
            for (int page = 0; page < pdf.getNumberOfPages(); page++) {
                writer.writeToSequence(new IIOImage(ren.renderImageWithDPI(page, default_dpi), null, null), params);
            }
            writer.endWriteSequence();
            if (file.toString().contains(normalized_path)) {
                if (file.getCanonicalFile().toPath().startsWith(filePart)) {
                    byte[] bytes = Files.readAllBytes(file.toPath());
                    base64String = java.util.Base64.getEncoder().encodeToString(bytes);
                    log.info("base 64 length :" + base64String.length());
                }
            }

        } catch (Exception e) {
            log.info("Exception:: " + e.getMessage());
            e.printStackTrace();
        }


        return base64String;
//        return filePath;
    }
}
