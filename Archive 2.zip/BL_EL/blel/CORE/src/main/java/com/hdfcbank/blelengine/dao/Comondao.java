package com.hdfcbank.blelengine.dao;

import lombok.extern.log4j.Log4j2;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;


@Repository
@Log4j2
public class Comondao {
    @Autowired
    private JdbcTemplate jdbcTemplate;



    public static final Logger logger = LoggerFactory.getLogger(Comondao.class);

    public String getAPIConfigParameters(String channelid, String dataname, String datakey) {

        log.info("get  API Constant Parameters :: ");
        List<String> apiConstantslist = null;
        String isactive = "Y";
        String apiConfig = "";
String getappconfigparameters="select datavalue from public.appconfigmap where channelid=? and dataname=? and datakey=? and isactive=?";
        try {

            apiConstantslist = jdbcTemplate.queryForList(getappconfigparameters,
                    new Object[] { channelid, dataname, datakey, isactive }, String.class);
            if (!apiConstantslist.isEmpty()) {
                apiConfig = apiConstantslist.get(0);
            }
            log.info("apiConfig  datakey::" + datakey + apiConfig);

        } catch (Exception exe) {
            //exe.printStackTrace();
            log.info("Exception :: " + exe);
        }
        return apiConfig;
    }

    public List<Map<String, Object>> getPDFDetailsFromLoanAppInfoTable(String partnerJourneyID, String bankJourneyId) {
        logger.info("getPDFDetailsFromLoanAppInfoTable :: ");


        List<Map<String, Object>> response = null;
        String query = "SELECT * FROM loanappinfo WHERE bankjourneyid = ? AND partnerjourneyid = ?";
        try {


            response = this.jdbcTemplate.queryForList(query,
                    new Object[]{Long.parseLong(bankJourneyId), partnerJourneyID});


        } catch (Exception exe) {
            //exe.printStackTrace();
            log.info("Exception in getPDFDetailsFromLoanAppInfoTable :: " + exe);
        }
        if(response.size() != 0)
        {
        log.info("response of getPDFDetailsFromLoanAppInfoTable :: " + response.toString());
        } else
        {
            log.info("response of getPDFDetailsFromLoanAppInfoTable size is {}" , response.size());
        }
        return response;
    }

    public int insertLoanDocumentUploadDetails(String bankJourneyId, int documentSrNo, int txnSrNo, String documentPath, int parentDocID,
                                               int childDocID, String documentType, String fileName, String fileData, String flgReupload,
                                               String flgFinalUpload, String fileType, String filler1, String filler2, String filler3,
                                               String filler4, String filler5) {
        logger.info("insertLoanDocumentUploadDetails  :: ");

        String insertloandocumentuploaddetails = "insert into public.loandocumentdetails (bankjourneyid, documentsrno, txnsrno, documentstoragepathonserver,parentdocid,childdocid,documenttype,fileName,fileData,flgReupload,flgFinalUpload,fileType,filler1,filler2,filler3,filler4,filler5) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

        int count = 0;
        try {
            count = jdbcTemplate.update(insertloandocumentuploaddetails, new Object[]{bankJourneyId, documentSrNo, txnSrNo, documentPath, parentDocID,
                    childDocID, documentType, fileName, fileData, flgReupload, flgFinalUpload, fileType, filler1, filler2, filler3,
                    filler4, filler5});
            logger.info("insertloandocumentuploaddetails count  :: " + count);

        } catch (Exception exe) {
            // exe.printStackTrace();
            log.info("Exception :: " + exe);
        }
        return count;
    }

    public List<Map<String, Object>> getPDFDetailsFromLoanDocumentdetailsTable(String bankJourneyId) {
        logger.info("getPDFDetailsFromLoanDocumentdetailsTable :: ");
        logger.info("bankJourneyId :: ", bankJourneyId);


        List<Map<String, Object>> response = null;
        String query = "SELECT * FROM loandocumentdetails WHERE bankjourneyid = ?";
        //String query = "SELECT * FROM loandocumentdetails WHERE bankjourneyid = ? AND partnerjourneyid = ?";
        try {


            response = this.jdbcTemplate.queryForList(query,
                    new Object[]{(bankJourneyId)});


        } catch (Exception exe) {
            //exe.printStackTrace();
            log.info("Exception in getPDFDetailsFromLoanDocumentdetailsTable :: " + exe);
        }
        if (response.size() != 0) {
            log.info("response of getPDFDetailsFromLoanDocumentdetailsTable :: " + response.toString());
        } else {
            log.info("response of getPDFDetailsFromLoanDocumentdetailsTable size is {}", response.size());
        }
        return response;
    }
}
