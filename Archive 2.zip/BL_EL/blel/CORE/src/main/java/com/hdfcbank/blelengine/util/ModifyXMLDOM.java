package com.hdfcbank.blelengine.util;

import java.io.File;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;



@Component
public class ModifyXMLDOM {

	private static final Logger logger = LoggerFactory.getLogger(ModifyXMLDOM.class);

	public static void main1(String[] args) {
		String filePath = "test.xml";
		File xmlFile = new File(filePath);
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		dbFactory.setExpandEntityReferences(false);
		DocumentBuilder dBuilder;
		try {

			dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(xmlFile);
			doc.getDocumentElement().normalize();

			// update attribute value
			updateAttributeValue(doc);

			// update Element value
			updateElementValue(doc);

			// delete element
			deleteElement(doc);

			// add new element
			addElement(doc);

			// write the updated document to file or console
			doc.getDocumentElement().normalize();
			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			DOMSource source = new DOMSource(doc);
			StreamResult result = new StreamResult(new File("employee_updated.xml"));
			transformer.setOutputProperty(OutputKeys.INDENT, "yes");
			transformer.transform(source, result);
			System.out.println("XML file updated successfully");

		} catch (SAXException | ParserConfigurationException | IOException | TransformerException e1) {
			logger.info("Exception :: "+CommonUtility.getPrintStackTrace(e1));
		}
	}

	private static void addElement(Document doc) {
		NodeList employees = doc.getElementsByTagName("Employee");
		Element emp = null;

		// loop for each employee
		for (int i = 0; i < employees.getLength(); i++) {
			emp = (Element) employees.item(i);
			Element salaryElement = doc.createElement("salary");
			salaryElement.appendChild(doc.createTextNode("10000"));
			emp.appendChild(salaryElement);
		}
	}

	private static void deleteElement(Document doc) {
		NodeList employees = doc.getElementsByTagName("Employee");
		Element emp = null;
		// loop for each employee
		for (int i = 0; i < employees.getLength(); i++) {
			emp = (Element) employees.item(i);
			Node genderNode = emp.getElementsByTagName("gender").item(0);
			emp.removeChild(genderNode);
		}

	}

	private static void updateElementValue(Document doc) {
		NodeList employees = doc.getElementsByTagName("Employee");
		Element emp = null;
		// loop for each employee
		for (int i = 0; i < employees.getLength(); i++) {
			emp = (Element) employees.item(i);
			Node name = emp.getElementsByTagName("name").item(0).getFirstChild();
			name.setNodeValue(name.getNodeValue().toUpperCase());
		}
	}

	private static void updateAttributeValue(Document doc) {
		NodeList employees = doc.getElementsByTagName("Employee");
		Element emp = null;
		// loop for each employee
		for (int i = 0; i < employees.getLength(); i++) {
			emp = (Element) employees.item(i);
			String gender = emp.getElementsByTagName("gender").item(0).getFirstChild().getNodeValue();
			if (gender.equalsIgnoreCase("male")) {
				// prefix id attribute with M
				emp.setAttribute("id", "M" + emp.getAttribute("id"));
			} else {
				// prefix id attribute with F
				emp.setAttribute("id", "F" + emp.getAttribute("id"));
			}
		}
	}

	public void updateXMLTagValue(Document doc, String tagName, String newValue) throws Exception {
		doc.getElementsByTagName(tagName).item(0).setTextContent(newValue);
	}

	public void addXMLTagValue(Document doc, String nodeName, String newTag, String newValue) throws Exception {
		Element salaryElement = doc.createElement(newTag);
		salaryElement.appendChild(doc.createTextNode(newValue));
		doc.getElementsByTagName(nodeName).item(0).appendChild(salaryElement);

	}

//	public String convertDocumentToString(Document doc) throws Exception {
//
//		TransformerFactory tf = TransformerFactory.newInstance();
//		Transformer trans = tf.newTransformer();
//		StringWriter sw = new StringWriter();
//		trans.transform(new DOMSource(doc), new StreamResult(sw));
//		return sw.toString();
//	}
	
	
	
	//	public String convertDocumentToString(Document doc) throws Exception {
	//
	//		TransformerFactory tf = TransformerFactory.newInstance();
	//		Transformer trans = tf.newTransformer();
	//		// StringWriter sw = new StringWriter();
	//		// trans.transform(new DOMSource(doc), new StreamResult(sw));
	//		XMLStreamWriter sw = XMLOutputFactory.newFactory().createXMLStreamWriter(System.out);
	//		trans.transform(new DOMSource(doc), new StAXResult(sw));
	//		return sw.toString();
	//
	//	}

	public Document convertStringToDocument(String xmlStr) {
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		factory.setExpandEntityReferences(false);
		DocumentBuilder builder;
		try {
			builder = factory.newDocumentBuilder();
			Document doc = builder.parse(new InputSource(new StringReader(xmlStr)));
			return doc;
		} catch (Exception e) {
			logger.info("Exception :: "+CommonUtility.getPrintStackTrace(e));
		}
		return null;
	}
	
	public String convertDocumentToString(Document doc) throws Exception {

		TransformerFactory tf = TransformerFactory.newInstance();
		Transformer trans = tf.newTransformer();
		trans.setOutputProperty(OutputKeys.METHOD, "html");
		StringWriter sw = new StringWriter();
		trans.transform(new DOMSource(doc), new StreamResult(sw));
		return sw.toString();

		}


	public List<String> getNodeList(Document doc, String outTagName, String inTagName) {
		List<String> nodeList = new ArrayList<String>();
		try {
			NodeList list = doc.getElementsByTagName(outTagName);
			Element element = (Element) list.item(0);
			NodeList nodeListObj = element.getElementsByTagName(inTagName).item(0).getChildNodes();

			for (int i = 0; i < nodeListObj.getLength(); i++) {
				String item = nodeListObj.item(i).getFirstChild().getNodeValue();
				nodeList.add(item);
			}
		} catch (Exception e) {
			logger.info("Exception :: "+CommonUtility.getPrintStackTrace(e));
		}
		return nodeList;
	}

	public static void main(String[] args) {
		final String xmlStr = "";

		Document doc = new ModifyXMLDOM().convertStringToDocument(xmlStr);
		List<String> nodeList = new ModifyXMLDOM().getNodeList(doc, "FILLERS", "APPLNLOSFILLERSFILLERTEXT1");
		System.out.println("nodeList :: " + nodeList);
	}
}
