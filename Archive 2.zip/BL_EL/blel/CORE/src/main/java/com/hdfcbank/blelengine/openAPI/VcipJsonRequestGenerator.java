package com.hdfcbank.blelengine.openAPI;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.hdfcbank.blelengine.dao.Comondao;
import lombok.extern.log4j.Log4j2;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.xml.sax.SAXException;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.security.PublicKey;
import java.security.UnrecoverableEntryException;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;

/**
 * Generate Json request
 * 
 * @author Madhura Oak
 *
 */
@Service
@Log4j2
public class VcipJsonRequestGenerator {
	private static final String X509 = "X.509";
	private static final String CONFIG = "Config";
	public final static Logger logger = LoggerFactory.getLogger(DigitalSignature.class);


	@Autowired
	OAuthTokenGenerator authTokenGenerator;

	@Autowired
	private Comondao commondao;


	/**
	 * Load public key from the bank's public certificate
	 * 
	 * @throws FileNotFoundException
	 * @throws CertificateException
	 */
	private PublicKey initPublicKey() throws FileNotFoundException, CertificateException {
		X509Certificate bankCertificate = null;
		PublicKey		publicKey		= null;
		String vcipCertificateFilePath = commondao.getAPIConfigParameters("Adobe", "Disbursement", "Disbursement.vcipstatus.vcipCertificateFilePath");

		try(FileInputStream fin = new FileInputStream(vcipCertificateFilePath)) {
			CertificateFactory factory = CertificateFactory.getInstance(X509);
			bankCertificate = (X509Certificate) factory.generateCertificate(fin);	
			if(bankCertificate != null) {
				publicKey = bankCertificate.getPublicKey();
			}
		} catch (Exception e) {
			//e.printStackTrace();
			log.info("Exception ::" + e);
		}
		return publicKey;
	}

	/**
	 * Load public key from the bank's public certificate
	 * 
	 * @throws FileNotFoundException
	 * @throws CertificateException
	 */


	static { /*
				 * try { // initPublicKey(); } catch (CertificateException e) { //TODO handle
				 * exception } catch (FileNotFoundException e) { //TODO handle exception }
				 */
	}

	private Gson gson = new GsonBuilder().disableHtmlEscaping().create();

	/**
	 * Generate json request
	 *
	 * @param xmlRequest    - original XML request without digital signature
	 * @param scope
	 * @param transactionId - Unique transaction Id for every request
	 * @return json request String
	 * @throws CertificateException        if any of the certificate in the key
	 *                                     store cannot be loaded
	 * @throws UnrecoverableEntryException if the password is invalid or unable to
	 *                                     retrieve private key
	 * @throws SAXException                if the XML passed to this method cannot
	 *                                     be parsed
	 * @throws IOException                 if unable to read public key file
	 */
	public String generateRequest(String xmlRequest, String scope, String transactionId,String status)
			throws CertificateException, UnrecoverableEntryException, SAXException, IOException {
		PublicKey bankPublicKey = initPublicKey();
		JsonRequest request = new JsonRequest();
		VcipCallBackResponse backResponse = new VcipCallBackResponse();
		// create XML Digital Signature for original XML Request
		/*
		 * XMLDigitalSignature xmlDigitalSignature = new XMLDigitalSignature(); String
		 * signedXML = xmlDigitalSignature.sign(xmlRequest, clientKeyStoreFilePath,
		 * clientKeyStorePassword, clientKeyAlias); signedXML =
		 * signedXML.substring(signedXML.indexOf('>')+1); Logger.info("Signed XML : "
		 * +signedXML);
		 */
		// generate 32 byte random key
		KeyGenerator keyGenerator = new KeyGenerator();
		byte[] key = keyGenerator.generateKey(32);

		// encrypt encoded value using random key
		AESEncrypterDecrypter aesEncrypter = new AESEncrypterDecrypter();
		byte[] encryptedValue = aesEncrypter.encrypt(xmlRequest, key);

		// encode the encrypted request
		Base64EncoderDecoder encoder = new Base64EncoderDecoder();
		byte[] encodedValue = encoder.encode(encryptedValue);

		backResponse.setResponseEncryptedValue(new String(encodedValue));
//		logger.info("Request :" + new String(encodedValue));

		// encrypt symmetric key using bank's public key
		RSAEncrypterDecrypter rsaEncrypter = new RSAEncrypterDecrypter();
//		logger.info("bank public key :"+bankPublicKey);
		byte[] symmetricKeyEncryptedValue = rsaEncrypter.encrypt(key, bankPublicKey);

		// encode symmetric key
		encodedValue = encoder.encode(symmetricKeyEncryptedValue);
		backResponse.setGWSymmetricKeyEncryptedValue(new String(encodedValue));
//		logger.info("Key :" + new String(encodedValue));

		backResponse.setScope(scope);
		backResponse.setTransactionId(transactionId);
		backResponse.setStatus(status);
		// Generate OAUTH token
//		OAuthTokenGenerator oauthTokenGenerator = new OAuthTokenGenerator();
//		String oauthToken = authTokenGenerator.getOAuthToken(clientId, clientSecret, clientScope);
//		String oauthToken = "f58805c0-6527-47df-be1b-7ebeba3c11ef";
//		request.setOAuthTokenValue(oauthToken);

		// convert request object to json
		String gsonRequest = gson.toJson(backResponse);

		return gsonRequest;
	}




}
