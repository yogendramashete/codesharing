package com.hdfcbank.blelengine.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.http.HttpEntity;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.hdfcbank.blelengine.bean.common.CommonRequest;
import com.hdfcbank.blelengine.constants.AppConstants;


@Component
public class UtilClass {


	static Logger logger = LoggerFactory.getLogger(UtilClass.class.getName());



	public boolean isValidRequest(CommonRequest commonRequest){
		boolean flag = false;
		try {
			String inputString = commonRequest.getInputString() == null?"": commonRequest.getInputString() ;
			String randomNo=commonRequest.getRandomNo() ==null ?"": commonRequest.getRandomNo();
			String osType = commonRequest.getOsType() == null?"": commonRequest.getOsType() ;

			logger.info("inputString :"+inputString ) ;
			logger.info("randomNo :"+ randomNo ) ;
			logger.info("osType :"+ osType  );

			if(isValidValue(inputString)) {
				return true;
			}else if(isValidValue(randomNo)) {
				return true;
			}else if(isValidValue(osType)) {
				return true;
				
			}

		}catch(Exception e){
			logger.info("exception occured in isValidRequest ::"+e);
			//e.printStackTrace();
		}
		return flag;
	}


	public boolean isValidValue(String value) throws Exception{

		try {
			Pattern regex = Pattern.compile("[^/\\s-A-Za-z0-9_@#&.,+={}:]");
			Matcher matcher = regex.matcher(value);
			if (matcher.find()){
				return true;
			}else{
				return false;
			}

		} catch (Exception e) {
			//e.printStackTrace();
			logger.info("Exception ::",e);
		} 
		return false;
	}

	//	  public static void main(String[] args) throws Exception {
	//		System.out.println("isvalid :"+new UtilClass().isValidValue(""));
	//	}

	public static  String postMethodAPIRequest(String httpUrl, String request) throws IOException {

		String response = "";
		CloseableHttpClient httpClient = null;
		CloseableHttpResponse httpResponse = null;
		HttpPost httpPost = null;

		try {
			logger.info("Inside postMethodAPIRequest ... " + httpUrl + " :: request ::" + request);
			httpPost = new HttpPost(httpUrl);
			httpPost.setHeader("Content-Type", "application/json");

			RequestConfig requestConfig = RequestConfig.custom()
					.setConnectTimeout(20000)
					.setConnectionRequestTimeout(20000)
					.setSocketTimeout(60000).build();
			httpClient = HttpClientBuilder.create().setDefaultRequestConfig(requestConfig).build();
			StringEntity requestEntity = new StringEntity(request.toString());
			httpPost.setEntity(requestEntity);
			httpResponse = (CloseableHttpResponse) httpClient.execute(httpPost);

			logger.info("POST postMethodAPIRequest, StatusCode :: " + httpResponse.getStatusLine().getStatusCode());

			int statusCode = httpResponse.getStatusLine().getStatusCode();

			if (statusCode == 200) {
				final HttpEntity entity = httpResponse.getEntity();
				if (entity != null) {
					final InputStream instream = entity.getContent();
					response = convertStreamToString(instream);
					instream.close();
				}

			}
			logger.info("POST checkPaymentStatus Request, Response :" + response);

		} catch (UnsupportedOperationException e) {
			//commonException.getPrintStackTrace(e);
			logger.info("UnsupportedOperationException ::",e);

		} catch (IOException e) {
			//e.printStackTrace();
			//commonException.getPrintStackTrace(e);
			logger.info("IOException ::",e);
		} catch (Exception e) {
			//e.printStackTrace();
			//commonException.getPrintStackTrace(e);
			logger.info("Exception ::",e);
		} finally {
			if (null != httpResponse) {
				httpResponse.close();
			}
			if (httpClient != null) {
				httpClient.close();
			}
		}
		return response;

	}

	private static String convertStreamToString(final InputStream is) {

		final BufferedReader reader = new BufferedReader(new InputStreamReader(is));
		final StringBuilder sb = new StringBuilder();

		String line = null;
		try {
			while ((line = reader.readLine()) != null) {
				sb.append(line);
			}
		} catch (IOException e) {
			// commonException.getPrintStackTrace(e);
			//e.printStackTrace();
			logger.info("IOException ::",e);
		} finally {
			try {
				if (is != null) {
					is.close();
				}
				if (reader != null) {
					reader.close();
				}
			} catch (IOException e) {
				// commonException.getPrintStackTrace(e);
				//e.printStackTrace();
				logger.info("IOException ::",e);
			}
		}
		return String.valueOf(sb);
	}

	public  int ageCalculator(String date) {
		DateFormat dateFormat = new SimpleDateFormat(AppConstants.DATE_FMT_ddMMyyyy2, Locale.getDefault());

		int age = 0;
		try {
			Date date1 = dateFormat.parse(date);
			Calendar now = Calendar.getInstance();
			Calendar dob = Calendar.getInstance();
			dob.setTime(date1);
			if (dob.after(now)) {
				logger.info("Invalid Date Of Birth");
			}
			int year1 = now.get(Calendar.YEAR);
			int year2 = dob.get(Calendar.YEAR);
			age = year1 - year2;
			logger.info("Date Of Birth converted to age:: "+age);
		} catch (ParseException e) {
			//e.printStackTrace();
			logger.info("ParseException ::",e);
		}
		return age;
	}

	public static int calculateAge(LocalDate localDate, LocalDate currentDate) {

		if ((localDate != null) && (currentDate != null)) {
			return Period.between(localDate, currentDate).getYears();
		} else {
			return 0;

		}

	}

	public static void main(String[] args) throws IOException, ParseException {
		System.out.println(new UtilClass().ageCalculator("20-01-2000"));

	}

}
