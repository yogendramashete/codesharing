package com.hdfcbank.blelengine.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@Service
public class CommonUtil {

    public final static Logger logger = LoggerFactory.getLogger(CommonUtil.class);

    public Map<Integer,String>  convertStringtoHashMap(String inputString)
    {
        Map<Integer,String> hashMapResponse = new HashMap<>();
        String responseMapFromRedisString = inputString.substring(1, inputString.length()-1);           //remove curly brackets
        String[] keyValuePairsResponse = responseMapFromRedisString.split(",");              //split the string to creat key-value pairs


        for(String pair : keyValuePairsResponse)                        //iterate over the pairs
        {
            String[] entry = pair.split("=");                   //split the pairs to get key and value
            hashMapResponse.put(Integer.parseInt(entry[0].trim()), entry[1].trim());          //add them to the hashmap and trim whitespaces
        }

        return hashMapResponse;
    }

    public String getCurrentDate(String format)
    {

        SimpleDateFormat formatter = new SimpleDateFormat(format);
        Date date = new Date();
        return formatter.format(date);
    }
    public HashMap<String, String> splitFullName(String inputString) {

                HashMap<String, String> nameList = new HashMap<>();
        String firstName = "";
        String lastName = "";
        String middleName = null;
        if (!inputString.equals("")) {
            logger.info("customerFullName {}", inputString);
            String[] splittedNameArray = Arrays.stream(inputString.split(" "))
                    .map(String::trim)
                    .toArray(String[]::new);
            //for (String s : splittedNameArray) {

            firstName = splittedNameArray[0];
            int lengthName=splittedNameArray.length;

            if (lengthName == 3) {

                middleName = splittedNameArray[1];
                lastName = splittedNameArray[2];
            } else if (lengthName == 2){

                middleName = "";
                lastName = splittedNameArray[1];

            } else if (lengthName == 4) {

                middleName = splittedNameArray[1];;
                lastName = splittedNameArray[2] + splittedNameArray[3];
            }
            logger.info(" firstname {}", firstName);
            logger.info(" middleName {}", middleName);
            logger.info(" lastname {}", lastName);

        }
        nameList.put("firstName",firstName);
        nameList.put("middleName",middleName);
        nameList.put("lastName",lastName);

        return nameList;
    }


public String removeNamespaceXML(String inputString) throws ParserConfigurationException, TransformerException, IOException, SAXException {

String styleSheet="<xsl:stylesheet version=\"1.0\" xmlns:xsl=\"http://www.w3.org/1999/XSL/Transform\"><xsl:output method=\"xml\" indent=\"yes\" /> <xsl:template match=\"/|comment()|processing-instruction()\"> <xsl:copy> <xsl:apply-templates /> </xsl:copy> </xsl:template> <xsl:template match=\"*\"> <xsl:element name=\"{local-name()}\"> <xsl:apply-templates select=\"@*|node()\" /> </xsl:element> </xsl:template> <xsl:template match=\"@*\"> <xsl:attribute name=\"{local-name()}\"> <xsl:value-of select=\".\" /> </xsl:attribute> </xsl:template> </xsl:stylesheet>";

    DocumentBuilder db = DocumentBuilderFactory.newInstance().newDocumentBuilder();

    Document doc = db.parse(new ByteArrayInputStream(inputString.getBytes()));

    StringWriter outWriter = new StringWriter();
    StreamResult result = new StreamResult( outWriter );
    TransformerFactory transformerFactory = TransformerFactory.newInstance();
    // add XSLT in Transformer
    Transformer transformer = transformerFactory.newTransformer( new StreamSource(new ByteArrayInputStream(styleSheet.getBytes())));

    transformer.transform(new DOMSource(doc), result);


    return outWriter.toString();
}

}
