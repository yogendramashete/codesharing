package com.hdfcbank.blelengine.openAPI;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.hdfcbank.blelengine.dao.Comondao;
import com.hdfcbank.blelengine.util.RedisUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.xml.sax.SAXException;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.security.PublicKey;
import java.security.UnrecoverableEntryException;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;

/**
 * Generate Json request
 * 
 * @author Madhura Oak
 *
 */
@Service
public class JsonRequestGenerator {
	private static final String X509 = "X.509";
	private static final String CONFIG = "Config";
	public final static Logger logger = LoggerFactory.getLogger(DigitalSignature.class);

//	@Value("${jsonrequestgenerator.bankcertificatefilepath}")
//	String bankCertificateFilePath;
	
	@Value("${jsonrequestgenerator.blelbankcertificatefilepath}")
	String BLELbankCertificateFilePath;

	@Value("${jsonrequestgenerator.blelclientid}")
	String BLELclientId;

	@Value("${jsonrequestgenerator.blelclientsecret}")
	String BLELclientSecret;

	@Value("${openbankapiconnector.blelclientscope}")
	String BLELclientScope;


	
		@Autowired
	OAuthTokenGenerator authTokenGenerator;

	@Autowired
	private Comondao commondao;

	@Autowired
	private RedisUtils redisUtils;
		/**
	 * Load public key from the bank's public certificate
	 * 
	 * @throws FileNotFoundException
	 * @throws CertificateException
	 */


	private Gson gson = new GsonBuilder().disableHtmlEscaping().create();



	public String generateRequestBLEL(String xmlRequest, String scope, String transactionId)
			throws CertificateException, UnrecoverableEntryException, SAXException, IOException {
		PublicKey bankPublicKey = initBLELPublicKey();
		JsonRequest request = new JsonRequest();

		KeyGenerator keyGenerator = new KeyGenerator();
		String alphakey = keyGenerator.generateAlphaNumericKey(32);

		logger.info(" alphakey Key :" + alphakey);

		byte[] key = alphakey.getBytes();

		// encrypt encoded value using random key
		AESEncrypterDecrypter aesEncrypter = new AESEncrypterDecrypter();
		byte[] encryptedValue = aesEncrypter.encrypt(xmlRequest, key);

		// encode the encrypted request
		Base64EncoderDecoder encoder = new Base64EncoderDecoder();
		byte[] encodedValue = encoder.encode(encryptedValue);

		request.setRequestSignatureEncryptedValue(new String(encodedValue));
//		logger.info("Request :" + new String(encodedValue));

		// encrypt symmetric key using bank's public key
		RSAEncrypterDecrypter rsaEncrypter = new RSAEncrypterDecrypter();
//		logger.info("bank public key :"+bankPublicKey);
		byte[] symmetricKeyEncryptedValue = rsaEncrypter.encrypt(key, bankPublicKey);

		// encode symmetric key
		encodedValue = encoder.encode(symmetricKeyEncryptedValue);
		request.setSymmetricKeyEncryptedValue(new String(encodedValue));
//		logger.info("Key :" + new String(encodedValue));

		request.setScope(BLELclientScope);
		request.setTransactionId(transactionId);


		String oauthToken = authTokenGenerator.getOAuthTokenBLEL(BLELclientId, BLELclientSecret, BLELclientScope);
		request.setOAuthTokenValue(oauthToken);
		String outhtoken="";
		logger.info("oauthToken" + oauthToken);
		String gsonRequest = null;
		if (oauthToken.equals("")) {
			outhtoken = "NO_OAUTHTOKEN";
			gsonRequest=outhtoken;
		} else {
			// convert request object to json
			gsonRequest = gson.toJson(request);
		}
		logger.info("gsonRequest" + gsonRequest);

		return gsonRequest;
	}

	public String generateGstnRequestBLEL(String xmlRequest, String scope, String transactionId)
			throws CertificateException, UnrecoverableEntryException, SAXException, IOException {
		PublicKey bankPublicKey = initBLELPublicKey();
		JsonRequest2 request = new JsonRequest2();

		KeyGenerator keyGenerator = new KeyGenerator();
		String alphakey = keyGenerator.generateAlphaNumericKey(32);

		logger.info(" alphakey Key :" + alphakey);

		byte[]  key=alphakey.getBytes();

		// encrypt encoded value using random key
		AESEncrypterDecrypter aesEncrypter = new AESEncrypterDecrypter();
		byte[] encryptedValue = aesEncrypter.encrypt(xmlRequest, key);

		// encode the encrypted request
		Base64EncoderDecoder encoder = new Base64EncoderDecoder();
		byte[] encodedValue = encoder.encode(encryptedValue);

		request.setRequestEncryptedValue(new String(encodedValue));
//		logger.info("Request :" + new String(encodedValue));

		// encrypt symmetric key using bank's public key
		RSAEncrypterDecrypter rsaEncrypter = new RSAEncrypterDecrypter();
//		logger.info("bank public key :"+bankPublicKey);
		byte[] symmetricKeyEncryptedValue = rsaEncrypter.encrypt(key, bankPublicKey);

		// encode symmetric key
		encodedValue = encoder.encode(symmetricKeyEncryptedValue);
		request.setSymmetricKeyEncryptedValue(new String(encodedValue));
//		logger.info("Key :" + new String(encodedValue));

		request.setScope(BLELclientScope);
		request.setTransactionId(transactionId);


		String oauthToken = ""; //authTokenGenerator.getOAuthTokenBLEL(BLELclientId, BLELclientSecret, BLELclientScope);
		request.setOAuthTokenValue(oauthToken);

		logger.info("oauthToken"+ oauthToken);

		// convert request object to json
		String gsonRequest = gson.toJson(request);

		logger.info("gsonRequest"+ gsonRequest);

		return gsonRequest;
	}
	private PublicKey initBLELPublicKey() throws FileNotFoundException, CertificateException {
		X509Certificate bankCertificate = null;
		PublicKey publicKey = null;
		try (FileInputStream fin = new FileInputStream(BLELbankCertificateFilePath)) {
			CertificateFactory factory = CertificateFactory.getInstance(X509);
			bankCertificate = (X509Certificate) factory.generateCertificate(fin);
			if(bankCertificate != null) {
				publicKey = bankCertificate.getPublicKey();
			}
		} catch (Exception e) {
			//e.printStackTrace();
			logger.info("Exception :" + e);
		}
		if (publicKey != null) {
			logger.info(publicKey+publicKey.toString());//+"bankCertificate"+ bankCertificate);
		}
		
		return publicKey;
	}

	public String generateRequestBLELGetDemog(String xmlRequest, String scope, String transactionId)
			throws CertificateException, UnrecoverableEntryException, SAXException, IOException {
		PublicKey bankPublicKey = initBLELPublicKey();
		JsonRequest request = new JsonRequest();

		KeyGenerator keyGenerator = new KeyGenerator();
		String alphakey = keyGenerator.generateAlphaNumericKey(32);

		logger.info(" alphakey Key :" + alphakey);

		byte[]  key=alphakey.getBytes();

		// encrypt encoded value using random key
		AESEncrypterDecrypter aesEncrypter = new AESEncrypterDecrypter();
		byte[] encryptedValue = aesEncrypter.encrypt(xmlRequest, key);

		// encode the encrypted request
		Base64EncoderDecoder encoder = new Base64EncoderDecoder();
		byte[] encodedValue = encoder.encode(encryptedValue);

		request.setRequestSignatureEncryptedValue(new String(encodedValue));
//		logger.info("Request :" + new String(encodedValue));

		// encrypt symmetric key using bank's public key
		RSAEncrypterDecrypter rsaEncrypter = new RSAEncrypterDecrypter();
//		logger.info("bank public key :"+bankPublicKey);
		byte[] symmetricKeyEncryptedValue = rsaEncrypter.encrypt(key, bankPublicKey);

		// encode symmetric key
		encodedValue = encoder.encode(symmetricKeyEncryptedValue);
		request.setSymmetricKeyEncryptedValue(new String(encodedValue));
//		logger.info("Key :" + new String(encodedValue));

		request.setScope(scope);
		request.setTransactionId(transactionId);


		String oauthToken = authTokenGenerator.getOAuthTokenBLEL(BLELclientId, BLELclientSecret, scope);
		request.setOAuthTokenValue(oauthToken);

		logger.info("oauthToken"+ oauthToken);

		// convert request object to json
		String gsonRequest = gson.toJson(request);

		logger.info("gsonRequest"+ gsonRequest);

		return gsonRequest;
	}

	public String generateRequestSignzyBLEL(String xmlRequest, String scope, String transactionId)
			throws CertificateException, UnrecoverableEntryException, SAXException, IOException {
		PublicKey bankPublicKey = initBLELPublicKey();
		JsonRequest2 request = new JsonRequest2();
		KeyGenerator keyGenerator = new KeyGenerator();

		String alphakey = keyGenerator.generateAlphaNumericKey(32);
		redisUtils.set("alphanumerickey",alphakey);

		logger.info(" alphakey Key :" + alphakey);

		byte[]  key=alphakey.getBytes();
		//KeyGenerator keyGenerator = new KeyGenerator();
		//byte[] key = keyGenerator.generateKey(32);

		/*logger.info(" alphakey Key :" + alphakey);

		byte[]  key=alphakey.getBytes();*/

		// encrypt encoded value using random key
		AESEncrypterDecrypter aesEncrypter = new AESEncrypterDecrypter();
		byte[] encryptedValue = aesEncrypter.encrypt(xmlRequest, key);

		// encode the encrypted request
		Base64EncoderDecoder encoder = new Base64EncoderDecoder();
		byte[] encodedValue = encoder.encode(encryptedValue);

		request.setRequestEncryptedValue(new String(encodedValue));
		logger.info("RequestEncryptedValue :" + new String(encodedValue));
//		logger.info("Request :" + new String(encodedValue));

		// encrypt symmetric key using bank's public key
		RSAEncrypterDecrypter rsaEncrypter = new RSAEncrypterDecrypter();
//		logger.info("bank public key :"+bankPublicKey);
		byte[] symmetricKeyEncryptedValue = rsaEncrypter.encrypt(key, bankPublicKey);

		// encode symmetric key
		encodedValue = encoder.encode(symmetricKeyEncryptedValue);
		request.setSymmetricKeyEncryptedValue(new String(encodedValue));
//		logger.info("Key :" + new String(encodedValue));

		request.setScope(scope);
		request.setTransactionId(transactionId);


		/*String oauthToken = authTokenGenerator.getOAuthTokenBLEL(BLELclientId, BLELclientSecret, BLELclientScope);
		logger.info("outhtoken added:"+oauthToken);*/
		//request.setOAuthTokenValue(oauthToken);

		request.setOAuthTokenValue("");

		//logger.info("oauthToken"+ oauthToken);

		// convert request object to json
		String gsonRequest = gson.toJson(request);

		logger.info("gsonRequest"+ gsonRequest);

		return gsonRequest;
	}
	public String generateRequestICAIDataBLEL(String xmlRequest, String scope, String transactionId)
			throws CertificateException, UnrecoverableEntryException, SAXException, IOException {
		PublicKey bankPublicKey = initBLELPublicKey();
		JsonRequest2 request = new JsonRequest2();
		KeyGenerator keyGenerator = new KeyGenerator();

		String alphakey = keyGenerator.generateAlphaNumericKey(32);
		redisUtils.set("alphanumerickey",alphakey);

		logger.info(" alphakey Key :" + alphakey);

		byte[]  key=alphakey.getBytes();
		//KeyGenerator keyGenerator = new KeyGenerator();
		//byte[] key = keyGenerator.generateKey(32);

		/*logger.info(" alphakey Key :" + alphakey);

		byte[]  key=alphakey.getBytes();*/

		// encrypt encoded value using random key
		AESEncrypterDecrypter aesEncrypter = new AESEncrypterDecrypter();
		byte[] encryptedValue = aesEncrypter.encrypt(xmlRequest, key);

		// encode the encrypted request
		Base64EncoderDecoder encoder = new Base64EncoderDecoder();
		byte[] encodedValue = encoder.encode(encryptedValue);

		request.setRequestEncryptedValue(new String(encodedValue));
		logger.info("RequestEncryptedValue :" + new String(encodedValue));
//		logger.info("Request :" + new String(encodedValue));

		// encrypt symmetric key using bank's public key
		RSAEncrypterDecrypter rsaEncrypter = new RSAEncrypterDecrypter();
//		logger.info("bank public key :"+bankPublicKey);
		byte[] symmetricKeyEncryptedValue = rsaEncrypter.encrypt(key, bankPublicKey);

		// encode symmetric key
		encodedValue = encoder.encode(symmetricKeyEncryptedValue);
		request.setSymmetricKeyEncryptedValue(new String(encodedValue));
//		logger.info("Key :" + new String(encodedValue));

		request.setScope(scope);
		request.setTransactionId(transactionId);


		/*String oauthToken = authTokenGenerator.getOAuthTokenBLEL(BLELclientId, BLELclientSecret, BLELclientScope);
		logger.info("outhtoken added:"+oauthToken);*/
		//request.setOAuthTokenValue(oauthToken);

		request.setOAuthTokenValue("");

		//logger.info("oauthToken"+ oauthToken);

		// convert request object to json
		String gsonRequest = gson.toJson(request);

		logger.info("gsonRequest"+ gsonRequest);

		return gsonRequest;
	}
	public String generateRequestGetMCIDataBLEL(String xmlRequest, String scope, String transactionId)
			throws CertificateException, UnrecoverableEntryException, IOException {
		PublicKey bankPublicKey = initBLELPublicKey();
		JsonRequest2 request = new JsonRequest2();
		KeyGenerator keyGenerator = new KeyGenerator();
		String alphakey = keyGenerator.generateAlphaNumericKey(32);
		redisUtils.set("alphanumerickey",alphakey);
		logger.info(" alphakey Key :" + alphakey);
		byte[]  key=alphakey.getBytes();
		//KeyGenerator keyGenerator = new KeyGenerator();
		//byte[] key = keyGenerator.generateKey(32);
      /*logger.info(" alphakey Key :" + alphakey);
      byte[]  key=alphakey.getBytes();*/
		// encrypt encoded value using random key
		AESEncrypterDecrypter aesEncrypter = new AESEncrypterDecrypter();
		byte[] encryptedValue = aesEncrypter.encrypt(xmlRequest, key);
		// encode the encrypted request
		Base64EncoderDecoder encoder = new Base64EncoderDecoder();
		byte[] encodedValue = encoder.encode(encryptedValue);
		request.setRequestEncryptedValue(new String(encodedValue));
		//logger.info("RequestEncryptedValue :" + new String(encodedValue));
//    logger.info("Request :" + new String(encodedValue));
		// encrypt symmetric key using bank's public key
		RSAEncrypterDecrypter rsaEncrypter = new RSAEncrypterDecrypter();
//    logger.info("bank public key :"+bankPublicKey);
		byte[] symmetricKeyEncryptedValue = rsaEncrypter.encrypt(key, bankPublicKey);
		// encode symmetric key
		encodedValue = encoder.encode(symmetricKeyEncryptedValue);
		request.setSymmetricKeyEncryptedValue(new String(encodedValue));
//    logger.info("Key :" + new String(encodedValue));
		request.setScope(scope);
		request.setTransactionId(transactionId);

      /*String oauthToken = authTokenGenerator.getOAuthTokenBLEL(BLELclientId, BLELclientSecret, BLELclientScope);
      logger.info("outhtoken added:"+oauthToken);*/
		//request.setOAuthTokenValue(oauthToken);
		request.setOAuthTokenValue("");
		//logger.info("oauthToken"+ oauthToken);
		// convert request object to json
		String gsonRequest = gson.toJson(request);
		//logger.info("gsonRequest"+ gsonRequest);
		return gsonRequest;
	}

	public String generateRequestGetElectricitystatus(String xmlRequest, String scope, String transactionId)
			throws CertificateException, UnrecoverableEntryException, SAXException, IOException {
		PublicKey bankPublicKey = initBLELPublicKey();
		JsonRequest2 request = new JsonRequest2();
		KeyGenerator keyGenerator = new KeyGenerator();

		String alphakey = keyGenerator.generateAlphaNumericKey(32);
		redisUtils.set("alphanumerickey",alphakey);

		logger.info(" alphakey Key :" + alphakey);

		byte[]  key=alphakey.getBytes();
		//KeyGenerator keyGenerator = new KeyGenerator();
		//byte[] key = keyGenerator.generateKey(32);

		/*logger.info(" alphakey Key :" + alphakey);

		byte[]  key=alphakey.getBytes();*/

		// encrypt encoded value using random key
		AESEncrypterDecrypter aesEncrypter = new AESEncrypterDecrypter();
		byte[] encryptedValue = aesEncrypter.encrypt(xmlRequest, key);

		// encode the encrypted request
		Base64EncoderDecoder encoder = new Base64EncoderDecoder();
		byte[] encodedValue = encoder.encode(encryptedValue);

		request.setRequestEncryptedValue(new String(encodedValue));
		logger.info("RequestEncryptedValue :" + new String(encodedValue));
//		logger.info("Request :" + new String(encodedValue));

		// encrypt symmetric key using bank's public key
		RSAEncrypterDecrypter rsaEncrypter = new RSAEncrypterDecrypter();
//		logger.info("bank public key :"+bankPublicKey);
		byte[] symmetricKeyEncryptedValue = rsaEncrypter.encrypt(key, bankPublicKey);

		// encode symmetric key
		encodedValue = encoder.encode(symmetricKeyEncryptedValue);
		request.setSymmetricKeyEncryptedValue(new String(encodedValue));
//		logger.info("Key :" + new String(encodedValue));

		request.setScope(scope);
		request.setTransactionId(transactionId);


		/*String oauthToken = authTokenGenerator.getOAuthTokenBLEL(BLELclientId, BLELclientSecret, BLELclientScope);
		logger.info("outhtoken added:"+oauthToken);*/
		//request.setOAuthTokenValue(oauthToken);

		request.setOAuthTokenValue("");

		//logger.info("oauthToken"+ oauthToken);

		// convert request object to json
		String gsonRequest = gson.toJson(request);

		logger.info("gsonRequest"+ gsonRequest);

		return gsonRequest;
	}



}
