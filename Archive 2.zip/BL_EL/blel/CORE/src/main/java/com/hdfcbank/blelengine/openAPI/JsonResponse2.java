package com.hdfcbank.blelengine.openAPI;

/**
 * Json Response
 * @author Madhura Oak
 *
 */
public class JsonResponse2 {
	private String ResponseEncryptedValue;
	private String GWSymmetricKeyEncryptedValue;
	private String Scope;
	private String TransactionId;
	private String OAuthTokenValue; 
	private String Status;
	
	public String getStatus() {
		return Status;
	}
	public void setStatus(String status) {
		Status = status;
	}
	
	
	public String getResponseEncryptedValue() {
		return ResponseEncryptedValue;
	}
	public void setResponseEncryptedValue(String responseEncryptedValue) {
		ResponseEncryptedValue = responseEncryptedValue;
	}
	public String getGWSymmetricKeyEncryptedValue() {
		return GWSymmetricKeyEncryptedValue;
	}
	public void setGWSymmetricKeyEncryptedValue(String gWSymmetricKeyEncryptedValue) {
		GWSymmetricKeyEncryptedValue = gWSymmetricKeyEncryptedValue;
	}
	public String getScope() {
		return Scope;
	}
	public void setScope(String scope) {
		Scope = scope;
	}
	public String getTransactionId() {
		return TransactionId;
	}
	public void setTransactionId(String transactionId) {
		TransactionId = transactionId;
	}
	public String getOAuthTokenValue() {
		return OAuthTokenValue;
	}
	public void setOAuthTokenValue(String oAuthTokenValue) {
		OAuthTokenValue = oAuthTokenValue;
	}	
}
