package com.hdfcbank.blelengine.openAPI;

import com.google.gson.Gson;

/**
 * Get Json Response object from String json response
 * 
 * @author Madhura Oak
 *
 */
public class JsonResponseReader {
	private Gson gson = new Gson();

	/**
	 * Get json response
	 * 
	 * @param jsonResponse
	 * @return
	 */
	public JsonResponse read(String jsonResponse) {
		JsonResponse response = gson.fromJson(jsonResponse, JsonResponse.class);
		return response;


	}

	public JsonResponse2 readNew(String jsonResponse) {
		JsonResponse2 response = gson.fromJson(jsonResponse, JsonResponse2.class);
		return response;
	}

	/**
	 * Get json response
	 * 
	 * @param jsonResponse
	 * @return
	 */




	/**
	 * Get json response
	 * 
	 * @param jsonResponse
	 * @return
	 */


	public PanValidationJsonResponse panRead(String jsonResponse) {
		PanValidationJsonResponse response = gson.fromJson(jsonResponse, PanValidationJsonResponse.class);
		return response;
	}


	public VcipJsonRequest vcipRequestRead(String jsonResponse) {
		VcipJsonRequest request = gson.fromJson(jsonResponse, VcipJsonRequest.class);
		return request;
	}
	

}
