package com.hdfcbank.blelengine.util;

import java.util.HashMap;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.json.XML;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hdfcbank.blelengine.constants.AppConstants;
import com.hdfcbank.blelengine.constants.RedisConstants;
import com.hdfcbank.blelengine.constants.StaticConstants;

import com.jayway.jsonpath.JsonPath;


@Component
public class BREUtil {

	private static final Logger logger = LoggerFactory.getLogger(BREUtil.class);

	@Autowired
	private ModifyXMLDOM modifyXMLDOM;

	@Autowired
	private NTBLoanUtil ntbLoanUtil;

	@Autowired
	private RedisUtils redisUtils;


	@Autowired
	private UtilClass utilClass;


	@Autowired
	private CommonUtility commonUtility;



	private String getData(String data, String path) {
		String stringXML = "";
		try {
			Object result = JsonPath.read(data, "$." + path);
			System.out.println(result.toString());
			String str = result.toString().replaceAll("=", ":");
			if (!StringUtils.isEmpty(str)) {
				if (str.contains(":")) {
					org.json.JSONObject jsonObject = new org.json.JSONObject(str);
					stringXML = XML.toString(jsonObject);
				} else {
					stringXML = str;
				}
			}
		} catch (Exception e) {
			logger.info("Exception :: "+CommonUtility.getPrintStackTrace(e));
		}
		return stringXML;
	}

	@SuppressWarnings("unchecked")
	public HashMap<String, String> getPerfiosData(String mobileNumber, String txnId) {
		HashMap<String, String> perfiosMapObj = new HashMap<String, String>();
		try {

			String perfiosXMLReq = "";

			// TODO below condition reserved because not having matching dtls with BRE1
			if (!AppConstants.IS_BRE_STATIC) {
				perfiosXMLReq = redisUtils
						.get(RedisConstants.PERFIOS_RETRIVE_DATA + mobileNumber + RedisConstants.US + txnId);
				logger.info("Redis getPerfiosData  xmlRequest :: " + perfiosXMLReq.length());
			} else {
				perfiosXMLReq = StaticConstants.PERFIOS_STATIC_RESP;
			}

			logger.info("perfiosXMLReq :: " + perfiosXMLReq.length());
			org.json.JSONObject xmlJSONObj = XML.toJSONObject(perfiosXMLReq);

			String jsonPrettyPrintString = xmlJSONObj.toString(AppConstants.PRETTY_PRINT_INDENT_FACTOR)
					.replaceAll("(\r\n|\n)", "").replaceAll("  ", "").replaceAll("PIR:", "");
			JSONParser jsonParser = new JSONParser();
			JSONObject jsonRequest = (JSONObject) jsonParser.parse(jsonPrettyPrintString);
			logger.info("BRE2 perfios jsonRequest :: " + jsonRequest);
			JSONObject dataObj = (JSONObject) jsonRequest.get("Data");
			JSONObject scoringDetailsObj = (JSONObject) dataObj.get("ScoringDetails");
			JSONArray detailArr = (JSONArray) scoringDetailsObj.get("Detail");

			JSONObject customerInfoObj = (JSONObject) dataObj.get("CustomerInfo");
			JSONObject additionalParametersObj = (JSONObject) dataObj.get("AdditionalParameters");
			//
			JSONObject summaryInfoObj = (JSONObject) dataObj.get("SummaryInfo");
			JSONObject monthlyObj = (JSONObject) dataObj.get("MonthlyDetails");

			Object monthlyObjectArr = monthlyObj.get("MonthlyDetail");
			JSONArray monthlyArr = new JSONArray();
			if (monthlyObjectArr instanceof JSONObject) {
				JSONObject monthlyInnerObj = (JSONObject) monthlyObj.get("MonthlyDetail");
				// logger.info("monthlyInnerObj :: " + monthlyInnerObj);
				monthlyArr.add(monthlyInnerObj);
			} else {
				monthlyArr = (JSONArray) monthlyObj.get("MonthlyDetail");
			}

			JSONArray emiEcsXnsArr = new JSONArray();
			if (dataObj.containsKey("EMIECSXns")) {
				JSONObject emiEcsXnsObj = (JSONObject) dataObj.get("EMIECSXns");
				Object emiEcsXnsObjectArr = emiEcsXnsObj.get("EMIECSXn");
				if (emiEcsXnsObjectArr instanceof JSONObject) {
					JSONObject emiEcsXnsInnerObj = (JSONObject) emiEcsXnsObj.get("EMIECSXn");
					emiEcsXnsArr.add(emiEcsXnsInnerObj);
				} else {
					emiEcsXnsArr = (JSONArray) emiEcsXnsObj.get("EMIECSXn");
				}
			}

			JSONObject xnsObj = (JSONObject) dataObj.get("Xns");
			JSONArray xnsObjArr = (JSONArray) xnsObj.get("Xn");

			JSONObject eodBalancesObj = (JSONObject) dataObj.get("EODBalances");
			JSONArray eodBalancesArr = (JSONArray) eodBalancesObj.get("EODBalance");

			JSONObject totalObj = (JSONObject) summaryInfoObj.get("Total");
			JSONObject avgObj = (JSONObject) summaryInfoObj.get("Average");

			perfiosMapObj.put("durationInMonths",
					StringUtils.isBlank(customerInfoObj.get("durationInMonths") == null ? ""
							: customerInfoObj.get("durationInMonths").toString()) == true ? "Z"
									: customerInfoObj.get("durationInMonths").toString());

			perfiosMapObj.put("endDate",
					StringUtils.isBlank(customerInfoObj.get("endDate") == null ? ""
							: customerInfoObj.get("endDate").toString()) == true ? AppConstants.DEFAULT_DATE
									: customerInfoObj.get("endDate").toString());

			perfiosMapObj.put("startDate",
					StringUtils.isBlank(customerInfoObj.get("startDate") == null ? ""
							: customerInfoObj.get("startDate").toString()) == true ? AppConstants.DEFAULT_DATE
									: customerInfoObj.get("startDate").toString());

			perfiosMapObj.put("sourceOfData",
					StringUtils.isBlank(customerInfoObj.get("sourceOfData") == null ? ""
							: customerInfoObj.get("sourceOfData").toString()) == true ? "Z"
									: customerInfoObj.get("sourceOfData").toString());

			perfiosMapObj.put("instId",
					StringUtils.isBlank(customerInfoObj.get("instId") == null ? ""
							: customerInfoObj.get("instId").toString()) == true ? "Z"
									: customerInfoObj.get("instId").toString());

			perfiosMapObj.put("bank",
					StringUtils.isBlank(
							customerInfoObj.get("bank") == null ? "" : customerInfoObj.get("bank").toString()) == true
									? "Z"
									: customerInfoObj.get("bank").toString());

			perfiosMapObj.put("customerTransactionId",
					StringUtils.isBlank(customerInfoObj.get("customerTransactionId") == null ? ""
							: customerInfoObj.get("customerTransactionId").toString()) == true ? "Z"
									: customerInfoObj.get("customerTransactionId").toString());

			perfiosMapObj.put("perfiosTransactionId",
					StringUtils.isBlank(customerInfoObj.get("perfiosTransactionId") == null ? ""
							: customerInfoObj.get("perfiosTransactionId").toString()) == true ? "Z"
									: customerInfoObj.get("perfiosTransactionId").toString());

			perfiosMapObj.put("pan",
					StringUtils.isBlank(
							customerInfoObj.get("pan") == null ? "" : customerInfoObj.get("pan").toString()) == true
									? "Z"
									: customerInfoObj.get("pan").toString());

			perfiosMapObj.put("email",
					StringUtils.isBlank(
							customerInfoObj.get("email") == null ? "" : customerInfoObj.get("email").toString()) == true
									? "Z"
									: customerInfoObj.get("email").toString());

			perfiosMapObj.put("mobile",
					StringUtils.isBlank(customerInfoObj.get("mobile") == null ? ""
							: customerInfoObj.get("mobile").toString()) == true ? "Z"
									: customerInfoObj.get("mobile").toString());

			perfiosMapObj.put("landline",
					StringUtils.isBlank(customerInfoObj.get("landline") == null ? ""
							: customerInfoObj.get("landline").toString()) == true ? "Z"
									: customerInfoObj.get("landline").toString());

			perfiosMapObj.put("address",
					StringUtils.isBlank(customerInfoObj.get("address") == null ? ""
							: customerInfoObj.get("address").toString()) == true ? "Z"
									: customerInfoObj.get("address").toString());

			perfiosMapObj.put("name",
					StringUtils.isBlank(
							customerInfoObj.get("name") == null ? "" : customerInfoObj.get("name").toString()) == true
									? "Z"
									: customerInfoObj.get("name").toString());

			logger.info("RedisConstants.BRE2_PERFIOS_CUST_NAME:: " + customerInfoObj.get("name") == null ? ""
					: customerInfoObj.get("name").toString());
			// Customer name setting in redis start
			redisUtils.set(RedisConstants.BRE2_PERFIOS_CUST_NAME + mobileNumber + RedisConstants.US + txnId,
					customerInfoObj.get("name") == null ? "" : customerInfoObj.get("name").toString());
			// Customer name setting in redis end 28-12-2020

			perfiosMapObj.put("employerName",
					StringUtils.isBlank(additionalParametersObj.get("employerName") == null ? ""
							: additionalParametersObj.get("employerName").toString()) == true ? "Z"
									: additionalParametersObj.get("employerName").toString());

			perfiosMapObj.put("applicantType",
					StringUtils.isBlank(additionalParametersObj.get("applicantType") == null ? ""
							: additionalParametersObj.get("applicantType").toString()) == true ? "Z"
									: additionalParametersObj.get("applicantType").toString());

			perfiosMapObj.put("sourceSystem",
					StringUtils.isBlank(additionalParametersObj.get("sourceSystem") == null ? ""
							: additionalParametersObj.get("sourceSystem").toString()) == true ? "Z"
									: additionalParametersObj.get("sourceSystem").toString());

			perfiosMapObj.put("referenceNumber",
					StringUtils.isBlank(additionalParametersObj.get("referenceNumber") == null ? ""
							: additionalParametersObj.get("referenceNumber").toString()) == true ? "Z"
									: additionalParametersObj.get("referenceNumber").toString());

			perfiosMapObj.put("productType",
					StringUtils.isBlank(additionalParametersObj.get("productType") == null ? ""
							: additionalParametersObj.get("productType").toString()) == true ? "Z"
									: additionalParametersObj.get("productType").toString());

			perfiosMapObj.put("dateOfApplication",
					StringUtils.isBlank(additionalParametersObj.get("dateOfApplication") == null ? ""
							: additionalParametersObj.get("dateOfApplication").toString()) == true ? "Z"
									: additionalParametersObj.get("dateOfApplication").toString());

			String variable = ntbLoanUtil.getItemArray(detailArr, "variable", AppConstants.TAG_TYPE_STRING);
			perfiosMapObj.put("variable", variable);

			String value = ntbLoanUtil.getItemArray(detailArr, "value", AppConstants.TAG_TYPE_STRING);
			perfiosMapObj.put("value", value);

			perfiosMapObj.put("instName",
					StringUtils.isBlank(summaryInfoObj.get("instName") == null ? ""
							: summaryInfoObj.get("instName").toString()) == true ? "Z"
									: summaryInfoObj.get("instName").toString());

			perfiosMapObj.put("accNo",
					StringUtils.isBlank(
							summaryInfoObj.get("accNo") == null ? "" : summaryInfoObj.get("accNo").toString()) == true
									? "Z"
									: summaryInfoObj.get("accNo").toString());

			perfiosMapObj.put("accType",
					StringUtils.isBlank(summaryInfoObj.get("accType") == null ? ""
							: summaryInfoObj.get("accType").toString()) == true ? "Z"
									: summaryInfoObj.get("accType").toString());

			String fullMonthCount = summaryInfoObj.get("fullMonthCount") == null ? "0"
					: summaryInfoObj.get("fullMonthCount").toString();
			perfiosMapObj.put("fullMonthCount", fullMonthCount);

			String score = summaryInfoObj.get("score") == null ? "0" : summaryInfoObj.get("score").toString();
			perfiosMapObj.put("score", score);

			String totalSalary = totalObj.get("totalSalary") == null ? "0" : totalObj.get("totalSalary").toString();
			perfiosMapObj.put("totalSalary", totalSalary);

			String totalInvExpense = totalObj.get("totalInvExpense") == null ? "0"
					: totalObj.get("totalInvExpense").toString();
			perfiosMapObj.put("totalInvExpense", totalInvExpense);

			String totalInterestIncome = totalObj.get("totalInterestIncome") == null ? "0"
					: totalObj.get("totalInterestIncome").toString();
			perfiosMapObj.put("totalInterestIncome", totalInterestIncome);

			String totalInterestCharged = totalObj.get("totalInterestCharged") == null ? "0"
					: totalObj.get("totalInterestCharged").toString();
			perfiosMapObj.put("totalInterestCharged", totalInterestCharged);

			String totalInsuranceExpense = totalObj.get("totalInsuranceExpense") == null ? "0"
					: totalObj.get("totalInsuranceExpense").toString();
			perfiosMapObj.put("totalInsuranceExpense", totalInsuranceExpense);

			String totalEmiEcsIssue = totalObj.get("totalEmiEcsIssue") == null ? "0"
					: totalObj.get("totalEmiEcsIssue").toString();
			perfiosMapObj.put("totalEmiEcsIssue", totalEmiEcsIssue);

			String totalDebit = totalObj.get("totalDebit") == null ? "0" : totalObj.get("totalDebit").toString();
			perfiosMapObj.put("totalDebit", totalDebit);

			String totalCredit = totalObj.get("totalCredit") == null ? "0" : totalObj.get("totalCredit").toString();
			perfiosMapObj.put("totalCredit", totalCredit);

			String totalChqIssue = totalObj.get("totalChqIssue") == null ? "0"
					: totalObj.get("totalChqIssue").toString();
			perfiosMapObj.put("totalChqIssue", totalChqIssue);

			String totalChqDeposit = totalObj.get("totalChqDeposit") == null ? "0"
					: totalObj.get("totalChqDeposit").toString();
			perfiosMapObj.put("totalChqDeposit", totalChqDeposit);

			String totalCashWithdrawal = totalObj.get("totalCashWithdrawal") == null ? "0"
					: totalObj.get("totalCashWithdrawal").toString();
			perfiosMapObj.put("totalCashWithdrawal", totalCashWithdrawal);

			String totalCashDeposit = totalObj.get("totalCashDeposit") == null ? "0"
					: totalObj.get("totalCashDeposit").toString();
			perfiosMapObj.put("totalCashDeposit", totalCashDeposit);

			String salaries = totalObj.get("salaries") == null ? "0" : totalObj.get("salaries").toString();
			perfiosMapObj.put("salaries", salaries);

			String outwBounces = totalObj.get("outwBounces") == null ? "0" : totalObj.get("outwBounces").toString();
			perfiosMapObj.put("outwBounces", outwBounces);

			String inwBounces = totalObj.get("inwBounces") == null ? "0" : totalObj.get("inwBounces").toString();
			perfiosMapObj.put("inwBounces", inwBounces);

			String invExpenses = totalObj.get("invExpenses") == null ? "0" : totalObj.get("invExpenses").toString();
			perfiosMapObj.put("invExpenses", invExpenses);

			String interestIncomes = totalObj.get("interestIncomes") == null ? "0"
					: totalObj.get("interestIncomes").toString();
			perfiosMapObj.put("interestIncomes", interestIncomes);

			String interestCharges = totalObj.get("interestCharges") == null ? "0"
					: totalObj.get("interestCharges").toString();
			perfiosMapObj.put("interestCharges", interestCharges);

			String emiEcsIssues = totalObj.get("emiEcsIssues") == null ? "0" : totalObj.get("emiEcsIssues").toString();
			perfiosMapObj.put("emiEcsIssues", emiEcsIssues);

			String debits = totalObj.get("debits") == null ? "0" : totalObj.get("debits").toString();
			perfiosMapObj.put("debits", debits);

			String credits = totalObj.get("credits") == null ? "0" : totalObj.get("credits").toString();
			perfiosMapObj.put("credits", credits);

			String chqIssues = totalObj.get("chqIssues") == null ? "0" : totalObj.get("chqIssues").toString();
			perfiosMapObj.put("chqIssues", chqIssues);

			String chqDeposits = totalObj.get("chqDeposits") == null ? "0" : totalObj.get("chqDeposits").toString();
			perfiosMapObj.put("chqDeposits", chqDeposits);

			String chqCredits = totalObj.get("chqCredits") == null ? "0" : totalObj.get("chqCredits").toString();
			perfiosMapObj.put("chqCredits", chqCredits);

			String cashWithdrawals = totalObj.get("cashWithdrawals") == null ? "0"
					: totalObj.get("cashWithdrawals").toString();
			perfiosMapObj.put("cashWithdrawals", cashWithdrawals);

			String bankCharges = totalObj.get("bankCharges") == null ? "0" : totalObj.get("bankCharges").toString();
			perfiosMapObj.put("bankCharges", bankCharges);

			String balMin = totalObj.get("balMin") == null ? "0" : totalObj.get("balMin").toString();
			perfiosMapObj.put("balMin", balMin);

			String balMax = totalObj.get("balMax") == null ? "0" : totalObj.get("balMax").toString();
			perfiosMapObj.put("balMax", balMax);

			String balLast = totalObj.get("balLast") == null ? "0" : totalObj.get("balLast").toString();
			perfiosMapObj.put("balLast", balLast);

			String balAvg = totalObj.get("balAvg") == null ? "0" : totalObj.get("balAvg").toString();
			perfiosMapObj.put("balAvg", balAvg);

			String totalSalaryAvg = avgObj.get("totalSalary") == null ? "0" : avgObj.get("totalSalary").toString();
			perfiosMapObj.put("totalSalaryAvg", totalSalaryAvg);

			String totalInvExpenseAvg = avgObj.get("totalInvExpense") == null ? "0"
					: avgObj.get("totalInvExpense").toString();
			perfiosMapObj.put("totalInvExpenseAvg", totalInvExpenseAvg);

			String totalInterestIncomeAvg = avgObj.get("totalInterestIncome") == null ? "0"
					: avgObj.get("totalInterestIncome").toString();
			perfiosMapObj.put("totalInterestIncomeAvg", totalInterestIncomeAvg);

			String totalInterestChargedAvg = avgObj.get("totalInterestCharged") == null ? "0"
					: avgObj.get("totalInterestCharged").toString();
			perfiosMapObj.put("totalInterestChargedAvg", totalInterestChargedAvg);

			String totalInsuranceExpenseAvg = avgObj.get("totalInsuranceExpense") == null ? "0"
					: avgObj.get("totalInsuranceExpense").toString();
			perfiosMapObj.put("totalInsuranceExpenseAvg", totalInsuranceExpenseAvg);

			String totalEmiEcsIssueAvg = avgObj.get("totalEmiEcsIssue") == null ? "0"
					: avgObj.get("totalEmiEcsIssue").toString();
			perfiosMapObj.put("totalEmiEcsIssueAvg", totalEmiEcsIssueAvg);

			String totalDebitAvg = avgObj.get("totalDebit") == null ? "0" : avgObj.get("totalDebit").toString();
			perfiosMapObj.put("totalDebitAvg", totalDebitAvg);

			String totalCreditAvg = avgObj.get("totalCredit") == null ? "0" : avgObj.get("totalCredit").toString();
			perfiosMapObj.put("totalCreditAvg", totalCreditAvg);

			String totalChqIssueAvg = avgObj.get("totalChqIssue") == null ? "0"
					: avgObj.get("totalChqIssue").toString();
			perfiosMapObj.put("totalChqIssueAvg", totalChqIssueAvg);

			String totalChqDepositAvg = avgObj.get("totalChqDeposit") == null ? "0"
					: avgObj.get("totalChqDeposit").toString();
			perfiosMapObj.put("totalChqDepositAvg", totalChqDepositAvg);

			String totalCashWithdrawalAvg = avgObj.get("totalCashWithdrawal") == null ? "0"
					: avgObj.get("totalCashWithdrawal").toString();
			perfiosMapObj.put("totalCashWithdrawalAvg", totalCashWithdrawalAvg);

			String totalCashDepositAvg = avgObj.get("totalCashDeposit") == null ? "0"
					: avgObj.get("totalCashDeposit").toString();
			perfiosMapObj.put("totalCashDepositAvg", totalCashDepositAvg);

			String salariesAvg = avgObj.get("salaries") == null ? "0" : avgObj.get("salaries").toString();
			perfiosMapObj.put("salariesAvg", salariesAvg);

			String outwBouncesAvg = avgObj.get("outwBounces") == null ? "0" : avgObj.get("outwBounces").toString();
			perfiosMapObj.put("outwBouncesAvg", outwBouncesAvg);

			String inwBouncesAvg = avgObj.get("inwBounces") == null ? "0" : avgObj.get("inwBounces").toString();
			perfiosMapObj.put("inwBouncesAvg", inwBouncesAvg);

			String invExpensesAvg = avgObj.get("invExpenses") == null ? "0" : avgObj.get("invExpenses").toString();
			perfiosMapObj.put("invExpensesAvg", invExpensesAvg);

			String interestIncomesAvg = avgObj.get("interestIncomes") == null ? "0"
					: avgObj.get("interestIncomes").toString();
			perfiosMapObj.put("interestIncomesAvg", interestIncomesAvg);

			String interestChargesAvg = avgObj.get("interestCharges") == null ? "0"
					: avgObj.get("interestCharges").toString();
			perfiosMapObj.put("interestChargesAvg", interestChargesAvg);

			String emiEcsIssuesAvg = avgObj.get("emiEcsIssues") == null ? "0" : avgObj.get("emiEcsIssues").toString();
			perfiosMapObj.put("emiEcsIssuesAvg", emiEcsIssuesAvg);

			String debitsAvg = avgObj.get("debits") == null ? "0" : avgObj.get("debits").toString();
			perfiosMapObj.put("debitsAvg", debitsAvg);

			String creditsAvg = avgObj.get("credits") == null ? "0" : avgObj.get("credits").toString();
			perfiosMapObj.put("creditsAvg", creditsAvg);

			String chqIssuesAvg = avgObj.get("chqIssues") == null ? "0" : avgObj.get("chqIssues").toString();
			perfiosMapObj.put("chqIssuesAvg", chqIssuesAvg);

			String chqDepositsAvg = avgObj.get("chqDeposits") == null ? "0" : avgObj.get("chqDeposits").toString();
			perfiosMapObj.put("chqDepositsAvg", chqDepositsAvg);

			String chqCreditsAvg = avgObj.get("chqCredits") == null ? "0" : avgObj.get("chqCredits").toString();
			perfiosMapObj.put("chqCreditsAvg", chqCreditsAvg);

			String cashWithdrawalsAvg = avgObj.get("cashWithdrawals") == null ? "0"
					: avgObj.get("cashWithdrawals").toString();
			perfiosMapObj.put("cashWithdrawalsAvg", cashWithdrawalsAvg);

			String cashDepositsAvg = avgObj.get("cashDeposits") == null ? "0" : avgObj.get("cashDeposits").toString();
			perfiosMapObj.put("cashDepositsAvg", cashDepositsAvg);

			String bounceOrPenalChargesAvg = avgObj.get("bounceOrPenalCharges") == null ? "0"
					: avgObj.get("bounceOrPenalCharges").toString();
			perfiosMapObj.put("bounceOrPenalChargesAvg", bounceOrPenalChargesAvg);

			String bankChargesAvg = avgObj.get("bankCharges") == null ? "0" : avgObj.get("bankCharges").toString();
			perfiosMapObj.put("bankChargesAvg", bankChargesAvg);

			String balMinAvg = avgObj.get("balMin") == null ? "0" : avgObj.get("balMin").toString();
			perfiosMapObj.put("balMinAvg", balMinAvg);

			String balMaxAvg = avgObj.get("balMax") == null ? "0" : avgObj.get("balMax").toString();
			perfiosMapObj.put("balMaxAvg", balMaxAvg);

			String balLastAvg = avgObj.get("balLast") == null ? "0" : avgObj.get("balLast").toString();
			perfiosMapObj.put("balLastAvg", balLastAvg);

			String balAvgAvg = avgObj.get("balAvg") == null ? "0" : avgObj.get("balAvg").toString();
			perfiosMapObj.put("balAvgAvg", balAvgAvg);

			// String cashDeposits = totalObj.get("cashDeposits") == null ? "0" :
			// totalObj.get("cashDeposits").toString();
			String cashDeposits = ntbLoanUtil.getItemArray(monthlyArr, "cashDeposits", AppConstants.TAG_TYPE_DECIMAL);
			perfiosMapObj.put("cashDeposits", cashDeposits);

			/*
			 * String bounceOrPenalCharges = totalObj.get("bounceOrPenalCharges") == null ?
			 * "0" : totalObj.get("bounceOrPenalCharges").toString();
			 */
			String bounceOrPenalCharges = ntbLoanUtil.getItemArray(monthlyArr, "bounceOrPenalCharges",
					AppConstants.TAG_TYPE_DECIMAL);
			perfiosMapObj.put("bounceOrPenalCharges", bounceOrPenalCharges);

			String startDateMonthly = ntbLoanUtil.getItemArray(monthlyArr, "startDate", AppConstants.TAG_TYPE_DATE3);
			perfiosMapObj.put("startDateMonthly", startDateMonthly);

			String totalSalaryMonthly = ntbLoanUtil.getItemArray(monthlyArr, "totalSalary",
					AppConstants.TAG_TYPE_DECIMAL);
			perfiosMapObj.put("totalSalaryMonthly", totalSalaryMonthly);

			String totalInvExpenseMonthly = ntbLoanUtil.getItemArray(monthlyArr, "totalInvExpense",
					AppConstants.TAG_TYPE_DECIMAL);
			perfiosMapObj.put("totalInvExpenseMonthly", totalInvExpenseMonthly);

			String totalInterestIncomeMonthly = ntbLoanUtil.getItemArray(monthlyArr, "totalInterestIncome",
					AppConstants.TAG_TYPE_DECIMAL);
			perfiosMapObj.put("totalInterestIncomeMonthly", totalInterestIncomeMonthly);

			String totalInterestChargedMonthly = ntbLoanUtil.getItemArray(monthlyArr, "totalInterestCharged",
					AppConstants.TAG_TYPE_DECIMAL);
			perfiosMapObj.put("totalInterestChargedMonthly", totalInterestChargedMonthly);

			String totalInsuranceExpenseMonthly = ntbLoanUtil.getItemArray(monthlyArr, "totalInsuranceExpense",
					AppConstants.TAG_TYPE_DECIMAL);
			perfiosMapObj.put("totalInsuranceExpenseMonthly", totalInsuranceExpenseMonthly);

			String totalEmiEcsIssueMonthly = ntbLoanUtil.getItemArray(monthlyArr, "totalEmiEcsIssue",
					AppConstants.TAG_TYPE_DECIMAL);
			perfiosMapObj.put("totalEmiEcsIssueMonthly", totalEmiEcsIssueMonthly);

			String totalDebitMonthly = ntbLoanUtil.getItemArray(monthlyArr, "totalDebit",
					AppConstants.TAG_TYPE_DECIMAL);
			perfiosMapObj.put("totalDebitMonthly", totalDebitMonthly);

			String totalCreditMonthly = ntbLoanUtil.getItemArray(monthlyArr, "totalCredit",
					AppConstants.TAG_TYPE_DECIMAL);
			perfiosMapObj.put("totalCreditMonthly", totalCreditMonthly);

			String totalChqIssueMonthly = ntbLoanUtil.getItemArray(monthlyArr, "totalChqIssue",
					AppConstants.TAG_TYPE_DECIMAL);
			perfiosMapObj.put("totalChqIssueMonthly", totalChqIssueMonthly);

			String totalChqDepositMonthly = ntbLoanUtil.getItemArray(monthlyArr, "totalChqDeposit",
					AppConstants.TAG_TYPE_DECIMAL);
			perfiosMapObj.put("totalChqDepositMonthly", totalChqDepositMonthly);

			String totalCashWithdrawalMonthly = ntbLoanUtil.getItemArray(monthlyArr, "totalCashWithdrawal",
					AppConstants.TAG_TYPE_DECIMAL);
			perfiosMapObj.put("totalCashWithdrawalMonthly", totalCashWithdrawalMonthly);

			String totalCashDepositMonthly = ntbLoanUtil.getItemArray(monthlyArr, "totalCashDeposit",
					AppConstants.TAG_TYPE_DECIMAL);
			perfiosMapObj.put("totalCashDepositMonthly", totalCashDepositMonthly);

			String salariesMonthly = ntbLoanUtil.getItemArray(monthlyArr, "salaries", AppConstants.TAG_TYPE_DECIMAL);
			perfiosMapObj.put("salariesMonthly", salariesMonthly);

			String outwBouncesMonthly = ntbLoanUtil.getItemArray(monthlyArr, "outwBounces",
					AppConstants.TAG_TYPE_DECIMAL);
			perfiosMapObj.put("outwBouncesMonthly", outwBouncesMonthly);

			String inwBouncesMonthly = ntbLoanUtil.getItemArray(monthlyArr, "inwBounces",
					AppConstants.TAG_TYPE_DECIMAL);
			perfiosMapObj.put("inwBouncesMonthly", inwBouncesMonthly);

			String invExpensesMonthly = ntbLoanUtil.getItemArray(monthlyArr, "invExpenses",
					AppConstants.TAG_TYPE_DECIMAL);
			perfiosMapObj.put("invExpensesMonthly", invExpensesMonthly);

			String interestIncomesMonthly = ntbLoanUtil.getItemArray(monthlyArr, "interestIncomes",
					AppConstants.TAG_TYPE_DECIMAL);
			perfiosMapObj.put("interestIncomesMonthly", interestIncomesMonthly);

			String interestChargesMonthly = ntbLoanUtil.getItemArray(monthlyArr, "interestCharges",
					AppConstants.TAG_TYPE_DECIMAL);
			perfiosMapObj.put("interestChargesMonthly", interestChargesMonthly);

			String emiEcsIssuesMonthly = ntbLoanUtil.getItemArray(monthlyArr, "emiEcsIssues",
					AppConstants.TAG_TYPE_DECIMAL);
			perfiosMapObj.put("emiEcsIssuesMonthly", emiEcsIssuesMonthly);

			String debitsMonthly = ntbLoanUtil.getItemArray(monthlyArr, "debits", AppConstants.TAG_TYPE_DECIMAL);
			perfiosMapObj.put("debitsMonthly", debitsMonthly);

			String creditsMonthly = ntbLoanUtil.getItemArray(monthlyArr, "credits", AppConstants.TAG_TYPE_DECIMAL);
			perfiosMapObj.put("creditsMonthly", creditsMonthly);

			String chqIssuesMonthly = ntbLoanUtil.getItemArray(monthlyArr, "chqIssues", AppConstants.TAG_TYPE_DECIMAL);
			perfiosMapObj.put("chqIssuesMonthly", chqIssuesMonthly);

			String chqDepositsMonthly = ntbLoanUtil.getItemArray(monthlyArr, "chqDeposits",
					AppConstants.TAG_TYPE_DECIMAL);
			perfiosMapObj.put("chqDepositsMonthly", chqDepositsMonthly);

			String chqCreditsMonthly = ntbLoanUtil.getItemArray(monthlyArr, "chqCredits",
					AppConstants.TAG_TYPE_DECIMAL);
			perfiosMapObj.put("chqCreditsMonthly", chqCreditsMonthly);

			String cashWithdrawalsMonthly = ntbLoanUtil.getItemArray(monthlyArr, "cashWithdrawals",
					AppConstants.TAG_TYPE_DECIMAL);
			perfiosMapObj.put("cashWithdrawalsMonthly", cashWithdrawalsMonthly);

			String cashDepositsMonthly = ntbLoanUtil.getItemArray(monthlyArr, "cashDeposits",
					AppConstants.TAG_TYPE_DECIMAL);
			perfiosMapObj.put("cashDepositsMonthly", cashDepositsMonthly);

			String bounceOrPenalChargesMonthly = ntbLoanUtil.getItemArray(monthlyArr, "bounceOrPenalCharges",
					AppConstants.TAG_TYPE_DECIMAL);
			perfiosMapObj.put("bounceOrPenalChargesMonthly", bounceOrPenalChargesMonthly);

			String bankChargesMonthly = ntbLoanUtil.getItemArray(monthlyArr, "bankCharges",
					AppConstants.TAG_TYPE_DECIMAL);
			perfiosMapObj.put("bankChargesMonthly", bankChargesMonthly);

			String balMinMonthly = ntbLoanUtil.getItemArray(monthlyArr, "balMin", AppConstants.TAG_TYPE_DECIMAL);
			perfiosMapObj.put("balMinMonthly", balMinMonthly);

			String balMaxMonthly = ntbLoanUtil.getItemArray(monthlyArr, "balMax", AppConstants.TAG_TYPE_DECIMAL);
			perfiosMapObj.put("balMaxMonthly", balMaxMonthly);

			String balLastMonthly = ntbLoanUtil.getItemArray(monthlyArr, "balLast", AppConstants.TAG_TYPE_DECIMAL);
			perfiosMapObj.put("balLastMonthly", balLastMonthly);

			String balAvgMonthly = ntbLoanUtil.getItemArray(monthlyArr, "balAvg", AppConstants.TAG_TYPE_DECIMAL);
			perfiosMapObj.put("balAvgMonthly", balAvgMonthly);

			String monthNameMonthly = ntbLoanUtil.getItemArray(monthlyArr, "monthName", AppConstants.TAG_TYPE_STRING);
			perfiosMapObj.put("monthNameMonthly", monthNameMonthly);

			String balanceEod = ntbLoanUtil.getItemArray(eodBalancesArr, "balance", AppConstants.TAG_TYPE_DECIMAL);
			perfiosMapObj.put("balanceEod", balanceEod);

			String dateEod = ntbLoanUtil.getItemArray(eodBalancesArr, "date", AppConstants.TAG_TYPE_DATE3);
			perfiosMapObj.put("dateEod", dateEod);

			String dateEmiEcs = ntbLoanUtil.getItemArray(emiEcsXnsArr, "date", AppConstants.TAG_TYPE_DATE3);
			perfiosMapObj.put("dateEmiEcs", dateEmiEcs);

			String categoryEmiEcs = ntbLoanUtil.getItemArray(emiEcsXnsArr, "category", AppConstants.TAG_TYPE_STRING);
			perfiosMapObj.put("categoryEmiEcs", categoryEmiEcs);

			String balanceEmiEcs = ntbLoanUtil.getItemArray(emiEcsXnsArr, "balance", AppConstants.TAG_TYPE_DECIMAL);
			perfiosMapObj.put("balanceEmiEcs", balanceEmiEcs);

			String amountEmiEcs = ntbLoanUtil.getItemArray(emiEcsXnsArr, "amount", AppConstants.TAG_TYPE_DECIMAL);
			perfiosMapObj.put("amountEmiEcs", amountEmiEcs);

			String narrationEmiEcs = ntbLoanUtil.getItemArray(emiEcsXnsArr, "narration", AppConstants.TAG_TYPE_STRING);
			perfiosMapObj.put("narrationEmiEcs", narrationEmiEcs);

			String chqnoEmiEcs = ntbLoanUtil.getItemArray(emiEcsXnsArr, "chqNo", AppConstants.TAG_TYPE_STRING);
			perfiosMapObj.put("chqnoEmiEcs", chqnoEmiEcs);

			String balanceXnsObj = ntbLoanUtil.getItemArray(xnsObjArr, "balance", AppConstants.TAG_TYPE_DECIMAL);
			perfiosMapObj.put("balanceXnsObj", balanceXnsObj);

			String dateXnsObj = ntbLoanUtil.getItemArray(xnsObjArr, "date", AppConstants.TAG_TYPE_DATE3);
			perfiosMapObj.put("dateXnsObj", dateXnsObj);

			String categoryXnsObj = ntbLoanUtil.getItemArray(xnsObjArr, "category", AppConstants.TAG_TYPE_STRING);
			perfiosMapObj.put("categoryXnsObj", categoryXnsObj);

			String amountXnsObj = ntbLoanUtil.getItemArray(xnsObjArr, "amount", AppConstants.TAG_TYPE_DECIMAL);
			perfiosMapObj.put("amountXnsObj", amountXnsObj);

			String narrationXnsObj = ntbLoanUtil.getItemArray(xnsObjArr, "narration", AppConstants.TAG_TYPE_STRING);
			perfiosMapObj.put("narrationXnsObj", narrationXnsObj);

			String chqnoXnsObj = ntbLoanUtil.getItemArray(xnsObjArr, "chqNo", AppConstants.TAG_TYPE_STRING);
			perfiosMapObj.put("chqnoXnsObj", chqnoXnsObj);

			// accountNoXnsObj and accountTypeXnsObj are array in BRE2 but coming single
			// value from source
			String accountNoXnsObj = StringUtils
					.isBlank(xnsObj.get("accountNo") == null ? "" : xnsObj.get("accountNo").toString()) == true ? "Z"
							: xnsObj.get("accountNo").toString();

			accountNoXnsObj = "<item>" + accountNoXnsObj + "</item>";

			perfiosMapObj.put("accountNoXnsObj", accountNoXnsObj);

			String accountTypeXnsObj = StringUtils
					.isBlank(xnsObj.get("accountType") == null ? "" : xnsObj.get("accountType").toString()) == true
							? "Z"
							: xnsObj.get("accountType").toString();
			accountTypeXnsObj = "<item>" + accountTypeXnsObj + "</item>";
			perfiosMapObj.put("accountTypeXnsObj", accountTypeXnsObj);
			logger.info(RedisConstants.BRE2_ACCOUNT_NUMBER + mobileNumber + RedisConstants.US + txnId +" :: "+ accountNoXnsObj);
			redisUtils.set(RedisConstants.BRE2_ACCOUNT_NUMBER + mobileNumber + RedisConstants.US + txnId, accountNoXnsObj);
			// 4 object not found for STATEMENTDETAILS
		} catch (Exception exe) {
			logger.info("Exception :: getPerfiosData : " + CommonUtility.getPrintStackTrace(exe));
		}
		return perfiosMapObj;
	}
	
	public HashMap<String, String> getPerfiosMapData(String mobileNumber, String transRefNo) {
		HashMap<String, String> perfiosData = new HashMap<String, String>();
		try {
			String perfiosXMLReq = "";

			if (!AppConstants.IS_BRE_STATIC) {
				perfiosXMLReq = redisUtils.get(RedisConstants.PERFIOS_RETRIVE_DATA + mobileNumber + RedisConstants.US + transRefNo);
			} else {
				perfiosXMLReq = StaticConstants.PERFIOS_STATIC_RESP;
			}
			logger.info("getPerfiosMapData  perfiosXMLReq :: " + perfiosXMLReq);

			org.json.JSONObject xmlJSONObj = XML.toJSONObject(perfiosXMLReq);

			String jsonPrettyPrintString = xmlJSONObj.toString(AppConstants.PRETTY_PRINT_INDENT_FACTOR)
					.replaceAll("(\r\n|\n)", "").replaceAll("  ", "").replaceAll("PIR:", "");
			JSONParser jsonParser = new JSONParser();
			JSONObject jsonRequest = (JSONObject) jsonParser.parse(jsonPrettyPrintString);
			JSONObject dataObj = (JSONObject) jsonRequest.get("Data");
			/*
			 * JSONObject statementdetailsDataObj = (JSONObject)
			 * dataObj.get("Statementdetails"); JSONObject statementObj = (JSONObject)
			 * statementdetailsDataObj.get("Statement"); JSONObject statementAccountsObj2 =
			 * (JSONObject) statementObj.get("StatementAccounts"); JSONObject
			 * statementAccountsObj3 = (JSONObject)
			 * statementAccountsObj2.get("StatementAccount"); String accountNo =
			 * statementAccountsObj3.get("accountNo") == null ? "" :
			 * statementAccountsObj3.get("accountNo").toString();
			 */
			JSONObject xnsObj = (JSONObject) dataObj.get("Xns");
			String accountNo = StringUtils.isBlank(xnsObj.get("accountNo") == null ? "" : xnsObj.get("accountNo").toString()) == true ? ""
							: xnsObj.get("accountNo").toString();
			//System.out.println("accountNo :: " + accountNo);
			perfiosData.put("accountNo", accountNo);
		} catch (Exception e) {
			logger.info("Exception :: "+CommonUtility.getPrintStackTrace(e));
		}
		return perfiosData;
	}



	@SuppressWarnings("unchecked")
	public HashMap<String, String> getCPData(String mobileNumber, String txnId) {
		HashMap<String, String> cpObj = new HashMap<String, String>();
		try {

			String cpJsonResp = "";
			if (!AppConstants.IS_BRE_STATIC) {
				cpJsonResp = redisUtils.get(RedisConstants.CP_DATA + mobileNumber);
				logger.info("Redis getCPData  xmlRequest :: " + cpJsonResp.length());
			} else {
				cpJsonResp = StaticConstants.CP_STATIC_RESP;
			}

			logger.info("getCPData :: " + cpJsonResp.length());
			JSONParser parser = new JSONParser();
			JSONObject cpRespObj = (JSONObject) parser.parse(cpJsonResp);

			JSONObject fintechDemographicDtlsRespObj = (JSONObject) cpRespObj.get("FintechDemographicDetailsResponse");
			String filler5 = "";
			if (fintechDemographicDtlsRespObj.containsKey("soaFillers")) {
				JSONObject soaFillersObj = (JSONObject) fintechDemographicDtlsRespObj
						.get("soaFillers");
				filler5 = soaFillersObj.get("filler5") == null ? "" : soaFillersObj.get("filler5").toString();
			}
			
			Object fintechDemographicDtlsOptObj = fintechDemographicDtlsRespObj.get("FintechDemographicDetails");
			JSONArray fintechDemographicDtlsObjArr = new JSONArray();
			if (fintechDemographicDtlsOptObj instanceof JSONObject) {
				JSONObject partObj = (JSONObject) fintechDemographicDtlsRespObj.get("FintechDemographicDetails");
				fintechDemographicDtlsObjArr.add(partObj);
			} else {
				fintechDemographicDtlsObjArr = (JSONArray) fintechDemographicDtlsRespObj
						.get("FintechDemographicDetails");
			}

			String rateOfInterest = NTBLoanUtilNew.getItemArray(fintechDemographicDtlsObjArr, "CPResponse",
					"RateOfInterest", AppConstants.TAG_TYPE_STRING);
			cpObj.put("rateOfInterest", rateOfInterest);

			String tenure = NTBLoanUtilNew.getItemArray(fintechDemographicDtlsObjArr, "CPResponse", "Tenure",
					AppConstants.TAG_TYPE_STRING);
			cpObj.put("tenureArr", tenure);

			String offerAmount = NTBLoanUtilNew.getItemArray(fintechDemographicDtlsObjArr, "CPResponse", "OfferAmount",
					AppConstants.TAG_TYPE_STRING);
			cpObj.put("offerAmountArr", offerAmount);

			if(StringUtils.isBlank(filler5)) {
				String productname = NTBLoanUtilNew.getItemArray(fintechDemographicDtlsObjArr, "CPResponse", "Productname",
						AppConstants.TAG_TYPE_STRING);
				cpObj.put("productnameArr", productname);
			}else {
				cpObj.put("productnameArr", "<item>" + filler5 + "</item>");
			}

			String cardType = NTBLoanUtilNew.getItemArray(fintechDemographicDtlsObjArr, "CPResponse", "CardType",
					AppConstants.TAG_TYPE_STRING);
			cpObj.put("cardType", cardType);

			String eKYCFlag = NTBLoanUtilNew.getItemArray(fintechDemographicDtlsObjArr, "CPResponse", "eKYCFlag",
					AppConstants.TAG_TYPE_STRING);
			cpObj.put("eKYCFlag", eKYCFlag);
		} catch (Exception exe) {
			logger.info("Exception ::" + CommonUtility.getPrintStackTrace(exe));
		}
		return cpObj;
	}

	public HashMap<String, String> getCIFData(String mobileNumber, String txnId) {
		HashMap<String, String> cifObj = new HashMap<String, String>();
		try {

			String cifXmlResp = "";

			if (!AppConstants.IS_BRE_STATIC) {
				cifXmlResp = redisUtils.get(RedisConstants.CIF_DATA + mobileNumber);
				logger.info("Redis getCIFData  xmlRequest :: " + cifXmlResp.length());
			} else {
				cifXmlResp = StaticConstants.CIF_STATIC_RESP;
			}

			org.json.JSONObject xmlJSONObj = XML.toJSONObject(cifXmlResp);

			String jsonPrettyPrintString = xmlJSONObj.toString(AppConstants.PRETTY_PRINT_INDENT_FACTOR)
					.replaceAll("(\r\n|\n)", "").replaceAll("  ", "").replaceAll("a:", "").replaceAll("soapenv:", "");

			JSONParser jsonParser = new JSONParser();
			JSONObject jsonRequest = (JSONObject) jsonParser.parse(jsonPrettyPrintString);
			JSONObject envelopeObj = ((JSONObject) jsonRequest.get("Envelope"));
			JSONObject bodyObj = ((JSONObject) envelopeObj.get("Body"));
			JSONObject serviceResponseObj = ((JSONObject) bodyObj.get("ServiceResponse"));
			JSONObject sasDiamDedupeObj = ((JSONObject) serviceResponseObj.get("SAS_DIM_DEDUPE_OUTPUT"));
			JSONObject allAccountObj = ((JSONObject) sasDiamDedupeObj.get("ALL_ACCOUNT"));
			JSONArray allAccountInfoArr = ((JSONArray) allAccountObj.get("ACCOUNT_INFO"));
			logger.info("allAccountInfoArr :: " + allAccountInfoArr);
			JSONObject allAccountInfoObj = (JSONObject) allAccountInfoArr.get(0);
			String BEHAV_SCORE1 = ntbLoanUtil.getItemArray(allAccountInfoArr, "BEHAV_SCORE1",
					AppConstants.TAG_TYPE_STRING);
			cifObj.put("BEHAV_SCORE1", BEHAV_SCORE1);
			String BEHAV_SCORE2 = ntbLoanUtil.getItemArray(allAccountInfoArr, "BEHAV_SCORE2",
					AppConstants.TAG_TYPE_STRING);
			cifObj.put("BEHAV_SCORE2", BEHAV_SCORE2);
			String BEHAVIORAL_SCORE3 = ntbLoanUtil.getItemArray(allAccountInfoArr, "BEHAVIORAL_SCORE3",
					AppConstants.TAG_TYPE_STRING);
			cifObj.put("BEHAVIORAL_SCORE3", BEHAVIORAL_SCORE3);
			String BEHAVIORAL_SCORE4 = ntbLoanUtil.getItemArray(allAccountInfoArr, "BEHAVIORAL_SCORE4",
					AppConstants.TAG_TYPE_STRING);
			cifObj.put("BEHAVIORAL_SCORE4", BEHAVIORAL_SCORE4);
			String BEHAVIORAL_SCORE5 = ntbLoanUtil.getItemArray(allAccountInfoArr, "BEHAVIORAL_SCORE5",
					AppConstants.TAG_TYPE_STRING);
			cifObj.put("BEHAVIORAL_SCORE5", BEHAVIORAL_SCORE5);
			String BEHAVIORAL_SCORE6 = ntbLoanUtil.getItemArray(allAccountInfoArr, "BEHAVIORAL_SCORE6",
					AppConstants.TAG_TYPE_STRING);
			cifObj.put("BEHAVIORAL_SCORE6", BEHAVIORAL_SCORE6);
			String BEHAVIORAL_SCORE7 = ntbLoanUtil.getItemArray(allAccountInfoArr, "BEHAVIORAL_SCORE7",
					AppConstants.TAG_TYPE_STRING);
			cifObj.put("BEHAVIORAL_SCORE7", BEHAVIORAL_SCORE7);
			String CARD_BEHAV_SCORE = ntbLoanUtil.getItemArray(allAccountInfoArr, "CARD_BEHAV_SCORE",
					AppConstants.TAG_TYPE_STRING);
			cifObj.put("CARD_BEHAV_SCORE", CARD_BEHAV_SCORE);
			String CNC_BEHAV_SCORE = ntbLoanUtil.getItemArray(allAccountInfoArr, "CNC_BEHAV_SCORE",
					AppConstants.TAG_TYPE_STRING);
			cifObj.put("CNC_BEHAV_SCORE", CNC_BEHAV_SCORE);
			String CUSTOMER_ID = ntbLoanUtil.getItemArray(allAccountInfoArr, "CUSTOMER_ID",
					AppConstants.TAG_TYPE_STRING);
			cifObj.put("CUSTOMER_ID", CUSTOMER_ID);
			String DEBIT_SCORE_AL = ntbLoanUtil.getItemArray(allAccountInfoArr, "DEBIT_SCORE_AL",
					AppConstants.TAG_TYPE_STRING);
			cifObj.put("DEBIT_SCORE_AL", DEBIT_SCORE_AL);
			String DEBIT_SCORE_BL = ntbLoanUtil.getItemArray(allAccountInfoArr, "DEBIT_SCORE_BL",
					AppConstants.TAG_TYPE_STRING);
			cifObj.put("DEBIT_SCORE_BL", DEBIT_SCORE_BL);
			String DEBIT_SCORE_CARDS = ntbLoanUtil.getItemArray(allAccountInfoArr, "DEBIT_SCORE_CARDS",
					AppConstants.TAG_TYPE_STRING);
			cifObj.put("DEBIT_SCORE_CARDS", DEBIT_SCORE_CARDS);
			String DEBIT_SCORE_PL = ntbLoanUtil.getItemArray(allAccountInfoArr, "DEBIT_SCORE_PL",
					AppConstants.TAG_TYPE_STRING);
			cifObj.put("DEBIT_SCORE_PL", DEBIT_SCORE_PL);

			String FILLER1 = ntbLoanUtil.getItemArray(allAccountInfoArr, "FILLER1", AppConstants.TAG_TYPE_STRING);
			cifObj.put("FILLER1", FILLER1);
			String FILLER2 = ntbLoanUtil.getItemArray(allAccountInfoArr, "FILLER2", AppConstants.TAG_TYPE_STRING);
			cifObj.put("FILLER2", FILLER2);
			String FILLER3 = ntbLoanUtil.getItemArray(allAccountInfoArr, "FILLER3", AppConstants.TAG_TYPE_STRING);
			cifObj.put("FILLER3", FILLER3);
			String FILLER4 = ntbLoanUtil.getItemArray(allAccountInfoArr, "FILLER4", AppConstants.TAG_TYPE_STRING);
			cifObj.put("FILLER4", FILLER4);
			String FILLER5 = ntbLoanUtil.getItemArray(allAccountInfoArr, "FILLER5", AppConstants.TAG_TYPE_STRING);
			cifObj.put("FILLER5", FILLER5);

			String FW_ACCNT_NUM = StringUtils.isBlank(allAccountInfoObj.get("FW_ACCNT_NUM") == null ? ""
					: allAccountInfoObj.get("FW_ACCNT_NUM").toString()) == true ? "Z"
							: allAccountInfoObj.get("FW_ACCNT_NUM").toString();
			cifObj.put("FW_ACCNT_NUM", FW_ACCNT_NUM);
			String FW_CUST_ID = StringUtils.isBlank(allAccountInfoObj.get("FW_CUST_ID") == null ? ""
					: allAccountInfoObj.get("FW_CUST_ID").toString()) == true ? "Z"
							: allAccountInfoObj.get("FW_CUST_ID").toString();
			cifObj.put("FW_CUST_ID", FW_CUST_ID);
			String SAS_ID = StringUtils.isBlank(
					allAccountInfoObj.get("SAS_ID") == null ? "" : allAccountInfoObj.get("SAS_ID").toString()) == true
							? "Z"
							: allAccountInfoObj.get("SAS_ID").toString();
			cifObj.put("SAS_ID", SAS_ID);
		} catch (Exception exe) {
			cifObj = AppConstants.CIF_EMPTY_RESP();
			logger.info("getCIFData Exception ::" + CommonUtility.getPrintStackTrace(exe));
		}
		return cifObj;
	}

	public HashMap<String, String> getEKYCData(String mobileNumber, String txnId) {
		HashMap<String, String> ekycObj = new HashMap<String, String>();

		try {
			String ekycResp = "";

			if (!AppConstants.IS_BRE_STATIC) {
				ekycResp = redisUtils.get(RedisConstants.AADHAR_OTP_VALDN + mobileNumber + RedisConstants.US + txnId);
				logger.info("Redis getEKYCData  jsonRequest :: " + ekycResp.length());
			} else {
				ekycResp = StaticConstants.AADHAR_OTP_VALIDATION_RESPONSE;
			}
			
			if (StringUtils.isBlank(ekycResp)) {
				ekycResp = redisUtils.get(RedisConstants.AADHAR_CALLBACK_RESP + mobileNumber + RedisConstants.US + txnId);
				
				JSONObject xmlJSONObj = (JSONObject) new JSONParser().parse(ekycResp);

				String ret = xmlJSONObj.get("AadhaarConsent") == null ? "" : xmlJSONObj.get("AadhaarConsent").toString();
				if (ret.equals("Y")) {

					JSONObject Data = (JSONObject) xmlJSONObj.get("Data");

					String dob = Data.get("DOB") == null ? "" : Data.get("DOB").toString();
					dob = CommonUtility.formatDate(dob, AppConstants.DATE_FMT_ddMMyyyy2, AppConstants.DATE_FMT_yyyy_MM_dd);
					ekycObj.put("dob", dob);
				}  else {
					ekycObj = AppConstants.EKYC_EMPTY_RESP();
				}
				
			} else {
				JSONObject xmlJSONObj = (JSONObject) new JSONParser().parse(ekycResp);

				JSONObject serviceResponse = (JSONObject) xmlJSONObj.get("Envelope");
				JSONObject body = (JSONObject) serviceResponse.get("Body");
				JSONObject eKYCResponseObj = (JSONObject) body.get("eKYCResponse");
				JSONObject returnCodebj = (JSONObject) eKYCResponseObj.get("Return_Code");
				String ret = returnCodebj.get("ret") == null ? "" : returnCodebj.get("ret").toString();
				if (ret.equals("Y")) {

					JSONObject UidData = (JSONObject) eKYCResponseObj.get("UidData");
					JSONObject ProofofIdentity = (JSONObject) UidData.get("ProofofIdentity");
					// JSONObject ProofofAddress = (JSONObject) UidData.get("ProofofAddress");
					String dob = ProofofIdentity.get("DOB") == null ? "" : ProofofIdentity.get("DOB").toString();
					dob = CommonUtility.formatDate(dob, AppConstants.DATE_FMT_ddMMyyyy2, AppConstants.DATE_FMT_yyyy_MM_dd);
					ekycObj.put("dob", dob);

				} else {
					ekycObj = AppConstants.EKYC_EMPTY_RESP();
				}
			}

			

		} catch (Exception exe) {
			ekycObj = AppConstants.EKYC_EMPTY_RESP();
			logger.info("getEKYCData Exception ::" + CommonUtility.getPrintStackTrace(exe));
		}
		return ekycObj;
	}

	@SuppressWarnings("unchecked")
	public static void main(String[] args) throws ParseException, java.text.ParseException {

		try {

			String cpJsonResp = "{\"FintechDemographicDetailsResponse\":{\"CIF_RespCode\":\"0\",\"CP_RespDesc\":\"\",\"FintechDemographicDetails\":{\"CPResponse\":{\"RateOfInterest\":\"8.9\",\"Tenure\":\"24\",\"OfferAmount\":\"200000.00\",\"Productname\":\"AUT_AL_PQ_PQL_REFERRAL\",\"CardType\":\"AUT_AL_PQ_PQA_REFERRAL\",\"eKYCFlag\":\"\"},\"CIFResponse\":{\"CustomerGender\":\"M\",\"CustomerState\":\"Karnataka\",\"CustomerOfficeAddress3\":\"\",\"CustomerOfficeAddress2\":\"\",\"CustomerLastname\":\"Iranna\",\"SAS_ID\":\"51227244\",\"CustomerOfficeAddress1\":\"\",\"CustomerOfficePhone\":\"0 0  0\",\"ResidenceType\":\"\",\"CustomerCountry\":\"IN\",\"CustomerRessidencePhone\":\"\",\"CustomerOfficeZipCode\":\"\",\"CustomerAddress3\":\"NAGPUR\",\"CustomerAddress2\":\"AATH RASTA SQUARE LAXMINAGAR\",\"CustomerAddress1\":\"101 MARIGOLD APPARTMENT LAXMINAGAR\",\"MonthlyIncome\":\"0\",\"CustomerPanNo\":\"BJLPS7930J\",\"CustomerFirstname\":\"Iranna\",\"DateOfBirth\":\"1982-12-06 00:00:00\",\"CustomerCity\":\"Hubli\",\"AccountNo\":\"50100010699390\",\"ZipCode\":\"580031\",\"EmailAddress\":\"shetti.amit@gmail.com\",\"Profession\":\"2\",\"CustomerMobileNo\":\"919886520106\",\"CustFullName\":\"Amit Iranna\",\"CustomerOfficeCity\":\"\"}},\"soaStandard\":{\"service_user\":\"\",\"service_password\":\"\",\"consumer_name\":\"\",\"unique_id\":\"\",\"time_stamp\":\"\"},\"CIF_RespDesc\":\"SUCCESS\",\"CP_RespCode\":false,\"soaFillers\":{\"filler9\":\"\",\"filler8\":\"\",\"filler5\":\"\",\"filler4\":\"\",\"filler7\":\"\",\"filler6\":\"\",\"filler1\":\"\",\"filler10\":\"\",\"filler3\":\"\",\"filler2\":\"\"}}}";
			JSONObject cpObj = new JSONObject();
			JSONParser parser = new JSONParser();
			JSONObject cpRespObj = (JSONObject) parser.parse(cpJsonResp);

			JSONObject fintechDemographicDtlsRespObj = (JSONObject) cpRespObj.get("FintechDemographicDetailsResponse");

			Object fintechDemographicDtlsOptObj = fintechDemographicDtlsRespObj.get("FintechDemographicDetails");
			JSONArray fintechDemographicDtlsObjArr = new JSONArray();
			if (fintechDemographicDtlsOptObj instanceof JSONObject) {
				JSONObject partObj = (JSONObject) fintechDemographicDtlsRespObj.get("FintechDemographicDetails");
				fintechDemographicDtlsObjArr.add(partObj);
			} else {
				fintechDemographicDtlsObjArr = (JSONArray) fintechDemographicDtlsRespObj
						.get("FintechDemographicDetails");
			}

			String rateOfInterest = NTBLoanUtilNew.getItemArray(fintechDemographicDtlsObjArr, "CPResponse",
					"RateOfInterest", AppConstants.TAG_TYPE_STRING);
			cpObj.put("rateOfInterest", rateOfInterest);

			String tenure = NTBLoanUtilNew.getItemArray(fintechDemographicDtlsObjArr, "CPResponse", "Tenure",
					AppConstants.TAG_TYPE_STRING);
			cpObj.put("tenureArr", tenure);

			String offerAmount = NTBLoanUtilNew.getItemArray(fintechDemographicDtlsObjArr, "CPResponse", "OfferAmount",
					AppConstants.TAG_TYPE_STRING);
			cpObj.put("offerAmountArr", offerAmount);

			String productname = NTBLoanUtilNew.getItemArray(fintechDemographicDtlsObjArr, "CPResponse", "Productname",
					AppConstants.TAG_TYPE_STRING);
			cpObj.put("productnameArr", productname);

			String cardType = NTBLoanUtilNew.getItemArray(fintechDemographicDtlsObjArr, "CPResponse", "CardType",
					AppConstants.TAG_TYPE_STRING);
			cpObj.put("cardType", cardType);

			String eKYCFlag = NTBLoanUtilNew.getItemArray(fintechDemographicDtlsObjArr, "CPResponse", "eKYCFlag",
					AppConstants.TAG_TYPE_STRING);
			cpObj.put("eKYCFlag", eKYCFlag);
			System.out.println("cpObj :: " + cpObj);
		} catch (Exception e) {
			logger.info("Exception :: "+CommonUtility.getPrintStackTrace(e));
		}
	}

	public void setAPIStatus(String mobileNo, String referenceNo, String apiName, String apiStatus) {
		try {

			if (StringUtils.isBlank(mobileNo)) {
				mobileNo = redisUtils.get(RedisConstants.NTB_MOBILE_NO + referenceNo);
			}

			String status = "";
			if (apiStatus.equals(AppConstants.BRE_SUCCESS) || apiStatus.equals(AppConstants.API_SUCCESS)) {
				status = "S";
			} else if (apiStatus.equals(AppConstants.BRE_FAIL) || apiStatus.equals(AppConstants.API_FAIL)) {
				status = "F";
			} else {
				status = apiStatus;
			}

			switch (1) {
			case 1:
				if (apiName.equalsIgnoreCase("CIBIL")) {
					redisUtils.sadd(RedisConstants.BRE_APIS_STATUS + mobileNo + RedisConstants.US + referenceNo,
							"Cibil_" + status);
					break;
				}
			case 2:
				if (apiName.equalsIgnoreCase("EQUIFAX")) {
					redisUtils.sadd(RedisConstants.BRE_APIS_STATUS + mobileNo + RedisConstants.US + referenceNo,
							"Equifax_" + status);
					break;
				}
			case 3:
				if (apiName.equalsIgnoreCase("CRIF HIGHMARK")) {
					redisUtils.sadd(RedisConstants.BRE_APIS_STATUS + mobileNo + RedisConstants.US + referenceNo,
							"CrifHighmark_" + status);
					break;
				}
			case 4:
				if (apiName.equalsIgnoreCase("EXPERIAN")) {
					redisUtils.sadd(RedisConstants.BRE_APIS_STATUS + mobileNo + RedisConstants.US + referenceNo,
							"Experian_" + status);
					break;
				}
			case 5:
				if (apiName.equalsIgnoreCase("MBEOT")) {
					redisUtils.sadd(RedisConstants.BRE_APIS_STATUS + mobileNo + RedisConstants.US + referenceNo,
							"Mbeot_" + status);
					break;
				}
			case 6:
				if (apiName.equalsIgnoreCase("MERGED_SCORE")) {
					redisUtils.sadd(RedisConstants.BRE_APIS_STATUS + mobileNo + RedisConstants.US + referenceNo,
							"MergedScore_" + status);
					break;
				}
			case 7:
				if (apiName.equalsIgnoreCase(AppConstants.TRUSTING_SOCIAL)) {
					redisUtils.sadd(RedisConstants.BRE_APIS_STATUS + mobileNo + RedisConstants.US + referenceNo,
							"TrustingSocial_" + status);
					break;
				}
			case 8:
				if (apiName.equalsIgnoreCase(AppConstants.NSDL)) {
					redisUtils.sadd(RedisConstants.BRE_APIS_STATUS + mobileNo + RedisConstants.US + referenceNo,
							"Pan_" + status);
					break;
				}
			case 9:
				if (apiName.equalsIgnoreCase(AppConstants.POSIDEX_STATUS)) {
					Set<String> breAPIStatusSet = redisUtils
							.smembers(RedisConstants.BRE_APIS_STATUS + mobileNo + RedisConstants.US + referenceNo);

					if (breAPIStatusSet.contains("PosidexOuput_F") || breAPIStatusSet.contains("PosidexOuput_S")) {
						breAPIStatusSet.remove("PosidexOuput_F");
						breAPIStatusSet.remove("PosidexOuput_S");
						redisUtils.sadd(RedisConstants.BRE_APIS_STATUS + mobileNo + RedisConstants.US + referenceNo,
								breAPIStatusSet);
					}

					redisUtils.sadd(RedisConstants.BRE_APIS_STATUS + mobileNo + RedisConstants.US + referenceNo,
							"PosidexOuput_" + status);
					break;
				}
			case 10:
				if (apiName.equalsIgnoreCase(AppConstants.SIGNZ)) {
					redisUtils.sadd(RedisConstants.BRE_APIS_STATUS + mobileNo + RedisConstants.US + referenceNo,
							"Signz_" + status);
					break;
				}
			case 11:
				if (apiName.equalsIgnoreCase(AppConstants.HUNTER)) {
					redisUtils.sadd(RedisConstants.BRE_APIS_STATUS + mobileNo + RedisConstants.US + referenceNo,
							"Hunter_" + status);
					break;
				}
			case 12:
				if (apiName.equalsIgnoreCase(AppConstants.POSIDEX_NAME_MATCH)) {
					redisUtils.sadd(RedisConstants.BRE_APIS_STATUS + mobileNo + RedisConstants.US + referenceNo,
							"PosidexNameMatch_" + status);
					break;
				}
			case 13:
				if (apiName.equalsIgnoreCase(AppConstants.PERFIOS_STATUS)) {
					redisUtils.sadd(RedisConstants.BRE_APIS_STATUS + mobileNo + RedisConstants.US + referenceNo,
							"Perfios_" + status);
					break;
				}
			case 14:
				if (apiName.equalsIgnoreCase(AppConstants.EKYC_STATUS)) {
					redisUtils.sadd(RedisConstants.BRE_APIS_STATUS + mobileNo + RedisConstants.US + referenceNo,
							"Ekyc_" + status);
					break;
				}
			case 15:
				if (apiName.equalsIgnoreCase(AppConstants.DL)) {
					redisUtils.sadd(RedisConstants.BRE_APIS_STATUS + mobileNo + RedisConstants.US + referenceNo,
							"DrivingLicence_" + status);
					break;
				}
			case 16:
				if (apiName.equalsIgnoreCase(AppConstants.ELECTRICITY)) {
					redisUtils.sadd(RedisConstants.BRE_APIS_STATUS + mobileNo + RedisConstants.US + referenceNo,
							"Electricity_" + status);
					break;
				}
			case 17:
				if (apiName.equalsIgnoreCase(AppConstants.LPG)) {
					redisUtils.sadd(RedisConstants.BRE_APIS_STATUS + mobileNo + RedisConstants.US + referenceNo,
							"Lpg_" + status);
					break;
				}
			case 18:
				if (apiName.equalsIgnoreCase(AppConstants.MOB_AUTH)) {
					redisUtils.sadd(RedisConstants.BRE_APIS_STATUS + mobileNo + RedisConstants.US + referenceNo,
							"MobileAuth_" + status);
					break;
				}
			case 19:
				if (apiName.equalsIgnoreCase(AppConstants.VOTER_ID)) {
					redisUtils.sadd(RedisConstants.BRE_APIS_STATUS + mobileNo + RedisConstants.US + referenceNo,
							"VoterId_" + status);
					break;
				}
			case 20:
				if (apiName.equalsIgnoreCase(AppConstants.CP)) {
					redisUtils.sadd(RedisConstants.BRE_APIS_STATUS_WM + mobileNo, "CP_" + status);
					break;
				}
			case 21:
				if (apiName.equalsIgnoreCase(AppConstants.CIF)) {
					redisUtils.sadd(RedisConstants.BRE_APIS_STATUS_WM + mobileNo, "CIF_" + status);
					break;
				}
			case 22:
				if (apiName.equalsIgnoreCase(AppConstants.BRE1_FINAL_ELIG)) {
					redisUtils.sadd(RedisConstants.BRE_APIS_STATUS + mobileNo + RedisConstants.US + referenceNo,
							"BRE1FINALELIG_" + status);
					break;
				}
			case 23:
				if (apiName.equalsIgnoreCase(AppConstants.BRE2_FINAL_ELIG)) {
					redisUtils.sadd(RedisConstants.BRE_APIS_STATUS + mobileNo + RedisConstants.US + referenceNo,
							"BRE2FINALELIG_" + status);
					break;
				}
			}
		} catch (Exception exe) {
			logger.info("setAPIStatus ::  Exception :: " + CommonUtility.getPrintStackTrace(exe));
		}
	}

	public void setAPIReqAndRespTime(String apiName, String mobileNo, String referenceNo, String creationTime,
			String updationTime) {
		try {

			if (StringUtils.isBlank(mobileNo)) {
				mobileNo = redisUtils.get(RedisConstants.NTB_MOBILE_NO + referenceNo);
			}
			String apiReqRespTimeDiff = commonUtility.getTimeDifference(creationTime, updationTime);

			String apiTime = creationTime + "~" + updationTime + "~" + apiReqRespTimeDiff;

			switch (1) {
			case 1:
				if (apiName.equalsIgnoreCase("CIBIL")) {
					redisUtils.sadd(RedisConstants.BRE_APIS_TIME + mobileNo + RedisConstants.US + referenceNo,
							"Cibil~" + apiTime);
					break;
				}
			case 2:
				if (apiName.equalsIgnoreCase("EQUIFAX")) {
					redisUtils.sadd(RedisConstants.BRE_APIS_TIME + mobileNo + RedisConstants.US + referenceNo,
							"Equifax~" + apiTime);
					break;
				}
			case 3:
				if (apiName.equalsIgnoreCase("CRIF HIGHMARK")) {
					redisUtils.sadd(RedisConstants.BRE_APIS_TIME + mobileNo + RedisConstants.US + referenceNo,
							"CrifHighmark~" + apiTime);
					break;
				}
			case 4:
				if (apiName.equalsIgnoreCase("EXPERIAN")) {
					redisUtils.sadd(RedisConstants.BRE_APIS_TIME + mobileNo + RedisConstants.US + referenceNo,
							"Experian~" + apiTime);
					break;
				}
			case 5:
				if (apiName.equalsIgnoreCase("MBEOT")) {
					redisUtils.sadd(RedisConstants.BRE_APIS_TIME + mobileNo + RedisConstants.US + referenceNo,
							"Mbeot~" + apiTime);
					break;
				}
			case 6:
				if (apiName.equalsIgnoreCase("MERGED_SCORE")) {
					redisUtils.sadd(RedisConstants.BRE_APIS_TIME + mobileNo + RedisConstants.US + referenceNo,
							"MergedScore~" + apiTime);
					break;
				}
			case 7:
				if (apiName.equalsIgnoreCase(AppConstants.TRUSTING_SOCIAL)) {
					redisUtils.sadd(RedisConstants.BRE_APIS_TIME + mobileNo + RedisConstants.US + referenceNo,
							"TrustingSocial~" + apiTime);
					break;
				}
			case 8:
				if (apiName.equalsIgnoreCase(AppConstants.NSDL)) {
					redisUtils.sadd(RedisConstants.BRE_APIS_TIME + mobileNo + RedisConstants.US + referenceNo,
							"Pan~" + apiTime);
					break;
				}
			case 9:
				if (apiName.equalsIgnoreCase(AppConstants.POSIDEX_STATUS)) {
					redisUtils.sadd(RedisConstants.BRE_APIS_TIME + mobileNo + RedisConstants.US + referenceNo,
							"PosidexOuput~" + apiTime);
					break;
				}
			case 10:
				if (apiName.equalsIgnoreCase(AppConstants.SIGNZ)) {
					redisUtils.sadd(RedisConstants.BRE_APIS_TIME + mobileNo + RedisConstants.US + referenceNo,
							"Signz~" + apiTime);
					break;
				}
			case 11:
				if (apiName.equalsIgnoreCase(AppConstants.HUNTER)) {
					redisUtils.sadd(RedisConstants.BRE_APIS_TIME + mobileNo + RedisConstants.US + referenceNo,
							"Hunter~" + apiTime);
					break;
				}
			case 12:
				if (apiName.equalsIgnoreCase(AppConstants.POSIDEX_NAME_MATCH)) {
					redisUtils.sadd(RedisConstants.BRE_APIS_TIME + mobileNo + RedisConstants.US + referenceNo,
							"PosidexNameMatch~" + apiTime);
					break;
				}
			case 13:
				if (apiName.equalsIgnoreCase(AppConstants.PERFIOS_STATUS)) {
					redisUtils.sadd(RedisConstants.BRE_APIS_TIME + mobileNo + RedisConstants.US + referenceNo,
							"Perfios~" + apiTime);
					break;
				}
			case 14:
				if (apiName.equalsIgnoreCase(AppConstants.EKYC_STATUS)) {
					redisUtils.sadd(RedisConstants.BRE_APIS_TIME + mobileNo + RedisConstants.US + referenceNo,
							"Ekyc~" + apiTime);
					break;
				}
			case 15:
				if (apiName.equalsIgnoreCase(AppConstants.DL)) {
					redisUtils.sadd(RedisConstants.BRE_APIS_TIME + mobileNo + RedisConstants.US + referenceNo,
							"DrivingLicence~" + apiTime);
					break;
				}
			case 16:
				if (apiName.equalsIgnoreCase(AppConstants.ELECTRICITY)) {
					redisUtils.sadd(RedisConstants.BRE_APIS_TIME + mobileNo + RedisConstants.US + referenceNo,
							"Electricity~" + apiTime);
					break;
				}
			case 17:
				if (apiName.equalsIgnoreCase(AppConstants.LPG)) {
					redisUtils.sadd(RedisConstants.BRE_APIS_TIME + mobileNo + RedisConstants.US + referenceNo,
							"Lpg~" + apiTime);
					break;
				}
			case 18:
				if (apiName.equalsIgnoreCase(AppConstants.MOB_AUTH)) {
					redisUtils.sadd(RedisConstants.BRE_APIS_TIME + mobileNo + RedisConstants.US + referenceNo,
							"MobileAuth~" + apiTime);
					break;
				}
			case 19:
				if (apiName.equalsIgnoreCase(AppConstants.VOTER_ID)) {
					redisUtils.sadd(RedisConstants.BRE_APIS_TIME + mobileNo + RedisConstants.US + referenceNo,
							"VoterId~" + apiTime);
					break;
				}
			case 20:
				if (apiName.equalsIgnoreCase(AppConstants.CP)) {
					redisUtils.sadd(RedisConstants.BRE_APIS_TIME_WM + mobileNo, "CP~" + apiTime);
					break;
				}
			case 21:
				if (apiName.equalsIgnoreCase(AppConstants.CIF)) {
					redisUtils.sadd(RedisConstants.BRE_APIS_TIME_WM + mobileNo, "CIF~" + apiTime);
					break;
				}
			}
		} catch (Exception exe) {
			logger.info("setAPIReqAndRespTime ::  Exception :: " + CommonUtility.getPrintStackTrace(exe));
		}
	}


	public HashMap<String, String> getAddRefFillerMapping(String mobileNo, String tranRefNo) {
		HashMap<String, String> addRefFillerMapping = new HashMap<String, String>();
		try {
			String breFillerResp = "";
			String filler2 = "";
			String filler5 = "";

			if (redisUtils.exists(RedisConstants.BRE3_CALL_DATA + mobileNo + RedisConstants.US + tranRefNo)) {
				breFillerResp = redisUtils
						.get(RedisConstants.BRE3_CALL_DATA + mobileNo + RedisConstants.US + tranRefNo);
				logger.info("breFillerResp tranRefNo ::" + tranRefNo + ", BRE3_CALL_DATA :: " + breFillerResp);
			} else if (redisUtils.exists(RedisConstants.BRE2_CALL_DATA + mobileNo + RedisConstants.US + tranRefNo)) {
				breFillerResp = redisUtils
						.get(RedisConstants.BRE2_CALL_DATA + mobileNo + RedisConstants.US + tranRefNo);
				logger.info("breFillerResp tranRefNo ::" + tranRefNo + ", BRE2_CALL_DATA :: " + breFillerResp);
			} else if (redisUtils.exists(RedisConstants.BRECALL_DATA + mobileNo + RedisConstants.US + tranRefNo)) {
				breFillerResp = redisUtils.get(RedisConstants.BRECALL_DATA + mobileNo + RedisConstants.US + tranRefNo);
				logger.info("breFillerResp tranRefNo ::" + tranRefNo + ", BRECALL_DATA :: " + breFillerResp);
			}
			if (StringUtils.isNotEmpty(breFillerResp)) {
				org.json.JSONObject breFillRespObj = new org.json.JSONObject();
				filler5 = breFillRespObj.get("FILLER5") == null ? "" : breFillRespObj.get("FILLER5").toString();
				filler2 = breFillRespObj.get("FILLER2") == null ? "" : breFillRespObj.get("FILLER2").toString();

			}

			// VCIP logic starts
			String vcipStage = "";
			String filler2VCIP = "";
			if (redisUtils.exists(RedisConstants.VCIP_STAGE + mobileNo + RedisConstants.US + tranRefNo)) {
				vcipStage = redisUtils.get(RedisConstants.VCIP_STAGE + mobileNo + RedisConstants.US + tranRefNo);
			}
			logger.info("vcipStage tranRefNo ::" + tranRefNo + ", vcipStage :: " + vcipStage);
			if (StringUtils.isNotBlank(vcipStage)) {
				if (vcipStage.equals(AppConstants.COMPLETED_STATUS)) {
					filler2VCIP = "VC_P";
				} else {
					filler2VCIP = "VC_F";
				}
			} else {
				filler2VCIP = "VC_NA";
			}
			if (StringUtils.isNotBlank(filler2)) {
				filler2 = filler2 + "," + filler2VCIP;
			} else {
				filler2 = filler2VCIP;
			}
			// VCIP logic ends

			// Emandate logic starts
			String emandateStatus = "";
			if (redisUtils.exists(RedisConstants.DIGITAL_DISBURSEMENT + mobileNo + RedisConstants.US + tranRefNo)) {
				emandateStatus = redisUtils
						.get(RedisConstants.DIGITAL_DISBURSEMENT + mobileNo + RedisConstants.US + tranRefNo);
			}
			logger.info("emandateStatus tranRefNo ::" + tranRefNo + ", emandateStatus :: " + emandateStatus);
			if (StringUtils.isNotBlank(emandateStatus)) {
				if (emandateStatus.equals(AppConstants.COMPLETED_STATUS)) {
					filler2 = filler2 + "," + "EM_P";
				} else {
					filler2 = filler2 + "," + "EM_F";
				}
			} else {
				filler2 = filler2 + "," + "EM_NA";
			}
			// Emandate logic ends

			// Perfios logic starts
			String perfios_AccNo = "";
			if (redisUtils.exists(RedisConstants.PERFIOS_RETRIVE_DATA + mobileNo + RedisConstants.US + tranRefNo)) {
				HashMap<String, String> perfiosData = getPerfiosMapData(mobileNo, tranRefNo);
				perfios_AccNo = perfiosData.get("accountNo");
			}
			//logger.info("perfios_AccNo tranRefNo ::" + tranRefNo + ", perfios_AccNo :: " + perfios_AccNo);
			if (StringUtils.isNotBlank(perfios_AccNo)) {
				if (perfios_AccNo.contains("X")) {
					filler2 = filler2 + "," + "MS_M";
				} else {
					filler2 = filler2 + "," + "MS_NM";
				}
			} else {
				filler2 = filler2 + "," + "MS_NA";
			}
			// Perfios logic ends

			addRefFillerMapping.put("filler5", filler5);
			addRefFillerMapping.put("filler2", filler2);
			logger.info(
					"addRefFillerMapping tranRefNo ::" + tranRefNo + ", addRefFillerMapping :: " + addRefFillerMapping);
		} catch (Exception e) {
			logger.info("getAddRefFillerMapping Exception :: " + CommonUtility.getPrintStackTrace(e));
			//e.printStackTrace();
			logger.info("Exception :: "+e);
			addRefFillerMapping.put("filler5", "");
			addRefFillerMapping.put("filler2", "");
			logger.info("addRefFillerMapping tranRefNo :: Exception :: " + tranRefNo + ", addRefFillerMapping :: "
					+ addRefFillerMapping);
		}
		return addRefFillerMapping;
	}
}
