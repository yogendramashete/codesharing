package com.hdfcbank.blelengine.openAPI;

public class AadharEKYCJsonResponse {

	private String ResponseEncryptedValue;
	private String GWSymmetricKeyEncryptedValue;
	
	public String getResponseEncryptedValue() {
		return ResponseEncryptedValue;
	}
	public void setResponseEncryptedValue(String responseEncryptedValue) {
		ResponseEncryptedValue = responseEncryptedValue;
	}
	public String getGWSymmetricKeyEncryptedValue() {
		return GWSymmetricKeyEncryptedValue;
	}
	public void setGWSymmetricKeyEncryptedValue(String gWSymmetricKeyEncryptedValue) {
		GWSymmetricKeyEncryptedValue = gWSymmetricKeyEncryptedValue;
	}
	
	
}
