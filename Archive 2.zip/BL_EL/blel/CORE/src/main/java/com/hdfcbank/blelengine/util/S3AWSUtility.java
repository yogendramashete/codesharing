package com.hdfcbank.blelengine.util;

import com.amazonaws.AmazonServiceException;
import com.amazonaws.HttpMethod;
import com.amazonaws.auth.DefaultAWSCredentialsProviderChain;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.*;
import com.hdfcbank.blelengine.constants.AppConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

@Configuration
public class S3AWSUtility {
	private static final Logger logger = LoggerFactory.getLogger(S3AWSUtility.class);

	//private String awsS3Bucket = AppConstants.S3BUCKETNAME;
	private String awsRegion = AppConstants.S3REGION;

	@Bean
	public AmazonS3 getS3Client() {
		return AmazonS3ClientBuilder.standard()
				.withCredentials(DefaultAWSCredentialsProviderChain.getInstance())
				.withRegion(awsRegion).build();
	}

	public void uploadFileToS3Bucket(File file, String filePath, String awsS3Bucket) throws Exception {

		String generatePresignedUrl = null;

		try {

            Path filePart = Paths.get(file.toString());
            String normalized_path = filePart.normalize().toString();
            if (file.toString().contains(normalized_path)) {
                if (file.getCanonicalFile().toPath().startsWith(filePart)) {
                    byte[] contentBytes = Files.readAllBytes(file.toPath());
                    logger.info("uploadFileToS3Bucket contentBytes : " + contentBytes);
                    String fileName = file.getName();
                    logger.info("uploadFileToS3Bucket fileName :: " + fileName);
                    // ByteArrayInputStream input = new ByteArrayInputStream(contentBytes);
                    ObjectMetadata metadata = new ObjectMetadata();
                    metadata.setContentLength(contentBytes.length);
                    PutObjectResult result = getS3Client().putObject(awsS3Bucket, filePath + "/" + fileName, new ByteArrayInputStream(contentBytes), metadata);
                    logger.info("file uploaded successully .. " + result);
                    GeneratePresignedUrlRequest generatePresignedUrlRequest =
                            new GeneratePresignedUrlRequest(awsS3Bucket, fileName)
                                    .withMethod(HttpMethod.GET);

                    URL url = getS3Client().generatePresignedUrl(generatePresignedUrlRequest);
                    logger.info("generatePresignedUrl :: " + url);
                    file.delete();
                }
            }

        } catch (Exception e) {
            logger.info("uploadFileToS3Bucket Exception :: " + e.getMessage());
            e.printStackTrace();
        }
    }

	public S3Object getS3File(String fileName, String awsS3Bucket) {

		return getS3Client().getObject(new GetObjectRequest(awsS3Bucket, fileName));
	}


	public boolean exists(String filePath, String awsS3Bucket) {
		try {
			getS3Client().getObjectMetadata(awsS3Bucket, filePath);
		} catch(AmazonServiceException e) {
			return false;
		}
		return true;
	}
}
