package com.hdfcbank.blelengine.util;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.hdfcbank.blelengine.constants.RedisConstants;
import com.hdfcbank.blelengine.dao.Comondao;
import com.hdfcbank.blelengine.openAPI.*;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.SSLContexts;
import org.apache.http.util.EntityUtils;
import org.json.XML;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import java.io.File;
import java.util.Base64;


@Service
public class OpenBankApiConnector {
	public final static Logger logger = LoggerFactory.getLogger(OpenBankApiConnector.class);

	@Autowired
	private JsonRequestGenerator jsonrequestGenerator;

	// private String xkarzakey = "nhzeDHuqsm0QENHD";

	@Value("${openbankapiconnector.jwsreprotectheader}")
	private String jwsreprotectheader;

	@Value("${jsonrequestgenerator.blelclientid}")
         String blelclientid;

         @Value("${jsonrequestgenerator.blelclientsecret}")
         String blelclientsecret;


	@Value("${openbankapiconnector.pfxpath}")
	private String pfxpath;

	@Value("${openbankapiconnector.pfxpassword}")
	private String pfxpassword;

	@Value("${openbankapiconnector.clientScope}")
	private String clientScope;

	@Value("${openbankapiconnector.keystorepath}")
	private String keystorepath;

	@Value("${openbankapiconnector.truststorepath}")
	private String truststorepath;

	@Value("${openbankapiconnector.truststorepassword}")
	private String truststorepassword;

	@Value("${openbankapiconnector.keystorepassword}")
	private String keystorepassword;

	@Value("${openbankapiconnector.apikey}")
	private String apikey;

	@Value("${openbankapiconnector.blelapikey}")
	private String blelapikey;


	@Value("${openbankapiconnector.nsdlapikey}")
	private String nsdlapikey;

	@Value("${openbankapiconnector.nsdlscope}")
	private String nsdlscope;


	@Value("${openbankapiconnector.namematchapikey}")
	private String namematchapikey;

	@Value("${openbankapiconnector.blelpfxpath}")
	private String blelpfxpath;

	@Value("${openbankapiconnector.blelpfxpassword}")
	private String blelpfxpassword;

	@Value("${openbankapiconnector.blelkeystorepath}")
	private String blelkeystorepath;

	@Value("${openbankapiconnector.blelkeystorepassword}")
	private String blelkeystorepassword;

	@Value("${openbankapiconnector.bleltruststorepath}")
	private String bleltruststorepath;

	@Value("${openbankapiconnector.bleltruststorepassword}")
	private String bleltruststorepassword;

	@Autowired
	private CommonUtility commonUtility;

	//@Autowired
	//private BREUtil breUtil;

	@Autowired
	private RedisUtils redisUtils;

	@Autowired
	private AESUtils aesUtils;

	@Autowired
	private Comondao commondao;





	private CloseableHttpClient createHttpClient() throws Exception {

		return HttpClients.custom().setSSLSocketFactory(getSSLSocketFactory()).build();

	}

	private SSLConnectionSocketFactory getSSLSocketFactory() throws Exception {

		SSLConnectionSocketFactory sslSocketFactory = new SSLConnectionSocketFactory(loadSSLContext(),

				new String[]{"SSLv3", "TLSv1", "TLSv1.1", "TLSv1.2"}, null,
				SSLConnectionSocketFactory.getDefaultHostnameVerifier());

		return sslSocketFactory;
	}

	private SSLContext loadSSLContext() throws Exception {

		logger.info("loadSSLContext : keyStorePath :: " + keystorepath + " trustStorePath :: " + truststorepath );
		//logger.info(" keyStorePassword:: " + keystorepassword + " trustStorePassword:: " + truststorepassword );
		HostnameVerifier hostnameVerifier = new HostnameVerifier() {

			@Override
			public boolean verify(String arg0, SSLSession arg1) {
				return true;
			}
		};

		SSLContext sslcontext = SSLContexts.custom().loadKeyMaterial(new File(keystorepath),

						keystorepassword.toCharArray(),

						keystorepassword.toCharArray())

				.loadTrustMaterial(new File(truststorepath), truststorepassword.toCharArray())

				.build();

		return sslcontext;

	}



	public String panValidationServiceCall(String url, String requestpayload) throws Exception {
		String response = "";
		try {

			CloseableHttpClient httpClient = createHttpClient();

			HttpPost httpPost = new HttpPost(url);
			// logger.info("nsdlapiKey :" + nsdlapiKey);
			StringEntity entity = new StringEntity(requestpayload);
			httpPost.setEntity(entity);
			httpPost.setHeader("Accept", "application/json");
			httpPost.setHeader("Content-type", "application/json");
			httpPost.setHeader("apikey", nsdlapikey);

			CloseableHttpResponse httpResponse = httpClient.execute(httpPost);
			logger.info("httpResponse :" + httpResponse);
			int status = httpResponse.getStatusLine().getStatusCode();
			logger.info("httpResponse status code:" + status);


			HttpEntity entity2 = httpResponse.getEntity();

			response = EntityUtils.toString(entity2);
			// logger.info("resposne nsdl :" + response);
			return response;
		} catch (Exception e) {
			logger.info("Exception :: " + e.getMessage());
		}
		return response;

	}



	public String processNameMatchApiRequestBLEL(String payload, String url,
												 String banjourneyid,String  partnerjourneyid) {
		JSONObject plainRes = new JSONObject();
		String response = "";
		String serviceResponse = null;
		try {
			String blelscope = commondao.getAPIConfigParameters("Adobe", "Certificate_apiuat", "blelclientscope");

			String tranRefNo = commonUtility.genRandomNumber(12);

			String finalRePayload = jsonrequestGenerator.generateGstnRequestBLEL(payload, blelscope, tranRefNo);

			logger.info("final request payload :" + finalRePayload);

			serviceResponse = BLELNameMatchserviceCall(url, finalRePayload,banjourneyid, partnerjourneyid);
			logger.info("service response :" + serviceResponse);
			JSONParser jsonParser = new JSONParser();
			logger.info("connector1");
			Object object = jsonParser.parse(serviceResponse);
			logger.info("connector2");

			if (object instanceof JSONObject) {
				logger.info("connector3");
				JSONObject apiStatusOb = (JSONObject) object;
				logger.info("connector4");
				String apiStatus = (String) apiStatusOb.get("Status");

				logger.info("connector5");
				JsonResponse2 jsonResponse = new JsonResponseReader().readNew(serviceResponse);
				logger.info("connector6");
				String status = jsonResponse.getStatus();
				logger.info("connector7");

				if (status.equalsIgnoreCase("SUCCESS")) {
					logger.info("connector8");
					response = decrpytPosidexResponsePayload(jsonResponse);
					/*plainRes = decrpytNameMismatchResponsePayload(jsonResponseAsPanValidation, mobileNumber, tranRefNo, payload,
							"", "");*/
					logger.info("doAddressMatchPercentageResponse after decrpytNameMismatch :: {}", response);
					return response;
				} else {
					logger.info("connector9");
					response = null;
				}
			}

		} catch (Exception e) {
			logger.info("connector10");
			logger.info("Exception :: " + e.getMessage());
		}
		return response;
	}

	public String BLELNameMatchserviceCall(String url, String requestpayload, String bankJourneyID, String partnerJourneyID) {
        String response = "";
        //    RestConnector rc=new RestConnector();
        try {
            String environment = commondao.getAPIConfigParameters("Adobe", "common", "environment_nameMatch");
            String txn = commondao.getAPIConfigParameters("Adobe", "common", "txn");
            logger.info("environment {}", environment);
            CloseableHttpClient httpClient = BLELcreateHttpClient();
 
            HttpPost httpPost = new HttpPost(url);
            logger.info("apiKey :" + blelapikey);
            StringEntity entity = new StringEntity(requestpayload);
            httpPost.setEntity(entity);
            httpPost.setHeader("Accept", "application/json");
            httpPost.setHeader("Content-type", "application/json");
            httpPost.setHeader("apikey", blelapikey);
            httpPost.setHeader("txn", txn);
            httpPost.setHeader("clientid", blelclientid);
            httpPost.setHeader("client-secret", blelclientsecret);
	    	httpPost.setHeader("environment", environment);
            CloseableHttpResponse httpResponse = httpClient.execute(httpPost);
            logger.info("httpResponse :" + httpResponse);
            int status = httpResponse.getStatusLine().getStatusCode();
            logger.info("httpResponse status code:" + status);
 

            redisUtils.set("httpStatusCodeNameMatch" + bankJourneyID + "*" + partnerJourneyID, status + "");
            HttpEntity entity2 = httpResponse.getEntity();
 
            response = EntityUtils.toString(entity2);
            logger.info("resposne :" + response);
            return response;
        } catch (Exception e) {
            logger.info("Exception :: " + e.getMessage());
        }
        return response;
 
    }

	public JSONObject decrpytNameMatchResponsePayload(PanValidationJsonResponse jsonResponse, String mobileNumber,
													  String tranRefNo, String payload, String operationType, String creationTime, String updationTime) {
		JSONObject jsonObject = new JSONObject();
		String response, apiStatus = "failure";
		try {

			String encryptedData = jsonResponse.getGWSymmetricKeyEncryptedValue();
			Base64EncoderDecoder encoder = new Base64EncoderDecoder();
			RSAEncrypterDecrypter rsaEncrypterDecrypter = new RSAEncrypterDecrypter();
			byte[] decoded = encoder.decode(encryptedData.getBytes());
			byte[] decryptedData = rsaEncrypterDecrypter.decrypt(decoded,
					DigitalSignature.privateKey(pfxpath, pfxpassword));
			// logger.info("decrptyed data :" + new String(decryptedData));

			AESEncrypterDecrypter encrypterDecrypter = new AESEncrypterDecrypter();
			String encryptedValue = jsonResponse.getResponseEncryptedValue();
			byte[] decryptedValue = encrypterDecrypter.decrypt(encoder.decode(encryptedValue.getBytes()),
					decryptedData);
			// logger.info("decrptyed data final :" + new String(decryptedValue));
			response = new String(decryptedValue);
			org.json.JSONObject xmlTojsonObject = new org.json.JSONObject();
			xmlTojsonObject = XML.toJSONObject(response);
			String responseErrorCode = StringUtils.substringBetween(response, "<responseservice:errorCode>",
					"</responseservice:errorCode>");
			if (responseErrorCode.equalsIgnoreCase("0")) {
				apiStatus = "success";
			}
			String nameMatchPercentage = StringUtils.substringBetween(response, "<namePercentage>",
					"</namePercentage>");
			// System.out.println("Lead_Number :"+leadNumber);
			jsonObject.put("responseErrorCode", responseErrorCode);
			jsonObject.put("nameMatchPercentage", nameMatchPercentage);
			// jsonObject.put("PanValidationResponse", xmlTojsonObject);
			if (operationType.equals("perfiosNameMatchAPI")) {
				redisUtils.set(RedisConstants.NTB_PERFIOS_NAME_MATCH + mobileNumber + RedisConstants.US + tranRefNo,
						response);
			}

			if (operationType.equals("ekycNameMatchAPI")) {
				redisUtils.set(RedisConstants.NTB_EKYC_NAME_MATCH + mobileNumber + RedisConstants.US + tranRefNo,
						response);
			}
		} catch (Exception e) {
			apiStatus = "failure";
			logger.info("Exception :: " + e.getMessage());
		}
		return jsonObject;
	}



	public JSONObject decrpytAddressMatchResponsePayload(PanValidationJsonResponse jsonResponse, String mobileNumber,
														 String tranRefNo, String payload, String creationTime, String updationTime) {
		JSONObject jsonObject = new JSONObject();
		String response, apiStatus;
		try {
			String encryptedData = jsonResponse.getGWSymmetricKeyEncryptedValue();
			Base64EncoderDecoder encoder = new Base64EncoderDecoder();
			RSAEncrypterDecrypter rsaEncrypterDecrypter = new RSAEncrypterDecrypter();
			byte[] decoded = encoder.decode(encryptedData.getBytes());
			byte[] decryptedData = rsaEncrypterDecrypter.decrypt(decoded,
					DigitalSignature.privateKey(pfxpath, pfxpassword));
			// logger.info("decrptyed data :" + new String(decryptedData));

			AESEncrypterDecrypter encrypterDecrypter = new AESEncrypterDecrypter();
			String encryptedValue = jsonResponse.getResponseEncryptedValue();
			byte[] decryptedValue = encrypterDecrypter.decrypt(encoder.decode(encryptedValue.getBytes()),
					decryptedData);
			logger.info("decrptyed Address final  :" + new String(decryptedValue));
			response = new String(decryptedValue);
			//updationTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").format(Calendar.getInstance().getTime());
			org.json.JSONObject xmlTojsonObject = new org.json.JSONObject();
			xmlTojsonObject = XML.toJSONObject(response);
			String responseErrorCode = StringUtils.substringBetween(response, "<responseservice:errorCode>",
					"</responseservice:errorCode>");
			if (responseErrorCode.equalsIgnoreCase("0")) {
				apiStatus = "success";

				logger.info("apiStatus", apiStatus);
			}
			String addressPercentage = StringUtils.substringBetween(response, "<addressPercentage>",
					"</addressPercentage>");
			// System.out.println("Lead_Number :"+leadNumber);
			jsonObject.put("responseErrorCode", responseErrorCode);
			jsonObject.put("addressPercentage", addressPercentage);

			logger.info("addressPercentage", addressPercentage);
			// jsonObject.put("PanValidationResponse", xmlTojsonObject);

			redisUtils.set(RedisConstants.NTB_ADDRESS_MATCH + mobileNumber + RedisConstants.US + tranRefNo, response);
			// logger.info("NTB_NAME_MATCH_ ::" + cluster.get("NTB_NAME_MATCH_" +
			// mobileNumber + "_" + tranRefNo));

			logger.info("address test1");
		} catch (Exception e) {
			apiStatus = "Server Error";
			logger.info("Exception :: " + e.getMessage());
		}

		logger.info("address test2");
		return jsonObject;
	}



	public JSONObject processApiRequestBLEL(String payload, String url, String partnerJourneyId, String bankJourneyId) {
		JSONObject plainRes = new JSONObject();
		try {

//			logger.debug("jwsreprotectheader :"+jwsreprotectheader );


			String protectHeader = new Base64EncoderDecoder().encodeToString(jwsreprotectheader);

//			logger.debug("encoded value :" + protectHeader);

			String encodedPayload = new Base64EncoderDecoder().encodeToString(payload);

//			logger.debug("encoded paylod :" + encodedPayload);

			String request;
			request = protectHeader + "." + encodedPayload;

//			logger.info("payload :" + payload);

			byte[] signRequest = new DigitalSignature().sign(request, blelpfxpath, blelpfxpassword);

//			logger.debug("sign request :" + Base64.getEncoder().encodeToString(signRequest));

			request += "." + Base64.getEncoder().encodeToString(signRequest);
			logger.info("final request : " + request);


			String tranRefNo = commonUtility.genRandomNumber(12);
			String blelscope = commondao.getAPIConfigParameters("Adobe", "Certificate_apiuat", "blelclientscope");
			String finalRePayload = jsonrequestGenerator.generateRequestBLEL(request, blelscope, tranRefNo);

			logger.info("final request payload :" + finalRePayload);

			//	String serviceResponse = BLELserviceCallRest(url, finalRePayload);
			String serviceResponse = BLELserviceCall(url, finalRePayload, partnerJourneyId, bankJourneyId);
			logger.info("service response :" + serviceResponse);
			if (null != serviceResponse) {
				JsonResponse jsonResponse = new JsonResponseReader().read(serviceResponse);

				String status = jsonResponse.getStatus();

				if (status.equalsIgnoreCase("SUCCESS")) {
					//plainRes = decrpytResponsePayload(jsonResponse);
					plainRes = decrpytBLELResponsePayload(jsonResponse);
					return plainRes;
				}
		//	}
		}
		} catch (Exception e) {
			logger.info("Exception :: " + e.getMessage());
		}
		return plainRes;
	}


	public JSONObject processGstnApiRequestBLEL(String payload, String url) {
		JSONObject plainRes = new JSONObject();
		String response;
		try {


			String tranRefNo = commonUtility.genRandomNumber(12);
			String blelscope = commondao.getAPIConfigParameters("Adobe", "Certificate_apiuat", "blelclientscope");
			String finalRePayload = jsonrequestGenerator.generateGstnRequestBLEL(payload, blelscope, tranRefNo);

			logger.info("final request payload :" + finalRePayload);

			String serviceResponse = BLELGstnserviceCall(url, finalRePayload);
			logger.info("service response :" + serviceResponse);
			JSONParser jsonParser = new JSONParser();
			logger.info("connector1");
			Object object = jsonParser.parse(serviceResponse);
			logger.info("connector2");

			if (object instanceof JSONObject) {
				logger.info("connector3");
				JSONObject apiStatusOb = (JSONObject) object;
				logger.info("connector4");
				String apiStatus = (String) apiStatusOb.get("Status");

				logger.info("connector5");
				JsonResponse2 jsonResponse = new JsonResponseReader().readNew(serviceResponse);
				logger.info("connector6");
				String status = jsonResponse.getStatus();
				logger.info("connector7");
				if (status.equalsIgnoreCase("SUCCESS")) {
					logger.info("connector8");
					//plainRes = decrpytResponsePayload(jsonResponse);
					//plainRes = decrpytGstnBLELResponsePayload(jsonResponse);
					response = decrpytPosidexResponsePayload(jsonResponse);

					logger.info("response {}", response);
					plainRes = JSonParser.parseString(response);
					return plainRes;
				} else {
					logger.info("connector9");
					plainRes = null;
				}
			}

		} catch (Exception e) {
			logger.info("connector10");
			logger.info("Exception :: " + e.getMessage());
		}
		return plainRes;
	}


	public JSONObject processGetEkycApiRequestBLEL(String payload, String url, String bankJourneyID, String partnerJourneyID) {
		JSONObject plainRes = new JSONObject();
		String response;
		try {


			String tranRefNo = commonUtility.genRandomNumber(12);
			String blelscope = commondao.getAPIConfigParameters("Adobe", "Certificate_apiuat", "blelclientscope");
			String finalRePayload = jsonrequestGenerator.generateGstnRequestBLEL(payload, blelscope, tranRefNo);

			logger.info("final request payload :" + finalRePayload);

			String serviceResponse = BLELGetEkycserviceCall(url, finalRePayload, bankJourneyID, partnerJourneyID);
			logger.info("service response :" + serviceResponse);
			JSONParser jsonParser = new JSONParser();
			logger.info("connector1");
			Object object = jsonParser.parse(serviceResponse);
			logger.info("connector2");

			if (object instanceof JSONObject) {
				logger.info("connector3");
				JSONObject apiStatusOb = (JSONObject) object;
				logger.info("connector4");
				String apiStatus = (String) apiStatusOb.get("Status");

				logger.info("connector5");
				JsonResponse2 jsonResponse = new JsonResponseReader().readNew(serviceResponse);
				logger.info("connector6");
				String status = jsonResponse.getStatus();
				logger.info("connector7");
				if (status.equalsIgnoreCase("SUCCESS")) {
					logger.info("connector8");
					//plainRes = decrpytResponsePayload(jsonResponse);
					//plainRes = decrpytGstnBLELResponsePayload(jsonResponse);
					response = decrpytPosidexResponsePayload(jsonResponse);

					logger.info("response {}", response);
					plainRes = JSonParser.parseString(response);
					return plainRes;
				} else {
					logger.info("connector9");
					plainRes = (JSONObject) jsonParser.parse(serviceResponse);
				}
			}

		} catch (Exception e) {
			logger.info("connector10");
			logger.info("Exception :: " + e.getMessage());
		}
		return plainRes;
	}

	public JSONObject processEquifaxApiRequestBLEL(String payload, String url, String bankjourneyid,String partnerjourneyid) {
		JSONObject plainRes = new JSONObject();
		String response;
		try {


			String tranRefNo = commonUtility.genRandomNumber(12);
			String blelscope = commondao.getAPIConfigParameters("Adobe", "Certificate_apiuat", "blelclientscope");
			String finalRePayload = jsonrequestGenerator.generateGstnRequestBLEL(payload, blelscope, tranRefNo);

			logger.info("final request payload :" + finalRePayload);

			String serviceResponse = BLELEquifaxserviceCall(url, finalRePayload, bankjourneyid, partnerjourneyid);
			logger.info("service response :" + serviceResponse);
			JSONParser jsonParser = new JSONParser();
			logger.info("connector1");
			Object object = jsonParser.parse(serviceResponse);
			logger.info("connector2");

			if (object instanceof JSONObject) {
				logger.info("connector3");
				JSONObject apiStatusOb = (JSONObject) object;
				logger.info("connector4");
				String apiStatus = (String) apiStatusOb.get("Status");

				logger.info("connector5");
				JsonResponse2 jsonResponse = new JsonResponseReader().readNew(serviceResponse);
				logger.info("connector6");
				String status = jsonResponse.getStatus();
				logger.info("connector7");
				if (status.equalsIgnoreCase("SUCCESS")) {
					logger.info("connector8");
					//plainRes = decrpytResponsePayload(jsonResponse);
					//plainRes = decrpytGstnBLELResponsePayload(jsonResponse);
					response = decrpytPosidexResponsePayload(jsonResponse);

					logger.info("response {}", response);
					plainRes = JSonParser.parseString(response);
					return plainRes;
				} else {
					logger.info("connector9");
					plainRes = null;
				}
			}

		} catch (Exception e) {
			logger.info("connector10");
			logger.info("Exception :: " + e.getMessage());
		}
		return plainRes;
	}

	public String processPANApiRequestBLEL(String payload, String url, String  bankjourneyid, String partnerjourneyid) {
		JSONObject plainRes = new JSONObject();
		String response = "";
		String serviceResponse = null;
		try {


			String tranRefNo = commonUtility.genRandomNumber(12);
			String blelscope = commondao.getAPIConfigParameters("Adobe", "Certificate_apiuat", "blelclientscope");
			String finalRePayload = jsonrequestGenerator.generateGstnRequestBLEL(payload, blelscope, tranRefNo);

			logger.info("final request payload :" + finalRePayload);

			serviceResponse = BLELPANserviceCall(url, finalRePayload, bankjourneyid, partnerjourneyid);
			logger.info("service response :" + serviceResponse);
				JSONParser jsonParser = new JSONParser();
			logger.info("connector1");
				Object object = jsonParser.parse(serviceResponse);
			logger.info("connector2");

			if (object instanceof JSONObject) {
				logger.info("connector3");
				JSONObject apiStatusOb = (JSONObject) object;
				logger.info("connector4");
				String apiStatus = (String) apiStatusOb.get("Status");

				logger.info("connector5");
				JsonResponse2 jsonResponse = new JsonResponseReader().readNew(serviceResponse);
				logger.info("connector6");
				String status = jsonResponse.getStatus();
				logger.info("connector7");
				if (status.equalsIgnoreCase("SUCCESS")) {
					logger.info("connector8");
		//	plainRes = decrpytResponsePayload(jsonResponse);
				//	plainRes = decrpytGstnBLELResponsePayload(jsonResponse);
					response = decrpytPosidexResponsePayload(jsonResponse);

					logger.info("response {}", response);
				//	plainRes = JSonParser.parseString(response);
					return response;
				} else {
					logger.info("connector9");
					response = null;
			}
			}

		} catch (Exception e) {
			logger.info("connector10");
			logger.info("Exception :: " + e.getMessage());
		}
		return response;
	}

	public String BLELPANserviceCall(String url, String requestpayload, String bankJourneyID, String partnerJourneyID) {
        String response = "";
        try {
            String environment = commondao.getAPIConfigParameters("Adobe", "CustomerIdentification", "CustomerIdentification.PANEnquiryPAN.environment");
			String txn = commondao.getAPIConfigParameters("Adobe", "common", "txn");
			logger.info("environment {}", environment);
            CloseableHttpClient httpClient = BLELcreateHttpClient();
            HttpPost httpPost = new HttpPost(url);
            logger.info("apiKey :" + blelapikey);
            StringEntity entity = new StringEntity(requestpayload);
            httpPost.setEntity(entity);
            httpPost.setHeader("Accept", "application/json");
            httpPost.setHeader("Content-type", "application/json");
            httpPost.setHeader("apikey", blelapikey);
            httpPost.setHeader("txn", txn);
            httpPost.setHeader("clientid", blelclientid);
            httpPost.setHeader("client-secret", blelclientsecret);
            httpPost.setHeader("environment", environment);
            CloseableHttpResponse httpResponse = httpClient.execute(httpPost);
            logger.info("httpResponse :" + httpResponse);
            int status = httpResponse.getStatusLine().getStatusCode();
            logger.info("httpResponse status code:" + status);

            redisUtils.set("httpStatusCodePAN" + bankJourneyID + "*" + partnerJourneyID, status + "");
            HttpEntity entity2 = httpResponse.getEntity();
            response = EntityUtils.toString(entity2);
            logger.info("resposne :" + response);
            return response;
        } catch (Exception e) {
            logger.info("Exception :: " + e.getMessage());
        }
        return response;
    }
	
    public String decrpytPosidexResponsePayload(JsonResponse2 jsonResponse) {
		JSONObject jsonObject = new JSONObject();
		String response = "";
		try {
			String encryptedData = jsonResponse.getGWSymmetricKeyEncryptedValue();
			Base64EncoderDecoder encoder = new Base64EncoderDecoder();
			RSAEncrypterDecrypter rsaEncrypterDecrypter = new RSAEncrypterDecrypter();
			byte[] decoded = encoder.decode(encryptedData.getBytes());
			byte[] decryptedData = rsaEncrypterDecrypter.decrypt(decoded,
					DigitalSignature.privateKey(blelpfxpath, blelpfxpassword));
			// logger.info("decrptyed data :" + new String(decryptedData));

			AESEncrypterDecrypter encrypterDecrypter = new AESEncrypterDecrypter();
			String encryptedValue = jsonResponse.getResponseEncryptedValue();
			byte[] decryptedValue = encrypterDecrypter.decrypt(encoder.decode(encryptedValue.getBytes()),
					decryptedData);

			response = new String(decryptedValue);
		} catch (Exception e) {
			logger.error("Exception :: " + CommonUtility.getPrintStackTrace(e));
		}
		return response;
	}


	public String processGstnSearchApiRequestBLEL(String oauthtoken, String payload, String url) {
		JSONObject plainRes = new JSONObject();
		String response = "";
		try {
			String tranRefNo = commonUtility.genRandomNumber(12);
			String blelscope = commondao.getAPIConfigParameters("Adobe", "Certificate_apiuat", "blelclientscope");
			String finalRePayload = jsonrequestGenerator.generateGstnRequestBLEL(payload, blelscope, tranRefNo);

			logger.info("final request payload :" + finalRePayload);

			String serviceResponse = BLELGstnSearchserviceCall(oauthtoken, url, finalRePayload);
			logger.info("service response :" + serviceResponse);
			if (null != serviceResponse) {
				JsonResponse2 jsonResponse = new JsonResponseReader().readNew(serviceResponse);

				String status = jsonResponse.getStatus();

				if (status.equalsIgnoreCase("SUCCESS")) {

					response = decrpytPosidexResponsePayload(jsonResponse);

					logger.info("response {}", response);
					//plainRes=JSonParser.parseString(response);

					return response;
				}
			}
		} catch (Exception e) {
			logger.info("Exception :: " + e.getMessage());
		}
		return response;

	}


	public JSONObject decrpytBLELResponsePayload(JsonResponse jsonResponse) {
		JSONObject jsonObject = new JSONObject();
		try {
			String encryptedData = jsonResponse.getGWSymmetricKeyEncryptedValue();
			Base64EncoderDecoder encoder = new Base64EncoderDecoder();
			RSAEncrypterDecrypter rsaEncrypterDecrypter = new RSAEncrypterDecrypter();
			byte[] decoded = encoder.decode(encryptedData.getBytes());
			byte[] decryptedData = rsaEncrypterDecrypter.decrypt(decoded,
					DigitalSignature.privateKey(blelpfxpath, blelpfxpassword));
			logger.info("decrptyed data :" + new String(decryptedData));
			AESEncrypterDecrypter encrypterDecrypter = new AESEncrypterDecrypter();
			String encryptedValue = jsonResponse.getResponseSignatureEncryptedValue();
			byte[] decryptedValue = encrypterDecrypter.decrypt(encoder.decode(encryptedValue.getBytes()),
					decryptedData);
			logger.debug("decrptyed data final  :" + new String(decryptedValue));
			String response = new String(decryptedValue);
			String resArray[] = response.split("[.]");
			String decodedRes = new String(encoder.decode(resArray[1].getBytes()));
			logger.info("decoded payload :" + decodedRes);
			jsonObject = JSonParser.parseString(decodedRes);
		} catch (Exception e) {
			logger.info("Exception :: " + e.getMessage());
		}
		return jsonObject;
	}

	public String BLELserviceCall(String url, String requestpayload, String partnerJourneyID, String bankJourneyID) {
		String response = "";

		try {

			CloseableHttpClient httpClient = BLELcreateHttpClient();

			HttpPost httpPost = new HttpPost(url);
			logger.info("apiKey :" + blelapikey);
			StringEntity entity = new StringEntity(requestpayload);
			httpPost.setEntity(entity);
			httpPost.setHeader("Accept", "application/json");
			httpPost.setHeader("Content-type", "application/json");
			httpPost.setHeader("apikey", blelapikey);
			//httpPost.setHeader("Environment", environment);

			CloseableHttpResponse httpResponse = httpClient.execute(httpPost);
			logger.info("httpResponse :" + httpResponse);
			int status = httpResponse.getStatusLine().getStatusCode();
			logger.info("httpResponse status code:" + status);

			redisUtils.set("httpStatusCodeCommon" + bankJourneyID + "*" + partnerJourneyID, status + "");
			HttpEntity entity2 = httpResponse.getEntity();

			response = EntityUtils.toString(entity2);
			logger.info("resposne :" + response);
			return response;
		} catch (Exception e) {
			logger.info("Exception :: " + e.getMessage());
		}
		return response;

	}

	public String BLELGstnserviceCall(String url, String requestpayload) {
		String response = "";
		//	RestConnector rc=new RestConnector();
		try {
			String environment = commondao.getAPIConfigParameters("Adobe", "CustomerIdentification", "CustomerIdentification.PanEnquiryGSTN.environment");
			String txn = commondao.getAPIConfigParameters("Adobe", "common", "txn");
			String cygnetclientid = commondao.getAPIConfigParameters("Adobe", "CustomerIdentification", "CustomerIdentification.PanEnquiryGSTN.cygnetclientid");
			String cygnetclientsecret = commondao.getAPIConfigParameters("Adobe", "CustomerIdentification", "CustomerIdentification.PanEnquiryGSTN.cygnetclientsecret");

			logger.info("*****************HEAER**********************");

			logger.info("environment {}", environment);
			logger.info("txn {}", txn);
			logger.info("cygnetclientid {}", cygnetclientid);
			logger.info("cygnetclientsecret {}", cygnetclientsecret);
			logger.info("requestpayload {}", requestpayload);
			logger.info("Gstn URL {}", url);

			CloseableHttpClient httpClient = BLELcreateHttpClient();
			logger.info("environment {}", environment);
			HttpPost httpPost = new HttpPost(url);
			logger.info("apiKey :" + blelapikey);
			StringEntity entity = new StringEntity(requestpayload);
			httpPost.setEntity(entity);
			httpPost.setHeader("Accept", "application/json");
			httpPost.setHeader("Content-type", "application/json");
			httpPost.setHeader("apikey", blelapikey);
			httpPost.setHeader("txn", txn);
			httpPost.setHeader("clientid", cygnetclientid);
                        httpPost.setHeader("client-secret", cygnetclientsecret);
			httpPost.setHeader("environment", environment);
			CloseableHttpResponse httpResponse = httpClient.execute(httpPost);
			logger.info("httpResponse :" + httpResponse);
			int status = httpResponse.getStatusLine().getStatusCode();
			logger.info("httpResponse status code:" + status);

			HttpEntity entity2 = httpResponse.getEntity();

			response = EntityUtils.toString(entity2);
			logger.info("resposne :" + response);
			return response;
		} catch (Exception e) {
			logger.info("Exception :: " + e.getMessage());
		}
		return response;

	}

	public String BLELGetEkycserviceCall(String url, String requestpayload, String bankJourneyID, String partnerJourneyID) {
		String response = "";
		//	RestConnector rc=new RestConnector();
		try {
//			String environment = commondao.getAPIConfigParameters("Adobe", "common", "environment");
			String environment = commondao.getAPIConfigParameters("Adobe", "ekyc", "ekyc.GetEkycStatus.environment");
			String txn = commondao.getAPIConfigParameters("Adobe", "common", "txn");
			CloseableHttpClient httpClient = BLELcreateHttpClient();

			logger.info("environment {}", environment);
			HttpPost httpPost = new HttpPost(url);
			logger.info("apiKey :" + blelapikey);
			StringEntity entity = new StringEntity(requestpayload);
			httpPost.setEntity(entity);
			httpPost.setHeader("Accept", "application/json");
			httpPost.setHeader("Content-type", "application/json");
			httpPost.setHeader("apikey", blelapikey);
			httpPost.setHeader("txn", txn);
			//httpPost.setHeader("clientid", "noMWmSP4aoqLFNvVxwJZHI7RcAp/8468mT9HFCME3iUBRkqK6V2zR9Z4L63m5YRR4wuXdErc3IJ30T0bYYRSofIO4XxsfSU13S0IW6b3DEiBI7n/ucQEdHSLKLZjyFmg");
			//httpPost.setHeader("client-secret", "Xgbp3Fz3/ZmRkVjp9LWp3DHpD529Zo5BzGKIlipmJShEV2CWcV1msg6rXo1rxb16MGFjqFbfGUyoJbjGoSwfaXFWDi9Yp3KijFAh3RS2S9GT7NiqASG0Y2SWRMhqlwbCfcLbJjRUR5rpmh/NnpwQaKUErcnu8Qwhpqv1EmNYSDSvSdH8vuqTpqqx54ho9hGMJ6qK0Wk9u3eNKMb55q5uqyfJ9hCl5eQswXApqHL58QagguoqZs7yqnxPdTDBRyVz");
			httpPost.setHeader("environment", environment);
			CloseableHttpResponse httpResponse = httpClient.execute(httpPost);
			logger.info("httpResponse :" + httpResponse);
			int status = httpResponse.getStatusLine().getStatusCode();
			logger.info("httpResponse status code:" + status);
			redisUtils.set("httpStatusCodeCommon" + bankJourneyID + "*" + partnerJourneyID, status + "");
			HttpEntity entity2 = httpResponse.getEntity();

			response = EntityUtils.toString(entity2);
			logger.info("resposne :" + response);
			return response;
		} catch (Exception e) {
			logger.info("Exception :: " + e.getMessage());
		}
		return response;

	}


	public String BLELEquifaxserviceCall(String url, String requestpayload, String bankJourneyID, String partnerJourneyID) {
		String response = "";
		//	RestConnector rc=new RestConnector();
		try {
			String environment = commondao.getAPIConfigParameters("Adobe", "CustomerIdentification", "CustomerIdentification.PANEnquiryEquifax.environment");
			String txn = commondao.getAPIConfigParameters("Adobe", "common", "txn");
			logger.info("environment {}", environment);
			CloseableHttpClient httpClient = BLELcreateHttpClient();

			HttpPost httpPost = new HttpPost(url);
			logger.info("apiKey :" + blelapikey);
			StringEntity entity = new StringEntity(requestpayload);
			httpPost.setEntity(entity);
			httpPost.setHeader("Accept", "application/json");
			httpPost.setHeader("Content-type", "application/json");
			httpPost.setHeader("apikey", blelapikey);
			httpPost.setHeader("txn", txn);
			httpPost.setHeader("clientid", blelclientid);
			httpPost.setHeader("client-secret", blelclientsecret);
			httpPost.setHeader("environment", environment);
			CloseableHttpResponse httpResponse = httpClient.execute(httpPost);
			logger.info("httpResponse :" + httpResponse);
			int status = httpResponse.getStatusLine().getStatusCode();
			logger.info("httpResponse status code:" + status);


			redisUtils.set("httpStatusCodePAN" + bankJourneyID + "*" + partnerJourneyID, status + "");
			HttpEntity entity2 = httpResponse.getEntity();

			response = EntityUtils.toString(entity2);
			logger.info("resposne :" + response);
			return response;
		} catch (Exception e) {
			logger.info("Exception :: " + e.getMessage());
		}
		return response;

	}


	public String BLELGstnSearchserviceCall(String oauthToken, String url, String requestpayload) {
		String response = "";
		//	RestConnector rc=new RestConnector();
		try {
			String environment = commondao.getAPIConfigParameters("Adobe", "CustomerIdentification", "CustomerIdentification.PANEnquiryGSTNFilling.environment");

			String txn = commondao.getAPIConfigParameters("Adobe", "common", "txn");
			String cygnetclientid = commondao.getAPIConfigParameters("Adobe", "CustomerIdentification", "CustomerIdentification.PanEnquiryGSTN.cygnetclientid");
			String cygnetclientsecret = commondao.getAPIConfigParameters("Adobe", "CustomerIdentification", "CustomerIdentification.PanEnquiryGSTN.cygnetclientsecret");

			logger.info("*****************HEAER**********************");

			logger.info("environment {}", environment);
			logger.info("txn {}", txn);
			logger.info("cygnetclientid {}", cygnetclientid);
			logger.info("cygnetclientsecret {}", cygnetclientsecret);
			logger.info("requestpayload {}", requestpayload);
			logger.info("Gstn URL {}", url);
			logger.info("oauthToken {}", oauthToken);


			logger.info("environment {}", environment);
			KeyGenerator keyGenerator = new KeyGenerator();
			String txnAlphaNumberic = keyGenerator.generateAlphaNumericKey(32);

			CloseableHttpClient httpClient = BLELcreateHttpClient();

			logger.info("oauthToken {}", oauthToken);
			HttpPost httpPost = new HttpPost(url);
			logger.info("apiKey :" + blelapikey);
			StringEntity entity = new StringEntity(requestpayload);
			httpPost.setEntity(entity);
			httpPost.setHeader("Accept", "application/json");
			httpPost.setHeader("Content-type", "application/json");
			httpPost.setHeader("apikey", blelapikey);
			httpPost.setHeader("txn", txn);
				httpPost.setHeader("clientid", cygnetclientid);
			httpPost.setHeader("client-secret", cygnetclientsecret);
            httpPost.setHeader("auth-token", oauthToken);
            httpPost.setHeader("environment", environment);
			CloseableHttpResponse httpResponse = httpClient.execute(httpPost);
			logger.info("httpResponse :" + httpResponse);
			int status = httpResponse.getStatusLine().getStatusCode();
			logger.info("httpResponse status code:" + status);

			HttpEntity entity2 = httpResponse.getEntity();

			response = EntityUtils.toString(entity2);
			logger.info("resposne :" + response);
			return response;
		} catch (Exception e) {
			logger.info("Exception :: " + e.getMessage());
		}
		return response;

	}



	private CloseableHttpClient BLELcreateHttpClient() throws Exception {

		return HttpClients.custom().setSSLSocketFactory(getBLELSSLSocketFactory()).build();

	}


	private SSLConnectionSocketFactory getBLELSSLSocketFactory() throws Exception {

		SSLConnectionSocketFactory sslSocketFactory = new SSLConnectionSocketFactory(BLELloadSSLContext(),

				new String[]{"SSLv3", "TLSv1", "TLSv1.1", "TLSv1.2"}, null,
				SSLConnectionSocketFactory.getDefaultHostnameVerifier());

		return sslSocketFactory;
	}





	private SSLContext BLELloadSSLContext() throws Exception {

		logger.info("loadSSLContext : BLELkeyStorePath :: " + blelkeystorepath + " BLELtrustStorePath :: " + bleltruststorepath);
		// logger.info(" BLELkeyStorePassword:: " + blelkeystorepassword +   " BLELtrustStorePassword:: " + bleltruststorepassword);
		HostnameVerifier hostnameVerifier = new HostnameVerifier() {
			@Override
			public boolean verify(String arg0, SSLSession arg1) {
				return true;
			}
		};

		SSLContext sslcontext = SSLContexts.custom().loadKeyMaterial(new File(blelkeystorepath),

						blelkeystorepassword.toCharArray(),

						blelkeystorepassword.toCharArray())

				.loadTrustMaterial(new File(bleltruststorepath), bleltruststorepassword.toCharArray())

				.build();

		return sslcontext;

	}

	public JSONObject processApiRequestBLELGetDemog(String payload, String url, String partnerJourneyID, String bankJourneyID) {
		JSONObject plainRes = new JSONObject();
		try {

//			logger.debug("jwsreprotectheader :"+jwsreprotectheader );
			String protectHeader = new Base64EncoderDecoder().encodeToString(jwsreprotectheader);

//			logger.debug("encoded value :" + protectHeader);

			String encodedPayload = new Base64EncoderDecoder().encodeToString(payload);

//			logger.debug("encoded paylod :" + encodedPayload);

			String request;
			request = protectHeader + "." + encodedPayload;

//			logger.info("payload :" + payload);

			byte[] signRequest = new DigitalSignature().sign(request, blelpfxpath, blelpfxpassword);

//			logger.debug("sign request :" + Base64.getEncoder().encodeToString(signRequest));

			request += "." + Base64.getEncoder().encodeToString(signRequest);
			logger.info("final request : " + request);


			String tranRefNo = commonUtility.genRandomNumber(12);
			String blelscope = commondao.getAPIConfigParameters("Adobe", "Certificate_apiuat", "blelclientscope");
			String finalRePayload = jsonrequestGenerator.generateRequestBLELGetDemog(request, blelscope, tranRefNo);

			logger.info("final request payload :" + finalRePayload);

			String serviceResponse = BLELserviceCall(url, finalRePayload, partnerJourneyID, bankJourneyID);
			logger.info("service response :" + serviceResponse);
			if (null != serviceResponse) {
				JsonResponse jsonResponse = new JsonResponseReader().read(serviceResponse);

				String status = jsonResponse.getStatus();

				if (status.equalsIgnoreCase("SUCCESS")) {
					//plainRes = decrpytResponsePayload(jsonResponse);
					plainRes = decrpytBLELResponsePayload(jsonResponse);
					return plainRes;
				}
			}
		} catch (Exception e) {
			logger.info("Exception :: " + CommonUtility.getPrintStackTrace(e));
		}
		return plainRes;
	}

	public JSONObject processApiRequestSignzy(String payload, String url) throws Exception {
		JSONObject plainRes = new JSONObject();
		String response;
		try {

			logger.info("payload :" + payload);

			String tranRefNo = commonUtility.genRandomNumber(12);
			String blelscope = commondao.getAPIConfigParameters("Adobe", "Certificate_apiuat", "blelclientscope");
			String finalRePayload = jsonrequestGenerator.generateRequestSignzyBLEL(payload, blelscope, tranRefNo);

			logger.info("final request payload :" + finalRePayload);


			String serviceResponse = BLELSignzyserviceCall(url, finalRePayload);
			logger.info("service response :" + serviceResponse);
			if (null != serviceResponse) {
				JsonResponse2 jsonResponse = new JsonResponseReader().readNew(serviceResponse);

				String status = jsonResponse.getStatus();

				if (status.equalsIgnoreCase("SUCCESS")) {

					response = decrpytPosidexResponsePayload(jsonResponse);
					plainRes = JSonParser.parseString(response);
					return plainRes;
				}
			}
		} catch (Exception e) {
			logger.info("Exception :: " + e.getMessage());
		}
		return plainRes;
	}

	public String BLELSignzyserviceCall(String url, String requestpayload) {
		String response = "";
		String environment = commondao.getAPIConfigParameters("Adobe", "externalintegration", "externalintegration.signgy.environment");
		//	RestConnector rc=new RestConnector();
		try {

			CloseableHttpClient httpClient = BLELcreateHttpClient();

			HttpPost httpPost = new HttpPost(url);
			logger.info("apiKey :" + blelapikey);
			logger.info("Environment :" + environment);
			StringEntity entity = new StringEntity(requestpayload);
			httpPost.setEntity(entity);
			httpPost.setHeader("Accept", "application/json");
			httpPost.setHeader("Content-type", "application/json");
			httpPost.setHeader("apikey", blelapikey);
			//httpPost.setHeader("x-karza-key", "nhzeDHuqsm0QENHD");
			httpPost.setHeader("environment", environment);
			CloseableHttpResponse httpResponse = httpClient.execute(httpPost);
			logger.info("httpResponse :" + httpResponse);
			int status = httpResponse.getStatusLine().getStatusCode();
			logger.info("httpResponse status code:" + status);

			HttpEntity entity2 = httpResponse.getEntity();

			response = EntityUtils.toString(entity2);
			logger.info("resposne :" + response);
			return response;
		} catch (Exception e) {
			logger.info("Exception :: " + e.getMessage());
		}
		return response;

	}


	public JSONObject processApiRequestICAIData(String payload, String url, String accesstoken, String patronId) {
		JSONObject plainRes = new JSONObject();
		String response;
		try {

			logger.info("payload :" + payload);

			String tranRefNo = commonUtility.genRandomNumber(12);

			String blelscope = commondao.getAPIConfigParameters("Adobe", "Certificate_apiuat", "blelclientscope");

			String finalRePayload = jsonrequestGenerator.generateRequestICAIDataBLEL(payload, blelscope, tranRefNo);

			logger.info("final request payload :" + finalRePayload);


			String serviceResponse = BLELICAIserviceCall(url, finalRePayload, accesstoken, patronId);
			logger.info("service response :" + serviceResponse);
			if (null != serviceResponse) {
				JsonResponse2 jsonResponse = new JsonResponseReader().readNew(serviceResponse);

				String status = jsonResponse.getStatus();

				if (status.equalsIgnoreCase("SUCCESS")) {

					response = decrpytPosidexResponsePayload(jsonResponse);
					plainRes = JSonParser.parseString(response);
					return plainRes;
				}
			}
		} catch (Exception e) {
			logger.info("Exception :: " + e.getMessage());
		}
		return plainRes;
	}

	public String BLELICAIserviceCall(String url, String requestpayload, String accesstoken, String patronId) {
		String response = "";
		String environment = commondao.getAPIConfigParameters("Adobe", "common", "environment");
		//	RestConnector rc=new RestConnector();
		try {

			CloseableHttpClient httpClient = BLELcreateHttpClient();

			HttpPost httpPost = new HttpPost(url);
			logger.info("apiKey :" + blelapikey);
			logger.info("Environment :" + environment);
			StringEntity entity = new StringEntity(requestpayload);
			httpPost.setEntity(entity);
			httpPost.setHeader("Accept", "application/json");
			httpPost.setHeader("Content-type", "application/json");
			httpPost.setHeader("apikey", blelapikey);
			httpPost.setHeader("Authorization", accesstoken);
			httpPost.setHeader("patron_id", patronId);
			httpPost.setHeader("environment", environment);
			CloseableHttpResponse httpResponse = httpClient.execute(httpPost);
			logger.info("httpResponse :" + httpResponse);
			int status = httpResponse.getStatusLine().getStatusCode();
			logger.info("httpResponse status code:" + status);

			HttpEntity entity2 = httpResponse.getEntity();

			response = EntityUtils.toString(entity2);
			logger.info("resposne :" + response);
			return response;
		} catch (Exception e) {
			logger.info("Exception :: " + e.getMessage());
		}
		return response;

	}

	public JSONObject processApiRequestGetElectricityData(String payload, String url) {
		JSONObject plainRes = new JSONObject();
		String response;
		try {

			logger.info("payload :" + payload);

			String tranRefNo = commonUtility.genRandomNumber(12);
			String blelscope = commondao.getAPIConfigParameters("Adobe", "Certificate_apiuat", "blelclientscope");
			String finalRePayload = jsonrequestGenerator.generateRequestGetElectricitystatus(payload, blelscope, tranRefNo);

			logger.info("final request payload :" + finalRePayload);


			String serviceResponse = getElectricityServiceCall(url, finalRePayload);
			logger.info("service response :" + serviceResponse);
			if (null != serviceResponse) {
				//Handling Failure Scenario
				if(serviceResponse.contains("TH99500") || serviceResponse.contains("Unexpected Response")) {
					plainRes = JSonParser.parseString(serviceResponse);
					return plainRes;
				}
				JsonResponse2 jsonResponse = new JsonResponseReader().readNew(serviceResponse);

				String status = jsonResponse.getStatus();

				if (status.equalsIgnoreCase("SUCCESS")) {

					response = decrpytPosidexResponsePayload(jsonResponse);
					plainRes = JSonParser.parseString(response);
					return plainRes;
				}
			}
		} catch (Exception e) {
			logger.info("Exception :: " + e.getMessage());
		}
		return plainRes;
	}

	public JSONObject processApiRequestGetMCIData(String payload, String url, String bankJourneyId, String partnerJourneyID) {
		JSONObject plainRes = new JSONObject();
		String response;
		try {
			//logger.info("payload :" + payload);
			String tranRefNo = commonUtility.genRandomNumber(12);
			String blelscope = commondao.getAPIConfigParameters("Adobe", "Certificate_apiuat", "blelclientscope");
			String finalRePayload = jsonrequestGenerator.generateRequestGetMCIDataBLEL(payload, blelscope, tranRefNo);
			//logger.info("final request payload :" + finalRePayload);

			String serviceResponse = BLELMCIserviceCall(url, finalRePayload, bankJourneyId, partnerJourneyID);
			logger.info("service response :" + serviceResponse);
			if (null != serviceResponse) {
				JsonResponse2 jsonResponse = new JsonResponseReader().readNew(serviceResponse);
				String status = jsonResponse.getStatus();
				if (status.equalsIgnoreCase("SUCCESS")) {
					response = decrpytPosidexResponsePayload(jsonResponse);
					plainRes = JSonParser.parseString(response);
					return plainRes;
				}
			}
		} catch (Exception e) {
			logger.info("Exception :: " + e.getMessage());
		}
		return plainRes;
	}

	public JSONObject processApiRequestGetIdeaRasData(String payload, String url, String bankJourneyId, String partnerJourneyID) {
		JSONObject plainRes = new JSONObject();
		String response;
		try {
			//logger.info("payload :" + payload);
			String tranRefNo = commonUtility.genRandomNumber(12);
			String blelscope = commondao.getAPIConfigParameters("Adobe", "Certificate_apiuat", "blelclientscope");
			String finalRePayload = jsonrequestGenerator.generateRequestGetMCIDataBLEL(payload, blelscope, tranRefNo);
			//logger.info("final request payload :" + finalRePayload);

			String serviceResponse = BLELIdeaRasServiceCall(url, finalRePayload, bankJourneyId, partnerJourneyID);
			logger.info("service response :" + serviceResponse);
			if (null != serviceResponse) {
				JsonResponse2 jsonResponse = new JsonResponseReader().readNew(serviceResponse);
				String status = jsonResponse.getStatus();
				if (status.equalsIgnoreCase("SUCCESS")) {
					response = decrpytPosidexResponsePayload(jsonResponse);
					plainRes = JSonParser.parseString(response);
					return plainRes;
				}
			}
		} catch (Exception e) {
			logger.info("Exception :: " + e.getMessage());
		}
		return plainRes;
	}

	public String getElectricityServiceCall(String url, String requestpayload) {
		String response = "";
		String environment = commondao.getAPIConfigParameters("Adobe", "externalintegration", "externalintegration.karzaelectricity.environment");
		String xkarzakey = commondao.getAPIConfigParameters("Adobe", "externalintegration", "externalintegration.karzaelectricity.xkarzakey");

		//	RestConnector rc=new RestConnector();
		try {

			CloseableHttpClient httpClient = BLELcreateHttpClient();

			HttpPost httpPost = new HttpPost(url);
			logger.info("x-karza-key :" + xkarzakey);
			logger.info("Environment :" + environment);
			StringEntity entity = new StringEntity(requestpayload);
			httpPost.setEntity(entity);
			httpPost.setHeader("Accept", "application/json");
			httpPost.setHeader("Content-type", "application/json");
			httpPost.setHeader("x-karza-key", xkarzakey);
			httpPost.setHeader("apikey", blelapikey);
			httpPost.setHeader("environment", environment);
			CloseableHttpResponse httpResponse = httpClient.execute(httpPost);
			logger.info("httpResponse :" + httpResponse);
			int status = httpResponse.getStatusLine().getStatusCode();
			logger.info("httpResponse status code:" + status);

			HttpEntity entity2 = httpResponse.getEntity();

			response = EntityUtils.toString(entity2);
			logger.info("resposne :" + response);
			return response;
		} catch (Exception e) {
			logger.info("Exception :: " + e.getMessage());
		}
		return response;


	}

	public String BLELMCIserviceCall(String url, String requestpayload, String bankJourneyId, String partnerJourneyID)  {
		String response = "";
		String environment = commondao.getAPIConfigParameters("Adobe", "externalintegration", "externalintegration.karmci.environment");
		//	RestConnector rc=new RestConnector();
		try {

			CloseableHttpClient httpClient = BLELcreateHttpClient();

			HttpPost httpPost = new HttpPost(url);
			logger.info("apiKey :" + blelapikey);
			logger.info("Environment :" + environment);
			StringEntity entity = new StringEntity(requestpayload);
			httpPost.setEntity(entity);
			httpPost.setHeader("Accept", "application/json");
			httpPost.setHeader("Content-type", "application/json");
			httpPost.setHeader("apikey", blelapikey);
			httpPost.setHeader("Environment", environment);

			CloseableHttpResponse httpResponse = httpClient.execute(httpPost);
			logger.info("httpResponse :" + httpResponse);
			int status = httpResponse.getStatusLine().getStatusCode();
			logger.info("httpResponse status code:" + status);
			redisUtils.set("MCI_httpStatusCode" + bankJourneyId + "*" + partnerJourneyID, String.valueOf(status));
			HttpEntity entity2 = httpResponse.getEntity();

			response = EntityUtils.toString(entity2);
			logger.info("resposne :" + response);
			return response;
		} catch (Exception e) {
			logger.info("Exception :: " + e.getMessage());
		}
		return response;

	}

	public String BLELIdeaRasServiceCall(String url, String requestpayload, String bankJourneyId, String partnerJourneyID) {
		String response = "";
		//	RestConnector rc=new RestConnector();
		try {

			CloseableHttpClient httpClient = BLELcreateHttpClient();

			HttpPost httpPost = new HttpPost(url);
			logger.info("apiKey :" + blelapikey);
			StringEntity entity = new StringEntity(requestpayload);
			httpPost.setEntity(entity);
			httpPost.setHeader("Accept", "application/json");
			httpPost.setHeader("Content-type", "application/json");
			httpPost.setHeader("apikey", blelapikey);

			CloseableHttpResponse httpResponse = httpClient.execute(httpPost);
			logger.info("httpResponse :" + httpResponse);
			int status = httpResponse.getStatusLine().getStatusCode();
			logger.info("httpResponse status code:" + status);
			redisUtils.set("IDEARRas_httpStatusCode" + bankJourneyId + "*" + partnerJourneyID, String.valueOf(status));
			HttpEntity entity2 = httpResponse.getEntity();

			response = EntityUtils.toString(entity2);
			logger.info("resposne :" + response);
			return response;
		} catch (Exception e) {
			logger.info("Exception :: " + e.getMessage());
		}
		return response;

	}

	public String BLELCallbackserviceCall(String url, String requestpayload, String partnerType,String callBackURLheader ) {
		String response = "";
		//	RestConnector rc=new RestConnector();
		try {

			logger.info("url {}", url);
			logger.info("partnerType {}", partnerType);
			logger.info("callBackURLheader {}", callBackURLheader);
			String environment = commondao.getAPIConfigParameters("Adobe", "CustomerIdentification", "CustomerIdentification.PANEnquiryEquifax.environment");

			CloseableHttpClient httpClient = BLELcreateHttpClient();

			HttpPost httpPost = new HttpPost(url);
			logger.info("apiKey :" + blelapikey);
			StringEntity entity = new StringEntity(requestpayload);
			httpPost.setEntity(entity);
			httpPost.setHeader("Accept", "application/json");
			httpPost.setHeader("Content-type", "application/json");
			httpPost.setHeader("partnerType", partnerType);
			httpPost.setHeader("callBackURL", callBackURLheader);
			CloseableHttpResponse httpResponse = httpClient.execute(httpPost);
			logger.info("httpResponse :" + httpResponse);
			int status = httpResponse.getStatusLine().getStatusCode();
			logger.info("httpResponse status code:" + status);

			HttpEntity entity2 = httpResponse.getEntity();

			response = EntityUtils.toString(entity2);
			logger.info("resposne :" + response);
			return response;
		} catch (Exception e) {
			logger.info("Exception :: " + e.getMessage());
		}
		return response;

	}


	private Gson gson = new GsonBuilder().disableHtmlEscaping().create();

	public String decrpytVCIPResponsePayload(VcipJsonRequest jsonRequest) {
		JSONObject jsonObject = new JSONObject();
		String response = "";
		try {

			logger.info("VcipJsonRequest :: " + jsonRequest);

			String encryptedData = jsonRequest.getSymmetricKeyEncryptedValue();

			logger.info("encryptedData :: " + encryptedData);


			Base64EncoderDecoder encoder = new Base64EncoderDecoder();
			RSAEncrypterDecrypter rsaEncrypterDecrypter = new RSAEncrypterDecrypter();
			byte[] decoded = encoder.decode(encryptedData.getBytes());
			byte[] decryptedData = rsaEncrypterDecrypter.decrypt(decoded,
					DigitalSignature.privateKey(pfxpath, pfxpassword));

			logger.info("pfxpath" + pfxpath);
		//	logger.info("pfxpassword" + pfxpassword);

			logger.info("decrpytVCIPResponsePayload decrptyed data :" + new String(decryptedData));
			AESEncrypterDecrypter encrypterDecrypter = new AESEncrypterDecrypter();
			String encryptedValue = jsonRequest.getRequestEncryptedValue();
			byte[] decryptedValue = encrypterDecrypter.decrypt(encoder.decode(encryptedValue.getBytes()),
					decryptedData);
			logger.debug("decrpytVCIPResponsePayload decrptyed data final  :" + new String(decryptedValue));
			response = new String(decryptedValue);

		} catch (Exception e) {
			logger.info("Exception :: " + e.getMessage());
			logger.info("decrpytVCIPResponsePayload :: Exception " + e.getMessage());
		}
		return response;
	}

	public String apiServiceCallBlElUpdated(String url, String requestpayload, String blelApiKey) throws Exception {
		String response = "";
		try {
			logger.info("inside apiServiceCallBlElUpdated::");
			logger.info("apikey :: "+blelApiKey);
			CloseableHttpClient httpClient = BLELcreateHttpClient();
//					createHttpClient();

			HttpPost httpPost = new HttpPost(url);
			StringEntity entity = new StringEntity(requestpayload);
			httpPost.setEntity(entity);
			httpPost.setHeader("Accept", "application/x-www-form-urlencoded");
			httpPost.setHeader("Content-type", "application/x-www-form-urlencoded");
			httpPost.setHeader("apikey", blelApiKey);

			CloseableHttpResponse httpResponse = httpClient.execute(httpPost);
			// logger.info("httpResponse :" + httpResponse);
			int status = httpResponse.getStatusLine().getStatusCode();
			// logger.info("httpResponse status code:" + status);

			HttpEntity entity2 = httpResponse.getEntity();

			response = EntityUtils.toString(entity2);
			return response;
		} catch (Exception e) {
			logger.info("Exception :: " + CommonUtility.getPrintStackTrace(e));
		}
		return response;

	}

	public JSONObject processApiRequestGetEPFO(String payload, String url, String bankJourneyID, String partnerJourneyID) {
		JSONObject plainRes = new JSONObject();
		String response;
		try {

			logger.info("payload :" + payload);

			String tranRefNo = commonUtility.genRandomNumber(12);
			String blelscope = commondao.getAPIConfigParameters("Adobe", "Certificate_apiuat", "blelclientscope");
			String finalRePayload = jsonrequestGenerator.generateRequestGetElectricitystatus(payload, blelscope, tranRefNo);

			logger.info("final request payload :" + finalRePayload);


			String serviceResponse = getEPFOServiceCall(url, finalRePayload, bankJourneyID, partnerJourneyID);
			logger.info("service response :" + serviceResponse);
			if (null != serviceResponse) {
				//Handling Failure Scenario
				if(serviceResponse.contains("TH99500") || serviceResponse.contains("Unexpected Response")) {
					plainRes = JSonParser.parseString(serviceResponse);
					return plainRes;
				}
				JsonResponse2 jsonResponse = new JsonResponseReader().readNew(serviceResponse);

				String status = jsonResponse.getStatus();

				if (status.equalsIgnoreCase("SUCCESS")) {

					response = decrpytPosidexResponsePayload(jsonResponse);
					plainRes = JSonParser.parseString(response);
					return plainRes;
				}
			}
		} catch (Exception e) {
			logger.info("Exception :: " + e.getMessage());
		}
		return plainRes;
	}

	public String getEPFOServiceCall(String url, String requestpayload, String bankJourneyID, String partnerJourneyID) {
		String response = "";

		//String environment = commondao.getAPIConfigParameters("Adobe", "externalintegration", "externalintegration.karzaelectricity.environment");
		//	RestConnector rc=new RestConnector();
		String xkarzakey = commondao.getAPIConfigParameters("Adobe", "externalintegration", "externalintegration.karzaelectricity.xkarzakey");


		try {

			CloseableHttpClient httpClient = BLELcreateHttpClient();

			HttpPost httpPost = new HttpPost(url);
			logger.info("x-karza-key :" + xkarzakey);
		//	logger.info("Environment :" + environment);
			StringEntity entity = new StringEntity(requestpayload);
			httpPost.setEntity(entity);
			httpPost.setHeader("Accept", "application/json");
			httpPost.setHeader("Content-type", "application/json");
			httpPost.setHeader("x-karza-key", xkarzakey);
			httpPost.setHeader("apikey", blelapikey);
		//	httpPost.setHeader("environment", environment);
			CloseableHttpResponse httpResponse = httpClient.execute(httpPost);
			logger.info("httpResponse :" + httpResponse);
			int status = httpResponse.getStatusLine().getStatusCode();
			logger.info("httpResponse status code:" + status);
			redisUtils.set("httpStatusEPFO" + bankJourneyID + "*" + partnerJourneyID, status + "");
			HttpEntity entity2 = httpResponse.getEntity();

			response = EntityUtils.toString(entity2);
			logger.info("resposne :" + response);
			return response;
		} catch (Exception e) {
			logger.info("Exception :: " + e.getMessage());
		}
		return response;


	}

}