package com.hdfcbank.blelengine.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
@Component
public class JdbcUtil {
	public final static Logger logger = LoggerFactory.getLogger(JdbcUtil.class);

	/*
	 * @Value("${spring.datasource.url}") String DbUrl;
	 */
	
	/*
	 * @Value("${spring.datasource.username}") String dbUsername;
	 * 
	 * @Value("${spring.datasource.password}") String dbPassword;
	 * 
	 * @Value("${dBurl}") String dBurl;
	 */
	
	String dbUsername = "postgres";
	String dBurl = "jdbc:postgresql://postgres-bl.cuiqb4b4pu1u.us-east-1.rds.amazonaws.com/postgres";
	
	String dbPassword = "SnP#bl927";
	
	public  Connection  getConnection() {
		 Connection conn=null;
		 try {
			String DB_URL = dBurl;
			 String USER = dbUsername;
			 String PASS = dbPassword;
			    conn = DriverManager.getConnection(DB_URL, USER, PASS);
			    /*if (conn == null) {
					logger.info("conn object is null");

				} 	else {

					logger.info("conn object is not null");
			    }*/
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			 logger.info("SQLException ::"+e);
		}
		 return conn;
	}
	
	
	public PreparedStatement getPreparedStatement(String sql) {
		PreparedStatement stmt = null;
		 try {
			Connection  conn =  getConnection();
			stmt=conn.prepareStatement(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			 logger.info("SQLException ::"+e);
		}
		 return stmt;
	}
	
}
