package com.hdfcbank.blelengine.util;

import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
@Service
public class PayloadGenerator {

	@Value("${partner_key}")
	 String partnerkey;

	@Value("${product_key}")
	 String productkey;
	
	@Value("${journey_key}")
	 String journeykey;
	
	
	
	public  JSONObject getAuthObj() {
		JSONObject authObj = new JSONObject();
		authObj.put("partner_key", partnerkey);
		authObj.put("product_key", productkey);
		authObj.put("journey_key", journeykey);
		return authObj;
	}

  public  JSONObject getReqPayloadObj(JSONObject dataObj,String clientInfo) {
	  JSONObject payloadObj =  new JSONObject();
	 
	  JSONObject authObj =  new PayloadGenerator().getAuthObj();
	  
	  JSONObject clientInfoObj =  JSonParser.parseString(clientInfo);
	  
	  payloadObj.put("auth", authObj);
	  payloadObj.put("data", dataObj);
	  payloadObj.put("client_info", clientInfoObj);
	  
	  
	return payloadObj;
		
  }
}
