package com.hdfcbank.blelengine.util;

import java.util.HashMap;

import org.apache.commons.lang3.StringUtils;
import org.json.XML;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.hdfcbank.blelengine.constants.AppConstants;
import com.hdfcbank.blelengine.constants.RedisConstants;
import com.hdfcbank.blelengine.constants.StaticConstants;


import ch.qos.logback.classic.Logger;

@Component
public class NTBLoanUtil {
	@Value("${cache.redis.cluster.host}")
	private String redisHostAddress;

	@Value("${cache.redis.cluster.port}")
	private String redisPort;


	@Autowired
	private RedisUtils redisUtils;


	@Autowired
	private OpenBankApiConnector openBankapiConnector;




	public final static Logger logger = (Logger) LoggerFactory.getLogger(NTBLoanUtil.class);


	public HashMap<String, String> getMBEOT(String mobileNo, String applicationId) {
		HashMap<String, String> mbEotDataMapObj = new HashMap<String, String>();

		try {

			String xmlRequest = "";
			if (!AppConstants.IS_BRE_STATIC) {
				// TODO key word for setting response of MB EOT
				xmlRequest = redisUtils.get(RedisConstants.MBEOT + mobileNo + RedisConstants.US + applicationId);

				logger.info("Redis getMBEOT xmlRequest :: " + xmlRequest.length());
			} else {
				xmlRequest = StaticConstants.MBEOT_STAIC_REQ;
			}

			if (StringUtils.isNotBlank(xmlRequest)) {
				org.json.JSONObject xmlJSONObj = XML.toJSONObject(xmlRequest);

				String jsonPrettyPrintString = xmlJSONObj.toString(AppConstants.PRETTY_PRINT_INDENT_FACTOR)
						.replaceAll("(\r\n|\n)", "").replaceAll("  ", "").replaceAll("soapenv:", "")
						.replaceAll("ns0:", "");
				JSONParser jsonParser = new JSONParser();
				JSONObject jsonRequest = (JSONObject) jsonParser.parse(jsonPrettyPrintString);

				JSONObject Envelope = (JSONObject) jsonRequest.get("Envelope");
				JSONObject Body = (JSONObject) Envelope.get("Body");
				JSONObject mbEoTRequestTypeObj = ((JSONObject) Body.get("MultiBureauEoTRequest"));

				JSONObject chmObj = ((JSONObject) mbEoTRequestTypeObj.get("SENT-TO-CHM"));
				JSONObject experianObj = ((JSONObject) mbEoTRequestTypeObj.get("SENT-TO-EXPERIAN"));
				JSONObject cibilObj = ((JSONObject) mbEoTRequestTypeObj.get("SENT-TO-CIBIL"));
				JSONObject equifaxObj = ((JSONObject) mbEoTRequestTypeObj.get("SENT-TO-EQUIFAX"));
				JSONObject soaFillersObj = ((JSONObject) mbEoTRequestTypeObj.get("soaFillers"));
				mbEotDataMapObj.put("SENT_TO_CHM",
						StringUtils
						.isBlank(chmObj.get("content") == null ? "" : chmObj.get("content").toString()) == true
						? "Z"
								: chmObj.get("content").toString());
				mbEotDataMapObj.put("SENT_TO_EXPERIAN",
						StringUtils.isBlank(
								experianObj.get("content") == null ? "" : experianObj.get("content").toString()) == true
								? "Z"
										: experianObj.get("content").toString());
				mbEotDataMapObj.put("SENT_TO_EQUIFAX",
						StringUtils.isBlank(
								equifaxObj.get("content") == null ? "" : equifaxObj.get("content").toString()) == true
								? "Z"
										: equifaxObj.get("content").toString());
				mbEotDataMapObj.put("SENT_TO_CIBIL",
						StringUtils.isBlank(
								cibilObj.get("content") == null ? "" : cibilObj.get("content").toString()) == true ? "Z"
										: cibilObj.get("content").toString());
				mbEotDataMapObj.put("Filler1",
						StringUtils.isBlank(soaFillersObj.get("filler1") == null ? ""
								: soaFillersObj.get("filler1").toString()) == true ? "Z"
										: soaFillersObj.get("filler1").toString());
				mbEotDataMapObj.put("Filler2",
						StringUtils.isBlank(soaFillersObj.get("filler2") == null ? ""
								: soaFillersObj.get("filler2").toString()) == true ? "Z"
										: soaFillersObj.get("filler2").toString());
				String filler3 = soaFillersObj.get("filler3") == null ? "" : soaFillersObj.get("filler3").toString();

				String score = "";
				String band = "";
				if (StringUtils.isNotBlank(filler3)) {
					String[] filler3Arr = filler3.split(",");
					if (filler3Arr.length > 1) {
						score = StringUtils.isBlank(filler3Arr[0] == null ? "" : filler3Arr[0].toString()) == true ? "Z"
								: filler3Arr[0].toString();
						band = StringUtils.isBlank(filler3Arr[1] == null ? "" : filler3Arr[1].toString()) == true ? "Z"
								: filler3Arr[1].toString();
					}

				}
				mbEotDataMapObj.put("Filler3", filler3);
				mbEotDataMapObj.put("score", score);
				mbEotDataMapObj.put("band", band);
				mbEotDataMapObj.put("Filler4",
						StringUtils.isBlank(soaFillersObj.get("filler4") == null ? ""
								: soaFillersObj.get("filler4").toString()) == true ? "Z"
										: soaFillersObj.get("filler4").toString());
				String filler5 = StringUtils.isBlank(
						soaFillersObj.get("filler5") == null ? "" : soaFillersObj.get("filler5").toString()) == true
						? "Z"
								: soaFillersObj.get("filler5").toString();
				filler5 = filler5.replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;");
				mbEotDataMapObj.put("Filler5", filler5);
			} else {
				mbEotDataMapObj = AppConstants.MBEOT_EMPTY_REQ();
			}

		} catch (Exception e) {
			logger.info("Exception :: "+CommonUtility.getPrintStackTrace(e));
			logger.info("Exception getMBEOT :: " + e.getMessage());
			mbEotDataMapObj = AppConstants.MBEOT_EMPTY_REQ();
		}
		return mbEotDataMapObj;
	}

	@SuppressWarnings("unchecked")
	public String getItemArray(JSONArray arrayObj, String tagKey, String tagType) {
		StringBuilder itemArrObj = new StringBuilder();
		StringBuilder isDataAvailable = new StringBuilder();
		try {

			if (arrayObj.size() > 0) {
				arrayObj.forEach(item -> {
					JSONObject obj = (JSONObject) item;
					String tagValue = obj.get(tagKey).toString();
					if (StringUtils.isNotBlank(tagValue)) {
						if (isDataAvailable.length() == 0)
							isDataAvailable.append("Y");
						if (tagType.equals(AppConstants.TAG_TYPE_DATE)) {
							tagValue = CommonUtility.formatDate(tagValue, AppConstants.DATE_FMT_ddMMyyyy,
									AppConstants.DATE_FMT_yyyy_MM_dd);
							itemArrObj.append("<item>" + tagValue + "</item>");
						} else if (tagType.equals(AppConstants.TAG_TYPE_DATE2)) {
							tagValue = tagValue.split(" ")[0];
							itemArrObj.append("<item>" + tagValue + "</item>");
						} else if (tagType.equals(AppConstants.TAG_TYPE_DATE3)) {
							itemArrObj.append("<item>" + tagValue + "</item>");
						} else if (tagType.equals(AppConstants.TAG_TYPE_DECIMAL)) {
							double tagValueDec = Double.parseDouble(tagValue);
							itemArrObj.append("<item>" + tagValueDec + "</item>");
						} else {
							itemArrObj.append("<item>" + tagValue + "</item>");
						}

					} else {
						/*
						 * //added below condition to avoid the multiple iteration for blank values
						 * if(StringUtils.isBlank(itemArrObj)) {
						 * itemArrObj.append(addDefaultTag(tagType)); }
						 */
						itemArrObj.append(addDefaultTag(tagType));
					}

				});

			}
			System.out.println("isDataavailable for tag :" + tagKey + ": :" + isDataAvailable);
			if (isDataAvailable.toString().equals("Y")) {
				return itemArrObj.toString();
			} else {
				return "".toString();
			}
		} catch (Exception e) {
			logger.info("Exception :: getItemArray : " + CommonUtility.getPrintStackTrace(e));
		}
		return itemArrObj.toString();
	}


	public String addDefaultTag(String tagType) {
		String defaultTag = "";

		if (tagType.equals(AppConstants.TAG_TYPE_DATE)) {
			defaultTag = "<item>" + AppConstants.DEFAULT_DATE + "</item>";
		} else if (tagType.equals(AppConstants.TAG_TYPE_DATE2)) {
			defaultTag = "<item>" + AppConstants.DEFAULT_DATE + "</item>";
		} else if (tagType.equals(AppConstants.TAG_TYPE_DATE3)) {
			defaultTag = "<item>" + AppConstants.DEFAULT_DATE + "</item>";
		} else if (tagType.equals(AppConstants.TAG_TYPE_INT)) {
			defaultTag = "<item>-999</item>";
		} else if (tagType.equals(AppConstants.TAG_TYPE_DECIMAL)) {
			defaultTag = "<item>-999</item>";
		} else {
			defaultTag = "<item>Z</item>";
		}

		return defaultTag;
	}

}
