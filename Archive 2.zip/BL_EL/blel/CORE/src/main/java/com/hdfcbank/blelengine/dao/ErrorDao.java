package com.hdfcbank.blelengine.dao;

import com.hdfcbank.blelengine.service.impl.ErrorConfig;
import com.hdfcbank.blelengine.service.impl.ErrorRowMapper;
import com.hdfcbank.blelengine.util.CommonUtility;
import lombok.extern.log4j.Log4j2;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Log4j2
@Repository
public class ErrorDao {


    @Autowired
    JdbcTemplate jdbcTemplate;

    public Boolean checkErrorRecord(String stepName, String errorCode) {
        log.info("getLoanAppInfo :: ");
        List<String> errorlist = null;
        String isactive = "Y";
        String error = "";

        Boolean recordFound = false;


        String checkErrorRecord = "select count(*) from errormsgconfig where stepname= ? and backenderrorcode=? ";


        recordFound = jdbcTemplate.queryForObject(checkErrorRecord, Boolean.class, stepName, errorCode);
        log.info("recordCount :: " + recordFound);


        return recordFound;
    }

    public List<Map<String, Object>> getErrorDetails(String stepName, String errorCode) {

        List<Map<String, Object>> leaddata = null;

        String query = "select errorcode, errormsg from errormsgconfig where  stepname =? and backenderrorcode= ?";

        try {
            leaddata = jdbcTemplate.queryForList(query, new Object[]{stepName, errorCode});
            log.info("leaddata ::" + leaddata.size());
        } catch (Exception exe) {
            log.info("Exception :: " + exe);
        }
        return leaddata;
    }


    public List<Map<String, Object>> getDefaultErrorDetails() {
        log.info("getDefaultErrorDetails");
        String errorCode = "LN11111";
        List<Map<String, Object>> leaddata = null;
        String query = "select errorcode, errormsg from errormsgconfig where errorcode= ? ";

        try {
            leaddata = jdbcTemplate.queryForList(query, new Object[]{errorCode});
            log.info("leaddata ::" + leaddata.size());
        } catch (Exception exe) {
            log.info("Exception :: " + exe);
        }
        return leaddata;
    }


}