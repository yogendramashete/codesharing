package com.hdfcbank.blelengine.util;

import com.hdfcbank.blelengine.constants.AppConstants;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.rendering.ImageType;
import org.apache.pdfbox.rendering.PDFRenderer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import javax.imageio.ImageIO;
import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.awt.image.BufferedImage;
import java.io.*;
import java.nio.file.DirectoryNotEmptyException;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Paths;
import java.security.SecureRandom;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;



@Service
public class CommonUtility {
	public final static Logger logger = LoggerFactory.getLogger(CommonUtility.class);


	@Value("${commonutility.mailfromaddress}")
	private String mailfromaddress;

	@Value("${commonutility.mailpassword}")
	private String mailpassword;

	@Value("${commonutility.mailtoaddress}")
	private String mailtoaddress;

	@Value("${commonutility.mailhost}")
	private String mailhost;

	@Value("${commonutility.mailport}")
	private String mailport;

	@Value("${commonutility.dafpath}")
	private String dafpath;
	

	@Autowired
	private APIConnector apiConnector;


	@Autowired
	private AESUtils aesUtils;
	
	@Autowired
	SFTPUtility sftpUtility;

	static SecureRandom random = new SecureRandom();

	public String genRandomNumber(int length) {
		char[] digits = new char[length];
		digits[0] = (char) (random.nextInt(9) + '1');
		for (int i = 1; i < length; i++) {
			digits[i] = (char) (random.nextInt(10) + '0');
		}

		return new String(digits);
	}

	public HashMap<String, String> getParsingDetailsfrmString(String message) {
		HashMap<String, String> hashMap = new HashMap<String, String>();
		try {
			String arr[] = message.split("&");
			for (int i = 0; i < arr.length; i++) {
				String data = arr[i];
				String dataArray[] = data.split("=");
				if (dataArray.length > 1) {
					hashMap.put(dataArray[0], dataArray[1]);
				} else {
					hashMap.put(dataArray[0], "");
				}
			}

		} catch (Exception e) {
			logger.info("Exception :: " + CommonUtility.getPrintStackTrace(e));
		}
		return hashMap;
	}

	public String changeDateFormat(String dateValue, String format, String targetDtFormat) {
		String formattedDate = "";
		try {

			DateFormat originalFormat = new SimpleDateFormat(format);
			DateFormat targetFormat = new SimpleDateFormat(targetDtFormat);
			Date date = originalFormat.parse(dateValue);
			formattedDate = targetFormat.format(date);
		} catch (Exception e) {
			return dateValue;
		}
		return formattedDate;

	}

	public static LocalDate getinterestStartDate() {
		LocalDate date = LocalDate.now();
		int day = 0;
		try {
			System.out.println("get day of month:" + date.getDayOfMonth());
			if (date.getDayOfMonth() < 7) {
				date = date.plusMonths(1);
				date = date.plusDays(Long.valueOf(7) - date.getDayOfMonth());
			} else if (date.getDayOfMonth() > 6 && date.getDayOfMonth() < 21) {
				date = date.plusMonths(1);
				date = date.minusDays(date.getDayOfMonth() - Long.valueOf(7));
			} else {
				date = date.plusMonths(2).withDayOfMonth(5);
			}
			logger.info("emi start date :" + date);
		} catch (Exception e) {
			logger.info("Exception :: " + e.getMessage());
		}
		return date;
	}

	public static boolean isWithInDueDate() {
		LocalDate date = LocalDate.now();
		boolean isWithInDueDt = false;
		try {
			System.out.println("isWithInDueDate : " + date.getDayOfMonth());
			if (date.getDayOfMonth() < 7) {
				date = date.plusMonths(1);
				date = date.plusDays(Long.valueOf(7) - date.getDayOfMonth());
				isWithInDueDt = true;
			} else if (date.getDayOfMonth() > 6 && date.getDayOfMonth() < 21) {
				date = date.plusMonths(1);
				date = date.minusDays(date.getDayOfMonth() - Long.valueOf(7));
				isWithInDueDt = true;
			} else {
				date = date.plusMonths(2).withDayOfMonth(5);
				isWithInDueDt = false;
			}
			logger.info("emi start date :" + date);
		} catch (Exception e) {
			logger.info("Exception :: " + e.getMessage());
		}
		return isWithInDueDt;
	}


	public String Panreqverification(String key) {
		logger.info("inside Panreqverification ...");
		String value = "";
		try {
			HashMap<String, String> panvalidation = new HashMap<String, String>();
			panvalidation.put("1", "Success");
			panvalidation.put("2", "System error");
			panvalidation.put("3", "Authentication failure");
			panvalidation.put("4", "User not authorized");
			panvalidation.put("5", "No PANs entered");
			panvalidation.put("6", "User validity has expired");
			panvalidation.put("7", "Number of PANs exceeds the limit (5)");
			panvalidation.put("8", "Not enough balance");
			panvalidation.put("9", "Not an HTTPs request");
			panvalidation.put("10", "POST method method not used ");
			panvalidation.put("99", "In Case of any kind of error");
			panvalidation.put("E", "EXISTING AND VALID");
			panvalidation.put("F", "Marked as Fake");
			panvalidation.put("X", "Marked as Deactivated");
			panvalidation.put("D", "Deleted");
			panvalidation.put("N", "Record (PAN) Not Found in ITD Database/Invalid PAN");
			panvalidation.put("EA", "Existing and Valid but event marked as “Amalgamation” in ITD database");
			panvalidation.put("EC", "Existing and Valid but event marked as “Acquisition” in ITD database");
			panvalidation.put("ED", "Existing and Valid but event marked as “Death” in ITD database");
			panvalidation.put("EI", "Existing and Valid but event marked as “Dissolution” in ITD database");
			panvalidation.put("EL", "Existing and Valid but event marked as “Liquidated” in ITD database");
			panvalidation.put("EM", "Existing and Valid but event marked as “Merger” in ITD database");
			panvalidation.put("EP", "Existing and Valid but event marked as “Partition” in ITD database");
			panvalidation.put("ES", "Existing and Valid but event marked ");
			panvalidation.put("EU", "Existing and Valid but event marked as “Under Liquidation” in ITD database");

			value = panvalidation.get("EU");
			logger.info(value);

		} catch (Exception e) {
			logger.info("Exception :: " + CommonUtility.getPrintStackTrace(e));
		}
		return value;

	}

	public static String getDate(String pattern) {

		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);

		String date = simpleDateFormat.format(new Date());
		return date;

	}

	public static String formatDate(String date, String oldPattern, String newPattern) {

		DateTimeFormatter oldPatternDTFObj = DateTimeFormatter.ofPattern(oldPattern);
		DateTimeFormatter newPatternDTFObj = DateTimeFormatter.ofPattern(newPattern);
		LocalDate datetime = LocalDate.parse(date, oldPatternDTFObj);
		String convertedDt = datetime.format(newPatternDTFObj);

		return convertedDt;
	}

	public static String getTimeStamp() {
		Date date = new Date();
		String timeStamp = String.valueOf(date.getTime());
		// System.out.println("timeStamp :: " + timeStamp);
		return timeStamp;
	}

	public static String getPrintStackTrace(Throwable e) {
		final StringWriter sw = new StringWriter();
		final PrintWriter pw = new PrintWriter(sw);
		e.printStackTrace(pw);
		return sw.toString();
	}

	public static String fetchPinCodeFromAddress(String address) {
		String zip = "";
		Pattern zipPattern = Pattern.compile("(\\d{6})");
		Matcher zipMatcher = zipPattern.matcher(address);
		if (zipMatcher.find()) {
			zip = zipMatcher.group(1);
		}
		return zip;
	}

	public static String getGender(String salutation) {
		String gender = "";
		if (StringUtils.isNotBlank(salutation)) {
			if (salutation.equalsIgnoreCase("Mr")) {
				gender = "M";
			} else if (salutation.equalsIgnoreCase("Ms")) {
				gender = "F";
			} else if (salutation.equalsIgnoreCase("Mrs")) {
				gender = "F";
			} else if (salutation.equalsIgnoreCase("Mx")) {
				gender = "T";
			}
		}
		return gender;
	}

	public static String getGenderInitial(String gender) {
		if (gender.equalsIgnoreCase("Male")) {
			gender = "M";
		} else if (gender.equalsIgnoreCase("Female")) {
			gender = "F";
		} else if (gender.equalsIgnoreCase("Transgender")) {
			gender = "T";
		}
		return gender;
	}

	public String generateRandomNo(int length) {
		String randomNo = RandomStringUtils.randomAlphanumeric(length).toUpperCase();
		return randomNo;
	}

	public String getTimeDifference(String time1, String time2) {
		String timeDifference = "";
		try {
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
			Date date1 = format.parse(time1);
			Date date2 = format.parse(time2);
			long difference = (date2.getTime() - date1.getTime()) / 1000;
			timeDifference = String.valueOf(difference);
		} catch (Exception exe) {

			logger.info("getTimeDifference Exception :: " + CommonUtility.getPrintStackTrace(exe));
		}
		return timeDifference;
	}

	public long getTimeDiffLong(String time1, String time2) {
		long timeDifference = 0;
		try {
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
			Date date1 = format.parse(time1);
			Date date2 = format.parse(time2);
			timeDifference = (date2.getTime() - date1.getTime()) / 1000;
		} catch (Exception exe) {
			logger.info("getTimeDifference Exception :: " + CommonUtility.getPrintStackTrace(exe));
		}
		return timeDifference;
	}

	public static String genUserOtp(int length) {
		char[] digits = new char[length];
		digits[0] = (char) (random.nextInt(9) + '1');
		for (int i = 1; i < length; i++) {
			digits[i] = (char) (random.nextInt(10) + '0');
		}
		return new String(digits);
	}

	public static String getYearMinus(int yearsToSubtract) {
		String changedYear = "";
		try {
			LocalDate localDateObj = LocalDate.now();
			localDateObj = localDateObj.minusYears(yearsToSubtract);
			changedYear = String.valueOf(localDateObj.getYear());
		} catch (Exception e) {
			logger.info("Exception :: " + CommonUtility.getPrintStackTrace(e));
		}
		return changedYear;
	}

	public void saveFileToPath(String base64, String filePath) {
		try {
			File outputFile = new File(filePath);
			byte[] decodedBytes = Base64.getDecoder().decode(base64);
			FileUtils.writeByteArrayToFile(outputFile, decodedBytes);

		} catch (Exception e) {
			logger.info("saveFileToPath Exception :: " + getPrintStackTrace(e));
		}
	}

	public String readImageFromPath(String imagePath) {
		String base64Image = "";
		File file = new File(imagePath);
		try (FileInputStream imageInFile = new FileInputStream(file)) {
			// Reading a Image file from file system
			byte imageData[] = new byte[(int) file.length()];
			long bytesLength = imageInFile.read(imageData);
			logger.info("readImageFromPath bytesLength :: " + bytesLength);
			base64Image = Base64.getEncoder().encodeToString(imageData);
		} catch (FileNotFoundException e) {
			logger.info("Image not found" + e);
		} catch (IOException ioe) {
			logger.info("Exception while reading the Image " + ioe);
		}
		return base64Image;
	}

	public String readImageFromPath(File file) {
		String base64Image = "";
		try (FileInputStream imageInFile = new FileInputStream(file)) {
			// Reading a Image file from file system
			byte imageData[] = new byte[(int) file.length()];
			long bytesLength = imageInFile.read(imageData);
			logger.info("readImageFromPath bytesLength :: " + bytesLength);
			base64Image = Base64.getEncoder().encodeToString(imageData);
		} catch (FileNotFoundException e) {
			logger.info("Image not found" + e);
		} catch (IOException ioe) {
			logger.info("Exception while reading the Image " + ioe);
		}
		return base64Image;
	}

	public void deleteFileFromPath(String path) {
		try {
			Files.delete(Paths.get(path));
		} catch (NoSuchFileException x) {
			logger.info("%s: no such" + " file or directory%n", path);
		} catch (DirectoryNotEmptyException x) {
			logger.info("%s not empty%n", path);
		} catch (IOException x) {
			// File permission problems are caught here.
			logger.info("deleteFileFromPath IOException " + getPrintStackTrace(x));
		}
	}

	public static void main(String[] args) throws IOException {
		String IN_FILE="C:\\Users\\Admin\\Documents\\AutoCircle\\Test\\etbdigitalappform123.pdf";
		byte[] inFileBytes = Files.readAllBytes(Paths.get(IN_FILE)); 
		byte[] encoded = Base64.getEncoder().encode(inFileBytes);
		String base64= Arrays.toString(encoded);
		System.out.println("base64 "+base64);
				
	}

	

	public boolean isIndividualDocumentSizeValid(String filePath) {
		boolean isSizeValid = false;
		double fileSize = 0;

		try {

			File file = new File(filePath);
			fileSize += (double) file.length() / 1024;
			logger.info("IndividualDocumentSize :: " + fileSize);

			if (fileSize <= ((double) AppConstants.MAX_INDIVIDUAL_FILE_SIZE * 1024)) {
				isSizeValid = true;
			} else {
				deleteFileFromPath(filePath);
			}
		} catch (Exception e) {
			logger.info("isIndividualDocumentSizeValid Exception :: " + getPrintStackTrace(e));
		}
		return isSizeValid;
	}

	public void sendEmail(String title, String subject, String request, String response) {

		logger.info("Send Mail :: " + subject);
		try {
			Properties props = new Properties();
			props.put("mail.smtp.auth", "true");
			props.put("mail.smtp.starttls.enable", "true");
			props.put("mail.smtp.host", mailhost);
			props.put("mail.smtp.port", mailport);

			Session session = Session.getInstance(props, new javax.mail.Authenticator() {
				protected PasswordAuthentication getPasswordAuthentication() {
					return new PasswordAuthentication(mailfromaddress, aesUtils.decrypt(mailtoaddress));
				}
			});
			Message msg = new MimeMessage(session);
			msg.setFrom(new InternetAddress(mailfromaddress, false));
			msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse(mailtoaddress));
			msg.setSubject(subject);
			msg.setContent(
					"<table style=\"border-collapse: collapse;width: 100%;\">  <tr>    <th style=\"padding: 8px;text-align: center;border-bottom: 1px solid #ddd;\" colspan=\"2\">"
							+ title
							+ "</th>  </tr>  <tr>    <th style=\"text-align: left\" colspan=\"2\">Request :</th>  </tr>  <tr>    <td style=\"padding: 8px;text-align: left;\" colspan=\"2\">"
							+ request
							+ "</td>  </tr>  <tr>    <th style=\"text-align: left\" colspan=\"2\">Response :</th>  </tr>  <tr>    <td style=\"padding: 8px;text-align: left;border-bottom: 1px solid #ddd;\" colspan=\"2\">"
							+ response + "</td>  </tr></table>",
					"text/html");
			msg.setSentDate(new Date());

			Transport.send(msg);
		} catch (Exception e) {
			logger.info("Send Mail Exception :: " + getPrintStackTrace(e));
		}

	}

	public static double getIntrestRate(double loanAmt, double emiAmt, double tenure) {
		double intrestRate = 0;
		try {
			intrestRate = loanAmt * emiAmt * tenure / 100;

		} catch (Exception e) {
			logger.info("Exception :: " + CommonUtility.getPrintStackTrace(e));
		}
		return intrestRate;
	}

	public String getDecryptedValueFor(String lastReceivedToken, String encryptedResponseField) {
		String decryptedValue = null;
		try {
			String decryptedString = getDecryptedTextFor(encryptedResponseField);
			if (decryptedString.contains(lastReceivedToken)) {
				decryptedValue = decryptedString.replaceAll(lastReceivedToken, "");
			} else {
				// This should never happen
				logger.info("======== WRONG DATA RECEIVED...");
			}
		} catch (Exception e) {
			logger.info("Exception :: " + CommonUtility.getPrintStackTrace(e));
		}
		return decryptedValue;
	}

	public String getDecryptedTextFor(String base64Str) throws Exception {
		byte[] keyBytes = new byte[16];
		String key = "HDFCBANK!@#987MOBAPP";
		byte[] b = key.getBytes("UTF-8");
		int len = b.length;
		if (len > keyBytes.length)
			len = keyBytes.length;
		System.arraycopy(b, 0, keyBytes, 0, len);
		SecretKeySpec keySpec = new SecretKeySpec(keyBytes, "AES");
		byte[] base64ToByteArray = com.loopj.android.http.Base64.decode(base64Str,
				com.loopj.android.http.Base64.DEFAULT);
		Cipher cipher = Cipher.getInstance(AppConstants.AES_CBC_PKCS5PADDING);
		IvParameterSpec ivSpec = new IvParameterSpec(keyBytes);
		cipher.init(Cipher.DECRYPT_MODE, keySpec, ivSpec);
		String decryptedStr = new String(cipher.doFinal(base64ToByteArray), "UTF-8");
		return decryptedStr;
	}

	public void sendEmail(String title1, String applyApiRequest, String applyApiResponse, String subject, String title2,
			String apiRequest, String apiResponse) {

		logger.info("Send Mail :: " + subject);
		try {
			Properties props = new Properties();
			props.put("mail.smtp.auth", "true");
			props.put("mail.smtp.starttls.enable", "true");
			props.put("mail.smtp.host", mailhost);
			props.put("mail.smtp.port", mailport);

			Session session = Session.getInstance(props, new javax.mail.Authenticator() {
				protected PasswordAuthentication getPasswordAuthentication() {
					return new PasswordAuthentication(mailfromaddress, aesUtils.decrypt(mailtoaddress));
				}
			});
			Message msg = new MimeMessage(session);
			msg.setFrom(new InternetAddress(mailfromaddress, false));
			msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse(mailtoaddress));
			msg.setSubject(subject);
			msg.setContent(
					"<table style=\"border-collapse: collapse;width: 100%;\"><tr><th style=\"padding: 8px;text-align: center;border-bottom: 1px solid #ddd;\" colspan=\"2\">"
							+ title1
							+ "</th>  </tr>  <tr>    <th style=\"text-align: left\" colspan=\"2\">Request :</th>  </tr>  <tr>    <td style=\"padding: 8px;text-align: left;\" colspan=\"2\">"
							+ applyApiRequest
							+ "</td>  </tr>  <tr>    <th style=\"text-align: left\" colspan=\"2\">Response :</th>  </tr>  <tr>    <td style=\"padding: 8px;text-align: left;border-bottom: 1px solid #ddd;\" colspan=\"2\">"
							+ applyApiResponse
							+ "</td></tr><tr><th style=\"padding: 8px;text-align: center;border-bottom: 1px solid #ddd;\" colspan=\"2\">"
							+ title2
							+ "</th></tr><tr><th style=\"text-align: left\" colspan=\"2\">Request :</th>  </tr>  <tr>    <td style=\"padding: 8px;text-align: left;\" colspan=\"2\">"
							+ apiRequest
							+ "</td>  </tr>  <tr>    <th style=\"text-align: left\" colspan=\"2\">Response :</th>  </tr>  <tr>    <td style=\"padding: 8px;text-align: left;border-bottom: 1px solid #ddd;\" colspan=\"2\">"
							+ apiResponse + "</td>  </tr></table>",
					"text/html");
			msg.setSentDate(new Date());

			Transport.send(msg);
		} catch (Exception e) {
			logger.info("Send Mail Exception :: " + getPrintStackTrace(e));
		}

	}

	public int getDateDaysDifference(String vcipLastDate) {
		int dateDaysDifference = 0;
		try {
			LocalDate currentDate = LocalDate.now();
			LocalDate vcipLastDtObj = LocalDate.parse(vcipLastDate);
			Period period = Period.between(vcipLastDtObj, currentDate);
			dateDaysDifference = Math.abs(period.getDays());
			logger.info("currentDate :: " + currentDate + " vcipLastDate :: " + vcipLastDate + " dateDaysDifference:: "
					+ dateDaysDifference);
		} catch (Exception e) {
			logger.info("getDateDaysDifference Exception:: " + CommonUtility.getPrintStackTrace(e));
		}
		return dateDaysDifference;
	}
	
	public String convertTocurrency(String amount) {
		StringBuilder stringBuilder = new StringBuilder();
		try {

			char[] amountArray = amount.toCharArray();
			int a = 0;
			int b = 0;
			for (int i = amountArray.length - 1; i >= 0; i--) {
				if (a < 3) {
					stringBuilder.append(amountArray[i]);
					a++;
				} else if (b < 2) {
					if (b == 0) {
						stringBuilder.append(",");
						stringBuilder.append(amountArray[i]);
						b++;
					} else {
						stringBuilder.append(amountArray[i]);
						b = 0;
					}
				}
			}
		}catch(Exception e) {
			logger.info("convertTocurrency Exception ::  " + CommonUtility.getPrintStackTrace(e));
		}
		return stringBuilder.reverse().toString();
	}
	
	public void savePdfToTiff(String filePath, String fileName, String mobileNo, String tranRefNumber)
			throws IOException {

		try {
			String date = CommonUtility.getDate(AppConstants.DATE_FMT_ddMMyyyy2);
			PDDocument document = PDDocument.load(new File(filePath));
			PDFRenderer pdfRenderer = new PDFRenderer(document);
			String extension = "_Appform.tiff";
			int numberOfFiles = 0;

			for (int page = 0; page < document.getNumberOfPages(); ++page) {
				++numberOfFiles;
				String mulFileName = fileName + "_P" + numberOfFiles + extension;
				String tiffFilePath = dafpath + "/" + date + "/" + mulFileName;
				logger.info("savePdfToTiff page  filePath :: " + tiffFilePath);
				File outputfile = new File(tiffFilePath);

				BufferedImage bim = pdfRenderer.renderImageWithDPI(page, 50, ImageType.RGB);
				boolean isFileCreated = ImageIO.write(bim, "tiff", outputfile);
				if (isFileCreated) {

					sftpUtility.uploadZipFileToSFTP(tiffFilePath);

				} else {
					logger.info("isFileCreated :: " + isFileCreated);
				}
			}
			document.close();

		} catch (Exception e) {
			logger.info("savePdfToTiff Exception ::  " + CommonUtility.getPrintStackTrace(e));
		}

	}
}
