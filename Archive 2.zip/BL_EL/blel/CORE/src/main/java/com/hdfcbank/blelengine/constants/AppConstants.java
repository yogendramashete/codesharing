package com.hdfcbank.blelengine.constants;

import org.json.JSONException;
import org.springframework.stereotype.Component;

import java.util.HashMap;


@Component
public class AppConstants {
	
		public static final String PRIVATE_KEY = "/opt/hdfc/privatekey.ppk";
		public static final String SFTP_HOST = "efg.hdfcbank.com";
		public static final int SFTP_PORT = 22;
		public static final String SFTP_USER = "CAutoFirst_SWUAT";
		public static final String SFTP_PASS = "TekSnap@11.";
		public static final String TARGET_FILE_LOCATION = "/AutoFirst_UAT/";
	
		public static final String SPRING_CONFIG_NAME = "application.properties";
		// public static String SPRING_CONFIG_LOCATION_FILE =
		// "/home/ec2-user/hdfc/properties/Loans/";
		public static final String SPRING_CONFIG_LOCATION_FILE = "D:\\Projects\\HDFC_AutoCircle_Web\\Documents\\Property_Files\\Dev\\Dev_Loans"; /*
																																			 * windows*/
		
																																	 
																																		
	public static final String AES_IV="554495832998beb0b0f7c198c46fbaba";
	public static final String AES_CBC="AES/CBC/PKCS5Padding";
	public static final String AES_ECB="RSA/ECB/PKCS1Padding";
	public static final String AES_SALT="b914741dca31bfae4c2d4d003780b00e";
	public static final String AES_PASS_PHRASE="1f491ea331dafff3bd8c38e3c3830e97";
	public static final String SSL="SSL";
	public static final String basic="Basic ";
	public static final String sslv="SSLv3";
		public static final int PERFIOS_START_MINUS = 1;
		public static final int PERFIOS_END_MINUS = 5;
		
		public static final String MALE_PATH = "assets/img/ico-male.svg";
		public static final String FEMALE_PATH = "assets/img/ico-female.svg";
		public static final String TRANSGENDER_PATH = "assets/img/ico-lgbtq.svg";
				
		public static final String AWS_LOANS_FILE_LOCATION = "loans/";
		public static final String AWS_PERFIOS_FILE_LOCATION = "loans/perfios/";
		public static final String AWS_DOCUMENT_LOCATION = "loans/document/";
		public static final String AWS_ETB_DOCUMENT_LOCATION = "loans/document/etb";
		public static final String OPERATION_TYPE_LOANS = "Loans";
		public static final String EMANDATE_LEADNO_SUFIX = "107AF";
		public static final String TAG_TYPE_DATE = "DATE";
		public static final String TAG_TYPE_DATE2 = "DATE2";
		public static final String TAG_TYPE_DATE3 = "DATE3";
		public static final String TAG_TYPE_STRING = "STRING";
		public static final String TAG_TYPE_DECIMAL = "DECIMAL";
		public static final String TAG_TYPE_INT = "INT";
		public static final String PQL_INCOME = "PQL_INCOME";

		public static final Long MAX_TIME_TO_CALL_BRE1 = 20800l;
		public static final String BRE1_IS_INITIATED_Y = "Y";
		public static final String BRE1_IS_INITIATED_N = "N";

		public static final int FILTER_ADD_COUNT = 3;
		public static final int MB_MERGE_COUNT = 1;
		public static final int HUNTER_MATCH_COUNT_SUCC = 1;
		public static final int HUNTER_MATCH_COUNT_SUCC_0 = 0;
		public static final int IMPS_INQUIRE_DELAY_TIME = 5000;

		public static final String VCIP_RETRIVER_ACTION_REJ = "rejected";
		public static final String IS_ENC = "Y";
		public static final String BRE_SUCCESS = "SUCCESS";
		public static final String BRE_FAIL = "FAIL";
		public static final String BRE_SUCCESS_CODE = "000";
		public static final String BRE_FAILURE_CODE = "001";
		public static final String DATE_FMT_dd_MM_yyyy = "dd/MM/yyyy";
		public static final String DATE_FMT_yyyy_MM_dd = "yyyy-MM-dd";
		public static final String DATE_FMT_yyyy_MM_dd_T_HHMMss = "yyyy-MM-dd'T'HH:mm:ss";
		public static final String DATE_FMT_yyyy_MM_dd_HHmmssa = "yyyy/MM/dd hh:mm:ss a";
		public static final String DATE_FMT_yyyy_MM_dd_HHmmssSSS = "yyyy-MM-dd HH:mm:ss.SSS";
		public static final String DATE_FMT_yyyy_MM_dd_HHmmss = "yyyy-MM-dd HH:mm:ss";
		public static final String DATE_FMT_yyyyMMddHHmmssSSS = "yyyyMMddHHmmssSSSSSS";
		public static final String YYYY_MM_dd_THH_mm_ss_SSSXXX = "YYYY-MM-dd'T'HH:mm:ss.SSSXXX";
		public static final String DATE_FMT_dd_MMM_yyyy = "dd-MMM-yyyy";
		public static final String DATE_FMT_ddMMyyyy = "ddMMyyyy";
		public static final String DATE_FMT_yyyyMMdd = "yyyyMMdd";
		public static final String DATE_FMT_ddMMyyyy2 = "dd-MM-yyyy";
		public static final String PERFIOS_NB_FETCH = "netbankingFetch";
		public static final String PERFIOS_STATEMENT = "statement";
		public static final String ERROR = "Please try after sometime...";
		public static final String DISBURSEMENT_ALREADY_INITIATED = "Disbursement already initiated for this number";
		public static final String PERFIOS_TXNSTATUS = "success";
		public static final String PERFIOS_FAILURE_TXNSTATUS = "fail";
		public static final String PERFIOS_ERRORCODE = "E_NO_ERROR";
		public static final String PERFIOS_REPORTTYPE = "xml";
		public static final String PERFIOS_REPORTTYPE_PDF = "pdf";
		/////////////// Aadhar /////////////////////

		public static final String SECURITY_QUESTION_1 = "What is your Date of Birth ?";
		public static final String SECURITY_QUESTION_2 = "What is your Father's Name ?";
		public static final String SECURITY_QUESTION_3 = "What is your Mother's Name ?";
		public static final String SECURITY_QUESTION_5 = "What is the city of your office address?";
		public static final String SECURITY_QUESTION_6 = "What is the state of your office address?";
		//public static final String SECURITY_QUESTION_13 = "What is your Mobile number ?";
		public static final String SECURITY_QUESTION_13 = "What are the last 4 digits of your mobile number?";
		public static final String SECURITY_QUESTION_14 = "What is your current resident type?";
		
		public static final String AADAHR_OT_GENERATION = "OTP-GENERATION";
		public static final String AADAHR_OT_VALIDATION = "OTP-VALIDATION";
		public static final String AADAHR_URL_GENERATION = "AADAHR-URL-GENERATION";
		public static final String AADAHR_CALLBACK_RESPONSE = "AADAHR-CALLBACK-RESPONSE";
		public static final String AADAHR_VCIP = "SYCN-PROFILE";
		public static final String AADAHR_PROFILE_DATA = "PROFILE-DATA";

		public static  final String DIGEST_ALGO = "SHA-1";
		public static  final String ENCRYPTION_ALGO = "RSA/ECB/PKCS1Padding";
		public static final String SERVER = "demo.perfios.com";
		public static final String VENDOR_ID = "hdfcBankRetail";
		public static final String API_VERSION = "2.0";
		public static final String SOURCE_SYSTEM = "LoanAssist";
		// public static String LOAN_DURATION = "12";
		public static final String APPLICANT_TYPE = "RETAIL";
		public static final String PRODUCT_TYPE = "AL";
		public static final String REPORT_TYPE = "xls";

		public static final boolean IS_BRE_STATIC = false;
		public static final boolean IS_PAN_VAL_STATIC = false;
		public static final boolean IS_NAME_MATCH_AT_PAN = false;
		public static final boolean IS_ADD_MATCH_STATIC = false;
		public static final boolean IS_NAME_MATCH_STATIC = false;

		public static final boolean IS_UAT = false;

		public static final String DEFAULT_DATE = "1900-01-01";
		public static final String RECORD_NOT_FOUND = "RECORD NOT FOUND";
		public static final int POXIDEX_RETRY_COUNT = 3;
		public static final int EKYC_RETRY_COUNT = 3;
		public static final String API_SUCCESS = "SUCCESS";
		public static final String API_FAIL = "FAIL";
		public static final String API_SUCCESS_CODE = "0";
		public static final String API_FAIL_CODE = "1";
		public static final String SIZE_GREATER_THAN_3MB_MSG = "31";
		public static final String SIZE_GREATER_THAN_10MB_MSG = "32";
		public static final String PASSWORD_PROTECTED = "53";

		public static final int PRETTY_PRINT_INDENT_FACTOR = 4;
		public static final String PERFIOS_GENERATE_URL = "GENERATE-URL";
		public static final String PERFIOS_TXN_STATUS = "TXN-STATUS";
		public static final String PERFIOS_RETRIVE_DATA = "RETRIVE-DATA";
		public static final String DOC_PERFIOS_GENERATE_URL = "DOC-GENERATE-URL";
		public static final String DOC_PERFIOS_TXN_STATUS = "DOC-TXN-STATUS";
		public static final String DOC_PERFIOS_RETRIVE_DATA = "DOC-RETRIVE-DATA";
		public static final String BRE1 = "BRE1";
		public static final String BRE2 = "BRE2";
		public static final String BRE3 = "BRE3";
		public static final String BRE1_SOURCE_ID = "SW1";
		public static final String BRE2_SOURCE_ID = "SW2";
		public static final String BRE3_SOURCE_ID = "SW3";
		public static final String BRE2_OPERATION_TYPE = "BRE2";
		public static final String BRE3_OPERATION_TYPE = "BRE3";
		public static final String ETB_BRE2_OPERATION_TYPE = "ETB-BRE2";
		
		public static final String AADHAR_GENERATE_URL = "AADHAR-GENERATE-URL";

		public static final String TRUSTING_SOCIAL = "TRUSTING_SOCIAL";
		public static final String NSDL = "NSDL";
		public static final String POSIDEX_STATUS = "POSIDEX";
		public static final String SIGNZ = "SIGNZ";
		public static final String HUNTER = "HUNTER";
		public static final String POSIDEX_NAME_MATCH = "POSIDEX_NAME_MATCH";
		public static final String PERFIOS_STATUS = "PERFIOS";
		public static final String EKYC_STATUS = "ekyc";
		public static final String DL = "DL";
		public static final String ELECTRICITY = "ELECTRICITY";
		public static final String MCI = "MCI";
		public static final String LPG = "LPG";
		public static final String MOB_AUTH = "MOB_AUTH";
		public static final String VOTER_ID = "VOTER_ID";
		public static final String CP = "CP";
		public static final String CIF = "CIF";
		public static final String BRE1_FINAL_ELIG = "BRE1_FINAL_ELIG";
		public static final String BRE2_FINAL_ELIG = "BRE2_FINAL_ELIG";

		public static final String PROMOTION_SCHEME = "IND";
		public static final String BRE_NOT_INITIATED = "NOT_INITIATED";
		public static final String INITIATED = "initiated";
		public static final String FIND_10MIN_BRE_STATUS = "FIND_10MIN_BRE_STATUS_";
		public static final String PERFIOS_NOT_INITIATED = "PERFIOS_NOT_INITIATED";

		public static final String SERVERERROR = "failure";
		public static final String BRESTATUS_FAIL = "failure";

		public static final String OFFER_PRODUCT = "AUTO LOAN";
		public static final String OFFER_PRODUCT_CODE = "AL";

		// BRE 3 redis key for address match/////
		public static final String PERFIOS = "Perfios_";
		public static final String POSIDEX = "Posidex_";
		public static final String MERGED = "Merged_";
		public static final String EKYC = "eKYC_";
		public static final String KARZA = "Karza_";
		public static final String ADD_RESI = "Resi";
		public static final String ADD_OFF = "Off";
		public static final String ADHAR_OTP_FAILURE_STATUS_CODE = "11";
		public static final String ADHAR_VERIFY_FAILURE_STATUS_CODE = "12";
		public static final String ADHAR_OTP_FAILURE_STATUS_MSG = "Aadhar OTP Generation Failed.";
		public static final String ADHAR_VERIFY_FAILURE_STATUS_MSG = "Aadhar OTP Validation Failed.";
		public static final String DL_AUTHENTICATION = "DL-AUTHENTICATION";
		public static final String DISBURSEMENT_STATUS = "DISBURSEMENT-STATUS";
		public static final String SUBMIT_DISBURSEMENT = "SUBMIT-DISBURSEMENT";
		public static final String PERFIOS_CALL = "PERFIOS";
		public static final String VCIP = "VCIP";
		public static final String SENDER_SRC_NAME_TYPE = "Sender-Name";
		public static final String COMPANY_SRC_NAME_TYPE = "Company-Name";
		public static final String PROFESSION_TYPE = "Self Employed";
		public static final String ACCOUNT_TYPE_CURRENT = "11";

		public static final String INIT_SOURCE = "NON-ZEEBE";
		public static final String TRAN_STATUS = "Initiated";

		public static final long LEAD_INSTA_MONTHLY_EMI_LIMIT = 100000;

		public static final String EMAIL_VERIFICATION = "emailVerification";
		public static final String EMAIL_VERIFICATION_TOKEN = "emailVerificationToken";
		public static final String IMPS_PAYMENT = "IMPS-PAYMENT";
		public static final String IMPS_INQUIRY = "IMPS-INQUIRY";
		public static final String SUCCESS = "success";
		public static final String FAIL = "fail";
		public static final String SUCCESS_CODE = "0";
		public static final String FAIL_CODE = "1";
		///////////// Document/////////////////
		public static final String ADD_REFERENCE = "ADD-REFERENCE";
		public static final String VALIDATE_PARTNER = "VALIDATE-PARTNER";
		public static final String APPLY_FOR_LOAN = "APPLY-FOR-LOAN";
		public static final String COMPLETE_DOCUMENT_UPLOAD = "COMPLETE-DOCUMENT-UPLOAD";
		public static final String DOCUMENT_UPLOAD = "DOCUMENT-UPLOAD";
		public static final String DAF_DOCUMENT_UPLOAD = "DAF-DOCUMENT-UPLOAD";
		public static final String PI_DOCUMENT_UPLOAD = "PI-DOCUMENT-UPLOAD";
		public static final String TRACK_YOUR_LOAN = "TRACK-YOUR-LOAN";
		public static final String INJECTION = "INJECTION";
		public static final String SIZE_GREATER_THAN_THREE_MSG = "Document size should be less than 2.8 MB";
		public static final String SIZE_GREATER_THAN_TEN_MSG = "Total documents size should be less than 10 MB";
		public static final double MAX_INDIVIDUAL_FILE_SIZE = 2.8;
		public static final double MAX_TOTAL_FILE_SIZE = 10;
		public static final String UPLOAD_FAIL = "failed to upload";
		public static final String DOCUMENT_ALREADY_AVAILABLE = "Document already available";
		public static final String MANDATORY_PARAM_NOT_PASSED = "Mandatory parameters not passed";
		public static final String DOCUMENT_PASSWORD_PROTECTED = "Seems uploaded PDF is password protected, please upload unprotected PDF document.";
		public static final String BRE3_PRODUCT = "ADL";
		public static final String DOC_UPLOAD_CONTENT_TYPE_PDF = "application/pdf";
		public static final String DOC_UPLOAD_FLG_INTERNAL = "Yes";
		public static final String SALARIED_CONSTITUTION_ID = "16";
		public static final String SALARIED_CONSTITUTION_VAL = "SALARIED";
		public static final String SELF_EMPLOYED_CONSTITUTION_ID = "15";
		public static final String SELF_EMPLOYED_CONSTITUTION_VAL = "SELF - EMPLOYED";

		public static final String ETB_ADD_REFERENCE = "ETB-ADD-REFERENCE";
		public static final String ETB_VALIDATE_PARTNER = "ETB-VALIDATE-PARTNER";
		public static final String ETB_APPLY_FOR_LOAN = "ETB-APPLY-FOR-LOAN";
		public static final String ETB_COMPLETE_DOCUMENT_UPLOAD = "ETB-COMPLETE-DOCUMENT-UPLOAD";
		public static final String ETB_DOCUMENT_UPLOAD = "ETB-DOCUMENT-UPLOAD";
		public static final String ETB_DAF_DOCUMENT_UPLOAD = "ETB-DAF-DOCUMENT-UPLOAD";
		public static final String ETB_TRACK_YOUR_LOAN = "ETB-TRACK-YOUR-LOAN";
		
		public static final String NOT_STARTED_STATUS = "not started";
		public static final String IN_PROGRESS_STATUS = "in_progress";
		public static final String FAILURE_STATUS = "failure";
		public static final String COMPLETED_STATUS = "completed";
		
		public static final String REQUEST_RESPONSE = "Request & Response";
		
		public static final String ADD_REFERENCE_SUBJECT = "ADD-REFERENCE - ";
		public static final String APPLY_FOR_LOAN_SUBJECT = "APPLY-FOR-LOAN - ";
		public static final String COMPLETE_DOCUMENT_UPLOAD_SUBJECT = "COMPLETE-DOCUMENT-UPLOAD - ";
		public static final String VALIDATE_PARTNER_SUBJECT = "VALIDATE-PARTNER - ";
		
		public static final String ETB_ADD_REFERENCE_SUBJECT = "ETB-ADD-REFERENCE - ";
		public static final String ETB_APPLY_FOR_LOAN_SUBJECT = "ETB-APPLY-FOR-LOAN - ";
		public static final String ETB_COMPLETE_DOCUMENT_UPLOAD_SUBJECT = "ETB-COMPLETE-DOCUMENT-UPLOAD - ";
		public static final String ETB_VALIDATE_PARTNER_SUBJECT = "ETB-VALIDATE-PARTNER - ";
		
		public static final String NAME_MATCH_REQUEST_BANK_CODE = "08";
		public static final String NAME_MATCH_REQUEST_CHANNEL = "APIGW";
		public static final String NAME_MATCH_REQUEST_TRANSACTION_BRANCH = "089999";
		public static final String NAME_MATCH_REQUEST_USER_ID = "DevUser01";
		public static final String NAME_MATCH_REQUEST_TRANSACTING_PARTY_CODE = "50000045";
		
		public static final String HUNTER_CUSTOMER_ID = "5";
		public static final String HUNTER_CUSTOMER_NAME = "HDFCBANK";
		public static final String HUNTER_SUBMISSION_LOAD = "1";
		public static final String HUNTER_SCHEME_ID_28 = "28";
		public static final String HUNTER_SCHEME_ID_20 = "20";
		public static final String HUNTER_SCHEME_ID_21 = "21";
		public static final String HUNTER_SCHEME_ID_22 = "22";
		public static final String HUNTER_SCHEME_ID_23 = "23";
		public static final String HUNTER_SCHEME_ID_24 = "24";
		public static final String HUNTER_SCHEME_ID_25 = "25";
		public static final String HUNTER_SCHEME_ID_26 = "26";
		public static final String HUNTER_SCHEME_ID_27 = "27";
		public static final String HUNTER_SCHEME_ID_56 = "56";
		public static final String HUNTER_SCHEME_ID_58 = "58";
		public static final String HUNTER_SCHEME_ID_78 = "78";
		public static final String HUNTER_SCHEME_ID_93 = "93";
		public static final String HUNTER_SCHEME_ID_94 = "94";
		public static final String HUNTER_PERSIST_MATCHES = "1";
		public static final String HUNTER_WORKLIST_INSERT = "1";
		public static final String HUNTER_RSLT_CODE = "1";
		public static final String HUNTER_COUNT = "1";
		public static final String HUNTER_ORIGINATOR = "HDFCBANK";
		public static final String HUNTER_CLASSIFICATION = "REFER";
		public static final String HUNTER_STATUS_CLEAR = "Clear";
		
		public static final String INITIATE_MB_AGGREGATOR_ID = "545";
		public static final String INITIATE_MB_INSTITUTION_ID = "4010";
		public static final String INITIATE_MB_MEMBER_ID = "cpu_AutoFirst@hdfcbank.com";
		public static final String INITIATE_MB_PASSWORD = "ZXVARVM3Tlc=";
		public static final String INITIATE_MB_REQUEST_TYPE = "REQUEST";
		public static final String INITIATE_MB_SOURCE_SYSTEM = "AutoFirst";
		public static final String INITIATE_MB_PRIORITY = "HIGH_PRIORITY";
		public static final String INITIATE_MB_PRODUCT_TYPE = "CIR";
		public static final String INITIATE_MB_LOAN_TYPE = "A";
		public static final String INITIATE_MB_LOAN_AMOUNT = "100000";
		public static final String INITIATE_MB_JOINT_IND = "INDV";
		public static final String INITIATE_MB_SOURCE_SYSTEM_NAME = "AutoFirst";
		public static final String INITIATE_MB_BUREAU_REGION = "QA/UAT";
		public static final String INITIATE_MB_INQUIRY_STAGE = "Pre-Screen";
		public static final String INITIATE_MB_INDIVIDUAL_CORPORATE_FLAG = "I";
		public static final String INITIATE_MB_CONSTITUTION = "15";
		public static final String INITIATE_MB_ADDRESS_TYPE = "CURRES";
		public static final String INITIATE_MB_ADDRESS_RESIDENCE_CODE = "01";
		public static final String INITIATE_MB_TENURE = "60";
		public static final String INITIATE_MB_RESPONSE_FORMAT = "04";
		
		public static final String POSIDEX_IN_SOA_PRODUCT_ID_C = "A";
		public static final String POSIDEX_IN_SOA_BORROWER_FLAG_C = "C";
		public static final String POSIDEX_IN_SOA_LOAN_AMT_N = "100000";
		public static final String POSIDEX_IN_SOA_BRANCHID_N = "3";
		public static final String POSIDEX_IN_SOA_EMPLOYER_NAME_C = "posidex";
		public static final String POSIDEX_IN_SOA_IND_CORP_FLAG_C = "I";
		public static final String POSIDEX_IN_SOA_SET_TARGET_DB = "AUTOF";
		public static final String POSIDEX_IN_SOA_SET_CREDIT_BUREAUS = "CIBIL";
		public static final String POSIDEX_IN_SOA_SOURCE_ID = "AUTOF";
		public static final String POSIDEX_IN_FILLER_13 = "3";
		public static final String POSIDEX_IN_FILLER_16 = "3";
		public static final String POSIDEX_IN_FILLER_17 = "3";
		public static final String POSIDEX_IN_FILLER_21 = "100";
		public static final String POSIDEX_IN_FILLER_22 = "3";
		public static final String POSIDEX_IN_FILLER_23 = "14";
		
		public static final String EQUI_FAX_REQ_PRODUCT_CODE = "PRFIL";
		public static final String EQUI_FAX_REQ_INQUIRY_PURPOSE = "01";
		public static final String EQUI_FAX_REQ_PHONE_TYPE = "M";
		public static final String EQUI_FAX_REQ_SEQ_1 = "1";
		public static final String EQUI_FAX_REQ_ID_TYPE_T = "T";
		public static final String EQUI_FAX_REQ_SEQ_2 = "2";
		public static final String EQUI_FAX_REQ_ID_TYPE_M = "M";
		public static final String EQUI_FAX_REQ_SEQ_3 = "3";
		public static final String EQUI_FAX_REQ_ID_TYPE_V = "V";
		public static final String EQUI_FAX_REQ_SOURCE = "Inquiry";
		public static final String EQUI_FAX_REQ_KEY = "PRFIL_Custom_Logic";
		
		public static final String OTP_AUTH_DEMOG_OFFER_PARTNER_UNAME = "Autocircle";
		public static final String OTP_AUTH_DEMOG_OFFER_PARTNER_PWD = "cgSSeMxLm733B8pGz7+tUA==";
		public static final String OTP_AUTH_DEMOG_OFFER_PARTNER_CODE = "AutoC";
		public static final String OTP_AUTH_DEMOG_OFFER_UDF_4 = "udf_4";
		public static final String OTP_AUTH_DEMOG_OFFER_UDF_5 = "udf_5";
		public static final String OTP_AUTH_DEMOG_OFFER_UDF_6 = "udf_6";
		public static final String OTP_AUTH_DEMOG_OFFER_UDF_7 = "udf_7";
		public static final String OTP_AUTH_DEMOG_OFFER_UDF_8 = "udf_8";
		public static final String OTP_AUTH_DEMOG_OFFER_UDF_9 = "udf_9";
		public static final String OTP_AUTH_DEMOG_OFFER_UDF_10 = "udf_10";
		public static final String OTP_AUTH_DEMOG_OFFER_UDF_11 = "udf_11";
		public static final String OTP_AUTH_DEMOG_OFFER_UDF_12 = "udf_12";
		public static final String OTP_AUTH_DEMOG_OFFER_UDF_13 = "udf_13";
		public static final String OTP_AUTH_DEMOG_OFFER_UDF_14 = "udf_14";
		public static final String OTP_AUTH_DEMOG_OFFER_UDF_15 = "udf_15";
		
		public static final String CALL_FINTECH_OFFER_INDICATION_PARTNER_UNAME = "Autocircle";
		public static final String CALL_FINTECH_OFFER_INDICATION_PARTNER_PWD = "cgSSeMxLm733B8pGz7+tUA==";
		public static final String CALL_FINTECH_OFFER_INDICATION_PARTNER_CODE = "AutoC";
		public static final String CALL_FINTECH_OFFER_INDICATION_IDENTIFIER_NAME = "DateOfBirth";
		public static final String CALL_FINTECH_OFFER_INDICATION_SOURCE_NAME = "SourceName";
		public static final String CALL_FINTECH_OFFER_INDICATION_CHANNEL_NAME = "ChannelName";
		public static final String CALL_FINTECH_OFFER_INDICATION_UDF_1 = "udf_1";
		public static final String CALL_FINTECH_OFFER_INDICATION_UDF_2 = "udf_2";
		public static final String CALL_FINTECH_OFFER_INDICATION_UDF_3 = "udf_3";
		public static final String CALL_FINTECH_OFFER_INDICATION_UDF_4 = "udf_4";
		public static final String CALL_FINTECH_OFFER_INDICATION_UDF_5 = "udf_5";
		public static final String CALL_FINTECH_OFFER_INDICATION_UDF_6 = "udf_6";
		public static final String CALL_FINTECH_OFFER_INDICATION_UDF_7 = "udf_7";
		public static final String CALL_FINTECH_OFFER_INDICATION_UDF_8 = "udf_8";
		public static final String CALL_FINTECH_OFFER_INDICATION_UDF_9 = "udf_9";
		public static final String CALL_FINTECH_OFFER_INDICATION_UDF_10 = "udf_10";
		public static final String CALL_FINTECH_OFFER_INDICATION_UDF_11 = "udf_11";
		public static final String CALL_FINTECH_OFFER_INDICATION_UDF_12 = "udf_12";
		public static final String CALL_FINTECH_OFFER_INDICATION_UDF_13 = "udf_13";
		public static final String CALL_FINTECH_OFFER_INDICATION_UDF_14 = "udf_14";
		public static final String CALL_FINTECH_OFFER_INDICATION_UDF_15 = "udf_15";
		
		
		//BLEL
		public static final String BLEL_FINTECH_GENERIC_OFFERS_AVAILABILITY_PARTNER_NAME = "LOANENGINE";
		public static final String BLEL_FINTECH_GENERIC_OFFERS_AVAILABILITY_IDENTIFIER_NAME = "PAN_NO";
		public static final String BLEL_FINTECH_GENERIC_OFFERS_AVAILABILITY_PRODUCT_NAME = "BL";
		public static final String BLEL_FINTECH_GENERIC_OFFERS_AVAILABILITY_SECURITY_KEY = "c09f1cb9a5046d6083e1a84d62f8dcc1";
		public static final String BLEL_FINTECH_GENERIC_OFFERS_AVAILABILITY_BUSINESS_ID = "50082";
		public static final String BLEL_FINTECH_GENERIC_OFFERS_AVAILABILITY_ORGANIZATION_ID = "10000";
		public static final String BLEL_FINTECH_GENERIC_OFFERS_AVAILABILITY_CHANNEL = "BA";
		public static final String BLEL_FINTECH_GENERIC_OFFERS_AVAILABILITY_PREFERRED_LANGUAGE = "ENG";
		public static final String BLEL_FINTECH_GENERIC_OFFERS_AVAILABILITY_PREFERRED_LANGUAGE_ONLY = "T";
		public static final String BLEL_FINTECH_GENERIC_OFFERS_AVAILABILITY_IGNORE_SOURCE_RESTRICTION = "T";
		public static final String BLEL_FINTECH_GENERIC_OFFERS_AVAILABILITY_BYPASS_OPEN_N_CLICK_CHECK = "T";
		public static final String BLEL_FINTECH_GENERIC_OFFERS_AVAILABILITY_SOURCE = "OFR";
		public static final String BLEL_FINTECH_GENERIC_OFFERS_AVAILABILITY_SPECIFIED_SOURCE_ONLY = "F";
		public static final String BLEL_FINTECH_GENERIC_OFFERS_AVAILABILITY_CONTENT_COUNT = "3";
		public static final String BLEL_FINTECH_GENERIC_OFFERS_AVAILABILITY_PERSONALIZATION_REQUIRED = "T";
		
		
		
		
		
		
		
		public static final String FINTECH_GENERIC_OFFERS_AVAILABILITY_PARTNER_NAME = "Autocircle";
		public static final String FINTECH_GENERIC_OFFERS_AVAILABILITY_IDENTIFIER_NAME = "DOB";
		public static final String FINTECH_GENERIC_OFFERS_AVAILABILITY_PRODUCT_NAME = "AL";
		public static final String FINTECH_GENERIC_OFFERS_AVAILABILITY_SECURITY_KEY = "c09f1cb9a5046d6083e1a84d62f8dcc1";
		public static final String FINTECH_GENERIC_OFFERS_AVAILABILITY_BUSINESS_ID = "50082";
		public static final String FINTECH_GENERIC_OFFERS_AVAILABILITY_ORGANIZATION_ID = "10000";
		public static final String FINTECH_GENERIC_OFFERS_AVAILABILITY_CHANNEL = "BA";
		public static final String FINTECH_GENERIC_OFFERS_AVAILABILITY_PREFERRED_LANGUAGE = "ENG";
		public static final String FINTECH_GENERIC_OFFERS_AVAILABILITY_PREFERRED_LANGUAGE_ONLY = "T";
		public static final String FINTECH_GENERIC_OFFERS_AVAILABILITY_IGNORE_SOURCE_RESTRICTION = "T";
		public static final String FINTECH_GENERIC_OFFERS_AVAILABILITY_BYPASS_OPEN_N_CLICK_CHECK = "T";
		public static final String FINTECH_GENERIC_OFFERS_AVAILABILITY_SOURCE = "OFR";
		public static final String FINTECH_GENERIC_OFFERS_AVAILABILITY_SPECIFIED_SOURCE_ONLY = "F";
		public static final String FINTECH_GENERIC_OFFERS_AVAILABILITY_CONTENT_COUNT = "0";
		public static final String FINTECH_GENERIC_OFFERS_AVAILABILITY_PERSONALIZATION_REQUIRED = "T";
		public static final String FINTECH_GENERIC_OFFERS_AVAILABILITY_SERVICE_USER = "string";
		public static final String FINTECH_GENERIC_OFFERS_AVAILABILITY_SERVICE_PASSWORD = "string";
		public static final String FINTECH_GENERIC_OFFERS_AVAILABILITY_CONSUMER_NAME = "string";
		public static final String FINTECH_GENERIC_OFFERS_AVAILABILITY_UNIQUE_ID = "string";
		public static final String FINTECH_GENERIC_OFFERS_AVAILABILITY_TIME_STAMP = "string";
		public static final String FINTECH_GENERIC_OFFERS_AVAILABILITY_FILLER_1 = "string";
		public static final String FINTECH_GENERIC_OFFERS_AVAILABILITY_FILLER_2 = "string";
		public static final String FINTECH_GENERIC_OFFERS_AVAILABILITY_FILLER_3 = "string";
		public static final String FINTECH_GENERIC_OFFERS_AVAILABILITY_FILLER_4 = "string";
		public static final String FINTECH_GENERIC_OFFERS_AVAILABILITY_FILLER_5 = "string";
		public static final String FINTECH_GENERIC_OFFERS_AVAILABILITY_FILLER_6 = "string";
		public static final String FINTECH_GENERIC_OFFERS_AVAILABILITY_FILLER_7 = "string";
		public static final String FINTECH_GENERIC_OFFERS_AVAILABILITY_FILLER_8 = "string";
		public static final String FINTECH_GENERIC_OFFERS_AVAILABILITY_FILLER_9 = "string";
		public static final String FINTECH_GENERIC_OFFERS_AVAILABILITY_FILLER_10 = "string";
		
		public static final String FINTECH_GENERIC_OFFERS_DEMOGA_UTH_PARTNER_NAME = "Autocircle";
		public static final String FINTECH_GENERIC_OFFERS_DEMOGA_UTH_IDENTIFIER_NAME = "DOB";
		public static final String FINTECH_GENERIC_OFFERS_DEMOGA_UTH_PRODUCT_NAME = "AL";
		public static final String FINTECH_GENERIC_OFFERS_DEMOGA_UTH_CALLER_ID = "hdfc_Api";
		public static final String FINTECH_GENERIC_OFFERS_DEMOGA_UTH_INSTANCE_ID = "8888";
		public static final String FINTECH_GENERIC_OFFERS_DEMOGA_UTH_LINK_DATA = "000000091";
		public static final String FINTECH_GENERIC_OFFERS_DEMOGA_UTH_MESSAGE_HASH = "static:verpwdreq:06:14b5wAfmOfPklbgtTsXZGys8Q6o=";
		public static final String FINTECH_GENERIC_OFFERS_DEMOGA_UTH_REF_NO = "5db047c6b1b522aff9ba49a3";
		public static final String FINTECH_GENERIC_OFFERS_DEMOGA_UTH_AUTHENTICATIONS_ALLOWED = "1";
		public static final String FINTECH_GENERIC_OFFERS_DEMOGA_UTH_EXPIRY_MIN = "15";
		public static final String FINTECH_GENERIC_OFFERS_DEMOGA_UTH_MAX_ATTEMPTS = "3";
		public static final String FINTECH_GENERIC_OFFERS_DEMOGA_UTH_PASSWORD_CATEGORY = "true";
		public static final String FINTECH_GENERIC_OFFERS_DEMOGA_UTH_PASSWORD_LENGTH = "6";
		public static final String FINTECH_GENERIC_OFFERS_DEMOGA_UTH_PASSWORD_MASK = "true";
		public static final String FINTECH_GENERIC_OFFERS_DEMOGA_UTH_PASSWORD_VALUE = "123456";
		public static final String FINTECH_GENERIC_OFFERS_DEMOGA_UTH_SECURITY_KEY = "c09f1cb9a5046d6083e1a84d62f8dcc1";
		public static final String FINTECH_GENERIC_OFFERS_DEMOGA_UTH_BUSINESS_ID = "50082";
		public static final String FINTECH_GENERIC_OFFERS_DEMOGA_UTH_ORGANIZATION_ID = "10000";
		public static final String FINTECH_GENERIC_OFFERS_DEMOGA_UTH_PARTNER_CODE = "AutoC";
		public static final String FINTECH_GENERIC_OFFERS_DEMOGA_UTH_CHANNEL = "BA";
		public static final String FINTECH_GENERIC_OFFERS_DEMOGA_UTH_PREFERRED_LANGUAGE = "ENG";
		public static final String FINTECH_GENERIC_OFFERS_DEMOGA_UTH_PREFERRED_LANGUAGE_ONLY = "T";
		public static final String FINTECH_GENERIC_OFFERS_DEMOGA_UTH_IGNORE_SOURCE_RESTRICTION = "T";
		public static final String FINTECH_GENERIC_OFFERS_DEMOGA_UTH_BYPASS_OPEN_N_CLICK_CHECK = "T";
		public static final String FINTECH_GENERIC_OFFERS_DEMOGA_UTH_SOURCE = "OFR";
		public static final String FINTECH_GENERIC_OFFERS_DEMOGA_UTH_SPECIFIED_SOURCE_ONLY = "F";
		public static final String FINTECH_GENERIC_OFFERS_DEMOGA_UTH_CONTENT_COUNT = "0";
		public static final String FINTECH_GENERIC_OFFERS_DEMOGA_UTH_PERSONALIZATION_REQUIRED = "T";
		
		public static final String DISBURSEMENT_STATUS_PARTNER_CODE = "AutoC";
		public static final String DISBURSEMENT_STATUS_PARTNER_UNAME = "Autocircle";
		public static final String DISBURSEMENT_STATUS_PARTNER_PWD = "cgSSeMxLm733B8pGz7+tUA==";
		public static final String DISBURSEMENT_STATUS_PRODUCT = "ZD";
		public static final String DISBURSEMENT_STATUS_UDF_1 = "udf_1";
		public static final String DISBURSEMENT_STATUS_UDF_2 = "udf_2";
		public static final String DISBURSEMENT_STATUS_UDF_3 = "udf_3";
		public static final String DISBURSEMENT_STATUS_UDF_4 = "udf_4";
		public static final String DISBURSEMENT_STATUS_UDF_5 = "udf_5";
		public static final String DISBURSEMENT_STATUS_UDF_6 = "udf_6";
		public static final String DISBURSEMENT_STATUS_UDF_7 = "udf_7";
		public static final String DISBURSEMENT_STATUS_UDF_8 = "udf_8";
		public static final String DISBURSEMENT_STATUS_UDF_9 = "udf_9";
		public static final String DISBURSEMENT_STATUS_UDF_10 = "udf_10";
		public static final String DISBURSEMENT_STATUS_UDF_11 = "udf_11";
		public static final String DISBURSEMENT_STATUS_UDF_12 = "udf_12";
		public static final String DISBURSEMENT_STATUS_UDF_13 = "udf_13";
		public static final String DISBURSEMENT_STATUS_UDF_14 = "udf_14";
		public static final String DISBURSEMENT_STATUS_UDF_15 = "udf_15";
		
		public static final String INJECTION_STATUS_BANKCODE = "08";
		public static final String INJECTION_STATUS_CHANNEL = "APIGW";
		public static final String INJECTION_STATUS_USERID = "DevUser01";
		public static final String INJECTION_STATUS_TRANSACTIONBRANCH = "089999";
		public static final String INJECTION_STATUS_EXTERNALREFERENCENO = "3";
		
		public static final String ETB_INJECTION_STATUS_BANKCODE = "08";
		public static final String ETB_INJECTION_STATUS_CHANNEL = "APIGW";
		public static final String ETB_INJECTION_STATUS_USERID = "DevUser01";
		public static final String ETB_INJECTION_STATUS_TRANSACTIONBRANCH = "089999";
		public static final String ETB_INJECTION_STATUS_EXTERNALREFERENCENO = "3";
		public static final String AES_CBC_PKCS5PADDING = "AES/CBC/PKCS5Padding";
		public static final String RSA_ECB_PKCS1PADDING = "RSA/ECB/PKCS1Padding";
		//

	//Application Form Generation constants
	public final static String HDFClogoImage = "iVBORw0KGgoAAAANSUhEUgAAANUAAAAjCAYAAAADi0+HAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAAEnQAABJ0Ad5mH3gAABTsSURBVHhe7V0JeFTV2X5nkkx2EsKWQNhF9h1BQKWIIoKCC0VUpFq1WkVMtSp/XcAiFaggIlaNAlYQRVRAICCggOy7gCSgLLIkBIGQhSyTZDL/95177+TOnXOTOyP2MT7zls9Mzpx71m8/56a2oi3b3Ta3G36DnwkLQ1iXjrDZ7QBRReYZlJ88BdhsaiXrsMON8yERyAhPoE9BBFFzYTvTvrs7pNQphMIvVFTAVrs2an+9ErbISNhC7Ch+fy4Kp05XhMpPwYp0l2NJbAs8mDwAFSRiJLXKF0EEUcNgO3dlJ7fDVU6M7CdcJFR1aiNu83og3CGKnLPnonjS1MCEqqIcX8S1xKjkgaiwBYUqiJoLu5uYnwXKbyKZ4Z9uN/9XAXuEXnUCICFM3FCQglRDyU+fL4gggqgO5kLlcgHl5eZUxj+pjh4UZ0nrGonrBRHE7xS2n1t3doeVl6mul4qQENjr1aVYKVwxaTJwoiI+DrUWfgSbFlN9+hmK/5NadUxF5e6LF+HOy/eqo8VUo5NvpLEEY6ogai58hYosFAtU9OSJsLdpo1gWM9jtCGnU0CMc7vwCVOTmis9msDnCUDzrHZTMnQdbZIRaGhSqIH4/8BUqEiJ7wyTEzn4HIW1JqH4FFL02A8XT34AtKkotCVCoKkzq2CVWUlZXWFT1M8OsPT20+maWWIOVtoyQjVuA2uINEm3q26X6/Aw/Vt14zCCatDjWQPqRrjtTNe1Y2S8NIkGgftZg7MPqOGRtaTDdH2/IhSopURGqdm3VwsuLoqnTUTzjzV8sVDERYQjRTZQ/lboqUOT0tq5cHhvl8NoP/uwsr0BxqVLXTosbTe1VtW683ty+01kGdynFk2E0Tsn5HrfFYzPuV1Xg2fK4y6l9L/Dv1HFsbCSSEqLRvH4t1IoKh5Ni2lPnC4gu4WJ+MVxlPJ4Q9SHrcITaEekIVX+Tg8fmIqZ0Uh/lxWU0QSoIrb4vG69peKjvHtG6F9Eami2Q2XOXSspQLhEOrhsWwtcHKuGkeL+E90gF1wmlOhrEOIy8QuvMdZgPjODyvKJS3/2RoOYKFU1u0fO3om3jBJSpEw0nplqz9ySenbsRThYW3jRaqChapLWv3CkWq4IlgxBBdT/4Oh1TFu0SbTVqUAsfpAxEg/gowUAycD8XL5Xgx6xc7DpyFqt3n0DWWYoNmZm1/ac6zZLiMe/pQcT8Dk9/VcFOzFNIzDo2dT12pWdVCgcxcYO6sbj/hnYYce2V6Ny8nhejMTIvFCJt93F8SHPZtO8U7T6tnVVppjW67brWmHBPb/rFLZSGDDyHQmLoMzmF2HvsHNJ2Hcf+Iz9T7E39mPVFY+/ZriGmPdRPWQd1TR0kjDt/zMbjb6+jOZeyBhLlHlC9+NgIvPVofzFfbW/DaF5Lth3FCx9son5V4aBxOWitZj7SH9e1bySEnsEC9uG6DExduF0RfhLiNx67HgM6Nfa0F+EIwfKdx/Hc3E00Niqj4YVTHy/e2xvDerX0Eh7mqx0/ZCPlvQ3ILSjxHbMBNVeoaKHSU+8XQqUHL9QfJ69ACTGBmDwtfEykA9nz/uKjgWYt34cn3llHbbnQgtrZPHUEEmtHq99Wj0OnczD1s92Yu/Z7pYAZjNpq26wetk8fiVjq1yqYaYdO/BLfEMMS5wnh7NEmCe8+PgDdWtZXa5nj4iUnJhITzVy8By5eOyuCRdbi4aFdkTrmBrXAGs7lFeP/PtyE2asOsEZQSw2gdRh/X18S2KvVgkrkk8a/deJSfLvnhDJXPWjedckir5xwG3pc0UAtVFBCSuD2ScuwavsxRfGQAEaQBVo+/jYM6NxYraXgrRX7MGbmWmqfhcqFtIl34uYezdRvFXy+5QhGTFmBCuIl5reXSLm8dHcvklnvOX1/4jzufW0V9h8jRWLh5lH1NX7D0LSfF0xkUVbsKROyZ66pzdAmOQFzUm7E2KHdiBkqH6aWLFkoIzxPEBN0bdUAn40bYkmgGLVjwjHl/mvw0OCOgjGtIpBx1ouLxGt/vg79SPOzRfIBW5takbi9d0u1wBtsuQZ2aVppcYygIcmGFUECOJEENbFOjDJH3jf1OyPEvHR6xSVrkMuYqK3Hb+2Kl8lKGQXqwE/nMeLVFdhP1tWKQDH8FqrJn+1Epyfm46qnPjalbikLMOD5z7H3KEl2DYeLXIMy0mTlVZytsXa7plOyN4NJ9pBdCnZRjMTlJfRTczsdZFGZaZtS/GREbqETx7LzcZpiKc2V0cBuz4S7r0bThrUFY1uCpBoz5Mlz+TianYfjZ/NwnmI2I+KjwzG4R3PiIAlnU99dSBmw+2aG4X1bITYmwvo4VfS4oj7+dkd35Rf/HvUBP85WatTADphMCskIFqhR01Yhg36S/6mWVg+/heoELfSB7zOF729Ge9Mzsftwtgjs/tdghnCTpmdt70UBYv66QxgxNQ33TfsKfyOf+huOWwyoQzHAg7QxdnJFPBst8b44hrvjX8uEy6Gn4ZOXY/Trq5B+8oJgsj8Sw/XrSEJqwCZa10HjF+OKh+egw+Mf4qWPtgq3UQ92Xx+gGExqQWSQjLOA9u3a5xZRP3PR6pEP0G/cIuymGNKIumSN7CJhYeBuEvZ7+1WdOb6yUW30bZtE87VuVTWMJZf1+i5NrM/RBJzMGEZrPYviN04s6ZF+6gLu/fdK7KdYyhPjWoTd7XTCh0pJGGTmkiBe8+BOqqRQ2OknZ8GkoLhN1i/KvBkkEDCD927XCL2IKXt3SEYvop70uzHAt4o9ZG2XfJOOT9YexIyFOzCCBGATKQ4jhlzVHPWIyarSvHsouE9bfwhfbjjsRUs3/IC0LUdxPrcItsgwDLu6pc94s3IK8ReKEbYfOC1YOI9iqMkLtmHFrp+UCjr0bdsQIdSO3/6sCn6qjBnWWQ5XcRnSSUFuPJipfKnDTz/no0JLCGkgIUlKivNRCpzYYausgR8ZyYIXwBA5yfTyqD6oQ7GXS+d2VwXZ7vdunSQSInHkjuqxnyzTaFKiB9jTqiYzKoM9fNBAhN8yGOFDblboliFwDLieHF9f1+NyIaRta0QMvaWyTyb6Pax7N3XygTEDo2+7hlj36nBse20ktvz7LvHz60l3Vps2NkMIZ7jY9PPzxKgXyO2avUZNTOjAAtU8Ma6SkSVTSK4XixYUK7UmF0ajNq3qI5GfY2VEAtm4bizaNamjPlGJTd+fRsaxc5WbzEJH9PqS3Xh10U5M+nSHoCmf78IXFIBzxsoSJOPk9HGvNkm4mgTjGop9HhjWFXf0aaV+q+DImTx8uvEHb4FilFWIpMEVSfFqgYLZqw9i54/e1q4P9dGC4lJOOvmLa2ifnyCLxWvG8XB1kNVoQeveiOMzA17/Yjd203qLPQkA9phpryLqzemInjlNobdeR9Qr4xGS3EitcvnBAhT97qzKPolC3p6JqIcfUKxbgBr2fwJi5J8optHOt/RoQgLhgYHXGGOGdMLGySOwbtJwD22echee8cQIbiSQpU2M981A7jtBriELuB7E/NsOZuEfqevxArmmTOPeWYe3l+xBEbuFZp6CHpIq0eFh+CDlJqS9fDuWvTQUqWMGoAkpBA1nyaI+OOMrHD5OQs4pfA00/tBIBwZ3b+7VNcdkm9MzsWqPt1Vt1TAe17FFC8AFZKTc1g3X0vN87nU5MbJ/G8QnkLD5Ge9psNv4fl9oKGwOhxdZ2pBAERLi2x+Fd7Ywcll+xW4vC2hdSsrKpULFZx8elSjZDz60bUguCx/iasRCxEG/ADFlOMUoEeG+GjKvkNxjGZipOZbTE4/D6v5JxsmPxkU7REaRxxYqyXpd37UJ4uOivBmPLS0J32BD6nofCV/6qRxx1mM8PB3asznCImj/LSjSLRlZIq2ugd22SX/qI84WLydu6toUf72lc8DCbhfxk8sFN8UzHqKY51e1FrSwXv0R8e4q/SpVfrOgdYkhTW4MbBkFfNtA4+UAlQNn9ErJhTKCDzml+KX7JBknZyEPZ+bgwInz4ozmyJlc5QaECmbi8SOvxj/v6wM7p8W1MdBzQ0ig4jQloWIXuX0uigHTT+YI4dLjpm5N0aQBhRp64TRBGsWP733l7Xr3apWIri3Ms4yB4tk7e6AHxVyBJLnsl575B4qe/DsKU55RaOzTKHrxn3Bl+gam/sF8kZzLVqDwr09W9knkGpOCotn/Vdb2F1hJToPyge4js9bi0be+Fj+fJPdIHyT7Bf00+DNR+2Z1KbTxZXJOP3sgmX7OpRIcp+CeA3yNOAFxTktZk2vJKfNz+UXK7zq0lDEeuT1/IPdnTspAvD/2RkFz6fOk0X3FWZIVRpWN81JxKW544Qt0emweOo6Zjy5jP8Kzczf5WOeHbuqAFkkUD2r9kOCPuLa18lkFHxWs2XtCzC3z9EWR+NEjihTUnb2vEIq2OrCVe3Xhdi/B5NsoTIFiw/eZWLSJYkMD2EK/QusYwwrCyjrqYHeuWAXn0mVwfrlcoSVfonT1GvI38tUqgcJ8oq70DJQsXlLZJ9PipSjbsZP2mCcQ+CLx2Urq8u+QSnHFu0v3IJVozorvxFlTIBBnR/zuGDMUaeuWzergsSHkGhhwjPo9ea5AMI+AZAozlu5Fz5SP0efvCz10VcoCkWgQIDeL7/MdIuYz4vrOTVCX3RxNOfC4yEI8NKgjHrihvUjpM91Pn/t3amw9zjBZamF8uA+iQoqhVm87KhSAHpz8acFnaVyXxsWJh/ZNvW+4hNJ6TBp9DdZNuxtfTxsplIARnO10cAauGqvLV5XOUDw7ft4W+cG/n2C39L5pqzCOFAbzjRFsRR8dTHttQeD1EDGVD1URU7nZz+SNrZLKUUE/TU/rOYaT9Mt/nemXgv1/O2k/6MlBFKCc8o2G2/q3wz03tscLpLmWPD8UV1KAbcTS7UeRk0cWpworm0su0Pnz+ThDgqNRFlEe3ydjEAOWFZViJV9VMoCvY818bABaNiGmpXWNJQ369IirMKxnC7VGJfYePYe8iyQAAWpwvtDK8UoMx1QU8yUn18Y9JLBNdckKDWUi7lD2+abuzZDAB7o6iExi60T8oVMyKYbGaCY50GZB5GMAwTvVIcyOzzf/gP9+k64WBI7Dmbk4TYrwGFm+aV/sVku9MW54D3Ru1cAvN9A3Aq0GTRPj0LFDI/Ro19CUurZrhO60kMb8f03EqP5t8Olzg/HhU4MwkWKIDk19092swed9k6FoNI2PJfpEuCkcgxhJz/zkQs1bdwjbD2erBZW4u19rcURw9P0/I/0/o/Evdk8M9wvZfXx/9QGlXSuQjDMmki8g34H0t0dj/6xR2P36PXhxZE8hIHrwfUOOt/jiaN3a0SKeCgRxUeEYSFbB0phJ4PnPorzyyQ5kSCy6GWTqRdwH5rWnNZ+z9qDiphpQp1YkJv2pLyIjrbuBFle+EuOGX4X9b47Czul3m9KeGfeIs6GuFu+t/ZbBd8HY7TA7PGZr/PKCrdjLQqBPJsirVw9imkKyXE/N3uDjbjH4FgOfryTXjfGJ6zjmmPjJduzlWwBWhUoyTj7WSEqIEWdmTPXJ7TTeiWPMJUY89fMl0UbHFvXQ3XABljOWfLN8/voMLNhwSNC8dRnYeuiMWqMSfDM8oZrDcw9oP46duoCJH2+T6QQp5PXUydMPZ5FTnPNdlGRZ+Yjg4UEdLLuBfgvVbwnSAFVSxJAVe8poxdnloX9+4Yesi3hw5hqkriTL4MXgFDxLG+MyC52QcG45kIm7pqQJv98K2Go8Q7HBG0vIjbEqUASet7/gd5DeXbkfExdso7XjxQPu6+/7RsPGg1m497WV4nbC6OkqTU3Di/O3+CSO2L3tTV6OECpqTzYs2iH1EyEsFJ98exjzSUhlUM471V8IUp3IZVo5hSQb9p3C7NW+B/vc1Asje6HLlYkiOVQdQp6pmzghhPxiT//02RYbg/Bht8Be7/KnKhllm7eifNsO5VxKRRjZ9IyIBCyu1ZLGIlsBA2gz+ayEcYbiBz6QZNeH76itJjPOF2G1nQklzXYzaRvWQlyPibXotwczxX06nnwUuVF92zdCMTFM9kWljp64LPNCgXA5+J2tt9P2Y8L8rfiWPgsm1oZMbcVEO8SJP999zFafZ6bnw88DLCQmVs8LVOdkVi6W7Dgmno+PjlAthveznFH8bPOP4h2yheSCuvl7q4JCDNw0KU7c4Pg5z3fOHqL15Zch00/nYPHWI8IavrXsOxTzS4DUFWfIOEHCxwHaXvC4Plp/CFv3KeujvAVAi0NUWFqOlhSXslLkd7S4Pr+ndqHAiQ3fnYSD4uDebZJEfKy1x+u3hr7bw7cyxBxp/GUVYkxtafycmdT2LYcs/cb0LGw6eJrq0t4QK/DVNX5RVeuP94bPzXgvxbjUNeMrSuxhFenaY+JEF7u/a/fTfKpZ3xr95i+/r6S3VvxJvM1puGTKaxBLfrt+Kfgza0uvN38plpBbGAXs6rmofRY8N78xygevEqvAY1Le/PVuq4Se4UucfoFdDuo3JoaFil2/eCTERAqlkZVzCcfP5uMCbzrPQ+9+WoR485eTOVWBZYH+x4xVXFKqaGvdtS/O8EXzAa5h6XgfjDfpNXAqnfvW7zK/LFhQVCbiHH73zahA+MVTTtF7gRrgl1CNbZXq9pYRHcFv/lauD7fseQNZD1I00SR8xviRwc/kkpvo1ZEEJkKVhNg5wb9RYQp+pgrhE7DSnz/g9lRNXwm1PZ5vdeMxAzfn1WYV0Low9mXWBlczG1d1e+fP+knrMukqW6mjwWxsDBlvGSARR3qI/wx09lmibFScPm1OWVlei+kuKJDX09PZs3Dn5VE/vl37DZ6gjGSQ1aN/XpDVkZEZo+ghfU79LhDw86w9OXbzEP3OZVbGYwZ+1DhOM+J+ZH1xkVl9M8jqM2mQfUf/pJDWJdLDSh0NsroaWYCvpWIhoaDN3qC+cnZkpsU49oqLQ+wn86iektZ1fvo5St55Txms2YCpvOJCjipYlXUCslRBBPEbhK9QaeC/UFuVW0C+sq1OAuK3bYAtQjnwK0mdjaJXJlctVAwOHg0p2qBQBfF7gTdn68FBHVksU+J3jAznJEJQZHWNZBCoIIL4PSHI3UEEcZlh5/8XRZYsv4m8M/5p0yUc2OPzqhMAUSuV7mOQglTjyIb/B7VEcShqsDMQAAAAAElFTkSuQmCC";
	public final static String emptyApplicantPhotograph = "iVBORw0KGgoAAAANSUhEUgAAAKcAAADKCAYAAADAfFBoAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAAEnQAABJ0Ad5mH3gAAAeESURBVHhe7dm7i9R6GMbx7OnFW2ulNoJg4aVRi10QRe0VW8EbIhwLFbFVvKA2ggpuI3gDCxvFC9hoJSLaq4WFlVf8A/bkec2757fZzDrnuLP7sH4/EJJJsplM5ju56NBYrSqMHB5tpoDZ8/TC7uqvZhqw0/PMqXKBmVb2x5kTtogTtogTtogTtogTtogTtogTtogTtogTtogTtogTtogTtogTtogTtogTtogTtogTtogTtogTtogTtogTtogTtogTtogTtogTtogTtogTtogTtogTtogTtogTtogTtogTtogTtogTtogTtogTtogTtogTtogTtogTtogTtogTtogTtogTtogTtogTtogTtogTtogTtogTtogTtogTtogTtogTtogTtogTtogTtogTtogTtogTtogTtogTtogTtogTtogTtogTtogTtogTtogTtogTtogTtogTtogTtogTtogTtogTtogTtuZcnDt37qyGhoaqs2fPNnPmlvx8V69ebebMXQOP88CBA3EwZyqYb9++NVM/vXnzJt570aJF1fv375u5fnI/y0H7rOOnZSk/3/fv32M8lw00zs+fP1e3b9+uFi5cGK9Pnz4d4z+JznAKTWe8qfz48aOZ+tfXr1+ry5cvV8PDwwP7YfW7f7NhoHE+efIkDvD+/furZcuWxfSDBw+apTNj1apV1djYWPXly5dq6dKlzdyZk2e49hl9KtpfDc+ePYvXOm53796N6en2f/Zvpgw0znv37sV4/fr11Y4dO2L6+vXrMU55OdMvV+EuX748Xmuss27KX7jGuj3QJU+v165dO+Gy11ZeLkt6L/2t5mtb5S2H3iOX5XJdXnUlSJqn4fnz59WWLVs6t6P5R48ejelHjx7FOprXrw0bNjRTkymq8papvX+ifSk/h6bLY/qr/dMxys+mQd+Jttl+n4Gpf6ETDP99LYbf9enTpzFtvr6kx+vXr1/Haw1aluqzw/h6ubwctFzOnDkTr7vW07zc5ubNm2Oe1pfcvoZ069at8XnlkO/VtUxDfQWI5dK1PAdtX3JfyqH+kcaytq79vHLlyvi8qbaZQ7l/x48f71xHg7YrU+3f/fv3Jy3LoddnmA5lfwM7c+ZlKO9ldHnVpV10uW/TpasOqqojq969ezd+n3rz5s0Yl+ovKi579QGM1/rbrm32cuLEiRjrdiPfL8/sou3XscR7aKi/6Jjfdd+3Zs2a+HttJz/fhw8fYvzw4cP4TFKHENsqz1y95Jlq37598VrvsWnTpphOOj65j7nvuX8anzp1KqbrEGMd7V+ud+7cuRhPtX+HDh2KcR4jLct179y5MyMPlwOL89q1azHevn17jCUPzvnz52PcduTIkWrx4sVxb6iDIu2DsG7duvHgt27dGl+cZBD9UEyya9eu8ffTl5KX0SVLllSXLl2Ky7QiyS+6y8WLF+PvtZ09e/bEvFevXsX4dyl2/TAUkbZfOnbs2Pj+Hjx4MMYvXryI8cePH2Mse/fujbH+PtfLzz+V9jESfT+pfI9BGUicCurly5cxvW3btvEzQX7JWvarX57Ohv3od71+ab82btwYZ4f/u+3ffbjQWUrD27dvq5MnT04Ks5fpPhazbSBxjo6ONlO9dT195s22HmLy8rJ69eoYJ50dcpnG+QtfuXJljPtR3jLo/TTogUIPN3lG0FkrL2d5Fv8d+RAxE5fDefPmNVM/H+5E76+rgeTVptTev/YxkvJhb8WKFc3UANUHf4LpeCCqv9i4cc6b+JJu2rVM60j5INA11PHFenrA6VquIbcleZOv9aXrQaPXtrRu+eDWHrTtlPP0Nym3W66nY5DrtpeVuvazS/vzSdff5npdgx52Uq/9m+p462FrUAb6QKSzns5m+uW1b+JF9zCiddr/BKQHHJ2xRL/u+qBP+rfJ+uDFjXn+snUf+/jx45iWBQsWNFM/lWeRpHsnbSPfS2O91j2cHtz0QNRe1pbv36XcB90fl2fekZGRZmqirv3s0v58pXKfbty4MeEzio6Vjqnu1VOv/dMx0nEoz7Ka1jzdasyISLQwHWfO/6LfM0Z9oGOdXmcezA0DPXMC02XW4+z3cjZ//vxmCn+KWY8z/+9bw1T073VaR//mhz8Dl3XYIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YIk7YGhqrNdNh5PBoMwXMnqcXdlf/AHN7GiYLEz/hAAAAAElFTkSuQmCC";
	public final static String checkMarkImage = "/9j/4AAQSkZJRgABAQEAeAB4AAD/2wBDAAMCAgMCAgMDAwMEAwMEBQgFBQQEBQoHBwYIDAoMDAsKCwsNDhIQDQ4RDgsLEBYQERMUFRUVDA8XGBYUGBIUFRT/2wBDAQMEBAUEBQkFBQkUDQsNFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBT/wAARCABRAFsDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD9U6KKKACiiigAooooAKKKKACori4jtYXlldY40GWdjgAepp8kgjUknAHJr8jf+Cm/7eEvijU7z4U+AdRP9kQvs1jULZv+Phx/yxQjqoPX1IFAH62WN9BqFus9tNHPE3R42DA/jVivi3/glX8MfFnw9/ZvjufE086rrV21/ZWE5Ja3gIAXr03Y3/8AAq+0qACiiigAooooAKKKKACiivk/9vb9tLT/ANl3wDNY6bJHdeOdUiMen2u7/UA8GZ/QAZI9TigDyL/gpj+3Ynwr0e6+GngjUB/wlt7CV1C8t2BNjEwxtB7ORz6gYPevgr9gb9mG8/aZ+Nlo19FJJ4Z0d1vdVuGzhiCCsefVjzj0Br59muPEHxU8bs7m41jxDrF17tJLK56frX9An7FX7N1r+zT8FdJ0Fo42125RbnVbhV5ecjlc+i5OPrQB7tYWMGl2kFraxLDbwxrFFGowqIoAUAegAAq1TKfQAUmaWsjxdNc23hjV5rMZuo7SVoh/tBCRQB4r8bv25vhD8A9cGi+J/E6JrC/6yzs4XuHjH+1sUhT7E5r0D4N/HnwP8e/Dh1vwTr1vrNop2yqmUlib0eNgGX8RzX83XjrWtW8QeMdZ1DXpZZ9YuLuWS6eYkv5hYlgc+hr0P9l/9pTxJ+zF8RrXxLoc7SWZYLfaezHy7qLPKkeuM4NAH9IdFef/AAO+Nvhv4/fD7TvFvhi6W4sbpBvjyN8D45jcdmHpWh8Vvin4f+DXgXVfFnia9Wy0rT4jI7Ejc5xwi+rE8Ae9AHE/tUftJ6B+zL8L73xLq8qyX7AxafYBv3lzNjgAeg4yeg49a/n3+MPxc8RfHLx9qfi7xReNd6nfSF8Mx2xLn5Y0HZVGAB7V3H7WP7T/AIg/ag+J13r+pyNDpMJMWm6cGPlwRZ44/vHufYVzv7OfwS1b9oL4saF4N0uKRvtc4N1Mq5EMC8yOfT5Qce+KAPuL/gkf+ye/iDxE/wAX/EFp/wAS7TpDDoySDh5wAWlA9FyMH1Br9dcYGO1cx8MvAOlfC/wLo3hbRbdbbTtMt1gjVRjOOrH3JyfxrqKAE2iloooAKRlDKVYZBGCKWigD8l/+Cm37A76Pdah8Wfh9p7SWc8hm1vTbdeY2Y/NOo7gnk/UmvzGweQRg1/Uzf2VvqNnNbXUKXFtMhikikXcrqRggjuCK/FD/AIKM/sH3fwN8RXnj3wjaSTeBtQlLzwRDd/Z8pPIPoh6j8aAPI/2Kv2wtd/ZV+IEcu+S88I6g6x6np27jGeJVHTcv8ia6T9vb9t7Uf2ovGH9maO81l4E01x9jtWODcPjmVx656DngCvksMOlJtoAcimSRUUZdjgAdzX7e/wDBLj9lQ/BX4UjxlrtoI/FfiWIS4dfmgtThkX2JG0kV+ff/AATf/ZXl/aD+MsOq6ras/hDw6y3N4zL8k0mfki984Yn6Cv3ht7dLWBIo1VI0GFVRgADsB6UATLTqatOoAKKKKACiiigBDWV4o8K6V408P32ia3ZRajpd9E0M9tMuVdSMEVrUUAfgR+3b+xXq/wCzH4+nvdKt573wLqUrPY3YUkwd/Kkx3A6Hvg9K+b/BfgfW/iF4ksNB0Cwl1DVL6ZYIYY1JyzEAZ9Bz1r+nLxN4X0jxlpE+la5pdnrGmzjElpfQrLE/1VgRXIfD/wDZ9+HHwu1CS/8AC3gnRdCv3zm6s7KOOTB7BgMge1AHOfslfs+aZ+zf8GNG8LWcSm/2CfULjGDNcMBuP06D8K9l206igBAMUtFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQB//9k=";

	public final static String IDENTIFYPLEKSEnvironmentDomainName = "devpl.snapwork.com";
	public final static String IDENTIFYBLEKSEnvironmentDomainName = "devbl.snapwork.com";
	public final static String IDENTIFYDEVELBLEnvironmentDomainName = "develbl.snapwork.com";

	//PDF Static Content
	public final static String BANKUSESECTION = "I / we confirm having submitted the following documents (ticked below) along with this loan application form to the Bank";
	public final static String LOANDETAILS= "Loan Detail � to be removed as eligibility is not confirmed";
	public final static String CHARGES= "CHARGES: All Charges are non-refundable & applicable post disbursement of loan.";
	public final static String LOANPROCESSING= "Loan Processing Charges + Govt Taxes\r\n" + "(Government Taxes and other levies on Processing charges : As specified by Government of India)\r\n";
	public final static String FORECLOSURE= "Foreclosure charges are on Principal outstanding balance and Part Payment charges on Part Payment amount\n" +
			"7-24 Months of EMI repayment: 4%;\n" +
			"25 - 36 Months of EMI repayment: 3%\n" +
			"36 Months of EMI repayment : 2%\n" +
			"Note: Prepayment not allowed prior to payment of 6 EMI. Part Prepayment not allowed prior to payment of 12 EMIs. Government Taxes and other levies as applicable, would be charged additionally";
	public final static String NIL = "NIL for cancellation of Loan (However client would be charged interest for the interim period between date of loan disbursement and loan cancellation and Processing Fees would be retained). \r\n" + "Rs. 1000/- for rebooking the loan.\r\n";
	public final static String BOTTOMPARA  = "* Foreclosure, Part-payment, Processing Fees, Cheque/SI/ECS Return charges, Collateral, Documentation and Valuation \r\n" + "charges are exclusive of government taxes. Government taxes and other levies, as applicable, would be charged additionally.";
	public final static String TERMSANDCONDITION = "I/We agree and confirm: (1) To the applicable schedule of charges, fees, commissions including the key facts informed to me by HDFC Bank Ltd. (Bank) and as more particularly mentioned in the \"Schedule of Charges\" of this Application. (2) That the bank's representative/ staff will not receive any payment in cash/ bearer cheque or kind along with or in connection with this loan application from me/ us. (3) That no discount or free gift or any other commitment whatsoever is given to me/ us by the Bank or any of its authorized representative(s) other than what is not documented in this application form the Terms and Conditions/ Agreement pursuant to the Loan. (4) The Bank shall not process incomplete/ defective application form, for which if any loss or delay is caused to me/ us, I/We will not hold the Bank liable for such loss or delay. (5) That Loan processing and disbursement will take at least 7 working days� post submission of all requisite documents and information as may be required by the Bank as per Bank's criteria. (6) That submission of loan application to your bank does not imply automatic approval by the Bank and the Bank will decide the quantum of the loan at its sole and absolute discretion. The Bank in its sole and absolute discretion may either sanction or reject the application for granting the loan. In case of rejection, the Bank shall not be required to give any reason. (7) That the Bank shall have the right to make disclosure of any information relating to me/us including personal information, details in relation to Loan, defaults, security, etc to the Credit information companies (CIC) and/or any other  governmental/ regulatory/ statutory or private agency/ entity, information utilities, RBI, the Bank's other branches/ subsidiaries / affiliates / rating agencies, service providers, other banks / financial institutions, any third parties, any assignes/potential assignees or transferees, who may need, process and publish the information in such manner and through such medium as it may be deemed necessary by the publisher/ Bank/ RBI, including publishing the name as part of willful defaulter's list from time to time, as also use for KYC information verification, credit risk analysis, or for other related purposes. (8) The Bank reserves its right to reject the loan application and retain the loan application form along with the photograph, information and documents. (9) That I/ We shall furnish any additional documents as and when required by the Bank. (10) That I/ We have not taken any loan from any other bank/ finance company unless specifically declared by me/ us. (11) That there is no impediment or restriction (whether legal or judicial) against me/ us and/or our asset filed/ reported by any other bank/ financer/ bank. (12) That the funds shall be used for the purpose for which loan has been applied and will not be used for speculative or antisocial purpose. (13) I/ We do not have any existing customer ID or customer ID apart from the one mentioned above, and incase found otherwise, Bank reserves the right to consolidate the customer IDs under a single customer ID as it may decide, without any prior notice to me/ us. (14) That the information furnished by me/ us above is true and accurate. \r\n" + "\r\n" + "Other declarations: \r\n" + "I/ We: (1) shall advise the HDFC Bank Ltd. (Bank) in writing of any change in my/ our residential or employment address. (2) hereby authorize and give consent to the Bank to disclose, without notice to me/ us, information furnished by me/ us in the application form(s)/ related documents executed/ to be executed in relation to the facilities to be availed by me/ us from the Bank, to the Bank's other branches/ subsidiaries/ affiliates/ credit information companies (CICs) Rating Agencies/ Service Providers, banks/ financial institutions, governmental/ regulatory authorities or third parties for information verification, credit risk analysis, or for other related purposes that the Bank may deem fit. I/ We waive the privilege of privacy and privity of contract. (3) shall credit all sums received by you in either or all the names of this account. (4) hereby confirm having received, read and understood the terms and conditions applicable to this loan including the application form and the Terms and Conditions/ Agreement and accept the same. (5) hereby unconditionally, agree that these terms may be changed by the Bank at any time and I / We will be bound by the amended terms and conditions. (6) Confirm that I/ We are citizen of India.\r\n" + "\r\n" + "I / We also confirm that (1) that Govt Taxes & Levies is applicable and will be charged in connection with the loan. (2) all the commission/s (in the form of up front and trail commissions) payable to HDFC Bank for the insurance policy recommended to me/us. (3) In the case of loan cancellation, the applicable pro-rata interest charges on any outstanding loan amount will have to be borne by me/us. I understand that Processing Fee, Stamp Duty are non-refundable charges and would not be waived/ refunded in case of loan cancellation or where the loan has not been disbursed. (4) That all the post-dated cheques are to be issued favouring HDFC Bank Limited A/c <Mention Product Name> only. (5) that loan related information like \"welcome letter\", \"repayment schedule\", \"Terms and condition\", \"disbursal advice (as applicable to Business Loan)\", will be sent on the e-mail id mentioned by me/ us in this loan application form. (6) I/ We may also request for a physical copy of Welcome Letter and Repayment Schedule separately if need be.\r\n" + "\r\n" + "DO NOT CALL REGISTRY: I understand that in case I do not wish to receive promotional information through telephone calls / email / SMS on products and services not currently availed by me, I can register for \"Do Not Call\" service through the Bank's website www.hdfcbank.com or through PhoneBanking or other channels that the Bank may offer. I agree that this service will not apply to receipt of advice and information regarding products and services currently availed by me, to help me in fully realising the benefits of the range of financial solutions designed to make my banking relationship value added and more convenient.\r\n";
	public final static String custIdConstant = "CUST_ID";
	public final static String Asterisk = "*";
	//S3 Bucket Configuration

	public final static String S3REGION = "ap-south-1";




		public static HashMap<String, Object> CIBIL_EMPTY_REQ() {
			HashMap<String, Object> cibilDataMapObj = new HashMap<String, Object>();

			cibilDataMapObj.put("BUREAUS_REPORTED", "");
			cibilDataMapObj.put("DATE_ISSUED", "");
			cibilDataMapObj.put("STATUS", "");
			cibilDataMapObj.put("SRNO", "");
			cibilDataMapObj.put("SOA_SOURCE_NAME", "");
			cibilDataMapObj.put("SUBJECT_RETURN_CODE", "");
			cibilDataMapObj.put("DATE_PROCESSED", "");
			cibilDataMapObj.put("ENQUIRY_CONTROL_NUMBER", "");
			cibilDataMapObj.put("CONSUMER_NAME_FIELD1", "");
			cibilDataMapObj.put("CONSUMER_NAME_FIELD2", "");
			cibilDataMapObj.put("CONSUMER_NAME_FIELD3", "");
			cibilDataMapObj.put("CONSUMER_NAME_FIELD4", "");
			cibilDataMapObj.put("CONSUMER_NAME_FIELD5", "");
			cibilDataMapObj.put("DATE_OF_BIRTH", "");
			cibilDataMapObj.put("GENDER", "");
			cibilDataMapObj.put("DT_ERRCODE_PN", "");
			cibilDataMapObj.put("ERR_SEG_TAG_PN", "");
			cibilDataMapObj.put("ERR_CODE_PN", "");
			cibilDataMapObj.put("ERROR_PN", "");
			cibilDataMapObj.put("DT_ENTCIBILRECODE_PN", "");
			cibilDataMapObj.put("CIBIL_REMARK_CODE_PN", "");
			cibilDataMapObj.put("DATE_DISP_REMARK_CODE_PN", "");
			cibilDataMapObj.put("ERR_DISP_REM_CODE1_PN", "");
			cibilDataMapObj.put("ERR_DISP_REM_CODE2_PN", "");
			cibilDataMapObj.put("ID_TYPE", "");
			cibilDataMapObj.put("ID_NUMBER", "");
			cibilDataMapObj.put("ISSUE_DATE", "");
			cibilDataMapObj.put("EXPIRATION_DATE", "");
			cibilDataMapObj.put("TELEPHONE_TYPE", "");
			cibilDataMapObj.put("TELEPHONE_EXTENSION", "");
			cibilDataMapObj.put("TELEPHONE_NUMBER", "");
			cibilDataMapObj.put("ENRICHED_THROUGH_ENQUIRY_PT", "");
			cibilDataMapObj.put("DATE_REPORTED_AND_CERTIFIED_EM", "");
			cibilDataMapObj.put("OCCUPATION_CODE_EM", "");
			cibilDataMapObj.put("INCOME_EM", "");
			cibilDataMapObj.put("NET_GROSS_INDICATOR_EM", "");
			cibilDataMapObj.put("MNTHLY_ANNUAL_INDICATOR_EM", "");
			cibilDataMapObj.put("DATE_ENTRY_ERR_CODE_EM", "");
			cibilDataMapObj.put("ERR_CODE_EM", "");
			cibilDataMapObj.put("DATE_CIBIL_ERR_CODE_EM", "");
			cibilDataMapObj.put("CIBIL_REMARK_CODE_EM", "");
			cibilDataMapObj.put("DT_DIS_REMARK_CODE_EM", "");
			cibilDataMapObj.put("ERR_DISP_REMCODE1_EM", "");
			cibilDataMapObj.put("ERR_DISP_REMCODE2_EM", "");
			cibilDataMapObj.put("ACCOUNT_NUMBER_PI", "");
			cibilDataMapObj.put("EXCLUSION_CODES_1_TO_5", "");
			cibilDataMapObj.put("EXCLUSION_CODES_6_TO_10", "");
			cibilDataMapObj.put("EXCLUSION_CODES_11_TO_15", "");
			cibilDataMapObj.put("EXCLUSION_CODES_16_TO_20", "");
			cibilDataMapObj.put("REASON_CODES_1_TO_5", "");
			cibilDataMapObj.put("REASON_CODES_6_TO_10", "");
			cibilDataMapObj.put("REASON_CODES_11_TO_15", "");
			cibilDataMapObj.put("REASON_CODES_16_TO_20", "");
			cibilDataMapObj.put("REASON_CODES_21_TO_25", "");
			cibilDataMapObj.put("REASON_CODES_26_TO_30", "");
			cibilDataMapObj.put("REASON_CODES_31_TO_35", "");
			cibilDataMapObj.put("REASON_CODES_36_TO_40", "");
			cibilDataMapObj.put("REASON_CODES_41_TO_45", "");
			cibilDataMapObj.put("REASON_CODES_46_TO_50", "");
			cibilDataMapObj.put("ERROR_CODE_SC", "");
			cibilDataMapObj.put("ADDRESS_LINE_1", "");
			cibilDataMapObj.put("ADDRESS_LINE_2", "");
			cibilDataMapObj.put("ADDRESS_LINE_3", "");
			cibilDataMapObj.put("ADDRESS_LINE_4", "");
			cibilDataMapObj.put("ADDRESS_LINE_5", "");
			cibilDataMapObj.put("ADDRESS_CATERGORY", "");
			cibilDataMapObj.put("ENRICHED_THROUGH_ENQUIRY_PA", "");
			cibilDataMapObj.put("PAYMENT_HISTORY_START_DATE", "");
			cibilDataMapObj.put("PAYMENT_HISTORY_END_DATE", "");
			cibilDataMapObj.put("WOF_SETTLED_STATUS_TL", "");
			cibilDataMapObj.put("VALOFCOLLATERAL_TL", "");
			cibilDataMapObj.put("TYPEOFCOLLATERAL_TL", "");
			cibilDataMapObj.put("CREDITLIMIT_TL", "");
			cibilDataMapObj.put("CASHLIMIT_TL", "");
			cibilDataMapObj.put("RATEOFINTREST_TL", "");
			cibilDataMapObj.put("REPAY_TENURE", "");
			cibilDataMapObj.put("WOF_TOT_AMOUNT_TL", "");
			cibilDataMapObj.put("WOF_PRINCIPAL_TL", "");
			cibilDataMapObj.put("SETTLEMENT_AMOUNT_TL", "");
			cibilDataMapObj.put("PAYMENT_FREQUENCY_TL", "");
			cibilDataMapObj.put("ACTUAL_PAYMENT_AMOUNT_TL", "");
			cibilDataMapObj.put("DT_ENTERRCODE_TL", "");
			cibilDataMapObj.put("ERRCODE_TL", "");
			cibilDataMapObj.put("DT_ENTCIBIL_REMARK_CODE_TL", "");
			cibilDataMapObj.put("CIBIL_REMARKS_CODE_TL", "");
			cibilDataMapObj.put("DT_DISPUTE_CODE_TL", "");
			cibilDataMapObj.put("ERR_DISP_REMCODE1_TL", "");
			cibilDataMapObj.put("ERR_DISP_REMCODE2_TL", "");
			cibilDataMapObj.put("DATE_OF_ENTRY_DR", "");
			cibilDataMapObj.put("DISP_REM_LINE1", "");
			cibilDataMapObj.put("DISP_REM_LINE2", "");
			cibilDataMapObj.put("DISP_REM_LINE3", "");
			cibilDataMapObj.put("DISP_REM_LINE4", "");
			cibilDataMapObj.put("DISP_REM_LINE5", "");
			cibilDataMapObj.put("DISP_REM_LINE6", "");
			cibilDataMapObj.put("OUTPUT_WRITE_FLAG", "");
			cibilDataMapObj.put("OUTPUT_WRITE_TIME", "");
			cibilDataMapObj.put("OUTPUT_READ_TIME", "");
			cibilDataMapObj.put("ACCOUNT_NUMBER_TL", "");
			cibilDataMapObj.put("ACCOUNT_TYPE_TL", "");
			cibilDataMapObj.put("AMOUNT_OVERDUE_TL", "");
			cibilDataMapObj.put("CURRENT_BALANCE_TL", "");
			cibilDataMapObj.put("DATE_CLOSED_TL", "");
			cibilDataMapObj.put("DATE_OF_LAST_PAYMENT_TL", "");
			cibilDataMapObj.put("DATE_OPENED_DISBURSED_TL", "");
			cibilDataMapObj.put("TL_DATE_REPORTED", "");
			cibilDataMapObj.put("EMI_AMOUNT_TL", "");
			cibilDataMapObj.put("HIGH_CREDIT_SANCTIONED_AMOUNT", "");
			cibilDataMapObj.put("OWNERSHIP_INDICATOR_TL", "");
			cibilDataMapObj.put("PAYMENT_HISTORY_1", "");
			cibilDataMapObj.put("PAYMENT_HISTORY_2", "");
			cibilDataMapObj.put("SUIT_FILED_STATUS_TL", "");
			cibilDataMapObj.put("DATE_REPORTED_PA", "");
			cibilDataMapObj.put("ENRICHED_THROUGH_ENQUIRY_ID", "");
			cibilDataMapObj.put("PINCODE", "");
			cibilDataMapObj.put("REPO_MEMSHORTNAME_TL", "");
			cibilDataMapObj.put("RESIDENCE_CODE", "");
			cibilDataMapObj.put("STATE", "");
			cibilDataMapObj.put("STATE_CODE", "");
			cibilDataMapObj.put("EMAIL_ID", "");
			cibilDataMapObj.put("DATE_OF_ENQUIRY_IQ", "");
			cibilDataMapObj.put("ENQ_MEMBER_SHORT_NAME_IQ", "");
			cibilDataMapObj.put("ENQIURY_AMOUNT_IQ", "");
			cibilDataMapObj.put("ENQUIRY_PURPOSE_IQ", "");
			cibilDataMapObj.put("MEMBER_REFERENCE_NUMBER", "");
			cibilDataMapObj.put("SCORE", "");
			cibilDataMapObj.put("SCORE_CARD_NAME", "");
			cibilDataMapObj.put("SCORE_CARD_VERSION", "");
			cibilDataMapObj.put("SCORE_NAME", "");
			cibilDataMapObj.put("SCORE_DATE", "");

			return cibilDataMapObj;
		}

		public static HashMap<String, Object> MERGE_BUREAU_EMPTY_REQ() {
			HashMap<String, Object> mergeBureauDataMapObj = new HashMap<String, Object>();

			mergeBureauDataMapObj.put("BUREAU", "");
			mergeBureauDataMapObj.put("PRODUCT", "");
			mergeBureauDataMapObj.put("APPLICATION-ID", "");
			mergeBureauDataMapObj.put("CUST-ID", "");
			mergeBureauDataMapObj.put("RESPONSE-TYPE", "");
			mergeBureauDataMapObj.put("REQUEST-RECEIVED-TIME", "");
			mergeBureauDataMapObj.put("SOURCE-SYSTEM", "");
			mergeBureauDataMapObj.put("ACKNOWLEDGEMENT-ID", "");
			mergeBureauDataMapObj.put("STATUS", "");
			mergeBureauDataMapObj.put("SRNO", "");
			mergeBureauDataMapObj.put("TL_PAYMENT_HISTORY_START_DATE", "");
			mergeBureauDataMapObj.put("TL_PAYMENT_HISTORY_END_DATE", "");
			mergeBureauDataMapObj.put("TL_ACCT_HIST_PAYMENT_STATUS", "");
			mergeBureauDataMapObj.put("TL_ACCT_HIST_ASSET_CLASS", "");
			mergeBureauDataMapObj.put("BUREAUS_REPORTED", "");
			mergeBureauDataMapObj.put("DATE_ISSUED", "");
			mergeBureauDataMapObj.put("DATE_PROCESSED", "");
			mergeBureauDataMapObj.put("MEMBER_REFERENCE_NUMBER", "");
			mergeBureauDataMapObj.put("OUTPUT_WRITE_FLAG", "");
			mergeBureauDataMapObj.put("SOA_SOURCE_NAME", "");
			mergeBureauDataMapObj.put("BUREAU_FEED_CHM_ERRORS", "");
			mergeBureauDataMapObj.put("BUREAU_FEED_CHM_REF_NUMBER", "");
			mergeBureauDataMapObj.put("BUREAU_FEED_CHM_SCORE", "");
			mergeBureauDataMapObj.put("BUREAU_FEED_CHM_SCORE_FACTOR_1", "");
			mergeBureauDataMapObj.put("BUREAU_FEED_CHM_SCORE_FACTOR_2", "");
			mergeBureauDataMapObj.put("BUREAU_FEED_CHM_SCORE_FACTOR_3", "");
			mergeBureauDataMapObj.put("BUREAU_FEED_CHM_SCORE_FACTOR_4", "");
			mergeBureauDataMapObj.put("BUREAU_FEED_CHM_SCORE_FACTOR_5", "");
			mergeBureauDataMapObj.put("BUREAU_FEED_CHM_SCORETYPE", "");
			mergeBureauDataMapObj.put("BUREAU_FEED_CHM_STATUS", "");
			mergeBureauDataMapObj.put("BUREAU_FEED_CIBIL_ERRORS", "");
			mergeBureauDataMapObj.put("BUREAU_FEED_CIBIL_REF_NUMBER", "");
			mergeBureauDataMapObj.put("BUREAU_FEED_CIBIL_SCORE", "");
			mergeBureauDataMapObj.put("BUREAU_FEED_CIBIL_SCORETYPE", "");
			mergeBureauDataMapObj.put("BUREAU_FEED_CIBIL_SCORE_FACTOR_1", "");
			mergeBureauDataMapObj.put("BUREAU_FEED_CIBIL_SCORE_FACTOR_2", "");
			mergeBureauDataMapObj.put("BUREAU_FEED_CIBIL_SCORE_FACTOR_3", "");
			mergeBureauDataMapObj.put("BUREAU_FEED_CIBIL_SCORE_FACTOR_4", "");
			mergeBureauDataMapObj.put("BUREAU_FEED_CIBIL_SCORE_FACTOR_5", "");
			mergeBureauDataMapObj.put("BUREAU_FEED_CIBIL_STATUS", "");
			mergeBureauDataMapObj.put("BUREAU_FEED_EQF_ERRORS", "");
			mergeBureauDataMapObj.put("BUREAU_FEED_EQF_REF_NUMBER", "");
			mergeBureauDataMapObj.put("BUREAU_FEED_EQF_SCORE", "");
			mergeBureauDataMapObj.put("BUREAU_FEED_EQF_SCORE_FACTOR_1", "");
			mergeBureauDataMapObj.put("BUREAU_FEED_EQF_SCORE_FACTOR_2", "");
			mergeBureauDataMapObj.put("BUREAU_FEED_EQF_SCORE_FACTOR_3", "");
			mergeBureauDataMapObj.put("BUREAU_FEED_EQF_SCORE_FACTOR_4", "");
			mergeBureauDataMapObj.put("BUREAU_FEED_EQF_SCORE_FACTOR_5", "");
			mergeBureauDataMapObj.put("BUREAU_FEED_EQF_SCORETYPE", "");
			mergeBureauDataMapObj.put("BUREAU_FEED_EQF_STATUS", "");
			mergeBureauDataMapObj.put("BUREAU_FEED_EXP_ERRORS", "");
			mergeBureauDataMapObj.put("BUREAU_FEED_EXP_REF_NUMBER", "");
			mergeBureauDataMapObj.put("BUREAU_FEED_EXP_SCORE", "");
			mergeBureauDataMapObj.put("BUREAU_FEED_EXP_SCORE_FACTOR_1", "");
			mergeBureauDataMapObj.put("BUREAU_FEED_EXP_SCORE_FACTOR_2", "");
			mergeBureauDataMapObj.put("BUREAU_FEED_EXP_SCORE_FACTOR_3", "");
			mergeBureauDataMapObj.put("BUREAU_FEED_EXP_SCORE_FACTOR_4", "");
			mergeBureauDataMapObj.put("BUREAU_FEED_EXP_SCORE_FACTOR_5", "");
			mergeBureauDataMapObj.put("BUREAU_FEED_EXP_SCORETYPE", "");
			mergeBureauDataMapObj.put("BUREAU_FEED_EXP_STATUS", "");
			mergeBureauDataMapObj.put("REV_CR_PERCENTAGE_USED", "");
			mergeBureauDataMapObj.put("REV_CR_SUMM_30DAYS_OVERDUE", "");
			mergeBureauDataMapObj.put("REV_CR_SUMM_60DAYS_OVERDUE", "");
			mergeBureauDataMapObj.put("REV_CR_SUMM_90DAYS_OVERDUE", "");
			mergeBureauDataMapObj.put("REV_CR_SUMM_BALANCE", "");
			mergeBureauDataMapObj.put("REV_CR_SUMM_OPEN_ACCTS", "");
			mergeBureauDataMapObj.put("REV_CR_SUMM_OVERDUE_AMT", "");
			mergeBureauDataMapObj.put("REV_CR_SUMM_PAYMENTS", "");
			mergeBureauDataMapObj.put("SEC_SUMM_30DAYS_OVERDUE", "");
			mergeBureauDataMapObj.put("SEC_SUMM_60DAYS_OVERDUE", "");
			mergeBureauDataMapObj.put("SEC_SUMM_90DAYS_OVERDUE", "");
			mergeBureauDataMapObj.put("SEC_SUMM_BALANCE", "");
			mergeBureauDataMapObj.put("SEC_SUMM_OPEN_ACCTS", "");
			mergeBureauDataMapObj.put("SEC_SUMM_OVERDUE_AMT", "");
			mergeBureauDataMapObj.put("SEC_SUMM_PAYMENTS", "");
			mergeBureauDataMapObj.put("SEC_SUMM_PERCENTAGE_USED", "");
			mergeBureauDataMapObj.put("TOTAL_NUM_CREDIT_LINES", "");
			mergeBureauDataMapObj.put("TOTAL_NUM_ENQUIRIES", "");
			mergeBureauDataMapObj.put("UNSEC_SUMM_30DAYS_OVERDUE", "");
			mergeBureauDataMapObj.put("UNSEC_SUMM_60DAYS_OVERDUE", "");
			mergeBureauDataMapObj.put("UNSEC_SUMM_90DAYS_OVERDUE", "");
			mergeBureauDataMapObj.put("UNSEC_SUMM_BALANCE", "");
			mergeBureauDataMapObj.put("UNSEC_SUMM_OPEN_ACCTS", "");
			mergeBureauDataMapObj.put("UNSEC_SUMM_OVERDUE_AMT", "");
			mergeBureauDataMapObj.put("UNSEC_SUMM_PAYMENTS", "");
			mergeBureauDataMapObj.put("UNSEC_SUMM_PERCENTAGE_USED", "");
			mergeBureauDataMapObj.put("ENQUIRY_DOB", "");
			mergeBureauDataMapObj.put("ENQUIRY_GENDER", "");
			mergeBureauDataMapObj.put("ENQUIRY_NAME", "");
			mergeBureauDataMapObj.put("OUTPUT_READ_TIME", "");
			mergeBureauDataMapObj.put("OUTPUT_WRITE_TIME", "");
			mergeBureauDataMapObj.put("DISP_CRED_ADDRESS_DATE_REPORTED", "");
			mergeBureauDataMapObj.put("DISP_CRED_ADDRESS_VALUE", "");
			mergeBureauDataMapObj.put("DISP_CRED_ADDRESS_BUREAUS_REPORTED", "");
			mergeBureauDataMapObj.put("DISP_CRED_DOB_DATE_REPORTED", "");
			mergeBureauDataMapObj.put("DISP_CRED_DOB_VALUE", "");
			mergeBureauDataMapObj.put("DISP_CRED_KYCID_BUREAUS_REPORTED", "");
			mergeBureauDataMapObj.put("DISP_CRED_KYCID_DATE_REPORTED", "");
			mergeBureauDataMapObj.put("DISP_CRED_KYCID_VALUE", "");
			mergeBureauDataMapObj.put("DISP_CRED_NAME_BUREAUS_REPORTED", "");
			mergeBureauDataMapObj.put("DISP_CRED_NAME_DATE_REPORTED", "");
			mergeBureauDataMapObj.put("DISP_CRED_NAME_VALUE", "");
			mergeBureauDataMapObj.put("DISP_CRED_PHONE_BUREAUS_REPORTED", "");
			mergeBureauDataMapObj.put("DISP_CRED_PHONE_DATE_REPORTED", "");
			mergeBureauDataMapObj.put("DISP_CRED_PHONE_VALUE", "");
			mergeBureauDataMapObj.put("PAST_ENQ_AMOUNT", "");
			mergeBureauDataMapObj.put("PAST_ENQ_DATE", "");
			mergeBureauDataMapObj.put("PAST_ENQ_DONE_BY", "");
			mergeBureauDataMapObj.put("PAST_ENQ_REASON", "");
			mergeBureauDataMapObj.put("PAST_ENQ_REPORTED_BUREAUS", "");
			mergeBureauDataMapObj.put("TL_ACCT_HIST_KEY", "");
			mergeBureauDataMapObj.put("TL_ACCT_HIST_SUIT_FILED_STATUS", "");
			mergeBureauDataMapObj.put("APPLICATION_SCORE_DESC", "");
			mergeBureauDataMapObj.put("APPLICATION_SCORE_FACTOR_1", "");
			mergeBureauDataMapObj.put("APPLICATION_SCORE_FACTOR_2", "");
			mergeBureauDataMapObj.put("APPLICATION_SCORE_FACTOR_3", "");
			mergeBureauDataMapObj.put("APPLICATION_SCORE_FACTOR_4", "");
			mergeBureauDataMapObj.put("APPLICATION_SCORE_FACTOR_5", "");
			mergeBureauDataMapObj.put("APPLICATION_SCORE_STATUS", "");
			mergeBureauDataMapObj.put("APPLICATION_SCORE_VALUE", "");
			mergeBureauDataMapObj.put("TL_ACCT_NUMBER", "");
			mergeBureauDataMapObj.put("TL_ACCT_OPEN_DATE", "");
			mergeBureauDataMapObj.put("TL_ACCT_TYPE", "");
			mergeBureauDataMapObj.put("TL_BUREAU_NAME", "");
			mergeBureauDataMapObj.put("TL_CLOSED_DATE", "");
			mergeBureauDataMapObj.put("TL_COLLATERAL", "");
			mergeBureauDataMapObj.put("TL_CREDIT_INST", "");
			mergeBureauDataMapObj.put("TL_CURRENT_BALANCE", "");
			mergeBureauDataMapObj.put("TL_DISBURSED_AMT", "");
			mergeBureauDataMapObj.put("TL_INSTALL_AMT", "");
			mergeBureauDataMapObj.put("TL_INTEREST_RATE", "");
			mergeBureauDataMapObj.put("TL_LAST_PAYMENT_AMT", "");
			mergeBureauDataMapObj.put("TL_LAST_PAYMENT_DATE", "");
			mergeBureauDataMapObj.put("TL_OVERDUE_AMOUNT", "");
			mergeBureauDataMapObj.put("TL_OWNERSHIP", "");
			mergeBureauDataMapObj.put("TL_PAYMENT_RATING", "");
			mergeBureauDataMapObj.put("TL_REPORTED_BUREAUS", "");
			mergeBureauDataMapObj.put("TL_REPORTED_DATE", "");
			mergeBureauDataMapObj.put("TL_SANCTIONED_AMT", "");
			mergeBureauDataMapObj.put("TL_SECURED", "");
			mergeBureauDataMapObj.put("TL_TENURE", "");
			mergeBureauDataMapObj.put("TL_WRITEOFF_STATUS", "");
			mergeBureauDataMapObj.put("TL_SUITFILED_STATUS", "");
			mergeBureauDataMapObj.put("DISP_CRED_EMAIL_VALUE", "");
			mergeBureauDataMapObj.put("DISP_CRED_EMAIL_BUREAUS_REPORTED", "");
			mergeBureauDataMapObj.put("DISPCRED_EMAIL_BUREAUS_REPORTED", "");
			mergeBureauDataMapObj.put("DISP_CRED_DOB_BUREAUS_REPORTED", "");

			return mergeBureauDataMapObj;
		}

		public static HashMap<String, String> TRUSTING_SOCIAL_EMPTY_REQ() {
			HashMap<String, String> trustingSocialMapObj = new HashMap<String, String>();

			trustingSocialMapObj.put("decryptedScore", "");
			return trustingSocialMapObj;
		}

		public static HashMap<String, String> JOURNEY_EMPTY_REQ() {
			HashMap<String, String> journeyDataMapObj = new HashMap<String, String>();
			journeyDataMapObj.put("panNumber", "");
			journeyDataMapObj.put("panUserName", "");
			journeyDataMapObj.put("panFirstName", "");
			journeyDataMapObj.put("address", "");
			journeyDataMapObj.put("city", "");
			journeyDataMapObj.put("state", "");
			journeyDataMapObj.put("pin", "");
			journeyDataMapObj.put("dob", "");
			journeyDataMapObj.put("organizationName", "");
			journeyDataMapObj.put("applicationId", "");
			return journeyDataMapObj;
		}

		public static HashMap<String, String> MBEOT_EMPTY_REQ() {
			HashMap<String, String> mbEotDataMapObj = new HashMap<String, String>();
			mbEotDataMapObj.put("SENT_TO_CHM", "");
			mbEotDataMapObj.put("SENT_TO_EXPERIAN", "");
			mbEotDataMapObj.put("SENT_TO_EQUIFAX", "");
			mbEotDataMapObj.put("SENT_TO_CIBIL", "");
			mbEotDataMapObj.put("TRACKING_ID", "");
			mbEotDataMapObj.put("score", "");
			mbEotDataMapObj.put("band", "");
			mbEotDataMapObj.put("Filler1", "");
			mbEotDataMapObj.put("Filler2", "");
			mbEotDataMapObj.put("Filler3", "");
			mbEotDataMapObj.put("Filler4", "");
			mbEotDataMapObj.put("Filler5", "");
			return mbEotDataMapObj;
		}

		public static org.json.JSONObject POSIDEX_EMPTY_REQ() {
			org.json.JSONObject posidexRequestObject = new org.json.JSONObject();
			org.json.JSONObject responseObj = new org.json.JSONObject();
			try {

				posidexRequestObject.put("POSIDEXLOSINPUTFROMSASLSILOANAMTN", "");
				posidexRequestObject.put("POSIDEXLOSINPUTFROMSASLSICURRENTOUTSTANDINGN", "");
				posidexRequestObject.put("POSIDEXLOSINPUTFROMSASLSIDAYSPASTDUEN", "");
				posidexRequestObject.put("POSIDEXOUTPUTDATAFILLER60", "");

				posidexRequestObject.put("POSIDEXOUTPUTDATASOAAPPIDC", "");
				posidexRequestObject.put("POSIDEXOUTPUTDATAFILLER20", "");
				posidexRequestObject.put("POSIDEXOUTPUTDATAFILLER21", "");
				posidexRequestObject.put("POSIDEXOUTPUTDATAFILLER22", "");
				posidexRequestObject.put("POSIDEXOUTPUTDATASOASASUPDATESTATUS", "");
				posidexRequestObject.put("POSIDEXOUTPUTDATASOAPRODUCTCODEC", "");
				posidexRequestObject.put("POSIDEXOUTPUTDATASOAREADFLAG", "");
				posidexRequestObject.put("POSIDEXOUTPUTDATAFILLER8", "");
				posidexRequestObject.put("POSIDEXOUTPUTDATAFILLER7", "");
				posidexRequestObject.put("POSIDEXOUTPUTDATASOAMNAMEC", "");
				posidexRequestObject.put("POSIDEXOUTPUTDATAFILLER9", "");
				posidexRequestObject.put("POSIDEXOUTPUTDATAFILLER24", "");
				posidexRequestObject.put("POSIDEXOUTPUTDATASOACUSTIDN", "");
				posidexRequestObject.put("POSIDEXOUTPUTDATAFILLER23", "");
				posidexRequestObject.put("POSIDEXOUTPUTDATAFILLER2", "");
				posidexRequestObject.put("POSIDEXOUTPUTDATAFILLER26", "");
				posidexRequestObject.put("POSIDEXOUTPUTDATAFILLER1", "");
				posidexRequestObject.put("POSIDEXOUTPUTDATAFILLER25", "");
				posidexRequestObject.put("POSIDEXOUTPUTDATAFILLER4", "");
				posidexRequestObject.put("POSIDEXOUTPUTDATAFILLER28", "");
				posidexRequestObject.put("POSIDEXOUTPUTDATAFILLER3", "");
				posidexRequestObject.put("POSIDEXOUTPUTDATAFILLER27", "");
				posidexRequestObject.put("POSIDEXOUTPUTDATASOAMATCHAPPIDC", "");
				posidexRequestObject.put("POSIDEXOUTPUTDATAFILLER6", "");
				posidexRequestObject.put("POSIDEXOUTPUTDATAFILLER5", "");
				posidexRequestObject.put("POSIDEXOUTPUTDATAFILLER29", "");
				posidexRequestObject.put("POSIDEXOUTPUTDATAFILLER51", "");
				posidexRequestObject.put("POSIDEXOUTPUTDATAFILLER50", "");
				posidexRequestObject.put("POSIDEXOUTPUTDATAFILLER53", "");
				posidexRequestObject.put("POSIDEXOUTPUTDATAFILLER52", "");
				posidexRequestObject.put("POSIDEXOUTPUTDATASOASTATUSC", "");
				posidexRequestObject.put("POSIDEXOUTPUTDATAFILLER11", "");
				posidexRequestObject.put("POSIDEXOUTPUTDATAFILLER55", "");
				posidexRequestObject.put("POSIDEXOUTPUTDATAFILLER10", "");
				posidexRequestObject.put("POSIDEXOUTPUTDATAFILLER54", "");
				posidexRequestObject.put("POSIDEXLOSINPUTFROMSASLSIBORROWERF", "");
				posidexRequestObject.put("POSIDEXOUTPUTDATAFILLER13", "");
				posidexRequestObject.put("POSIDEXOUTPUTDATAFILLER57", "");
				posidexRequestObject.put("POSIDEXOUTPUTDATAFILLER12", "");
				posidexRequestObject.put("POSIDEXOUTPUTDATAFILLER56", "");
				posidexRequestObject.put("POSIDEXOUTPUTDATAFILLER15", "");
				posidexRequestObject.put("POSIDEXOUTPUTDATAFILLER59", "");
				posidexRequestObject.put("POSIDEXOUTPUTDATAFILLER14", "");
				posidexRequestObject.put("POSIDEXOUTPUTDATAFILLER58", "");
				posidexRequestObject.put("POSIDEXOUTPUTDATAFILLER17", "");
				posidexRequestObject.put("POSIDEXOUTPUTDATAFILLER16", "");
				posidexRequestObject.put("POSIDEXOUTPUTDATAFILLER19", "");
				posidexRequestObject.put("POSIDEXOUTPUTDATAFILLER18", "");
				posidexRequestObject.put("POSIDEXOUTPUTDATAFILLER40", "");
				posidexRequestObject.put("POSIDEXOUTPUTDATASOACUSTEXPOSUREN", "");
				posidexRequestObject.put("POSIDEXOUTPUTDATAFILLER42", "");
				posidexRequestObject.put("POSIDEXOUTPUTDATAFILLER41", "");
				posidexRequestObject.put("POSIDEXOUTPUTDATAFILLER44", "");
				posidexRequestObject.put("POSIDEXOUTPUTDATAFILLER43", "");
				posidexRequestObject.put("POSIDEXOUTPUTDATASOAREADDATE", "");
				posidexRequestObject.put("POSIDEXOUTPUTDATASOASOURCEC", "");
				posidexRequestObject.put("POSIDEXOUTPUTDATASOASASUPDATEDATE", "");
				posidexRequestObject.put("POSIDEXOUTPUTDATAFILLER46", "");
				posidexRequestObject.put("POSIDEXOUTPUTDATAFILLER45", "");
				posidexRequestObject.put("POSIDEXOUTPUTDATAFILLER48", "");
				posidexRequestObject.put("POSIDEXOUTPUTDATASOAFILENAMEC", "");
				posidexRequestObject.put("POSIDEXOUTPUTDATAFILLER47", "");
				posidexRequestObject.put("POSIDEXOUTPUTDATAFILLER49", "");
				posidexRequestObject.put("POSIDEXOUTPUTDATAFILLER31", "");
				posidexRequestObject.put("POSIDEXOUTPUTDATAFILLER30", "");
				posidexRequestObject.put("POSIDEXOUTPUTDATAFILLER33", "");
				posidexRequestObject.put("POSIDEXOUTPUTDATAFILLER32", "");
				posidexRequestObject.put("POSIDEXOUTPUTDATASOALNAMEC", "");
				posidexRequestObject.put("POSIDEXOUTPUTDATASOACUSTTYPEC", "");
				posidexRequestObject.put("POSIDEXOUTPUTDATAFILLER35", "");
				posidexRequestObject.put("POSIDEXOUTPUTDATAFILLER34", "");
				posidexRequestObject.put("POSIDEXOUTPUTDATAFILLER37", "");
				posidexRequestObject.put("POSIDEXOUTPUTDATAFILLER36", "");
				posidexRequestObject.put("POSIDEXOUTPUTDATAFILLER39", "");
				posidexRequestObject.put("POSIDEXOUTPUTDATAFILLER38", "");
				posidexRequestObject.put("POSIDEXOUTPUTDATASOAFNAMEC", "");
				posidexRequestObject.put("SOA_DEDUPE_DATE", "");
				responseObj.put("POSIDEX", posidexRequestObject);
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return responseObj;
		}

		public static org.json.JSONObject SIGNZY_EMPTY_REQ() {
			org.json.JSONObject signZyRequestObject = new org.json.JSONObject();
			org.json.JSONObject responseObj = new org.json.JSONObject();
			try {

				signZyRequestObject.put("SIGNZYCUSTOMERINFOEMAILID", "");

				signZyRequestObject.put("SIGNZYCUSTOMERINFOSTATUS", "");
				signZyRequestObject.put("SIGNZYCUSTOMERINFOSUBSTATUS", "");
				signZyRequestObject.put("SIGNZYCUSTOMERINFOCATCHALLOUTPUT", "");
				signZyRequestObject.put("SIGNZYCUSTOMERINFOFIRSTNAME", "");
				signZyRequestObject.put("SIGNZYCUSTOMERINFOLASTNAME", "");
				signZyRequestObject.put("SIGNZYCUSTOMERINFOFREEEMAIL", "");
				signZyRequestObject.put("SIGNZYCUSTOMERINFODOMAIN", "");
				signZyRequestObject.put("SIGNZYCUSTOMERINFODOMAINAGEDAYS", "");
				signZyRequestObject.put("SIGNZYCUSTOMERINFOCOMPANYNAME", "");
				signZyRequestObject.put("SIGNZYCUSTOMERINFOCOMPANYLEGALNAME", "");
				signZyRequestObject.put("SIGNZYCUSTOMERINFOCOMPANYESTABLISHMENTID", "");
				signZyRequestObject.put("SIGNZYCUSTOMERINFOEMAILNAMEMATCHSTATUS", "");
				signZyRequestObject.put("SIGNZYCUSTOMERINFOEMAILNAMEMATCHSCORE", "");
				signZyRequestObject.put("SIGNZYCUSTOMERINFOEMAILFINALSTATUS", "");
				signZyRequestObject.put("SIGNZYCUSTOMERINFODOMAINMATCHSTATUS", "");
				signZyRequestObject.put("SIGNZYCUSTOMERINFOEPFOSTATUS", "");
				signZyRequestObject.put("SIGNZYCUSTOMERINFOOVERALLSTATUS", "");
				signZyRequestObject.put("SIGNZYCUSTOMERINFOOFFICEEMAILVALIDATED", "");
				responseObj.put("SIGNZY", signZyRequestObject);
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return responseObj;
		}

		public static org.json.JSONObject NAME_MATCH_EMPTY_REQ() {
			org.json.JSONObject posidexNameObject = new org.json.JSONObject();
			org.json.JSONObject responseObj = new org.json.JSONObject();
			try {

				posidexNameObject.put("APPLNLOSFILLERSFILLERTEXT5", "Z");
				posidexNameObject.put("APPLNLOSFILLERSFILLERTEXT6", "Z");
				posidexNameObject.put("APPLNLOSFILLERSFILLERTEXT7", "Z");
				// posidexNameObject.put("APPLNLOSFILLERSFILLERTEXT8", "");

				responseObj.put("POSIDEXNAMEMATCH", posidexNameObject);
			} catch (JSONException e) {
				e.printStackTrace();
			}
			return responseObj;
		}

		public static org.json.JSONObject HUNTER_EMPTY_RESP() {
			org.json.JSONObject hunterJsonObject = new org.json.JSONObject();
			org.json.JSONObject responseObj = new org.json.JSONObject();
			try {

				hunterJsonObject.put("TotalMatchScore", "");
				hunterJsonObject.put("RuleID", "");
				hunterJsonObject.put("Score", "");
				hunterJsonObject.put("ruleCount", "");
				hunterJsonObject.put("matches", "");

				responseObj.put("HUNTER", hunterJsonObject);
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return responseObj;
		}

		public static HashMap<String, String> EKYC_EMPTY_RESP() {
			HashMap<String, String> ekycMapObj = new HashMap<String, String>();

			ekycMapObj.put("dob", AppConstants.DEFAULT_DATE);
			return ekycMapObj;
		}

		public static HashMap<String, String> CIF_EMPTY_RESP() {
			HashMap<String, String> cifObj = new HashMap<String, String>();
			cifObj.put("BEHAV_SCORE1", "");
			cifObj.put("BEHAV_SCORE2", "");
			cifObj.put("BEHAVIORAL_SCORE3", "");
			cifObj.put("BEHAVIORAL_SCORE4", "");
			cifObj.put("BEHAVIORAL_SCORE5", "");
			cifObj.put("BEHAVIORAL_SCORE6", "");
			cifObj.put("BEHAVIORAL_SCORE7", "");
			cifObj.put("CARD_BEHAV_SCORE", "");
			cifObj.put("CNC_BEHAV_SCORE", "");
			cifObj.put("CUSTOMER_ID", "");
			cifObj.put("DEBIT_SCORE_AL", "");
			cifObj.put("DEBIT_SCORE_BL", "");
			cifObj.put("DEBIT_SCORE_CARDS", "");
			cifObj.put("DEBIT_SCORE_PL", "");
			cifObj.put("FW_ACCNT_NUM", "Z");
			cifObj.put("FW_CUST_ID", "Z");
			cifObj.put("SAS_ID", "");
			cifObj.put("FILLER1", "");
			cifObj.put("FILLER2", "");
			cifObj.put("FILLER3", "");
			cifObj.put("FILLER4", "");
			cifObj.put("FILLER5", "");

			return cifObj;
		}

		public static HashMap<String, String> CP_EMPTY_DATA() {
			HashMap<String, String> cpObj = new HashMap<String, String>();

			cpObj.put("rateOfInterest", "");
			cpObj.put("tenureArr", "");
			cpObj.put("offerAmountArr", "");
			cpObj.put("productnameArr", "");
			cpObj.put("cardType", "");
			cpObj.put("eKYCFlag", "");

			return cpObj;
		}

	}

	

