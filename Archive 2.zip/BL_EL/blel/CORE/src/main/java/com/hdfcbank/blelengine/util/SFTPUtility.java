package com.hdfcbank.blelengine.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.hdfcbank.blelengine.constants.AppConstants;
import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;

@Component
public class SFTPUtility {

	private final static Logger logger = LoggerFactory.getLogger(SFTPUtility.class);

	public void uploadZipFileToSFTP(String filePath) throws JSchException, SftpException {
		JSch jsch = new JSch();
		try {
			jsch.addIdentity(AppConstants.PRIVATE_KEY);
		} catch (JSchException e) {
			e.printStackTrace();
			logger.info("uploadZipFileToSFTP Exception :: " + CommonUtility.getPrintStackTrace(e));
		}

		Session session = null;
		Channel channel = null;
		ChannelSftp channelSftp = null;

		logger.info("connecting to sftp :: ");
		try {
			session = jsch.getSession(AppConstants.SFTP_USER, AppConstants.SFTP_HOST, AppConstants.SFTP_PORT);
			if(session != null) {
				session.setPassword(AppConstants.SFTP_PASS);
				java.util.Properties config = new java.util.Properties();
				config.put("StrictHostKeyChecking", "no");
				session.setConfig(config);
				//NOSONAR
				session.connect();
				channel = session.openChannel("sftp");
				channel.connect();
				logger.info("connected to sftp :: ");
				channelSftp = (ChannelSftp) channel;
				String targetLocation = AppConstants.TARGET_FILE_LOCATION;
				channelSftp.cd(targetLocation);
				// File directory = new File(zipPath);
				channelSftp.put(filePath, targetLocation, ChannelSftp.OVERWRITE);
				logger.info(filePath + " transferred to :: " + targetLocation);
			}
		} catch (JSchException e) {
			logger.info("uploadZipFileToSFTP Exception :: " + CommonUtility.getPrintStackTrace(e));
			e.printStackTrace();
		}




	}
}
