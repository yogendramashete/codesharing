package com.hdfcbank.blelengine.util;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.UUID;

import lombok.extern.log4j.Log4j2;
import org.apache.commons.codec.binary.Base64;
import org.bouncycastle.crypto.InvalidCipherTextException;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.stereotype.Component;

@Log4j2
@Component
public class OtpEkyc {
	private byte[] encXMLPIDData;
	private byte[] encryptedHmacBytes;
	private byte[] encryptedSessionKey;
	private String certificateIdentifier;
	private String keyIdentifier;

	private Encrypter encrypter;

	private HashGenerator hashGenerator;

	SynchronizedKey synchronizedKey;

	public OtpEkyc() {
		this.synchronizedKey = null;
	}

	public String pidGeneration(final String ts, final String otp, final String certificatePath)
			throws IllegalStateException, InvalidCipherTextException, IOException, GeneralSecurityException {
		byte[] sessionKey = null;
		byte[] iv = null;
		byte[] aad = null;
		final String pidXML = "<Pid ts=\"" + ts + "\"" + " ver=\"2.0\"><Pv otp=" + "\"" + otp + "\"" + "/></Pid>";
		System.out.println("pidXML: " + pidXML);
		System.out.println("certificatePath: " + certificatePath);
		this.encrypter = new Encrypter(certificatePath);
		this.hashGenerator = new HashGenerator();
		final byte[] pidXmlBytes = pidXML.getBytes();
		final byte[] hmac = this.hashGenerator.generateSha256Hash(pidXmlBytes);
		sessionKey = this.encrypter.generateSessionKey();
		iv = this.encrypter.generateIv(ts);
		aad = this.encrypter.generateAad(ts);
		this.encXMLPIDData = this.encrypter.encryptUsingSessionKey(true, sessionKey, iv, aad, pidXmlBytes);
		final byte[] tsInBytes = ts.getBytes("UTF-8");
		final byte[] packedEncXMLPIDData = new byte[this.encXMLPIDData.length + tsInBytes.length];
		System.arraycopy(tsInBytes, 0, packedEncXMLPIDData, 0, tsInBytes.length);
		System.arraycopy(this.encXMLPIDData, 0, packedEncXMLPIDData, tsInBytes.length, this.encXMLPIDData.length);
		this.encryptedHmacBytes = this.encrypter.encryptUsingSessionKey(true, sessionKey, iv, aad, hmac);
		final String hmacString = new String(Base64.encodeBase64(this.encryptedHmacBytes));
		this.encryptedSessionKey = this.encrypter.encryptUsingPublicKey(sessionKey);
		final String skeyString = new String(Base64.encodeBase64(this.encryptedSessionKey));
		final SimpleDateFormat df2 = new SimpleDateFormat("yyyyMMdd");
		this.certificateIdentifier = df2.format(this.encrypter.getCertExpiryDate());
		this.synchronizedKey = new SynchronizedKey(this.encrypter.generateSessionKey(), UUID.randomUUID().toString(),
				new Date());
		this.keyIdentifier = this.synchronizedKey.getKeyIdentifier();
		final String data = new String(Base64.encodeBase64(packedEncXMLPIDData));
		final JSONObject json = new JSONObject();
		try {
			json.put("Filler1", (Object) data);
			json.put("Filler2", (Object) skeyString);
			json.put("Filler3", (Object) hmacString);
			json.put("Status", (Object) "Success");
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return json.toString();
	}

	public static void main(final String[] args) {
		final OtpEkyc ekyc = new OtpEkyc();
		final Date date = new Date();
		final SimpleDateFormat sdf3 = new SimpleDateFormat("yyyy-MM-dd");
		final SimpleDateFormat sdfTime1 = new SimpleDateFormat("HH:mm:ss");
		final String ts = String.valueOf(sdf3.format(date)) + "T" + sdfTime1.format(date);
		try {
			final String encryptedPid = ekyc.pidGeneration(ts, "123466",
					"E:/ANAND_BKP/Projects/HDFC_BANK_SELFY/Documents/Auth_Benchmarking_server/uidai_auth_encrypt_preprod.cer");
			System.out.println(encryptedPid);
		} catch (Exception e) {
			//e.printStackTrace();
			log.info("Exception ::"+e);
		}
	}
}
