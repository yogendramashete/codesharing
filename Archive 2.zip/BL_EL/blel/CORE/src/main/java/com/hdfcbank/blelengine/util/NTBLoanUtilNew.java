package com.hdfcbank.blelengine.util;

import java.util.HashMap;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.text.similarity.JaroWinklerDistance;
import org.json.XML;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hdfcbank.blelengine.constants.AppConstants;
import com.hdfcbank.blelengine.constants.RedisConstants;
import com.hdfcbank.blelengine.constants.StaticConstants;

import ch.qos.logback.classic.Logger;

@Component
public class NTBLoanUtilNew {

	@Autowired
	private BREUtil breUtil;

	@Autowired
	private RedisUtils redisUtils;

	@Autowired
	private OpenBankApiConnector openBankapiConnector;




	public final static Logger logger = (Logger) LoggerFactory.getLogger(NTBLoanUtilNew.class);


	public HashMap<String, String> getMBEOT(String mobileNo, String applicationId) {
		HashMap<String, String> mbEotDataMapObj = new HashMap<String, String>();

		try {

			String xmlRequest = "";
			if (!AppConstants.IS_BRE_STATIC) {
				// TODO key word for setting response of MB EOT
				xmlRequest = redisUtils.get(RedisConstants.MBEOT + mobileNo + RedisConstants.US + applicationId);

				logger.info("Redis getMBEOT xmlRequest :: " + xmlRequest.length());
			} else {
				xmlRequest = StaticConstants.MBEOT_STAIC_REQ;
			}

			if (StringUtils.isNotBlank(xmlRequest)) {
				org.json.JSONObject xmlJSONObj = XML.toJSONObject(xmlRequest);

				String jsonPrettyPrintString = xmlJSONObj.toString(AppConstants.PRETTY_PRINT_INDENT_FACTOR)
						.replaceAll("(\r\n|\n)", "").replaceAll("  ", "").replaceAll("soapenv:", "")
						.replaceAll("ns0:", "");
				JSONParser jsonParser = new JSONParser();
				JSONObject jsonRequest = (JSONObject) jsonParser.parse(jsonPrettyPrintString);

				JSONObject Envelope = (JSONObject) jsonRequest.get("Envelope");
				JSONObject Body = (JSONObject) Envelope.get("Body");
				JSONObject mbEoTRequestTypeObj = ((JSONObject) Body.get("MultiBureauEoTRequest"));

				JSONObject chmObj = ((JSONObject) mbEoTRequestTypeObj.get("SENT-TO-CHM"));
				JSONObject experianObj = ((JSONObject) mbEoTRequestTypeObj.get("SENT-TO-EXPERIAN"));
				JSONObject cibilObj = ((JSONObject) mbEoTRequestTypeObj.get("SENT-TO-CIBIL"));
				JSONObject equifaxObj = ((JSONObject) mbEoTRequestTypeObj.get("SENT-TO-EQUIFAX"));
				JSONObject soaFillersObj = ((JSONObject) mbEoTRequestTypeObj.get("soaFillers"));
				mbEotDataMapObj.put("SENT_TO_CHM",
						StringUtils
								.isBlank(chmObj.get("content") == null ? "" : chmObj.get("content").toString()) == true
										? "Z"
										: chmObj.get("content").toString());
				mbEotDataMapObj.put("SENT_TO_EXPERIAN",
						StringUtils.isBlank(
								experianObj.get("content") == null ? "" : experianObj.get("content").toString()) == true
										? "Z"
										: experianObj.get("content").toString());
				mbEotDataMapObj.put("SENT_TO_EQUIFAX",
						StringUtils.isBlank(
								equifaxObj.get("content") == null ? "" : equifaxObj.get("content").toString()) == true
										? "Z"
										: equifaxObj.get("content").toString());
				mbEotDataMapObj.put("SENT_TO_CIBIL",
						StringUtils.isBlank(
								cibilObj.get("content") == null ? "" : cibilObj.get("content").toString()) == true ? "Z"
										: cibilObj.get("content").toString());
				mbEotDataMapObj.put("Filler1",
						StringUtils.isBlank(soaFillersObj.get("filler1") == null ? ""
								: soaFillersObj.get("filler1").toString()) == true ? "Z"
										: soaFillersObj.get("filler1").toString());
				mbEotDataMapObj.put("Filler2",
						StringUtils.isBlank(soaFillersObj.get("filler2") == null ? ""
								: soaFillersObj.get("filler2").toString()) == true ? "Z"
										: soaFillersObj.get("filler2").toString());
				String filler3 = soaFillersObj.get("filler3") == null ? "" : soaFillersObj.get("filler3").toString();

				String score = "";
				String band = "";
				if (StringUtils.isNotBlank(filler3)) {
					String[] filler3Arr = filler3.split(",");
					if (filler3Arr.length > 1) {
						score = StringUtils.isBlank(filler3Arr[0] == null ? "" : filler3Arr[0].toString()) == true ? "Z"
								: filler3Arr[0].toString();
						band = StringUtils.isBlank(filler3Arr[1] == null ? "" : filler3Arr[1].toString()) == true ? "Z"
								: filler3Arr[1].toString();
					}

				}
				mbEotDataMapObj.put("Filler3", filler3);
				mbEotDataMapObj.put("score", score);
				mbEotDataMapObj.put("band", band);
				mbEotDataMapObj.put("Filler4",
						StringUtils.isBlank(soaFillersObj.get("filler4") == null ? ""
								: soaFillersObj.get("filler4").toString()) == true ? "Z"
										: soaFillersObj.get("filler4").toString());
				String filler5 = StringUtils.isBlank(
						soaFillersObj.get("filler5") == null ? "" : soaFillersObj.get("filler5").toString()) == true
								? "Z"
								: soaFillersObj.get("filler5").toString();
				filler5 = filler5.replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;");
				mbEotDataMapObj.put("Filler5", filler5);
			} else {
				mbEotDataMapObj = AppConstants.MBEOT_EMPTY_REQ();
			}

		} catch (Exception e) {
			logger.info("Exception getMBEOT :: " + e.getMessage());
			mbEotDataMapObj = AppConstants.MBEOT_EMPTY_REQ();
		}
		return mbEotDataMapObj;
	}

	@SuppressWarnings("unchecked")
	public static String getItemArray(JSONArray arrayObj, String arrayTagKey, String tagKey, String tagType) {
		StringBuilder itemArrObj = new StringBuilder();
		StringBuilder isDataAvailable = new StringBuilder();
		try {

			if (arrayObj.size() > 0) {
				arrayObj.forEach(item -> {
					JSONObject obj = (JSONObject) item;
					JSONObject arrayTagObj = (JSONObject) obj.get(arrayTagKey);
					String tagValue = arrayTagObj.get(tagKey).toString();
					if (StringUtils.isNotBlank(tagValue)) {
						if (isDataAvailable.length() == 0)
							isDataAvailable.append("Y");
						if (tagType.equals(AppConstants.TAG_TYPE_DATE)) {
							tagValue = CommonUtility.formatDate(tagValue, AppConstants.DATE_FMT_ddMMyyyy,
									AppConstants.DATE_FMT_yyyy_MM_dd);
							itemArrObj.append("<item>" + tagValue + "</item>");
						} else if (tagType.equals(AppConstants.TAG_TYPE_DATE2)) {
							tagValue = tagValue.split(" ")[0];
							itemArrObj.append("<item>" + tagValue + "</item>");
						} else if (tagType.equals(AppConstants.TAG_TYPE_DATE3)) {
							itemArrObj.append("<item>" + tagValue + "</item>");
						} else if (tagType.equals(AppConstants.TAG_TYPE_DECIMAL)) {
							double tagValueDec = Double.parseDouble(tagValue);
							itemArrObj.append("<item>" + tagValueDec + "</item>");
						} else {
							itemArrObj.append("<item>" + tagValue + "</item>");
						}

					} else {
						/*
						 * //added below condition to avoid the multiple iteration for blank values
						 * if(StringUtils.isBlank(itemArrObj)) {
						 * itemArrObj.append(addDefaultTag(tagType)); }
						 */
						// itemArrObj.append(addDefaultTag(tagType));
					}

				});

			}
			System.out.println("isDataavailable for tag :" + tagKey + ": :" + isDataAvailable);
			if (isDataAvailable.toString().equals("Y")) {
				return itemArrObj.toString();
			} else {
				return "".toString();
			}
		} catch (Exception e) {
			logger.info("Exception :: getItemArray : " + CommonUtility.getPrintStackTrace(e));
		}
		return itemArrObj.toString();
	}

	public String addDefaultTag(String tagType) {
		String defaultTag = "";

		if (tagType.equals(AppConstants.TAG_TYPE_DATE)) {
			defaultTag = "<item>" + AppConstants.DEFAULT_DATE + "</item>";
		} else if (tagType.equals(AppConstants.TAG_TYPE_DATE2)) {
			defaultTag = "<item>" + AppConstants.DEFAULT_DATE + "</item>";
		} else if (tagType.equals(AppConstants.TAG_TYPE_DATE3)) {
			defaultTag = "<item>" + AppConstants.DEFAULT_DATE + "</item>";
		} else if (tagType.equals(AppConstants.TAG_TYPE_INT)) {
			defaultTag = "<item>-999</item>";
		} else if (tagType.equals(AppConstants.TAG_TYPE_DECIMAL)) {
			defaultTag = "<item>-999</item>";
		} else {
			defaultTag = "<item>Z</item>";
		}

		return defaultTag;
	}

	public String getBureauStatus(String status) {
		String returnStatus = "";
		try {
			switch (1) {
			case 1:
				if (status.equals("-1")) {
					returnStatus = "SUCCESS";
					break;
				}
			case 2:
				if (status.equals("-2")) {
					returnStatus = "ERROR";
					break;
				}
			case 3:
				if (status.equals("-3")) {
					returnStatus = "BUREAU-ERROR";
					break;
				}
			case 4:
				if (status.equals("-4")) {
					returnStatus = "NO-MATCH";
					break;
				}
			case 5:
				if (status.equals("END-OF-TXN")) {
					returnStatus = "SUCCESS";
					break;
				}
			default:
				returnStatus = status;
				break;
			}

		} catch (Exception e) {
			logger.info("Exception :: "+CommonUtility.getPrintStackTrace(e));
		}
		return returnStatus;
	}

	public String returnBureauStatus(String status) {
		String returnStatus = "";
		try {
			switch (1) {
			case 1:
				if (status.equals("-1")) {
					returnStatus = "000";
					break;
				}
			case 2:
				if (status.equals("-2")) {
					returnStatus = "000";
					break;
				}
			case 3:
				if (status.equals("-3")) {
					returnStatus = "000";
					break;
				}
			case 4:
				if (status.equals("-4")) {
					returnStatus = "000";
					break;
				}
			case 5:
				if (status.equals("END-OF-TXN")) {
					returnStatus = "000";
					break;
				}
			default:
				returnStatus = "001";
				break;
			}

		} catch (Exception e) {
			logger.info("Exception :: "+CommonUtility.getPrintStackTrace(e));
		}
		return returnStatus;
	}

	public static int getNameMatchScore(String a1, String a2) {

		double d = new JaroWinklerDistance().apply(a1, a2);

		String percentage = String.valueOf(d);

		int score = Integer.valueOf(percentage.substring(percentage.indexOf(".") + 1));
		logger.info("getNameMatchScore:: " + a1 + " " + a2 + " :: " + score);
		return score;
	}

	@SuppressWarnings("unchecked")
	public static void main(String[] args) {
		HashMap<String, String> cpObj = new HashMap<String, String>();
		try {
			String cpJsonResp = "{\"FintechDemographicDetailsResponse\":{\"CIF_RespCode\":\"0\",\"CP_RespDesc\":\"\",\"FintechDemographicDetails\":[{\"CPResponse\":{\"RateOfInterest\":\"10\",\"Tenure\":\"48\",\"OfferAmount\":\"100000.00\",\"Productname\":\"AUT_AL_PQ_PQA_REFERRAL_APR2\",\"CardType\":\"AUT_AL_PQ_PQA_REFERRAL_APR2\",\"eKYCFlag\":\"\"},\"CIFResponse\":{\"CustomerGender\":\"M\",\"CustomerState\":\"Maharashtra\",\"CustomerOfficeAddress3\":\"\",\"CustomerOfficeAddress2\":\"\",\"CustomerLastname\":\"Monde\",\"SAS_ID\":\"0\",\"CustomerOfficeAddress1\":\"\",\"CustomerOfficePhone\":\"0 22  0\",\"ResidenceType\":\"\",\"CustomerCountry\":\"IN\",\"CustomerRessidencePhone\":\"22\",\"CustomerOfficeZipCode\":\"\",\"CustomerAddress3\":\"\",\"CustomerAddress2\":\"\",\"CustomerAddress1\":\"133   260 Transport Nagar\",\"MonthlyIncome\":\"0\",\"CustomerPanNo\":\"AKNPM4992L\",\"CustomerFirstname\":\"Santosh\",\"DateOfBirth\":\"1980-05-20 00:00:00\",\"CustomerCity\":\"Chakur\",\"AccountNo\":\"15551026279524\",\"ZipCode\":\"413513\",\"EmailAddress\":\"arun98501@gmail.com\",\"Profession\":\"\",\"CustomerMobileNo\":\"919820531698\",\"CustFullName\":\"Santosh Shankar Monde\",\"CustomerOfficeCity\":\"\"}}],\"soaStandard\":{\"service_user\":\"\",\"service_password\":\"\",\"consumer_name\":\"\",\"unique_id\":\"\",\"time_stamp\":\"\"},\"CIF_RespDesc\":\"SUCCESS\",\"CP_RespCode\":false,\"soaFillers\":{\"filler9\":\"\",\"filler8\":\"\",\"filler5\":\"PQA_REFERRAL\",\"filler4\":\"\",\"filler7\":\"\",\"filler6\":\"11102\",\"filler1\":\"\",\"filler10\":\"\",\"filler3\":\"1.50%\",\"filler2\":\"\"}}}";
			JSONParser parser = new JSONParser();
			JSONObject cpRespObj = (JSONObject) parser.parse(cpJsonResp);

			JSONObject fintechDemographicDtlsRespObj = (JSONObject) cpRespObj.get("FintechDemographicDetailsResponse");
			String filler5 = "";
			if (fintechDemographicDtlsRespObj.containsKey("soaFillers")) {
				JSONObject soaFillersObj = (JSONObject) fintechDemographicDtlsRespObj.get("soaFillers");
				filler5 = soaFillersObj.get("filler5") == null ? "" : soaFillersObj.get("filler5").toString();
			}

			Object fintechDemographicDtlsOptObj = fintechDemographicDtlsRespObj.get("FintechDemographicDetails");
			JSONArray fintechDemographicDtlsObjArr = new JSONArray();
			if (fintechDemographicDtlsOptObj instanceof JSONObject) {
				JSONObject partObj = (JSONObject) fintechDemographicDtlsRespObj.get("FintechDemographicDetails");
				fintechDemographicDtlsObjArr.add(partObj);
			} else {
				fintechDemographicDtlsObjArr = (JSONArray) fintechDemographicDtlsRespObj
						.get("FintechDemographicDetails");
			}

			if (fintechDemographicDtlsObjArr.size() > 0) {
				String rateOfInterest = getItemArray(fintechDemographicDtlsObjArr, "CPResponse", "RateOfInterest",
						AppConstants.TAG_TYPE_STRING);
				cpObj.put("rateOfInterest", rateOfInterest);

				String tenure = getItemArray(fintechDemographicDtlsObjArr, "CPResponse", "Tenure",
						AppConstants.TAG_TYPE_STRING);
				cpObj.put("tenureArr", tenure);

				String offerAmount = getItemArray(fintechDemographicDtlsObjArr, "CPResponse", "OfferAmount",
						AppConstants.TAG_TYPE_STRING);
				cpObj.put("offerAmountArr", offerAmount);

				if (StringUtils.isBlank(filler5)) {
					String productname = getItemArray(fintechDemographicDtlsObjArr, "CPResponse", "Productname",
							AppConstants.TAG_TYPE_STRING);
					cpObj.put("productnameArr", productname);
				} else {
					cpObj.put("productnameArr", "<item>" + filler5 + "</item>");
				}

				String cardType = getItemArray(fintechDemographicDtlsObjArr, "CPResponse", "CardType",
						AppConstants.TAG_TYPE_STRING);
				cpObj.put("cardType", cardType);

				String eKYCFlag = getItemArray(fintechDemographicDtlsObjArr, "CPResponse", "eKYCFlag",
						AppConstants.TAG_TYPE_STRING);
				cpObj.put("eKYCFlag", eKYCFlag);
			} else {
				cpObj = AppConstants.CP_EMPTY_DATA();
			}
			System.out.println("cpObj ::" + cpObj + " filler5 :: " + filler5);
		} catch (Exception e) {
			logger.info("Exception :: "+CommonUtility.getPrintStackTrace(e));
		}
	}



}
