package com.hdfcbank.blelengine.bitly;

public class TestBitly {
	public static void main(String argp[]){
		System.out.println("Start "+new java.util.Date());
		String access_token = "";
				Bitly bitly = Bit.ly(access_token);
			String shortUrl = bitly.shorten("https://www.techepoch.com/carsdev");
			System.out.println("shortUrl "+shortUrl);
			System.out.println("End "+new java.util.Date());
	}
}