package com.hdfcbank.blelengine.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import redis.clients.jedis.JedisCluster;

import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;


@Component
public class RedisUtils {

	private static Logger logger = LoggerFactory.getLogger(RedisUtils.class);

	@Autowired
	private RedisPubTest redisPub;

	@Value("${cache.redis.cluster.host}")
	private String redisHostAddress;

	@Value("${cache.redis.cluster.port}")
	private String redisPort;

//	@Value("${cache.redis.cluster.expiry}")
//	private String expiry;

	JedisCluster cluster = null;

	public void set(String key, String value) {

		try {
			//Need to check with Ram sir and Sunitha
//			int time = Integer.parseInt(expiry);
			if (cluster == null) {

				cluster = redisPub.openConnection(redisHostAddress, Integer.valueOf(redisPort));
				logger.info("redis cluster object 337:: " + cluster);
			}
			cluster.set(key, value);
//			cluster.expire(key, time);

		} catch (Exception exe) {
			//exe.printStackTrace();
			logger.info("Exception :: " + CommonUtility.getPrintStackTrace(exe));
		}
	}

	public String get(String key) {
		String value = "";
		try {
			if (cluster == null) {
				cluster = redisPub.openConnection(redisHostAddress, Integer.valueOf(redisPort));
				logger.info("redis cluster object 337:" + cluster);
			}

			value = cluster.get(key) == null ? "" : cluster.get(key);
			// logger.info("cluster get :: " + cluster.get(key));
		} catch (Exception exe) {
			//exe.printStackTrace();
			logger.info("Exception :: " + CommonUtility.getPrintStackTrace(exe));
		}
		return value;
	}

	public void sadd(String key, String value) {

		try {
			if (cluster == null) {
				cluster = redisPub.openConnection(redisHostAddress, Integer.valueOf(redisPort));
				logger.info("redis cluster object 337:" + cluster);
			}

			cluster.sadd(key, value);
			// logger.info("cluster smembers :: " + cluster.smembers(key));
		} catch (Exception exe) {
			//exe.printStackTrace();
			logger.info("Exception :: " + CommonUtility.getPrintStackTrace(exe));
		}
	}

	public void sadd(String key, Set<String> value) {

		try {
			String[] valueArr = Arrays.copyOf(value.toArray(), value.size(), String[].class);
			if (cluster == null) {
				cluster = redisPub.openConnection(redisHostAddress, Integer.valueOf(redisPort));
				logger.info("redis cluster object 337:" + cluster);
			}

			cluster.sadd(key, valueArr);
			// logger.info("cluster smembers :: " + cluster.smembers(key));
		} catch (Exception e) {
			//e.printStackTrace();
			logger.info("Exception :: " + CommonUtility.getPrintStackTrace(e));
		}
	}

	public Set<String> smembers(String key) {
		Set<String> smembers = new HashSet<String>();
		try {
			if (cluster == null) {
				cluster = redisPub.openConnection(redisHostAddress, Integer.valueOf(redisPort));
				logger.info("redis cluster object 337:" + cluster);
			}

			smembers = cluster.smembers(key);
			// logger.info("cluster smembers :: " + cluster.smembers(key));
		} catch (Exception exe) {
			//exe.printStackTrace();
			logger.info("Exception :: " + CommonUtility.getPrintStackTrace(exe));
		}
		return smembers;

	}

	public long scard(String key) {
		long membersCount = 0;
		try {
			if (cluster == null) {
				cluster = redisPub.openConnection(redisHostAddress, Integer.valueOf(redisPort));
				logger.info("redis cluster object 337:" + cluster);
			}

			membersCount = cluster.scard(key);
			// logger.info("cluster smembers :: " + cluster.smembers(key));
		} catch (Exception exe) {
			//exe.printStackTrace();
			logger.info("Exception :: " + CommonUtility.getPrintStackTrace(exe));
		}
		return membersCount;

	}

	public long del(String key) {
		long delCount = 0;
		try {
			if (cluster == null) {
				cluster = redisPub.openConnection(redisHostAddress, Integer.valueOf(redisPort));
			}

			cluster.del(key);
		} catch (Exception exe) {
			//exe.printStackTrace();
			logger.info("Exception :: " + CommonUtility.getPrintStackTrace(exe));
		}
		return delCount;
	}

	public long incr(String key) {
		long value = 0;
		try {
			if (cluster == null) {
				cluster = redisPub.openConnection(redisHostAddress, Integer.valueOf(redisPort));
			}

			value = cluster.incr(key);
		} catch (Exception exe) {
			//exe.printStackTrace();
			logger.info("Exception :: " + CommonUtility.getPrintStackTrace(exe));
		}
		return value;
	}

	public void expire(String key, int time) {

		try {
			if (cluster == null) {
				cluster = redisPub.openConnection(redisHostAddress, Integer.valueOf(redisPort));
			}

			cluster.expire(key, time);
		} catch (Exception exe) {
			//exe.printStackTrace();
			logger.info("Exception :: " + CommonUtility.getPrintStackTrace(exe));
		}
	}

	public boolean exists(String key) {
		boolean isExists = false;
		try {
			if (cluster == null) {
				cluster = redisPub.openConnection(redisHostAddress, Integer.valueOf(redisPort));
			}

			isExists = cluster.exists(key);
		} catch (Exception exe) {
			//exe.printStackTrace();
			logger.info("Exception :: " + CommonUtility.getPrintStackTrace(exe));
		}
		return isExists;
	}
	
	public String getValue(String key) {
		String value = "";
		try {
			JedisCluster cluster = null;
			if (cluster == null) {
				cluster = redisPub.openConnection(redisHostAddress, Integer.valueOf(redisPort));
				logger.info("redis cluster object 337:" + cluster);
			}

			value = cluster.get(key) == null ? "" : cluster.get(key);
			// logger.info("cluster get :: " + cluster.get(key));
		} catch (Exception e) {
			//e.printStackTrace();
			logger.info("Exception :: " + CommonUtility.getPrintStackTrace(e));
		}
		return value;
	}

	public void hmset(String hmkey, HashMap inputMap) {

		try {

			if (cluster == null) {
				cluster = redisPub.openConnection(redisHostAddress, Integer.valueOf(redisPort));
				logger.info("redis cluster object 337:: " + cluster);
			}
			cluster.hmset(hmkey,inputMap);

		} catch (Exception exe) {
			//exe.printStackTrace();
			logger.info("Exception :: " + CommonUtility.getPrintStackTrace(exe));
		}
	}

	public String hgetall(String hmkey) {
		String value = "";
		try {
			JedisCluster cluster = null;
			if (cluster == null) {
				cluster = redisPub.openConnection(redisHostAddress, Integer.valueOf(redisPort));
				logger.info("redis cluster object 337:" + cluster);
			}

			value = String.valueOf((HashMap) cluster.hgetAll(hmkey));
			// logger.info("cluster get :: " + cluster.get(key));
		} catch (Exception e) {
			//e.printStackTrace();
			logger.info("Exception :: " + CommonUtility.getPrintStackTrace(e));
		}
		return value;
	}

}
