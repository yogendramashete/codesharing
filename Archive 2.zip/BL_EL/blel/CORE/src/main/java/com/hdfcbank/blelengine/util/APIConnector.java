package com.hdfcbank.blelengine.util;

import com.hdfcbank.blelengine.constants.AppConstants;
import org.apache.http.HttpEntity;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.net.ssl.SSLParameters;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.SecureRandom;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.logging.Level;

import static javax.swing.JOptionPane.ERROR_MESSAGE;


@Component
public class APIConnector {

	private String xkarzakey = "nhzeDHuqsm0QENHD";

	@Autowired
	private NTBLoanUtil ntbLoanUtil;

	@Autowired
	private AESUtils	aesUtils;


	@Value("${vcipapikey}")
	private String vcipapikey;

	@Value("${vcipaccountid}")
	private String vcipaccountid;

	public final static Logger logger = LoggerFactory.getLogger(APIConnector.class);

	@SuppressWarnings("unchecked")
	public String restPostMethodAPI(String baseUrl, String reqStr, String operationType, String optional,
									String tranRefNo,String mobileNumber) {
		logger.info("restPostMethodAPI :: ");
		HttpURLConnection conn = null;
		StringBuilder response = new StringBuilder();
		BufferedReader in = null;
		OutputStream out = null;
		// String soapAction = "";
		// logger.info("baseUrl :: " + baseUrl);
		// logger.info("request :: " + reqStr);
		String jsonResponse = "", apiStatus = "Failure";
		String creationTime = "";
		String updationTime = "";
		try {
			creationTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").format(Calendar.getInstance().getTime());

			try {
				trustAllHttpsCertificates();
			} catch (Exception e) {
				//e.printStackTrace();
				logger.info("Exception ::"+e);
			}

			URL obj = new URL(baseUrl);
			conn = (HttpURLConnection) obj.openConnection();
			ByteArrayOutputStream bout = new ByteArrayOutputStream();
			byte[] buffer = new byte[reqStr.length()];
			buffer = reqStr.getBytes();
			bout.write(buffer);
			byte[] b = bout.toByteArray();

			conn.setRequestProperty("Content-Type", "application/json");
			conn.setRequestMethod("POST");
			conn.setConnectTimeout(60000);
			conn.setReadTimeout(90000);
			conn.setDoOutput(true);
			conn.setDoInput(true);


			out = conn.getOutputStream();
			out.write(b);
			out.flush();
			out.close();
			int responseCode = conn.getResponseCode();
			String jsonString = conn.getResponseMessage();
			// logger.info("response code from server :" + responseCode);
			// logger.info("response message code from server :" + jsonString);
			updationTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").format(Calendar.getInstance().getTime());
			if (responseCode == 200) {
				apiStatus = "Success";
				in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
				String inputLine;

				while ((inputLine = in.readLine()) != null) {
					response.append(inputLine);
				}
				in.close();
				// logger.info("response :: " + response);
				jsonResponse = response.toString();
			} else {
				apiStatus = "Failure";
				BufferedReader reader = null;
				reader = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
				// logger.info("error stream :" + reader.read());
				JSONObject failRespObj = new JSONObject();
				failRespObj.put("responseCode", responseCode);
				failRespObj.put("responseMessage", jsonString);
				failRespObj.put("errorStream", reader);
				jsonResponse = failRespObj.toString();
			}

		} catch (Exception e) {
			//e.printStackTrace();
			updationTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").format(Calendar.getInstance().getTime());
			apiStatus = "Server Error";
			logger.info("exception :: " + e);
		} finally {
			//ntbLoanDao.insertPanValidationDetails(aesUtils.encrypt(optional), aesUtils.encrypt(reqStr), aesUtils.encrypt(jsonResponse), creationTime, updationTime,
			//		operationType, apiStatus, tranRefNo);// optional is a mobile number
			if (null != conn)
				conn.disconnect();
			conn = null;
			in = null;
		}
		logger.info("Rest service Server end  Time...:" + new java.util.Date());

		return jsonResponse;
	}






	private static void trustAllHttpsCertificates() throws Exception {
		logger.info("trustAllHttpsCertificates :: ");

		// Create a trust manager that does not validate certificate chains:

		javax.net.ssl.TrustManager[] trustAllCerts = new javax.net.ssl.TrustManager[1];

		javax.net.ssl.TrustManager tm = new TempTrustedManager();

		trustAllCerts[0] = tm;

		javax.net.ssl.SSLContext sc = javax.net.ssl.SSLContext.getInstance(AppConstants.SSL);
		sc.init(null, trustAllCerts, new SecureRandom());
		SSLParameters parameters = sc.getDefaultSSLParameters();

		String rr[] = parameters.getProtocols();

		for (int i = 0; i < rr.length; i++) {
			// logger.info("Supported ssl params :" + rr[i]);
		}

		javax.net.ssl.HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

	}

	public static class TempTrustedManager implements javax.net.ssl.TrustManager, javax.net.ssl.X509TrustManager {
		public java.security.cert.X509Certificate[] getAcceptedIssuers() {
			return null;
		}

		public boolean isServerTrusted(java.security.cert.X509Certificate[] certs) {
			return true;
		}

		public boolean isClientTrusted(java.security.cert.X509Certificate[] certs) {
			return true;
		}

		public void checkServerTrusted(java.security.cert.X509Certificate[] certs, String authType)
				throws java.security.cert.CertificateException {
			logger.info(String.valueOf(Level.SEVERE), ERROR_MESSAGE);
			return;
		}

		public void checkClientTrusted(java.security.cert.X509Certificate[] certs, String authType)
				throws java.security.cert.CertificateException {
			return;
		}
	}

	

	
	@SuppressWarnings("unchecked")
	public String postMethodVCIPAPI(String baseUrl, String reqStr) {
		logger.info("postMethodVCIPAPI :: ");
		HttpURLConnection conn = null;
		StringBuilder response = new StringBuilder();
		BufferedReader in = null;
		OutputStream out = null;
		logger.info("baseUrl :: " + baseUrl);
		//logger.info("request :: " + reqStr);
		String jsonResponse = "";
		try {

			try {
				trustAllHttpsCertificates();
			} catch (Exception e) {
				//e.printStackTrace();
				logger.info("restPostMethodAPI exception :: " + e);
			}

			URL obj = new URL(baseUrl);
			conn = (HttpURLConnection) obj.openConnection();
			ByteArrayOutputStream bout = new ByteArrayOutputStream();
			byte[] buffer = new byte[reqStr.length()];
			buffer = reqStr.getBytes();
			bout.write(buffer);
			byte[] b = bout.toByteArray();

			// conn.setRequestProperty("Content-Length", String.valueOf(b.length));

			conn.setRequestProperty("Content-Type", "application/json");
			// conn.setRequestProperty("accept-language", "en-US,en;q=0.8");
			// conn.setRequestProperty("accept", "*/*");
			conn.setRequestProperty("api-key", vcipapikey);
			conn.setRequestProperty("account-id", vcipaccountid);

			conn.setRequestMethod("POST");
			conn.setConnectTimeout(60000);
			conn.setReadTimeout(90000);
			conn.setDoOutput(true);
			conn.setDoInput(true);

			out = conn.getOutputStream();
			out.write(b);
			out.flush();
			out.close();
			int responseCode = conn.getResponseCode();
			String respMsg = conn.getResponseMessage();
			logger.info("response code from server :" + responseCode);
			logger.info("response message code from server :" + respMsg);
			if (responseCode == 200) {
				in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
				String inputLine;

				while ((inputLine = in.readLine()) != null) {
					response.append(inputLine);
				}
				in.close();
				jsonResponse = response.toString();
			} else {
				BufferedReader reader = null;
				reader = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
				logger.info("error stream :" + reader.read());
				JSONObject failRespObj = new JSONObject();
				failRespObj.put("responseCode", responseCode);
				failRespObj.put("responseMessage", respMsg);
				failRespObj.put("errorStream", reader);
				jsonResponse = failRespObj.toString();
			}

			logger.info("jsonResponse :: " + jsonResponse);
		} catch (Exception e) {
			//e.printStackTrace();
			logger.info("exception :: " + CommonUtility.getPrintStackTrace(e));
		} finally {
			if (null != conn)
				conn.disconnect();
			conn = null;
			in = null;
		}
		logger.info("Rest service Server end  Time...:" + new java.util.Date());

		return jsonResponse;

	}
	
	@SuppressWarnings("unchecked")
	public String smsPostMethodAPI(String baseUrl, String auth, String reqStr) {
		logger.info("otpPostMethodAPI :: ");
		HttpURLConnection conn = null;
		StringBuilder response = new StringBuilder();
		BufferedReader in = null;
		OutputStream out = null;
		// String soapAction = "";
		logger.info("baseUrl :: " + baseUrl);
		logger.info("request :: " + reqStr);
		String jsonResponse = "";
		try {

			try {
				trustAllHttpsCertificates();
			} catch (Exception e) {
				//e.printStackTrace();
				logger.info("restPostMethodAPI exception :: " + e);
			}

			URL obj = new URL(baseUrl);
			conn = (HttpURLConnection) obj.openConnection();
			ByteArrayOutputStream bout = new ByteArrayOutputStream();
			byte[] buffer = new byte[reqStr.length()];
			buffer = reqStr.getBytes();
			bout.write(buffer);
			byte[] b = bout.toByteArray();

			conn.setRequestProperty("Authorization", AppConstants.basic + reqStr);

			conn.setRequestProperty("Content-Type", "application/json");
			conn.setRequestMethod("POST");
			conn.setConnectTimeout(40000);
			conn.setReadTimeout(30000);
			conn.setDoOutput(true);
			conn.setDoInput(true);

			out = conn.getOutputStream();
			out.write(b);
			out.flush();
			out.close();
			int responseCode = conn.getResponseCode();
			String jsonString = conn.getResponseMessage();
			logger.info("response code from server :" + responseCode);
			logger.info("response message code from server :" + jsonString);
			if (responseCode == 200) {
				in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
				String inputLine;

				while ((inputLine = in.readLine()) != null) {
					response.append(inputLine);
				}
				in.close();
				logger.info("response :: " + response);
				jsonResponse = response.toString();
			} else {
				BufferedReader reader = null;
				reader = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
				logger.info("error stream :" + reader.read());
				JSONObject failRespObj = new JSONObject();
				failRespObj.put("responseCode", responseCode);
				failRespObj.put("responseMessage", jsonString);
				failRespObj.put("errorStream", reader);
				jsonResponse = failRespObj.toString();
			}

			logger.info("jsonResponse :: " + jsonResponse);
		} catch (Exception e) {
			//e.printStackTrace();
			logger.info("exception :: " + e);
		} finally {
			if (null != conn)
				conn.disconnect();
			conn = null;
			in = null;
		}
		logger.info("Rest service Server end  Time...:" + new java.util.Date());

		return jsonResponse;

	}
	public String sendGET(String url, String apikey, String accountId) {
		StringBuffer response = new StringBuffer();
		try {
			URL obj = new URL(url);
			HttpURLConnection con = (HttpURLConnection) obj.openConnection();
			con.setRequestMethod("GET");
			con.setRequestProperty("api-key", apikey);
			con.setRequestProperty("account-id", accountId);
			int responseCode = con.getResponseCode();
			logger.info("GET Response Code :: " + responseCode);
			if (responseCode == HttpURLConnection.HTTP_OK) { // success
				BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
				String inputLine;

				while ((inputLine = in.readLine()) != null) {
					response.append(inputLine);
				}
				in.close();

				// print result
				logger.info(response.toString());
			} else {
				logger.info("GET request not worked");
			}

		} catch (Exception e) {
			e.printStackTrace();
			logger.info("Exception :: sendGET :: " + CommonUtility.getPrintStackTrace(e));
		}
		return response.toString();
	}


	public String postMethodAPIRequest(String httpUrl, String request) {

		String response = "";
		CloseableHttpClient httpClient = null;
		CloseableHttpResponse httpResponse = null;
		HttpPost httpPost;

		try {
			logger.info("Inside postMethodAPIRequest ... " + httpUrl + " :: request ::" + request);
			httpPost = new HttpPost(httpUrl);
			httpPost.setHeader("Content-Type", "application/json");

			RequestConfig requestConfig = RequestConfig.custom().setConnectTimeout(20000)
					.setConnectionRequestTimeout(20000).setSocketTimeout(60000).build();
			httpClient = HttpClientBuilder.create().setDefaultRequestConfig(requestConfig).build();
			StringEntity requestEntity = new StringEntity(request);
			httpPost.setEntity(requestEntity);
			httpResponse = httpClient.execute(httpPost);

			logger.info("POST postMethodAPIRequest, StatusCode :: " + httpResponse.getStatusLine().getStatusCode());

			int statusCode = httpResponse.getStatusLine().getStatusCode();

			if (statusCode == 200) {
				final HttpEntity entity = httpResponse.getEntity();
				if (entity != null) {
					final InputStream instream = entity.getContent();
					response = convertStreamToString(instream);
					instream.close();
				}

			}
			logger.info("POST checkPaymentStatus Request, Response :" + response);

		} catch (UnsupportedOperationException e) {
			logger.info("Exception {}", e.toString());

		} catch (Exception e) {
			logger.info("Exception {}", e.toString());
		} finally {
			if (null != httpResponse) {
				try {
					httpResponse.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					// e.printStackTrace();
					logger.info("Exception {}", e.toString());
				}
			}
			if (httpClient != null) {
				try {
					httpClient.close();
				} catch (IOException e) {
					logger.info("Exception {}", e.toString());
				}
			}
		}
		return response;

	}

	private static String convertStreamToString(final InputStream is) {

		final BufferedReader reader = new BufferedReader(new InputStreamReader(is));
		final StringBuilder sb = new StringBuilder();

		String line;
		try {
			while ((line = reader.readLine()) != null) {
				sb.append(line);
			}
		} catch (IOException e) {
			logger.info("Exception {}", e.toString());
		} finally {
			try {
				is.close();
				reader.close();
			} catch (IOException e) {
				logger.info("Exception {}", e.toString());
			}
		}
		return String.valueOf(sb);
	}


	public JSONObject restKarzaPostMethodAPI(String baseUrl, String reqStr) {
		logger.info("restPostMethodAPI :: ");
		HttpURLConnection conn = null;
		StringBuilder response = new StringBuilder();
		BufferedReader in;
		OutputStream out;
		String jsonResponse = "", apiStatus = "Failure";
		JSONObject jsonObject;
		try {

			try {
				trustAllHttpsCertificates();
			} catch (Exception e) {
				e.printStackTrace();
			}


			URL obj = new URL(baseUrl);
			conn = (HttpURLConnection) obj.openConnection();
			ByteArrayOutputStream bout = new ByteArrayOutputStream();
			byte[] buffer = new byte[reqStr.length()];
			buffer = reqStr.getBytes();
			bout.write(buffer);
			byte[] b = bout.toByteArray();

			conn.setRequestProperty("Content-Type", "application/json");
			conn.setRequestProperty("x-karza-key", xkarzakey);
			conn.setRequestMethod("POST");
			conn.setConnectTimeout(60000);
			conn.setReadTimeout(90000);
			conn.setDoOutput(true);
			conn.setDoInput(true);

			out = conn.getOutputStream();
			out.write(b);
			out.flush();
			out.close();
			int responseCode = conn.getResponseCode();
			String jsonString = conn.getResponseMessage();
			// logger.info("response code from server :" + responseCode);
			// logger.info("response message code from server :" + jsonString);

			if (responseCode == 200) {
				apiStatus = "Success";
				in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
				String inputLine;

				while ((inputLine = in.readLine()) != null) {
					response.append(inputLine);
				}
				in.close();
				// logger.info("response :: " + response);
				jsonResponse = response.toString();
			} else {
				apiStatus = "Failure";
				BufferedReader reader = null;
				reader = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
				// logger.info("error stream :" + reader.read());
				JSONObject failRespObj = new JSONObject();
				failRespObj.put("responseCode", responseCode);
				failRespObj.put("responseMessage", jsonString);
				failRespObj.put("errorStream", reader);
				jsonResponse = failRespObj.toString();
			}

			// logger.info("jsonResponse :: " + jsonResponse);
		} catch (Exception e) {
			e.printStackTrace();
			apiStatus = "Server Error";
			logger.info("exception :: " + e);
		} finally {

			if (null != conn)
				conn.disconnect();
			conn = null;
			in = null;
		}
		logger.info("Rest service Server end  Time...:" + new java.util.Date());

		jsonObject = JSonParser.parseString(jsonResponse);
		return jsonObject;
	}

}
