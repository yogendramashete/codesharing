package com.hdfcbank.blelengine.util;

import com.hdfcbank.blelengine.bean.common.RetailPerfiosPrivateKey;
import com.hdfcbank.blelengine.bean.common.SMEPerfiosPrivateKey_PROD;
import com.hdfcbank.blelengine.bean.common.SMEPerfiosPrivateKey_UAT;
import com.hdfcbank.blelengine.dao.Comondao;
import org.bouncycastle.openssl.PEMReader;
import org.bouncycastle.util.encoders.Hex;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.crypto.Cipher;
import java.io.IOException;
import java.io.StringReader;
import java.security.*;

@Component
public class PerfiosUtil {
	public final static Logger logger = LoggerFactory.getLogger(PerfiosUtil.class);

	@Autowired
	private Comondao commondao;

	@Autowired
	AESUtils aesUtils;
	public static int  responseCode1;


	public static String getSignature(String encryptAlgo, String digestAlgo, Key k, String xml) {
		String dig = makeDigest(xml, digestAlgo);
		return encrypt(dig, encryptAlgo, k);
	}



	public String getRetailSignature(String encryptAlgo, String digestAlgo, String xml) {
		Key k = buildPrivateKey(RetailPerfiosPrivateKey.PERFIOS_RETAIL_PRIVAYE_KEY);
		return getSignature(encryptAlgo, digestAlgo, k, xml);
	}

	public String getSMESignature(String encryptAlgo, String digestAlgo, String xml) {
		String landingZone = commondao.getAPIConfigParameters("Adobe", "common", "landingzone");
		Key k;
		if(landingZone.equalsIgnoreCase("UAT")) {

	 k = buildPrivateKey(SMEPerfiosPrivateKey_UAT.PERFIOS_SME_PRIVAYE_KEY);
} else if(landingZone.equalsIgnoreCase("PROD")) {

	 k = buildPrivateKey(SMEPerfiosPrivateKey_PROD.PERFIOS_SME_PRIVAYE_KEY);
}  else {

	 k = buildPrivateKey(SMEPerfiosPrivateKey_UAT.PERFIOS_SME_PRIVAYE_KEY);
}
		return getSignature(encryptAlgo, digestAlgo, k, xml);
	}

	public static String makeDigest(String payload, String digestAlgo) {
		String strDigest = "";
		try {
			MessageDigest md = MessageDigest.getInstance(digestAlgo);
			md.update(payload.getBytes("UTF-8"));
			byte[] digest = md.digest();
			byte[] encoded = Hex.encode(digest);
			strDigest = new String(encoded);
		} catch (Exception ex) {
			//ex.printStackTrace();
			logger.info("Exception ::"+ex);
		}
		return strDigest;
	}

	public static String encrypt(String raw, String encryptAlgo, Key k) {
		String strEncrypted = "";
		try {
			Cipher cipher = Cipher.getInstance(encryptAlgo);
			cipher.init(Cipher.ENCRYPT_MODE, k);
			byte[] encrypted = cipher.doFinal(raw.getBytes("UTF-8"));
			byte[] encoded = Hex.encode(encrypted);
			strEncrypted = new String(encoded);
		} catch (Exception ex) {
			//ex.printStackTrace();
			logger.info("Exception ::"+ex);
		}
		return strEncrypted;
	}



	private static PrivateKey buildPrivateKey(String privateKeySerialized) {
		StringReader reader = new StringReader(privateKeySerialized);
		PrivateKey pKey = null;
		try {
			Security.addProvider(new org.bouncycastle.jce.provider.BouncyCastleProvider());
			PEMReader pemReader = new PEMReader(reader);
			KeyPair keyPair = (KeyPair) pemReader.readObject();
			pKey = keyPair.getPrivate();
			pemReader.close();
		} catch (IOException i) {
			//i.printStackTrace();
			logger.info("IOException ::"+i);
		}
		return pKey;
	}

}
