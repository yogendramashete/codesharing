package com.hdfcbank.blengine.controller;

import com.hdfcbank.blengine.bean.saveAdditionalDetails.AdditionalDetailsRequest;
import com.hdfcbank.blengine.bean.saveAdditionalDetails.AdditionalDetailsResponse;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import com.hdfcbank.blengine.exception.BLEngineException;
import com.hdfcbank.blengine.model.AdditionalDetailsService;

import javax.validation.Valid;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@Validated
public class AdditionalDetailsController {
	public static final Logger logger = LoggerFactory.getLogger(AdditionalDetailsController.class);

	@Autowired
	private AdditionalDetailsService additionalDetailsService;

	@RequestMapping("/api/v2/SaveAdditionalDetails")
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	public ResponseEntity<AdditionalDetailsResponse> saveAddtionalDetails(
			@Valid @RequestBody AdditionalDetailsRequest request) {

		AdditionalDetailsResponse response = null;

		try {
			 response = additionalDetailsService.saveAdditionalDetails(request);
			return new ResponseEntity<>(response, HttpStatus.OK);
		} catch (BLEngineException exe) {
			logger.error("exception occured :: {}", ExceptionUtils.getStackTrace(exe));
			return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
		}

	}

}
