package com.hdfcbank.blengine.model;

import com.hdfcbank.blengine.bean.generateEmailOTP.GenerateEmailOTPRequest;
import com.hdfcbank.blengine.bean.generateEmailOTP.GenerateEmailOTPResponse;
import com.hdfcbank.blengine.bean.validateEmailOTP.ValidateEmailOTPRequest;
import com.hdfcbank.blengine.bean.validateEmailOTP.ValidateEmailOTPResponse;
import com.hdfcbank.blengine.exception.BLEngineException;

public interface EmailOTPService {
	
	GenerateEmailOTPResponse generateEmailOTP(GenerateEmailOTPRequest request)  throws BLEngineException;
	//ValidateEmailOTPResponse validateEmailOTP(ValidateEmailOTPRequest request)  throws BLEngineException;


}
