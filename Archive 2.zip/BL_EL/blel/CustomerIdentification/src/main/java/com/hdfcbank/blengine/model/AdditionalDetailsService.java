package com.hdfcbank.blengine.model;


import com.hdfcbank.blengine.bean.saveAdditionalDetails.AdditionalDetailsRequest;
import com.hdfcbank.blengine.bean.saveAdditionalDetails.AdditionalDetailsResponse;
import com.hdfcbank.blengine.exception.BLEngineException;

public interface AdditionalDetailsService {

	   AdditionalDetailsResponse saveAdditionalDetails(AdditionalDetailsRequest request)  throws BLEngineException;
}
