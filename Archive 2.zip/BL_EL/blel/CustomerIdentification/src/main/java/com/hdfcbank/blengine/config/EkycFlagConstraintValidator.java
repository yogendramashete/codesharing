package com.hdfcbank.blengine.config;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class EkycFlagConstraintValidator implements ConstraintValidator<EkycFlagConstraint, String> {
    @Override
    public void initialize(EkycFlagConstraint constraintAnnotation) {
        ConstraintValidator.super.initialize(constraintAnnotation);
    }

    @Override
    public boolean isValid(String value, ConstraintValidatorContext context) {
        return (value.equalsIgnoreCase("no") || value.equalsIgnoreCase("yes"));
    }
}
