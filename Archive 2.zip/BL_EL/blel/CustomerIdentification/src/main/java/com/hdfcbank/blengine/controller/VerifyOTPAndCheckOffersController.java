package com.hdfcbank.blengine.controller;

import com.hdfcbank.blengine.exception.BLEngineException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.hdfcbank.blengine.bean.verifyOTPandDemogDetails.GetDemogDetailsRequest;
import com.hdfcbank.blengine.bean.verifyOTPandDemogDetails.GetDemogDetailsResponse;
import org.apache.commons.lang3.exception.ExceptionUtils;

import com.hdfcbank.blengine.model.VerifyOTPandCheckOffersService;

import javax.validation.Valid;
@Validated
@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController

public class VerifyOTPAndCheckOffersController {

	public final static Logger logger = LoggerFactory.getLogger(VerifyOTPAndCheckOffersController.class);

	@Autowired
	private VerifyOTPandCheckOffersService verifyOTPandCheckOffersService;

	@PostMapping("/api/v2/VerifyOTPAndGetDemogDetails")
	public ResponseEntity<GetDemogDetailsResponse> getDemogDetails(@Valid @RequestBody GetDemogDetailsRequest request) {

		GetDemogDetailsResponse response = null;
		try {
			response = verifyOTPandCheckOffersService.getDemogDetails(request);
			return new ResponseEntity<>(response, HttpStatus.OK);
		} catch (BLEngineException exe) {

			logger.error("exception occured :: {}", ExceptionUtils.getStackTrace(exe));
			return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);

		}
	}
}