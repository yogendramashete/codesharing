package com.hdfcbank.blengine.constants;

public class AppConstants {


    public final static String channel = "Adobe";
    public final static String Asterisk = "*";
    public final static String verticalBar = "|";

    public final static String createDateTimeFormat2 = "dd-MM-yyyy HH:mm:ss";
    public final static String createDateTimeFormat = "yyyy-MM-dd	 HH:mm:ss.SSS";
    public final static String creationDateFormat = "ddMMyy";
    public final static String offerAvailableConstant = "offerAvailable";
    public final static String existingCustomerConstant = "existingCustomer";
    public final static String requestRedisKeyConstant = "LoanAppRequestInfo";
    public final static String responseRedisKeyConstant = "LoanAppResponseInfo";

    public final static String initiateCustomererrorCode = "ERROR_CODE";
    public final static String initiateCustomererrorMsg = "Error_msg";
    public final static String initiateCustomerstepId = "1.0";
    public final static String initiateCustomerstepLevel = "1";
    public final static String verifyOTPStepId = "2.0";
    public final static String verifyOTPStepLevel = "1";
    public final static String panEnquiryStepId = "3.0";
    public final static String panEnquiryStepLevel = "1";
    public final static String panEnquiryOperationModel1 = "1";
    public final static String panEnquiryOperationModel2 = "2";
    public final static String panEnquiryOperationModel3 = "3";
    public final static String panEnquiryOperationModel4 = "4";
    public final static String panEnquiryOperationModel5 = "5";
    public final static String panEnquiryOperationModel6 = "6";
    public final static String panEnquiryOperationModel7 = "7";
    public final static String equifaxoperationType = "EquiFaxAPI";
    public final static String genemailbakend="generateEmailOTP-Backend";
    public final static String valmailbakend="ValidateEmail-Backend";
	
	public final static String KEY = "datakey";
    public final static String VALUE = "datavalue";

    public final static String genemail="generateEmailOTP";

    public final static Double email = 1.0;
    public final static Double email1 = 2.0;
    public final static int email2 = 0;
    public final static int email3 = 1;
    public final static String validateemail = "ValidateEmailOTP";
    public final static String validateemailstatus = "validateEmailOTP";




    public final static String existingCustomer = "Existing_Customer";
    public final static String initiateLabel = "InitiateCustomerIdentification";


	public final static String cifResponseCodeFieldName = "CIF_RespCode";


    public final static String insertFintech = "InitiateCustomerIdentification-FintechOffer";
    public final static String insertVerifyDemog = "VerifyOTPAndGetDemogDetails-FintechDemographic";
    public final static String IS_ENC = "Y";

    public final static String offerAvailableFieldName = "OFFER_AVAILABLE";


    public final static String tenantID = "HDFC";
    public final static String saveAddDetailsAPI = "SaveAdditionalDetails";
    public final static String getBureauOfferAPI = "GetBureauOffer";
    public final static String panEnquiryAPI = "PANEnquiry";
    public final static String panValidationAPI = "PANEnquiry-PAN";
    public final static String pannamematchAPI = "PANEnquiry-NAMEMATCH";
    public final static String equifaxAPI = "PANEnquiry-Equifax";
    public final static String gstnAuthAPI = " PANEnquiry-GSTN-Authentication";
    public final static String gstnSearchFilingDataMonths = " PANEnquiry-GSTN-SEARCH-FILINGDATAMONTHS";
    public final static String gstnSearchFilingDataYearStatecode = " PANEnquiry-GSTN-DETAIL-FILINGDATAYEAR_STATECODE";
    public final static String gstnSearchFilingDataMonthStatecode = " PANEnquiry-GSTN-DETAIL-FILINGDATAMONTH_STATECODE";
    public final static String gstnSearchFilingDataMonth = " PANEnquiry-GSTN-DETAIL-FILINGDATAMONTH";
    public final static String gstnSearchFilingDataYear = " PANEnquiry-GSTN-DETAIL-FILINGDATAYEAR";
    public final static String gstnSearchPAN = " PANEnquiry-GSTN-SEARCH-PAN";
    public final static String gstnSearchGstn = " PANEnquiry-GSTN-DETAIL-GSTN";
    public final static String verifyOTPAPI = "VerifyOTPAndGetDemogDetails";




	public final static String documentUploadAPI = "DocumentUpload";



    public final static String dbRecordUnavilable = "Record does not exist in LoanAppInfo table";
    public final static String backEndAPIDetailsNotFound = "Customer data is not available";

	public final static String dbErrorOccured = "Error Occurred while updating the details in DB";
	public final static String trueConstant = "true";
	public final static String falseConstant = "false";
	public final static String stepIdSaveAdditionalDetails = "3.0";
	public final static String stepIdSGetBureauOffer = "2.0";
	public final static String stepIdDocumentUpload = "1.1f";
	public final static String requestType = "IN";
	public final static String stepLevelSaveAdditionalDetails = "1";
	public final static String stepLevelGetBureauOffer = "1";
	public final static String stepLevelDocumentUpload = "1";

	public final static String dataKey = "DOCUMENT_SAVE_PATH";
	public final static String documentName = "WaerBill";

    public final static String panNumberConstant = "PAN_NO";
    public final static String dobConstant = "DOB";
    public final static String mobileNoConstant = "MOBILE_NO";
    public final static String txnRefNoConstant = "txnRefNo";

    public final static String NAME_MATCH_REQUEST_BANK_CODE = "08";
    public final static String NAME_MATCH_REQUEST_CHANNEL = "APIGW";
    public final static String NAME_MATCH_REQUEST_TRANSACTION_BRANCH = "089999";
    public final static String NAME_MATCH_REQUEST_USER_ID = "DevUser01";
    public final static String NAME_MATCH_REQUEST_TRANSACTING_PARTY_CODE = "50000045";

    public final static String fullNameGetBureauOffer = "fullNamegetBureauOffer";
    public final static String addressGetBureauOffer = "addressgetBureauOffer";

    public final static String custIdConstant = "CUST_ID";
    public final static String sasIdConstant = "SAS_ID";
    public final static String offerAmountConstant = "VERIFYOTP_OFFER_AMT";

    public final static String behavScore2Constant = "VERIFYOTP_BEHAVSCORE2";

    public final static String saveAdditionalResiOfficeAddrMatch="saveAdditional_Office_Resi_NameAddrMatch";
    public final static String saveAdditionalPanEquifaxOfficeAddrMatch="saveAdditional_Office_PanEquifax_NameAddrMatch";
    public final static String saveAdditionalElectricityOfficeAddrMatch="saveAdditional_Office_Electricity_NameAddrMatch";
    public final static String saveAdditionalEkycOfficeAddrMatch="saveAdditional_Office_EKYC_NameAddrMatch";
    public final static String dbfailure = "FAILURE";
    public final static String dbSuccess = "SUCCESS";
    public final static int incrementalNum = 10000000;

    public final static String behavScore4Constant = "VERIFYOTP_BEHAVSCORE4";
    public final static String internalDebitScoreConstant = "VERIFYOTP_INTERNAL_DEBSCORE";
    public final static String internalDebitScoreBandConstant = "VERIFYOTP_INTERNAL_DEBSCOREBAND";
    public final static String verifyOtpZipcodeConstant = "VERIFYOTP_ZIPCODE";
}
