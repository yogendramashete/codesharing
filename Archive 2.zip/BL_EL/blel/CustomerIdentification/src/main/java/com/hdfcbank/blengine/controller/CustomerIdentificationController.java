package com.hdfcbank.blengine.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.hdfcbank.blelengine.bean.common.CommonRequest;
import com.hdfcbank.blelengine.bean.common.CommonResponse;
import com.hdfcbank.blelengine.util.JedisUtil;
import com.hdfcbank.blelengine.util.RedisUtils;
import com.hdfcbank.blengine.exception.BLEngineException;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hdfcbank.blengine.bean.initiateCustomerIdentification.InitiateCustomerIdentificationRequest;
import com.hdfcbank.blengine.bean.initiateCustomerIdentification.InitiateCustomerIdentificationResponse;
import com.hdfcbank.blengine.model.InitiateCustomerIdentificationService;

import javax.validation.Valid;
import java.util.Set;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@Validated
public class CustomerIdentificationController {
	public static final  Logger logger = LoggerFactory.getLogger(CustomerIdentificationController.class);

	@Autowired
	private InitiateCustomerIdentificationService initiateCustomerIdentificationService;

	@Autowired
	private JedisUtil jedisUtil;
	
	@Autowired
	private RedisUtils redisUtils;


	
	@RequestMapping("/api/v2/InitiateCustomerIdentification")
	public ResponseEntity<InitiateCustomerIdentificationResponse> initiateCustomerIdentification(@Valid
			@RequestBody InitiateCustomerIdentificationRequest request) {
		InitiateCustomerIdentificationResponse response = null;

		try {
			response = initiateCustomerIdentificationService.intitiateCustomerIdentification(request);
			return new ResponseEntity<>(response, HttpStatus.OK);
		} catch (BLEngineException exe) {
			logger.error("exception occured :: {}", ExceptionUtils.getStackTrace(exe));
			return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
			return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
		}


	}

	@RequestMapping("/deleteAllMobRedisKey")
	public ResponseEntity<Object> deleteAllMobRedisKey(@RequestBody CommonRequest request) {
		CommonResponse response = new CommonResponse();
		response.setRandomNo(request.getRandomNo());
		try {
			String inputString = request.getInputString();
			JSONParser parser = new JSONParser();
			JSONObject jsonObject = (JSONObject) parser.parse(inputString);
			logger.info("deleteAllMobRedisKey jsonObject :: " + jsonObject);
			String keyPattern = jsonObject.get("keyPattern") == null ? "" : jsonObject.get("keyPattern").toString();
			logger.info("redis cluster delete deleteRedisKey :" + keyPattern);
			Set<String> keysList = jedisUtil.getKeys(keyPattern);

			logger.info("mobileNo :: " + keyPattern + " keysList :: " + keysList.size());
			long keyDelCount = 0;
			for (String key : keysList) {
				long count = redisUtils.del(key);
				keyDelCount = keyDelCount + count;
			}
			logger.info("mobileNo :: " + keyPattern + " keyDelCount :: " + keyDelCount);
			response.setOutputString("keyDelCount :: " + keyDelCount);
			response.setStatusCode("0");
			response.setMessage("Success");
		} catch (Exception exe) {
			//exe.printStackTrace();
			logger.error("deleteRedisKey Exception :: " + exe.getMessage());
			exe.printStackTrace();
			response.setStatusCode("1");
			response.setMessage("Failure");

		}
		return new ResponseEntity<Object>(response, HttpStatus.OK);
	}

}
