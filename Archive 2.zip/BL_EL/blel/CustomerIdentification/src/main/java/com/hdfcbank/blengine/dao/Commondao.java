package com.hdfcbank.blengine.dao;

import com.hdfcbank.blelengine.util.CommonUtility;
import com.hdfcbank.blengine.bean.saveAdditionalDetails.AdditionalDetailsRequestString;
import com.hdfcbank.blengine.exception.BLEngineException;
import lombok.extern.log4j.Log4j2;
import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Log4j2
@Repository
public class Commondao {

	public static final Logger logger = LoggerFactory.getLogger(Commondao.class);

	@Autowired
	JdbcTemplate jdbcTemplate;


	@Value("${sql.query.getappconfigparameters}")
	private String getappconfigparameters;

	@Value("${sql.query.insertloanappjourneydetails}")
	private String insertloanAppJourneyDetails;

	@Value("${sql.query.insertloanappjourneydata}")
	private String insertloanAppJourneyData;

	@Value("${sql.query.insertloanAppOfferDetails}")
	private String insertloanAppOfferDetails;

	@Value("${sql.query.insertloanappinfo}")
	private String insertloanappinfo;

	@Value("${sql.query.updateloanappjourneydetails}")
	private String updateloanappjourneydetails;

	@Value("${sql.query.getloanappinfo}")
	private String getloanappinfo;

	@Value("${sql.query.updateloanappinfo}")
	private String updateloanappinfo;

	@Value("${sql.query.updatepanloanappinfoPL}")
	private String updatepanloanappinfoPL;

	@Value("${sql.query.updateloanappjourneydata}")
	private String updateloanappjourneydata;

	@Value("${sql.query.updateloanappjourneydataforvalidateemail}")
	private String updateloanappjourneydataforvalidateemail;

	@Value("${sql.query.updatepanloanappjourneydata}")
	private String updatepanloanappjourneydata;

	@Value("${sql.query.updatepanloanappinfo}")
	private String updatepanloanappinfo;

	@Value("${sql.query.updateSaveAddionalDetailsLoanAppInfo}")
	private String updateSaveAddionalDetailsLoanAppInfo;

	@Value("${sql.query.updateGstLoanAppJourneyData}")
	private String updateGstLoanAppJourneyData;


	@Value("${sql.query.updateResiAddrMatchLoanAppJourneyData}")
	private String updateResiAddrMatchLoanAppJourneyData;

	@Value("${sql.query.insertloanappjourneydetailswithuniqueserialnumber}")
	private String insertloanappjourneydetailswithuniqueserialnumber;

	@Value("${sql.query.updateloanappjourneydetailswithuniqueserialnumber}")
	private String updateloanappjourneydetailswithuniqueserialnumber;

	@Value("${sql.query.validatefromcategorymaster}")
	private String validatefromcategorymaster;

	public int updateLoanAppJourneyDetails(String stepName, double stepID, long bankJourneyId, String response,
										   String result, String errorCode, String errorMessage) {
		int count = 0;

		try {
			count = jdbcTemplate.update(updateloanappjourneydetails,
					new Object[]{response, result, errorCode, errorMessage, bankJourneyId, stepID, stepName});
			logger.info("stepName updateLoanAppJourneyDetails  result count::{}", count);
		} catch (Exception e) {
			logger.info("updateLoanAppJourneyDetails Exception ::{} ", CommonUtility.getPrintStackTrace(e));
		}
		return count;
	}

	public int updateLoanAppJourneyDetailsWithUniqueSerialNumber(String stepName, double stepID, long bankJourneyId, String response,
										   String result, String errorCode, String errorMessage, String uniqueSerialNumber) {
		int count = 0;

		try {
			count = jdbcTemplate.update(updateloanappjourneydetailswithuniqueserialnumber,
					new Object[]{response, result, errorCode, errorMessage, bankJourneyId, stepID, stepName, uniqueSerialNumber});
			logger.info("stepName updateLoanAppJourneyDetails  result count::{}", count);
		} catch (Exception e) {
			logger.info("updateLoanAppJourneyDetails Exception ::{} ", CommonUtility.getPrintStackTrace(e));
		}
		return count;
	}

	public int insertLoanAppJourneyDetails(String stepName, String requestType, double stepID, Integer stepLevel,
										   long bankJourneyId, String API, String request, String redirectionToPartnerURL) {

		String result = "";
		String response = "";

		int count = 0;
		try {

			count = jdbcTemplate.update(insertloanAppJourneyDetails, new Object[]{bankJourneyId, stepID, stepName,
					stepLevel, requestType, API, request, response, result, redirectionToPartnerURL});
			logger.info("insertLoanAppJourneyDetails count  :: {}", count);

		} catch (BLEngineException e) {
			//TODO - Do what you want

			throw new BLEngineException(e.getMessage());

		}
		return count;
	}

	public int insertLoanAppJourneyDetailsWithUniqueSerialNumber(String stepName, String requestType, double stepID, Integer stepLevel,
										   long bankJourneyId, String API, String request, String redirectionToPartnerURL, String uniqueSerialNumber) {

		String result = "";
		String response = "";
		log.info(" inside insertLoanAppJourneyDetailsWithUniqueSerialNumber");
		int count = 0;
		try {

			count = jdbcTemplate.update(insertloanappjourneydetailswithuniqueserialnumber, new Object[]{bankJourneyId, stepID, stepName,
					stepLevel, requestType, API, request, response, result, redirectionToPartnerURL, uniqueSerialNumber});
			logger.info("insertLoanAppJourneyDetails count  :: {}", count);

		} catch (BLEngineException e) {
			//TODO - Do what you want

			throw new BLEngineException(e.getMessage());

		}
		return count;
	}

	public int insertLoanAppJourneyData(long bankJourneyId, String OFFER_AVAILABLE, String Existing_Customer) {
		logger.info("insertLoanAppJourneyData  :: ");

		int count = 0;
		try {
			count = jdbcTemplate.update(insertloanAppJourneyData,
					new Object[]{bankJourneyId, OFFER_AVAILABLE, Existing_Customer});
			logger.info("insertLoanAppJourneyData count  :: " + count);

		} catch (BLEngineException e) {
			//TODO - Do what you want

			throw new BLEngineException(e.getMessage());

		}
		return count;
	}

	public int updateLoanAppJourneyData(String kycFlag, String  netLoan, String grossLoan,String OfferType, long OfferAmount, long bankJourneyId, double Offer_Tenure, String profession) {
		int count = 0;

		try {
			count = jdbcTemplate.update(updateloanappjourneydata, new Object[]{kycFlag,netLoan, grossLoan, OfferType, String.valueOf(OfferAmount),
					String.valueOf(Offer_Tenure), profession, bankJourneyId});
			logger.info("count::" + count);
		} catch (Exception e) {
			throw new BLEngineException(e.getMessage());
		}

		return count;
	}

	public int updateLoanAppJourneyDataForValEmail(String valEmailFlag, long bankJourneyId) {
		int count = 0;

		try {
			count = jdbcTemplate.update(updateloanappjourneydataforvalidateemail, new Object[]{valEmailFlag, bankJourneyId});
			logger.info("count::" + count);
		} catch (Exception e) {
			throw new BLEngineException(e.getMessage());
		}

		return count;
	}

	public int updatePANLoanAppJourneyData(String panScore, String panfname, String panmname, String panlname,String panStatus, String panTitle, String filler1, String filler2,
										   String filler3, String filler4, String filler5, long bankJourneyId) {
		int count = 0;
		logger.info("filler05 {}");
		try {
			logger.info("filler05 {}");
			count = jdbcTemplate.update(updatepanloanappjourneydata,
					new Object[]{panScore,panfname, panmname, panlname, panStatus, panStatus, filler1, filler2, filler3, filler4, filler5, bankJourneyId});
			logger.info("count::" + count);
		} catch (BLEngineException e) {
			logger.info("updateTXNtHistory Exception :: " + CommonUtility.getPrintStackTrace(e));
		}

		return count;
	}

	public int insertLoanAppInfo(String partnerJourneyId, long bankJourneyId, String tenantId, String channelId,
								 String productCode, String mobileNo, String PANNO) {
		logger.info("insertLoanAppJourneyData  :: ");

		String status = "InitiateCustomerIdentification";

		int count = 0;
		try {
			count = jdbcTemplate.update(insertloanappinfo, new Object[]{channelId, productCode, tenantId,
					bankJourneyId, partnerJourneyId, status, mobileNo, PANNO});
			logger.info("insertLoanAppJourneyData count  :: " + count);

		} catch (BLEngineException exe) {
			throw new BLEngineException(exe.getMessage());
		}
		return count;
	}

	public String updateLoanAppInfo(String status, String channelId, String productCode, String tenantId,
									long bankJourneyId, String partnerJourneyId) {
		logger.info("getLoanAppInfo :: ");

		int recordUpdated = 0;

		String isUpdate = "false";

		try {

			logger.info("ChannelId {},  ProductCode{}, Tenant_ID{}, -BankJourneyId{}, -PartnerJourneyId {}", channelId,
					productCode, tenantId, bankJourneyId, partnerJourneyId);

			Boolean recordFound = jdbcTemplate.queryForObject(getloanappinfo, Boolean.class, channelId, productCode,
					tenantId, bankJourneyId, partnerJourneyId);
			logger.info("recordFound {} ", recordFound);

			if (Boolean.TRUE.equals(recordFound)) {

				recordUpdated = jdbcTemplate.update(updateloanappinfo, status, channelId, productCode, tenantId,
						bankJourneyId, partnerJourneyId);
				logger.info("recordUpdated {}", recordUpdated);

				isUpdate = "true";

			}
			logger.info("getLoanAppInfo isUpdate :: {} ", isUpdate);
		} catch (BLEngineException exe) {

			throw new BLEngineException(exe.getMessage());
		}
		return isUpdate;
	}

	public boolean recordFoundLoanAppInfo(String channelId, String productCode, String tenantId,
									long bankJourneyId, String partnerJourneyId) {
		logger.info("getLoanAppInfo :: ");

		String isUpdate = "false";

		Boolean recordFound;
		try {

			logger.info("ChannelId {},  ProductCode{}, Tenant_ID{}, -BankJourneyId{}, -PartnerJourneyId {}", channelId,
					productCode, tenantId, bankJourneyId, partnerJourneyId);

			recordFound = jdbcTemplate.queryForObject(getloanappinfo, Boolean.class, channelId, productCode,
					tenantId, bankJourneyId, partnerJourneyId);
			logger.info("recordFound {} ", recordFound);

		} catch (BLEngineException exe) {

			throw new BLEngineException(exe.getMessage());
		}
		return recordFound;
	}


	public String updateSaveAddionalDetailsLoanAppInfo(AdditionalDetailsRequestString saveAddtionalReq, String status,
													   String channelId, String productCode, String tenantID, long bankJourneyId, String partnerJourneyId) {
		logger.info("getLoanAppInfo :: ");

		Boolean recordFound = false;
		int updateCount = 0;
		String isUpdate = "";

		try {

			logger.info("Status {}", status);

			logger.info("ChannelId -ProductCode -Tenant_ID -BankJourneyId -PartnerJourneyId {}",
					channelId + productCode + tenantID + bankJourneyId + partnerJourneyId);

			recordFound = jdbcTemplate.queryForObject(getloanappinfo, Boolean.class, channelId, productCode, tenantID, bankJourneyId, partnerJourneyId);
			logger.info("recordCount :: " + recordFound);

			if (recordFound) {

				logger.info("getLoanAppInfo before update :: ");



				updateCount = jdbcTemplate.update(updateSaveAddionalDetailsLoanAppInfo, saveAddtionalReq.getOfficeOrBusinessAddrLine1(),
						saveAddtionalReq.getOfficeOrBusinessAddrLine2(), saveAddtionalReq.getOfficeOrBusinessAddrLine3(),
						saveAddtionalReq.getOfficeOrBusinesspincode(), saveAddtionalReq.getOfficeOrBusinessCity(),
						saveAddtionalReq.getOfficeOrBusinessState(), saveAddtionalReq.getOfficeOrBusinessPhoneNo(),
						saveAddtionalReq.getResiAddressType(), saveAddtionalReq.getAadhaarAddrLine1(), saveAddtionalReq.getAadhaarAddrLine2(),
						saveAddtionalReq.getAadhaarAddrLine3(), saveAddtionalReq.getAadhaarAddrPincode(),
						saveAddtionalReq.getAadhaarAddrCity(), saveAddtionalReq.getPermanentAddrLine1(),
						saveAddtionalReq.getPermanentAddrLine2(), saveAddtionalReq.getPermanentAddrLine3(),
						saveAddtionalReq.getPermanentAddrPincode(), saveAddtionalReq.getPermanentAddrCity(),
						saveAddtionalReq.getPermanentAddrState(), saveAddtionalReq.getRefFirstName(),
						saveAddtionalReq.getRefMiddleName(), saveAddtionalReq.getRefLastName(), saveAddtionalReq.getRefMobileNo(),
						saveAddtionalReq.getBankName(), saveAddtionalReq.getBankAccountNo(), saveAddtionalReq.getIfscCode(),
						saveAddtionalReq.getMicrCode(), saveAddtionalReq.getBranchName(), saveAddtionalReq.getAccountType(),
						saveAddtionalReq.getAadhaarAddrState(), saveAddtionalReq.getEmploymentType(), saveAddtionalReq.getNameOfBiz(),
						saveAddtionalReq.getNatureOfBusiness(), saveAddtionalReq.getOccupation(),
						saveAddtionalReq.getPurposeOfLoan(), saveAddtionalReq.getNameOfEmployer(), saveAddtionalReq.getMaritalStatus(),
						saveAddtionalReq.getReligion(), saveAddtionalReq.getCaste(), saveAddtionalReq.getPersonalEmail(),
						saveAddtionalReq.getPreferredContactLocation(), saveAddtionalReq.getOfficePhoneNumber(),
						saveAddtionalReq.getWorkEmail(), saveAddtionalReq.getTurnOver(), saveAddtionalReq.getProfitAfterTax(), saveAddtionalReq.getDepreciation(),saveAddtionalReq.getMonthlySalary(), saveAddtionalReq.getObligation(), status,
						saveAddtionalReq.getEkycConsentFlag(),saveAddtionalReq.getEkycConsentDate(),saveAddtionalReq.getEkycLanguageConsent(),
						saveAddtionalReq.getEkycLanguageConsentDate(),saveAddtionalReq.getVkycConsentFlag(),saveAddtionalReq.getVkycConsentDate(),
						saveAddtionalReq.getVkycLanguageConsent(),saveAddtionalReq.getVkycLanguageConsentDate(),channelId, productCode, tenantID, bankJourneyId, partnerJourneyId
					);//Add new Column
				logger.info("updateCount" + updateCount);

				if (updateCount == 1) {
					isUpdate = "true";

				}

			}
			logger.info("getLoanAppInfo isUpdate :: " + isUpdate);

		} catch (BLEngineException exe) {

			logger.info("Exception :: " + CommonUtility.getPrintStackTrace(exe));
		}
		return isUpdate;
	}

	public String updatePANEnquiryLoanAppInfo(String Status, String ChannelId, String ProductCode, String Tenant_ID,
											  long BankJourneyId, String PartnerJourneyId, String customerfirstname, String customerlastname, String panNumber) {
		logger.info("getLoanAppInfo ::{} ");

		List<String> loanAppInfoList = null;
		String loanAppInfo = "";
		int updateCount = 0;
		String isUpdate = "";

		try {


			loanAppInfoList = jdbcTemplate.queryForList(getloanappinfo,
					new Object[]{ChannelId, ProductCode, Tenant_ID, BankJourneyId, PartnerJourneyId}, String.class);

			logger.info("loanAppInfoList.size() :: " + loanAppInfoList.size());
			String updateloaninfo;
			if (!loanAppInfoList.isEmpty() && loanAppInfoList.size() == 1) {
				loanAppInfo = loanAppInfoList.get(0);

				logger.info("getLoanAppInfo before update :: ");
				if (ProductCode.equalsIgnoreCase("PL")) {
					//if(!panNumber.equals("")) {
					updateCount = jdbcTemplate.update(updatepanloanappinfoPL, new Object[]{Status, customerfirstname,
							customerlastname, panNumber, ChannelId, ProductCode, Tenant_ID, BankJourneyId, PartnerJourneyId});
				}
//					} else {
				updateCount = jdbcTemplate.update(updatepanloanappinfo, new Object[]{Status, customerfirstname,
						customerlastname, ChannelId, ProductCode, Tenant_ID, BankJourneyId, PartnerJourneyId});
//					}
			}

			logger.info("updateOtp row" + updateCount);
			if (updateCount > 0) {
				logger.info("getLoanAppInfo isUpdate :: " + isUpdate);
				isUpdate = "true";

			}

	else if (!loanAppInfoList.isEmpty() && loanAppInfoList.size() >= 1) {

				isUpdate = "Duplicate records Found";

			} else {
				isUpdate = "false";
			}
			logger.info("getLoanAppInfo isUpdate :: " + isUpdate);
		} catch (BLEngineException exe) {
			throw new BLEngineException(exe.getMessage());
		}
		return isUpdate;
	}

	public String getAPIConfigParameters(String channelid, String dataname, String datakey) {
		logger.info("get  API Constant Parameters :: ");
		List<String> apiConstantslist = null;
		String isactive = "Y";
		String apiConfig = "";

		try {

			apiConstantslist = jdbcTemplate.queryForList(getappconfigparameters,
					new Object[]{channelid, dataname, datakey, isactive}, String.class);
			if (!apiConstantslist.isEmpty()) {
				apiConfig = apiConstantslist.get(0);
			}
			logger.info("apiConfig  datakey::" + datakey + apiConfig);

		} catch (Exception exe) {
			//exe.printStackTrace();
			log.info("Exception :: " + exe);
		}
		return apiConfig;
	}


	public int insertLoanAppOfferDetails(long bankJourneyId, HashMap inputOfferDetails)
	{
		logger.info("insertLoanAppOfferDetails  :: ");

		int count = 0;
		try {
			count = jdbcTemplate.update(insertloanAppOfferDetails,
					new Object[]{bankJourneyId, inputOfferDetails.get("offerStage"),inputOfferDetails.get("stpNonSTP"),inputOfferDetails.get("offerTenure"),inputOfferDetails.get("offerAmount"),inputOfferDetails.get("emi"),inputOfferDetails.get("rateOfInterest"),inputOfferDetails.get("procFeesPer"),inputOfferDetails.get("failedReason"), inputOfferDetails.get("hardReject") });
			logger.info("insertLoanAppJourneyData count  :: " + count);

		} catch (BLEngineException e) {
			//TODO - Do what you want

			throw new BLEngineException(e.getMessage());

		}
		return count;
	}

	public JSONObject getNTBCustomerDetailsFromLoanAppJourneyData(long bankJourneyId) {
		logger.info("getNTBCustomerDetailsFromLoanAppJourneyData :: ");
		List<Map<String, Object>> list = null;
		JSONObject obj = new JSONObject();
		String offerAvailable = "";
		String existingCustomer = "";
		String query = "SELECT offer_available, existing_customer FROM loanappjourneydata where bankjourneyid='"+bankJourneyId+"'";

		try {

			list = jdbcTemplate.queryForList(query);
			for (Map<String, Object> map : list) {
				offerAvailable = 	map.get("offer_available") == null ? "" : map.get("offer_available").toString();
				existingCustomer = 	map.get("existing_customer") == null ? "" : map.get("existing_customer").toString();
			}
			obj.put("offerAvailable",offerAvailable);
			obj.put("existingCustomer",existingCustomer);

			logger.info("getNTBCustomerDetailsFromLoanAppJourneyData response:: " + obj.toString() );

		} catch (Exception exe) {
			//exe.printStackTrace();
			logger.info("Exception :: " + exe);
		}
		return obj;
	}

	public int updateGSTNameMatchloanAppJourneyData( long bankJourneyId, String nameMatchScore)

	{		int count = 0;

		try {
			count = jdbcTemplate.update(updateGstLoanAppJourneyData, new Object[]{nameMatchScore, bankJourneyId});
			logger.info("count::" + count);
		} catch (Exception e) {
			throw new BLEngineException(e.getMessage());
		}

		return count;
	}

	public Map<String, Object> getJourneyRecordLoanAppInfo(String channelid, String bankJourneyId, String partnerJourneyId) {

		List<Map<String, Object>> loanAppinfoList = null;
		Map<String, Object>  loanAppInfo = null;

		String query = "select customerfirstname, customermiddlename, customerlastname, mobileno, panno, permanentaddressline1,permanentaddressline2, permanentaddressline3, permanentaddresscity, permanentaddressstate, permanentaddresspincode, bankname, bankaccountno, employmenttype, nameofbiz, occupation, nameofemployer, maritalstatus, religion,personalemailaddress, natureofbusiness, purposeofloan, preferredcontactlocation, officephonenumber, workemail, workemailverification, customer_consent, officeorbusinessaddrline1, officeorbusinessaddrline2, officeorbusinessaddrline3, officeorbusinesspincode, officeorbusinesscity, officeorbusinessstate, officeorbusinessphoneno, resiaddresstype, addressline1, addressline2, addressline3, city, state, pincode  from loanappinfo where  channelid =? and bankjourneyid= ?and partnerjourneyid= ?";

		try {
			loanAppinfoList = jdbcTemplate.queryForList(query, new Object[] { channelid, Long.parseLong(bankJourneyId), partnerJourneyId });
			logger.info("leaddata size::" + loanAppinfoList.size());
			logger.info("leaddata ::" + loanAppinfoList);
			if(loanAppinfoList.size() !=0) {
				loanAppInfo = loanAppinfoList.get(0);
			}

		} catch (Exception exe) {
			logger.info("Exception :: " + exe);
		}

		return loanAppInfo;
	}

	public void updateResiAddrMatchWithOfficeAddrloanAppJourneyData(long bankJourneyId, String officeAddressMatchPercentage, String officeAddrMatchWthPanEquifaxAddrPecentage,
																	String officeAddrMatchWthElectricityAddrPecentage, String officeAddrMatchWthEkycAddrPecentage) {
int count=0;
		try {
			logger.info("inside update ResiAddrMatch With OfficeAddr loanAppJourneyData:: {}",bankJourneyId);
			logger.info("office AddressMatch with ResiAddress Percentage:: {}",officeAddressMatchPercentage);
			logger.info("office AddressMatch with PAN Equifax Percentage:: {}",officeAddrMatchWthPanEquifaxAddrPecentage);
			logger.info("office AddressMatch with Electricity Address Percentage:: {}",officeAddrMatchWthElectricityAddrPecentage);
			logger.info("office AddressMatch with EKYC Address Percentage:: {}",officeAddrMatchWthEkycAddrPecentage);

			count=jdbcTemplate.update(updateResiAddrMatchLoanAppJourneyData, new Object[]{ officeAddressMatchPercentage, officeAddrMatchWthPanEquifaxAddrPecentage,
					officeAddrMatchWthElectricityAddrPecentage, officeAddrMatchWthEkycAddrPecentage, bankJourneyId});

			logger.info("count::" + count);
		} catch (Exception e) {
			logger.error("Exception :: " + e.getMessage());
			throw new BLEngineException(e.getMessage());
		}

	}

	public boolean validateCategoryFromCategoryMaster(String caste) {
		logger.info("validateCategoryFromCategoryMaster :: ");
		logger.info("Category:: "+caste);

		Boolean recordFound;
		try {

			recordFound = jdbcTemplate.queryForObject(validatefromcategorymaster, Boolean.class, caste);
			logger.info("recordFound {} ", recordFound);

		} catch (BLEngineException exe) {

			throw new BLEngineException(exe.getMessage());
		}
		return recordFound;
	}
}