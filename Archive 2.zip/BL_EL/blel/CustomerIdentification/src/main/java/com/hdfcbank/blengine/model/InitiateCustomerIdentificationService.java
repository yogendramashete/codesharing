package com.hdfcbank.blengine.model;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.hdfcbank.blengine.bean.initiateCustomerIdentification.InitiateCustomerIdentificationRequest;
import com.hdfcbank.blengine.bean.initiateCustomerIdentification.InitiateCustomerIdentificationResponse;
import com.hdfcbank.blengine.exception.BLEngineException;


public interface InitiateCustomerIdentificationService {

	InitiateCustomerIdentificationResponse intitiateCustomerIdentification(InitiateCustomerIdentificationRequest request) throws BLEngineException, JsonProcessingException;

	}

	
