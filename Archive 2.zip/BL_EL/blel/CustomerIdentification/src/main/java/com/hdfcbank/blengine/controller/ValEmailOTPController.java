package com.hdfcbank.blengine.controller;

import com.hdfcbank.blengine.bean.validateEmailOTP.ValidateEmailOTPRequest;
import com.hdfcbank.blengine.bean.validateEmailOTP.ValidateEmailOTPResponse;
import com.hdfcbank.blengine.exception.BLEngineException;
import com.hdfcbank.blengine.model.ValEmailOTPService;
import com.itextpdf.text.log.Logger;
import com.itextpdf.text.log.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import javax.validation.Valid;

@Validated
@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
public class ValEmailOTPController {

    public final static Logger logger = LoggerFactory.getLogger(ValEmailOTPController.class);

    @Autowired
    private ValEmailOTPService valemailotp;

    @PostMapping("/api/v2/validateEmailOTP")
    public ResponseEntity<Object> validateEmailOTP(@Valid @RequestBody ValidateEmailOTPRequest request) {
        ValidateEmailOTPResponse response =null;
        logger.info("Validate email request1:"+request.toString());
        try {
            logger.info("Validate email request:"+request.toString());

            response = valemailotp.validateEmailOTP(request);
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (BLEngineException exe) {
            logger.error("validateEmailOTP Exception :: " + exe);
            return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
        }
    }


}
