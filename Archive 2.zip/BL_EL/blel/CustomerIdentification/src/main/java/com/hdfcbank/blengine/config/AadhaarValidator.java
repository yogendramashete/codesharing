package com.hdfcbank.blengine.config;


import lombok.extern.slf4j.Slf4j;
import org.apache.commons.beanutils.BeanUtils;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import java.lang.reflect.InvocationTargetException;

import static org.apache.commons.lang3.ObjectUtils.isEmpty;

@Slf4j
public class AadhaarValidator implements ConstraintValidator<AadhaarValidation, Object> {

    private String selected;
    private String[] required;
    private String message;
    private String values;

    @Override
    public void initialize(AadhaarValidation constraintAnnotation) {
        selected = constraintAnnotation.selected();
        required = constraintAnnotation.required();
        message = constraintAnnotation.message();
        values = constraintAnnotation.values();
        ConstraintValidator.super.initialize(constraintAnnotation);
    }

    @Override
    public boolean isValid(Object objectToValidate, ConstraintValidatorContext context) {
        Boolean valid = true;
        try {
            Object actualValue = BeanUtils.getProperty(objectToValidate, selected);
            if (values.equalsIgnoreCase((String) actualValue)) {
                for (String propName : required) {
                    Object requiredValue = BeanUtils.getProperty(objectToValidate, propName);
                    boolean isValid = requiredValue != null && !isEmpty(requiredValue);
                    if (!isValid) {
                        valid=isValid;
                       context.disableDefaultConstraintViolation();
                       String msg= propName + message;
                        context.buildConstraintViolationWithTemplate(msg).addPropertyNode(propName).addConstraintViolation();
                    }
                }
            }
        } catch (IllegalAccessException e) {
            log.error("Accessor method is not available for class : {}, exception : {}", objectToValidate.getClass().getName(), e);
            e.printStackTrace();
            return false;
        } catch (NoSuchMethodException e) {
            log.error("Field or method is not present on class : {}, exception : {}", objectToValidate.getClass().getName(), e);
            e.printStackTrace();
            return false;
        } catch (InvocationTargetException e) {
            log.error("An exception occurred while accessing class : {}, exception : {}", objectToValidate.getClass().getName(), e);
            e.printStackTrace();
            return false;
        }
        return valid;
    }
}
