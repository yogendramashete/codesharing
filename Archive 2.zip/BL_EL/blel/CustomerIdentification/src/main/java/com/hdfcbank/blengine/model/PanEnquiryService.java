package com.hdfcbank.blengine.model;

import com.hdfcbank.blengine.bean.panEnquiry.PanEnquiryRequest;
import com.hdfcbank.blengine.bean.panEnquiry.PanEnquiryResponse;
import com.hdfcbank.blengine.exception.BLEngineException;


public interface PanEnquiryService {
	
	public PanEnquiryResponse panEnquiry(PanEnquiryRequest request)  throws BLEngineException;
	

}
