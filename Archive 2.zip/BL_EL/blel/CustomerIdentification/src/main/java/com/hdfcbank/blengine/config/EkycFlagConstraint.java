package com.hdfcbank.blengine.config;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.*;

@Documented
@Constraint(validatedBy = EkycFlagConstraintValidator.class)
@Target( { ElementType.METHOD, ElementType.FIELD })
@Retention(RetentionPolicy.RUNTIME)
public @interface EkycFlagConstraint {

    String message() default "Invalid EKYC Type Please Pass Yes or No";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};
}
