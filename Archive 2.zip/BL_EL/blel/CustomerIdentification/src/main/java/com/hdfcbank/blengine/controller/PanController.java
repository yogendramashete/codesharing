package com.hdfcbank.blengine.controller;

import com.hdfcbank.blengine.bean.panEnquiry.PanEnquiryRequest;
import com.hdfcbank.blengine.bean.panEnquiry.PanEnquiryResponse;
import com.hdfcbank.blengine.exception.BLEngineException;
import com.hdfcbank.blengine.model.PanEnquiryService;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;


@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@Validated
public class PanController {
	public final static Logger logger = LoggerFactory.getLogger(PanController.class);

	@Autowired
	PanEnquiryService panEnquiryService;

	@RequestMapping("/api/v2/PANEnquiry")
	public ResponseEntity<Object> panEnquiry(@Valid @RequestBody PanEnquiryRequest request) {
		PanEnquiryResponse response = null;
		
		try {
			logger.info("PanEnquiryRequest Controller::: "+request.toString());
			response = panEnquiryService.panEnquiry(request);

			return new ResponseEntity<>(response, HttpStatus.OK);
		} catch (BLEngineException exe) {

			logger.error("exception occured :: {}", ExceptionUtils.getStackTrace(exe));
			return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
			

		}

	}
	
	
	
}

