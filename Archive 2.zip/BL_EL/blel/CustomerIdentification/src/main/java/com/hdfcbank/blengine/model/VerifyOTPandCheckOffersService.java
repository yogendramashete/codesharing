package com.hdfcbank.blengine.model;

import com.hdfcbank.blengine.bean.verifyOTPandDemogDetails.GetDemogDetailsRequest;
import com.hdfcbank.blengine.bean.verifyOTPandDemogDetails.GetDemogDetailsResponse;
import com.hdfcbank.blengine.exception.BLEngineException;

public interface VerifyOTPandCheckOffersService {
	
	GetDemogDetailsResponse getDemogDetails(GetDemogDetailsRequest request)  throws BLEngineException;

}
