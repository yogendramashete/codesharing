package com.hdfcbank.blengine.model;

import com.hdfcbank.blengine.bean.validateEmailOTP.ValidateEmailOTPRequest;
import com.hdfcbank.blengine.bean.validateEmailOTP.ValidateEmailOTPResponse;
import com.hdfcbank.blengine.exception.BLEngineException;

public interface ValEmailOTPService {
    ValidateEmailOTPResponse validateEmailOTP(ValidateEmailOTPRequest request)  throws BLEngineException;
}
