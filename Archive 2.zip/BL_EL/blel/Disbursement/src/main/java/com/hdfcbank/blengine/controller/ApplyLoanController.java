package com.hdfcbank.blengine.controller;

import com.hdfcbank.blengine.bean.applyLoan.ApplyLoanRequest;
import com.hdfcbank.blengine.bean.applyLoan.ApplyLoanResponse;
import com.hdfcbank.blengine.exception.BLEngineException;
import com.hdfcbank.blengine.model.ApplyLoanService;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@Validated
public class ApplyLoanController{

	public static final Logger logger = LoggerFactory.getLogger(ApplyLoanController.class);

	@Autowired
	private ApplyLoanService applyLoanService;

	@RequestMapping("/api/v2/ApplyLoan")
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	public ResponseEntity<ApplyLoanResponse> applyLoan(
			@Valid @RequestBody ApplyLoanRequest request) {

		ApplyLoanResponse response = null;

		try {
			 response = applyLoanService.applyLoan(request);
			return new ResponseEntity<>(response, HttpStatus.OK);
		} catch (BLEngineException exe) {
			logger.error("exception occured :: {}", ExceptionUtils.getStackTrace(exe));
			return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
		}

	}

	@RequestMapping(value = "/api/v2/vcipstatus", produces = MediaType.APPLICATION_XML_VALUE)
	public String vcipStatus(@RequestBody String request) {

		String response = "";

		try { response = applyLoanService.vcipStatus(request, response);

		} catch (BLEngineException exe) {
		logger.error("exception occured :: {}", ExceptionUtils.getStackTrace(exe));
		}

		return response; }


	@GetMapping(value = "/api/v2/{profileId}/fetchProfileDataVCIP")
	public ResponseEntity<String> fetchProfileDataVCIP(@PathVariable String profileId) {

		String response=null;

		try {
			response = applyLoanService.fetchProfileDataVCIP(profileId);

		} catch (BLEngineException exe) {
			logger.error("exception occured :: {}", ExceptionUtils.getStackTrace(exe));
		}

		return ResponseEntity.ok(response);
	}
}
