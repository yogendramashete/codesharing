package com.hdfcbank.blengine.config;

import lombok.NoArgsConstructor;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.context.EnvironmentAware;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.core.env.Environment;
import org.springframework.core.env.MapPropertySource;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.hdfcbank.blengine.constants.AppConstants.KEY;
import static com.hdfcbank.blengine.constants.AppConstants.VALUE;

@Configuration
@NoArgsConstructor
@Log4j2
public class PropertiesDatabaseInitializer implements BeanPostProcessor,InitializingBean, EnvironmentAware {

    //@Autowired
    private  JdbcTemplate jdbcTemplate;

    //@Autowired
    private  ConfigurableEnvironment environment;

    @Autowired
    public PropertiesDatabaseInitializer(JdbcTemplate jdbcTemplate, ConfigurableEnvironment environment){
        log.info("Inside PropertiesDatabaseInitializer constructor");
        this.jdbcTemplate = jdbcTemplate;
    }

    private static final String PROPERTY_SOURCE_NAME = "propertiesInsideDatabase";

    public final static String sql = "select  datakey , datavalue  from appconfigmap  where isactive='Y'";

    @Override
    public void afterPropertiesSet() {
        log.info("Inside PropertiesDatabaseInitializer afterPropertiesSet method {}",environment);

        if (environment != null) {
            Map<String, Object> configMap = new HashMap<>();

            List<Map<String, Object>> maps = jdbcTemplate.queryForList(sql);
            for (Map<String, Object> map : maps) {
                configMap.put(String.valueOf(map.get(KEY)), map.get(VALUE));
            }

            environment.getPropertySources().addFirst(new MapPropertySource(PROPERTY_SOURCE_NAME, configMap));
        }
    }

    @Override
    public void setEnvironment(Environment environment) {
        if (environment instanceof ConfigurableEnvironment) {
            this.environment = (ConfigurableEnvironment) environment;
        }
    }

}
