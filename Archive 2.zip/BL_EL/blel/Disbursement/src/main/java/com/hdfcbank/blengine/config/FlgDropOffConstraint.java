package com.hdfcbank.blengine.config;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.*;

@Documented
@Constraint(validatedBy = FlgDropOffConstraintValidator.class)
@Target( { ElementType.METHOD, ElementType.FIELD })
@Retention(RetentionPolicy.RUNTIME)
public @interface FlgDropOffConstraint {

    String message() default "Invalid FlgDrop Type Please Pass Y or N";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};
}
