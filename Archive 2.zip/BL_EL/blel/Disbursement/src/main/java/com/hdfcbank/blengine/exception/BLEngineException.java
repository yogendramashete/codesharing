package com.hdfcbank.blengine.exception;	


public class BLEngineException extends RuntimeException {
		public BLEngineException(String message) {
			
			super(message);
		}

		public BLEngineException(Throwable cause) {
			
			super(cause);
		}

		public BLEngineException(String message, Throwable throwable) {
			
			super(message, throwable);
		}
	}
