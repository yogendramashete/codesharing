package com.hdfcbank.blengine.config;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class FlgDropOffConstraintValidator implements ConstraintValidator<FlgDropOffConstraint, String> {
    @Override
    public void initialize(FlgDropOffConstraint constraintAnnotation) {
        ConstraintValidator.super.initialize(constraintAnnotation);
    }

    @Override
    public boolean isValid(String value, ConstraintValidatorContext context) {
        return (value.equalsIgnoreCase("N") || value.equalsIgnoreCase("n") || value.equalsIgnoreCase("y") || value.equalsIgnoreCase("Y"));
    }
}
