package com.hdfcbank.blengine.model;

import com.hdfcbank.blengine.exception.BLEngineException;
import com.hdfcbank.blengine.bean.applyLoan.ApplyLoanRequest;
import com.hdfcbank.blengine.bean.applyLoan.ApplyLoanResponse;

public interface ApplyLoanService {

	ApplyLoanResponse applyLoan(ApplyLoanRequest request)  throws BLEngineException;
	String vcipStatus(String request, String response) throws BLEngineException;

	/*
		Fetch the Status of VCIP
	 */
	String fetchProfileDataVCIP(String profileId) throws BLEngineException;
}
