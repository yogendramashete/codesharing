package com.hdfcbank.blengine.dao;

import com.hdfcbank.blelengine.util.CommonUtility;
import com.hdfcbank.blengine.bean.applyLoan.ApplyLoanRequestString;
import com.hdfcbank.blengine.bean.common.ContextParam;
import com.hdfcbank.blengine.exception.BLEngineException;
import lombok.extern.log4j.Log4j2;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
@Log4j2
public class Commondao {

    public static final Logger logger = LoggerFactory.getLogger(Commondao.class);

    @Autowired
    JdbcTemplate jdbcTemplate;

    @Value("${sql.query.updatevkycloanappjourneydata}")
    private String updatevkycloanappjourneydata;

    @Value("${sql.query.updateVkycFinalStatusLoanAppJourneyData}")
    private String updateVkycFinalStatusLoanAppJourneyData;

    @Value("${sql.query.updatevcipstatusloanappinfo}")
    private String updatevcipstatusloanappinfo;

    @Value("${sql.query.updateackidloanappinfo}")
    private String updateackidloanappinfo;


    @Value("${sql.query.getappconfigparameters}")
    private String getappconfigparameters;

    @Value("${sql.query.insertloanappjourneydetails}")
    private String insertloanAppJourneyDetails;


    @Value("${sql.query.updateloanappjourneydetails}")
    private String updateloanappjourneydetails;

    @Value("${sql.query.getloanappinfo}")
    private String getloanappinfo;

    @Value("${sql.query.updateloanappinfo}")
    private String updateloanappinfo;

    @Value("${sql.query.updateloanappinfosalespromotion}")
    private String updateloanappinfosalespromotion;

    @Value("${sql.query.getloanappofferdetails}")
    private String getloanappofferdetails;


    public int updateLoanAppJourneyDetails(String stepName, double stepID, long bankJourneyId, String response,
                                           String result, String errorCode, String errorMessage) {
        int count = 0;

        try {
            count = jdbcTemplate.update(updateloanappjourneydetails,
                    new Object[]{response, result, errorCode, errorMessage, bankJourneyId, stepID, stepName});
            log.info("stepName updateLoanAppJourneyDetails  result count::{}", count);
        } catch (BLEngineException e) {
            log.info("updateLoanAppJourneyDetails Exception ::{} ", CommonUtility.getPrintStackTrace(e));
        }
        return count;
    }

    public int insertLoanAppJourneyDetails(String stepName, String requestType, double stepID, int stepLevel,
                                           long bankJourneyId, String API, String request, String redirectionToPartnerURL) {

        String result = "";
        String response = "";

        int count = 0;
        try {

            count = jdbcTemplate.update(insertloanAppJourneyDetails, new Object[]{bankJourneyId, stepID, stepName,
                    stepLevel, requestType, API, request, response, result, redirectionToPartnerURL});
            log.info("insertLoanAppJourneyDetails count  :: {}", count);

        } catch (DuplicateKeyException e) {
            //TODO - Do what you want

            throw new BLEngineException("Duplicate Record Found with  BanKJourneyID " + bankJourneyId);

        }
        return count;
    }


    public String updateLoanAppInfo(String status, String channelId, String productCode, String tenantId,
                                    long bankJourneyId, String partnerJourneyId, ApplyLoanRequestString applyLoanRequestString) {
        log.info("getLoanAppInfo :: ");

        int recordUpdated = 0;

        String isUpdate = "false";

        try {

            log.info("ChannelId {},  ProductCode{}, Tenant_ID{}, -BankJourneyId{}, -PartnerJourneyId {}", channelId,
                    productCode, tenantId, bankJourneyId, partnerJourneyId);

            Boolean recordFound = jdbcTemplate.queryForObject(getloanappinfo, Boolean.class, channelId, productCode,
                    tenantId, bankJourneyId, partnerJourneyId);
            log.info("recordFound {} ", recordFound);

            if (recordFound) {

                log.info("LoanAmount from Request {}", applyLoanRequestString.getLoanAmount());
                log.info("getEmi from Request {}", applyLoanRequestString.getEmi());
                log.info("getEducationalQualification from Request {}", applyLoanRequestString.getEducationalQualification());
                log.info("getEmployerName from Request {}", applyLoanRequestString.getEmployerName());
                log.info("getProcessingfees from Request {}", applyLoanRequestString.getProcessingfees());
                log.info("getRateofInterest from Request {}", applyLoanRequestString.getRateofInterest());
                log.info("getTenure from Request {}", applyLoanRequestString.getTenure());
                log.info("getYearAtCurrentAddress from Request {}", applyLoanRequestString.getYearAtCurrentAddress());
                log.info("getSalesPromotion from Request {}", applyLoanRequestString.getSalesPromotion());
                log.info("updateloanappinfo {}", updateloanappinfo);
                recordUpdated = jdbcTemplate.update(updateloanappinfo, status, applyLoanRequestString.getEmi(),applyLoanRequestString.getLoanAmount(),
                        applyLoanRequestString.getEducationalQualification(), applyLoanRequestString.getEmployerName(), applyLoanRequestString.getProcessingfees(),
                        applyLoanRequestString.getProduct(), applyLoanRequestString.getRateofInterest(), applyLoanRequestString.getTenure(),
                        applyLoanRequestString.getYearAtCurrentAddress(), applyLoanRequestString.getSalesPromotion(), channelId, productCode, tenantId,
                        bankJourneyId, partnerJourneyId);
                log.info("recordUpdated {}", recordUpdated);

                isUpdate = "true";

            }
            log.info("getLoanAppInfo isUpdate :: {} ", isUpdate);
        } catch (BLEngineException exe) {

            throw new BLEngineException(exe.getMessage());
        }
        return isUpdate;
    }

    public String updateAckIdLoanAppInfo(String status, String ackId, String channelId, String productCode, String tenantId,
                                         long bankJourneyId, String partnerJourneyId) {
        log.info("getLoanAppInfo :: ");

        int recordUpdated = 0;

        String isUpdate = "false";

        try {

            log.info("ChannelId {},  ProductCode{}, Tenant_ID{}, -BankJourneyId{}, -PartnerJourneyId {}", channelId,
                    productCode, tenantId, bankJourneyId, partnerJourneyId);

            Boolean recordFound = jdbcTemplate.queryForObject(getloanappinfo, Boolean.class, channelId, productCode,
                    tenantId, bankJourneyId, partnerJourneyId);
            log.info("recordFound {} ", recordFound);

            if (recordFound) {

                recordUpdated = jdbcTemplate.update(updateackidloanappinfo, status, ackId, channelId, productCode, tenantId,
                        bankJourneyId, partnerJourneyId);
                log.info("recordUpdated {}", recordUpdated);

                isUpdate = "true";

            }
            log.info("getLoanAppInfo isUpdate :: {} ", isUpdate);
        } catch (BLEngineException exe) {

            throw new BLEngineException(exe.getMessage());
        }
        return isUpdate;
    }

    public String updateVCIPStatusLoanAppInfo(String status, String channelId, String productCode, String tenantId,
                                              long bankJourneyId, String partnerJourneyId, String vcippath) {
        log.info("getLoanAppInfo :: ");
        log.info("vcipstatus-31");
        int recordUpdated = 0;

        String isUpdate = "false";

        try {
            log.info("vcipstatus-32");
            log.info("ChannelId {},  ProductCode{}, Tenant_ID{}, -BankJourneyId{}, -PartnerJourneyId {}", channelId,
                    productCode, tenantId, bankJourneyId, partnerJourneyId);

            Boolean recordFound = jdbcTemplate.queryForObject(getloanappinfo, Boolean.class, channelId, productCode,
                    tenantId, bankJourneyId, partnerJourneyId);
            log.info("recordFound {} ", recordFound);
            log.info("vcipstatus-33");
            if (recordFound) {

                recordUpdated = jdbcTemplate.update(updatevcipstatusloanappinfo, status, vcippath, channelId, productCode, tenantId,
                        bankJourneyId, partnerJourneyId);
                log.info("recordUpdated {}", recordUpdated);
                log.info("vcipstatus-34");

                isUpdate = "true";

            }
            log.info("vcipstatus-35");
            log.info("getLoanAppInfo isUpdate :: {} ", isUpdate);
        } catch (BLEngineException exe) {
            log.info("vcipstatus-36");
            throw new BLEngineException(exe.getMessage());
        }
        return isUpdate;
    }

    public String getAPIConfigParameters(String channelid, String dataname, String datakey) {
        log.info("get  API Constant Parameters :: ");
        List<String> apiConstantslist = null;
        String isactive = "Y";
        String apiConfig = "";

        try {

            apiConstantslist = jdbcTemplate.queryForList(getappconfigparameters,
                    new Object[]{channelid, dataname, datakey, isactive}, String.class);
            if (!apiConstantslist.isEmpty()) {
                apiConfig = apiConstantslist.get(0);
            }
            log.info("apiConfig  datakey::" + datakey + apiConfig);

        } catch (Exception exe) {
            // exe.printStackTrace();
            log.info("Exception :: " + exe);
        }
        return apiConfig;
    }


    public int updateVkycLoanAppJourneyData(String vcipStatus, String VCIPreferenceId, String vkycURL, long bankJourneyId) {
        int count = 0;
        log.info("updateVkycLoanAppJourneyData{}");
        try {


            count = jdbcTemplate.update(updatevkycloanappjourneydata, new Object[]{vcipStatus, VCIPreferenceId, vkycURL, bankJourneyId});
            logger.info("updateVkycLoanAppJourneyDatacount {}", count);
            logger.info("count::" + count);

        } catch (Exception e) {
            throw new BLEngineException(e.getMessage());
        }

        return count;
    }


    public int updateVkycFinalStatusLoanAppJourneyData(String vcipStatus, long bankJourneyId) {
        int count = 0;
        log.info("updateVkycLoanAppJourneyData{}");
        try {


            count = jdbcTemplate.update(updateVkycFinalStatusLoanAppJourneyData, new Object[]{vcipStatus, bankJourneyId});
            logger.info("updateVkycLoanAppJourneyDatacount {}", count);
            logger.info("count::" + count);

        } catch (Exception e) {
            throw new BLEngineException(e.getMessage());
        }

        return count;
    }


    public Map<String, Object> getRecordLoanAppInfo(String channelid, String bankJourneyId, String partnerJourneyId) {

        List<Map<String, Object>> loanAppinfoList = null;
        Map<String, Object> loanAppinfo = null;
        String query = "select officeorbusinessstate,resiaddresstype, employmenttype, officeorbusinesscity, state, nameofemployer, nameofbiz from loanappinfo where  channelid =? and bankjourneyid= ?and partnerjourneyid= ?";

        try {
            loanAppinfoList = jdbcTemplate.queryForList(query, new Object[]{channelid, Long.parseLong(bankJourneyId), partnerJourneyId});

            logger.info("leaddata ::" + loanAppinfoList.size());
            if (loanAppinfoList.size() > 0) {
                loanAppinfo = loanAppinfoList.get(0);
            }

        } catch (Exception exe) {
            log.info("Exception :: " + exe);
        }
        return loanAppinfo;
    }

    public boolean recordFoundLoanAppInfo(String channelId, String productCode, String tenantId,
                                          long bankJourneyId, String partnerJourneyId) {
        logger.info("getLoanAppInfo :: ");

        String isUpdate = "false";

        Boolean recordFound;
        try {

            logger.info("ChannelId {},  ProductCode{}, Tenant_ID{}, -BankJourneyId{}, -PartnerJourneyId {}", channelId,
                    productCode, tenantId, bankJourneyId, partnerJourneyId);

            recordFound = jdbcTemplate.queryForObject(getloanappinfo, Boolean.class, channelId, productCode,
                    tenantId, bankJourneyId, partnerJourneyId);
            logger.info("recordFound {} ", recordFound);

        } catch (BLEngineException exe) {

            throw new BLEngineException(exe.getMessage());
        }
        return recordFound;
    }

    public String getRecordLoanAppOfferDetails(String bankJourneyId, long offerAmount, int offerTenure) {
        String recordExists = "false";
        List<Map<String, Object>> loanAppinfoList = null;
        Map<String, Object> loanAppinfo = null;
       // String query = "Select * from  loanappofferdetails  where bankjourneyid = ? And offerstage='BRE3' and stp_nonstp in ('STP', 'stp') and hardreject='no' and offeramount <= ? and offertenure = ?";
        String query = "Select * from  loanappofferdetails  where bankjourneyid = ? And offerstage='BRE3' and stp_nonstp in ('stp') and hardreject='no' and offeramount >= ? and offertenure = ?";

        try {
            loanAppinfoList = jdbcTemplate.queryForList(query, new Object[]{Long.parseLong(bankJourneyId), String.valueOf(offerAmount), String.valueOf(offerTenure)});

            logger.info("leaddata ::" + loanAppinfoList.size());
            if (loanAppinfoList.size() > 0) {
                loanAppinfo = loanAppinfoList.get(0);
                recordExists = "true";
            }

        } catch (Exception exe) {
            log.info("Exception :: " + exe);
        }
        return recordExists;
    }

    public String getRecordLoanAppOfferDetails(String bankJourneyId, long offerAmount, int offerTenure, String offerStage) {
        String recordExists = "false";
        List<Map<String, Object>> loanAppinfoList = null;
        Map<String, Object> loanAppinfo = null;
        // String query = "Select * from  loanappofferdetails  where bankjourneyid = ? And offerstage='BRE3' and stp_nonstp in ('STP', 'stp') and hardreject='no' and offeramount <= ? and offertenure = ?";
        String query = "Select * from  loanappofferdetails  where bankjourneyid = ? And offerstage=? and stp_nonstp in ('stp') and hardreject='no' and offeramount >= ? and offertenure = ?";

        try {
            loanAppinfoList = jdbcTemplate.queryForList(query, new Object[]{Long.parseLong(bankJourneyId), offerStage,String.valueOf(offerAmount), String.valueOf(offerTenure)});

            logger.info("leaddata ::" + loanAppinfoList.size());
            if (loanAppinfoList.size() > 0) {
                loanAppinfo = loanAppinfoList.get(0);
                recordExists = "true";
            }

        } catch (Exception exe) {
            log.info("Exception :: " + exe);
        }
        return recordExists;
    }

    public String getVideoKycConsent(String channelid, String bankJourneyId, String partnerJourneyId) {
        log.info("get  API Constant Parameters :: ");
        List<String> videokycList = null;
        String isactive = "Y";
        String videokyc = "";

        String videoKycConsentQuery = "select vkycconsentflag from loanappinfo where  channelid =? and bankjourneyid= ? and partnerjourneyid= ?";

        try {

            videokycList = jdbcTemplate.queryForList(videoKycConsentQuery,
                    new Object[]{channelid, Long.valueOf(bankJourneyId), partnerJourneyId}, String.class);
            if (!videokycList.isEmpty()) {
                videokyc = videokycList.get(0);
            }
            log.info("videokyc ::" + videokyc);

        } catch (Exception exe) {
            // exe.printStackTrace();
            log.info("Exception :: " + exe);
        }
        return videokyc;
    }


    public String getEkycStatus(String bankJourneyId) {

        List<String> ekycStatusList = null;
        String ekycstatus = "";

        String ekycStatusQuery = "select ekyc_status from loanappjourneydata where bankjourneyid= ?";

        try {

            ekycStatusList = jdbcTemplate.queryForList(ekycStatusQuery,
                    new Object[]{Long.valueOf(bankJourneyId)}, String.class);
            if (!ekycStatusList.isEmpty()) {
                ekycstatus = ekycStatusList.get(0);
            }
            log.info("ekycstatus ::" + ekycstatus);

        } catch (Exception exe) {
            // exe.printStackTrace();
            log.info("Exception :: " + exe);
        }
        return ekycstatus;
    }


    public String updateSalesPromotionLoanAppInfo(String salesPromotion, ContextParam param) {
        log.info("updateSalesPromotionLoanAppInfo :: ");

        int recordUpdated = 0;

        String isUpdate = "false";

        try {

            log.info("salesPromotion {}, bankJourneyId {}, partnerJourneyId {}", salesPromotion, param.getBankJourneyID(), param.getPartnerJourneyID());
log.info("updateloanappinfosalespromotion {}", updateloanappinfosalespromotion);
            recordUpdated = jdbcTemplate.update(updateloanappinfosalespromotion, salesPromotion, Long.parseLong(param.getBankJourneyID()), param.getPartnerJourneyID());
            log.info("recordUpdated {}", recordUpdated);

            log.info("recordUpdated {}", recordUpdated);

            if (recordUpdated > 0) {
                isUpdate = "true";
                log.info("Record Updated Successfully::");
            }

            log.info("getLoanAppInfo isUpdate :: {} ", isUpdate);
        } catch (BLEngineException exe) {

            throw new BLEngineException(exe.getMessage());
        }
        return isUpdate;
    }

    public Map<String, Object> getRecordLoanAppOfferDetails(String bankJourneyId) {
        log.info("inside getRecordLoanAppOfferDetails:: "+bankJourneyId);

        List<Map<String, Object>> loanAppOfferList = null;
        Map<String, Object> loanAppOffer = null;
        //String query = "select stp_nonstp, offertenure, offeramount from loanappofferdetails where  bankjourneyid= ?";

        try {
            loanAppOfferList = jdbcTemplate.queryForList(getloanappofferdetails, new Object[]{Long.parseLong(bankJourneyId)});

            logger.info("leaddata loanAppOfferDetails::" + loanAppOfferList.size());
            if (loanAppOfferList.size() > 0) {
                loanAppOffer = loanAppOfferList.get(0);
            }

        } catch (Exception exe) {
            log.info("Exception getRecordLoanAppOfferDetails:: " + exe.getMessage());
            exe.printStackTrace();
        }
        return loanAppOffer;
    }


}