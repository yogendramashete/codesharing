package com.hdfcbank.blengine.constants;

public class AppConstants {

    public static String VCIP_RETRIVER_ACTION_REJ = "rejected";


    public static String IN_PROGRESS_STATUS = "in_progress";
    public static String COMPLETED_STATUS = "completed";



    public final static String vcipStatusAPI = "vcipstatus";


    public final static String fullNameGetBureauOffer = "fullNamegetBureauOffer";
	
	public final static String KEY = "datakey";
    public final static String VALUE = "datavalue";

    public final static String VCIPStatusAPI = "VcipStatus";

    public final static String applyForLoanAPI = "ApplyLoan";
    public final static String NonSTPServiceAPI = "NonSTP-service";
    public final static String STPServiceAPI = "STP-service";
    public final static String applyForLoanbackendAPI = "ApplyLoan-Backend";


    public final static String applyForLoanStepId = "15";
    public final static String applyForLoanStepLevel = "1";
    public final static String VcipStatusStepId = "1";
    public final static String VcipStatusStepLevel = "1";

    public final static String DATE_FMT_ddMMyyyy2 = "dd-MM-yyyy";
    public final static String DATE_FMT_ddMMyyyy3 = "dd-MM-yyyy";
    public final static String DATE_FMT_yyyy_MM_dd = "yyyy-MM-dd";

    public final static String API_SUCCESS = "SUCCESS";
    public final static String API_FAIL = "FAIL";
    public final static String API_SUCCESS_CODE = "0";
    public final static String API_FAIL_CODE = "1";


    public  final static String tenantID = "HDFC";
    public final static String IS_ENC = "Y";

    public final static String dbRecordUnavilable = "Record does not exist in LoanAppInfo table";
    public final static String requestType = "IN";
    public final static String steplevelprocessNONSTP="2";

    public final static String stepIdprocessNONSTP = "2.0";

    public final static String panNumberConstant = "PAN_NO";
    public final static String mobileNoConstant = "MOBILE_NO";
    public final static String txnRefNoConstant = "txnRefNo";


}
