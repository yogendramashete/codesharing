package com.hdfcbank.blengine.dao;

import com.hdfcbank.blelengine.util.CommonUtility;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
public class Disbursementdao {

    public static final Logger logger = LoggerFactory.getLogger(Disbursementdao.class);

    @Autowired
    JdbcTemplate jdbcTemplate;


    public List<String> fetchDocumentPath(String bankJourneyId) {

        logger.info("docDataAvailable :: ");
        String documentPath = "";
        List<String> documentPathList = null;
        int txnsrno=52;
        try {
             documentPathList = jdbcTemplate.queryForList("select documentstoragepathonserver  from loandocumentdetails where bankjourneyid= ? and txnsrno= ?",
                    new Object[] {  bankJourneyId, txnsrno }, String.class);
            logger.info("docDataAvailable :: " + documentPathList);
            if (!documentPathList.isEmpty()) {
                documentPath = documentPathList.get(0);
            }
        } catch (Exception exe) {
            logger.info("docDataAvailable Exception :: " + CommonUtility.getPrintStackTrace(exe));
        }
        return documentPathList;
    }

}
