package com.hdfcbank.openAPI;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.xml.sax.SAXException;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.security.PublicKey;
import java.security.UnrecoverableEntryException;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;

/**
 * Generate Json request
 * 
 * @author Madhura Oak
 *
 */
@Service
public class JsonRequestGenerator {
	private static final String X509 = "X.509";
	private static final String CONFIG = "Config";
	public final static Logger logger = LoggerFactory.getLogger(DigitalSignature.class);


	@Value("${jsonrequestgenerator.blelbankcertificatefilepath}")
	String apibankCertificateFilePathUpdated;



	/**
	 * Load public key from the bank's public certificate
	 * 
	 * @throws FileNotFoundException
	 * @throws CertificateException
	 */
	private PublicKey initApiPublicKey() throws FileNotFoundException, CertificateException {
		X509Certificate bankCertificate = null;
		PublicKey publicKey = null;
		try (FileInputStream fin = new FileInputStream(apibankCertificateFilePathUpdated)) {
			CertificateFactory factory = CertificateFactory.getInstance(X509);
			bankCertificate = (X509Certificate) factory.generateCertificate(fin);
			if(bankCertificate != null) {
				publicKey = bankCertificate.getPublicKey();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return publicKey;
	}
	

	private Gson gson = new GsonBuilder().disableHtmlEscaping().create();



	public String generateLeadStatusRequest(String xmlRequest, String scope, String transactionId)
			throws CertificateException, UnrecoverableEntryException, SAXException, IOException {

		PublicKey bankPublicKey = initApiPublicKey();
		LeadStatusJsonRequest request = new LeadStatusJsonRequest();
		// create XML Digital Signature for original XML Request
		/*
		 * XMLDigitalSignature xmlDigitalSignature = new XMLDigitalSignature(); String
		 * signedXML = xmlDigitalSignature.sign(xmlRequest, clientKeyStoreFilePath,
		 * clientKeyStorePassword, clientKeyAlias); signedXML =
		 * signedXML.substring(signedXML.indexOf('>')+1); Logger.info("Signed XML : "
		 * +signedXML);
		 */
		// generate 32 byte random key
		KeyGenerator keyGenerator = new KeyGenerator();
		byte[] key = keyGenerator.generateAlphaNumericKey(32).getBytes();

		// encrypt encoded value using random key
		AESEncrypterDecrypter aesEncrypter = new AESEncrypterDecrypter();
		byte[] encryptedValue = aesEncrypter.encrypt(xmlRequest, key);

		// encode the encrypted request
		Base64EncoderDecoder encoder = new Base64EncoderDecoder();
		byte[] encodedValue = encoder.encode(encryptedValue);

		request.setRequestEncryptedValue(new String(encodedValue));
		logger.info("Request :" + new String(encodedValue));

		// encrypt symmetric key using bank's public key
		RSAEncrypterDecrypter rsaEncrypter = new RSAEncrypterDecrypter();
		logger.info("bank public key :" + bankPublicKey);
		byte[] symmetricKeyEncryptedValue = rsaEncrypter.encrypt(key, bankPublicKey);

		// encode symmetric key
		encodedValue = encoder.encode(symmetricKeyEncryptedValue);
		request.setSymmetricKeyEncryptedValue(new String(encodedValue));
		logger.info("Key :" + new String(encodedValue));

		request.setScope(scope);
		request.setTransactionId(transactionId);

		// Generate OAUTH token
//		OAuthTokenGenerator oauthTokenGenerator = new OAuthTokenGenerator();
		String oauthToken = "";
//				authTokenGenerator.getOAuthToken(clientId, clientSecret, clientScope);
//		String oauthToken = "f58805c0-6527-47df-be1b-7ebeba3c11ef";
		request.setOAuthTokenValue(oauthToken);

		// convert request object to json
		String gsonRequest = gson.toJson(request);

		return gsonRequest;
	}


}
