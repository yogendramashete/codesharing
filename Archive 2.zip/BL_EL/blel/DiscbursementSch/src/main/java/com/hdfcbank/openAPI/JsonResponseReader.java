package com.hdfcbank.openAPI;

import com.google.gson.Gson;

/**
 * Get Json Response object from String json response
 * 
 * @author Madhura Oak
 *
 */
public class JsonResponseReader {
	private Gson gson = new Gson();


	public LeadStatusJsonResponse leadRead(String jsonResponse) {
		LeadStatusJsonResponse response = gson.fromJson(jsonResponse, LeadStatusJsonResponse.class);
		return response;
	}

	/**
	 * Get json response
	 * 
	 * @param jsonResponse
	 * @return
	 */

}
