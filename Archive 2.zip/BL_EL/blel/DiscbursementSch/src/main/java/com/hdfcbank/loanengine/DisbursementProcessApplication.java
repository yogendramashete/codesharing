package com.hdfcbank.loanengine;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.scheduling.annotation.EnableScheduling;

import lombok.extern.slf4j.Slf4j;


//@PropertySources({
//		@PropertySource("classpath:application-${spring.profiles.active}.yaml"),
//		@PropertySource("classpath:application-info-${spring.profiles.active}.properties")})
@SpringBootApplication(scanBasePackages = "com")
@EnableJpaRepositories("com.hdfcbank.loanengine.repository")
@EntityScan("com.hdfcbank.*")
@ComponentScan("com.hdfcbank.*")
@EnableScheduling
@Slf4j
public class DisbursementProcessApplication {
	 
	public static void main(String[] args) {
		SpringApplication.run(DisbursementProcessApplication.class, args);
	}

	   
}
