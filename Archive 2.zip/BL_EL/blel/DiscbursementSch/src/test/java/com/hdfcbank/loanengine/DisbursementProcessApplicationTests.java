package com.hdfcbank.loanengine;

//@SpringBootTest
class DisbursementProcessApplicationTests {

//	@Test
	void contextLoads() {
	}

}
