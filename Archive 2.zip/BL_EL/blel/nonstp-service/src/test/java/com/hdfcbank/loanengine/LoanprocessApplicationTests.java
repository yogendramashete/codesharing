package com.hdfcbank.loanengine;

//@SpringBootTest
class LoanprocessApplicationTests {

//	@Test
	void contextLoads() {
	}

}
