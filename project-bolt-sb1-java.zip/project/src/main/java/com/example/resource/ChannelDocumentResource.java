package com.example.resource;

import com.example.entity.ChannelDocument;
import jakarta.transaction.Transactional;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;

@Path("/channel-documents")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class ChannelDocumentResource {
    
    @POST
    @Transactional
    public Response create(ChannelDocument channelDocument) {
        channelDocument.persist();
        return Response.status(Response.Status.CREATED).entity(channelDocument).build();
    }
    
    @GET
    public List<ChannelDocument> findAll() {
        return ChannelDocument.listAll();
    }
    
    @GET
    @Path("/{id}")
    public Response findById(@PathParam("id") Long id) {
        ChannelDocument channelDocument = ChannelDocument.findById(id);
        if (channelDocument != null) {
            return Response.ok(channelDocument).build();
        }
        return Response.status(Response.Status.NOT_FOUND).build();
    }
    
    @DELETE
    @Path("/{id}")
    @Transactional
    public Response delete(@PathParam("id") Long id) {
        boolean deleted = ChannelDocument.deleteById(id);
        if (deleted) {
            return Response.noContent().build();
        }
        return Response.status(Response.Status.NOT_FOUND).build();
    }
}