package com.example.resource;

import com.example.entity.Document;
import com.example.service.DocumentService;
import jakarta.inject.Inject;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;

@Path("/documents")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class DocumentResource {
    
    @Inject
    DocumentService documentService;
    
    @POST
    public Response create(Document document) {
        Document created = documentService.create(document);
        return Response.status(Response.Status.CREATED).entity(created).build();
    }
    
    @GET
    public List<Document> findAll() {
        return documentService.findAll();
    }
    
    @GET
    @Path("/{id}")
    public Response findById(@PathParam("id") Long id) {
        Document document = documentService.findById(id);
        if (document != null) {
            return Response.ok(document).build();
        }
        return Response.status(Response.Status.NOT_FOUND).build();
    }
    
    @PUT
    @Path("/{id}")
    public Response update(@PathParam("id") Long id, Document document) {
        Document updated = documentService.update(id, document);
        if (updated != null) {
            return Response.ok(updated).build();
        }
        return Response.status(Response.Status.NOT_FOUND).build();
    }
    
    @DELETE
    @Path("/{id}")
    public Response delete(@PathParam("id") Long id) {
        boolean deleted = documentService.delete(id);
        if (deleted) {
            return Response.noContent().build();
        }
        return Response.status(Response.Status.NOT_FOUND).build();
    }
}