package com.example.resource;

import com.example.entity.Channel;
import com.example.service.ChannelService;
import com.example.dto.PromptDto;
import com.example.dto.JsonSchemaDto;
import jakarta.inject.Inject;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;

@Path("/channels")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class ChannelResource {
    
    @Inject
    ChannelService channelService;
    
    @POST
    public Response create(Channel channel) {
        Channel created = channelService.create(channel);
        return Response.status(Response.Status.CREATED).entity(created).build();
    }
    
    @GET
    public List<Channel> findAll() {
        return channelService.findAll();
    }
    
    @GET
    @Path("/{id}")
    public Response findById(@PathParam("id") Long id) {
        Channel channel = channelService.findById(id);
        if (channel != null) {
            return Response.ok(channel).build();
        }
        return Response.status(Response.Status.NOT_FOUND).build();
    }
    
    @PUT
    @Path("/{id}")
    public Response update(@PathParam("id") Long id, Channel channel) {
        Channel updated = channelService.update(id, channel);
        if (updated != null) {
            return Response.ok(updated).build();
        }
        return Response.status(Response.Status.NOT_FOUND).build();
    }
    
    @DELETE
    @Path("/{id}")
    public Response delete(@PathParam("id") Long id) {
        boolean deleted = channelService.delete(id);
        if (deleted) {
            return Response.noContent().build();
        }
        return Response.status(Response.Status.NOT_FOUND).build();
    }
    
    @GET
    @Path("/{channelId}/prompt")
    public Response getPrompt(
            @PathParam("channelId") Long channelId,
            @QueryParam("documentId") Long documentId,
            @QueryParam("operationId") Long operationId) {
        PromptDto prompt = channelService.getPromptForChannel(channelId, documentId, operationId);
        if (prompt != null) {
            return Response.ok(prompt).build();
        }
        return Response.status(Response.Status.NOT_FOUND).build();
    }
    
    @GET
    @Path("/{channelId}/classification-prompt")
    public Response getClassificationPrompt(
            @PathParam("channelId") Long channelId,
            @QueryParam("operationId") Long operationId) {
        PromptDto prompt = channelService.getClassificationPromptForChannel(channelId, operationId);
        if (prompt != null) {
            return Response.ok(prompt).build();
        }
        return Response.status(Response.Status.NOT_FOUND).build();
    }
    
    @GET
    @Path("/{channelId}/json-schema")
    public Response getJsonSchema(
            @PathParam("channelId") Long channelId,
            @QueryParam("documentId") Long documentId,
            @QueryParam("operationId") Long operationId) {
        JsonSchemaDto schema = channelService.createJsonSchema(channelId, documentId, operationId);
        if (schema != null) {
            return Response.ok(schema).build();
        }
        return Response.status(Response.Status.NOT_FOUND).build();
    }
}