package com.example.resource;

import com.example.entity.DocumentOperation;
import com.example.service.DocumentOperationService;
import com.example.dto.PromptDto;
import jakarta.inject.Inject;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;

@Path("/document-operations")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class DocumentOperationResource {
    
    @Inject
    DocumentOperationService documentOperationService;
    
    @POST
    public Response create(DocumentOperation documentOperation) {
        DocumentOperation created = documentOperationService.create(documentOperation);
        return Response.status(Response.Status.CREATED).entity(created).build();
    }
    
    @GET
    public List<DocumentOperation> findAll() {
        return documentOperationService.findAll();
    }
    
    @GET
    @Path("/{id}")
    public Response findById(@PathParam("id") Long id) {
        DocumentOperation documentOperation = documentOperationService.findById(id);
        if (documentOperation != null) {
            return Response.ok(documentOperation).build();
        }
        return Response.status(Response.Status.NOT_FOUND).build();
    }
    
    @PUT
    @Path("/{id}")
    public Response update(@PathParam("id") Long id, DocumentOperation documentOperation) {
        DocumentOperation updated = documentOperationService.update(id, documentOperation);
        if (updated != null) {
            return Response.ok(updated).build();
        }
        return Response.status(Response.Status.NOT_FOUND).build();
    }
    
    @DELETE
    @Path("/{id}")
    public Response delete(@PathParam("id") Long id) {
        boolean deleted = documentOperationService.delete(id);
        if (deleted) {
            return Response.noContent().build();
        }
        return Response.status(Response.Status.NOT_FOUND).build();
    }
    
    @GET
    @Path("/prompt")
    public Response getPrompt(
            @QueryParam("documentId") Long documentId,
            @QueryParam("operationId") Long operationId) {
        PromptDto prompt = documentOperationService.getPromptByDocumentAndOperation(documentId, operationId);
        if (prompt != null) {
            return Response.ok(prompt).build();
        }
        return Response.status(Response.Status.NOT_FOUND).build();
    }
}