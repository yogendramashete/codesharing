package com.example.resource;

import com.example.entity.Validation;
import com.example.service.ValidationService;
import jakarta.inject.Inject;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;

@Path("/validations")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class ValidationResource {
    
    @Inject
    ValidationService validationService;
    
    @POST
    public Response create(Validation validation) {
        Validation created = validationService.create(validation);
        return Response.status(Response.Status.CREATED).entity(created).build();
    }
    
    @GET
    public List<Validation> findAll() {
        return validationService.findAll();
    }
    
    @GET
    @Path("/{id}")
    public Response findById(@PathParam("id") Long id) {
        Validation validation = validationService.findById(id);
        if (validation != null) {
            return Response.ok(validation).build();
        }
        return Response.status(Response.Status.NOT_FOUND).build();
    }
    
    @PUT
    @Path("/{id}")
    public Response update(@PathParam("id") Long id, Validation validation) {
        Validation updated = validationService.update(id, validation);
        if (updated != null) {
            return Response.ok(updated).build();
        }
        return Response.status(Response.Status.NOT_FOUND).build();
    }
    
    @DELETE
    @Path("/{id}")
    public Response delete(@PathParam("id") Long id) {
        boolean deleted = validationService.delete(id);
        if (deleted) {
            return Response.noContent().build();
        }
        return Response.status(Response.Status.NOT_FOUND).build();
    }
}