package com.example.resource;

import com.example.entity.FieldValidation;
import com.example.service.FieldValidationService;
import jakarta.inject.Inject;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;

@Path("/field-validations")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class FieldValidationResource {
    
    @Inject
    FieldValidationService fieldValidationService;
    
    @POST
    public Response create(FieldValidation fieldValidation) {
        FieldValidation created = fieldValidationService.create(fieldValidation);
        return Response.status(Response.Status.CREATED).entity(created).build();
    }
    
    @GET
    public List<FieldValidation> findAll() {
        return fieldValidationService.findAll();
    }
    
    @GET
    @Path("/{id}")
    public Response findById(@PathParam("id") Long id) {
        FieldValidation fieldValidation = fieldValidationService.findById(id);
        if (fieldValidation != null) {
            return Response.ok(fieldValidation).build();
        }
        return Response.status(Response.Status.NOT_FOUND).build();
    }
    
    @PUT
    @Path("/{id}")
    public Response update(@PathParam("id") Long id, FieldValidation fieldValidation) {
        FieldValidation updated = fieldValidationService.update(id, fieldValidation);
        if (updated != null) {
            return Response.ok(updated).build();
        }
        return Response.status(Response.Status.NOT_FOUND).build();
    }
    
    @DELETE
    @Path("/{id}")
    public Response delete(@PathParam("id") Long id) {
        boolean deleted = fieldValidationService.delete(id);
        if (deleted) {
            return Response.noContent().build();
        }
        return Response.status(Response.Status.NOT_FOUND).build();
    }
}