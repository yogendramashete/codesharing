package com.example.service;

import com.example.entity.Operation;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.transaction.Transactional;
import java.util.List;

@ApplicationScoped
public class OperationService {
    
    @Transactional
    public Operation create(Operation operation) {
        operation.persist();
        return operation;
    }
    
    public List<Operation> findAll() {
        return Operation.listAll();
    }
    
    public Operation findById(Long id) {
        return Operation.findById(id);
    }
    
    @Transactional
    public Operation update(Long id, Operation operation) {
        Operation existing = Operation.findById(id);
        if (existing != null) {
            existing.name = operation.name;
            existing.persist();
            return existing;
        }
        return null;
    }
    
    @Transactional
    public boolean delete(Long id) {
        return Operation.deleteById(id);
    }
}