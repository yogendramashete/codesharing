package com.example.service;

import com.example.entity.Document;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.transaction.Transactional;
import java.util.List;

@ApplicationScoped
public class DocumentService {
    
    @Transactional
    public Document create(Document document) {
        document.persist();
        return document;
    }
    
    public List<Document> findAll() {
        return Document.listAll();
    }
    
    public Document findById(Long id) {
        return Document.findById(id);
    }
    
    @Transactional
    public Document update(Long id, Document document) {
        Document existing = Document.findById(id);
        if (existing != null) {
            existing.tableName = document.tableName;
            existing.persist();
            return existing;
        }
        return null;
    }
    
    @Transactional
    public boolean delete(Long id) {
        return Document.deleteById(id);
    }
}