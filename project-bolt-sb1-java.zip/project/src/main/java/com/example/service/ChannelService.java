package com.example.service;

import com.example.entity.Channel;
import com.example.entity.ChannelDocument;
import com.example.entity.DocumentOperation;
import com.example.entity.ChannelFieldValidation;
import com.example.entity.FieldValidation;
import com.example.dto.PromptDto;
import com.example.dto.JsonSchemaDto;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.transaction.Transactional;
import java.util.List;
import java.util.HashMap;
import java.util.ArrayList;
import java.util.stream.Collectors;

@ApplicationScoped
public class ChannelService {
    
    @Transactional
    public Channel create(Channel channel) {
        channel.persist();
        return channel;
    }
    
    public List<Channel> findAll() {
        return Channel.listAll();
    }
    
    public Channel findById(Long id) {
        return Channel.findById(id);
    }
    
    @Transactional
    public Channel update(Long id, Channel channel) {
        Channel existing = Channel.findById(id);
        if (existing != null) {
            existing.name = channel.name;
            existing.persist();
            return existing;
        }
        return null;
    }
    
    @Transactional
    public boolean delete(Long id) {
        return Channel.deleteById(id);
    }
    
    public PromptDto getPromptForChannel(Long channelId, Long documentId, Long operationId) {
        ChannelDocument channelDoc = ChannelDocument.find(
            "SELECT cd FROM ChannelDocument cd " +
            "JOIN cd.channel c " +
            "JOIN cd.documentOperation do " +
            "JOIN do.document d " +
            "JOIN do.operation o " +
            "WHERE c.id = ?1 AND d.tableId = ?2 AND o.id = ?3",
            channelId, documentId, operationId
        ).firstResult();
        
        if (channelDoc != null && channelDoc.documentOperation != null) {
            return new PromptDto(
                channelDoc.documentOperation.userPrompt,
                channelDoc.documentOperation.systemPrompt
            );
        }
        return null;
    }
    
    public PromptDto getClassificationPromptForChannel(Long channelId, Long operationId) {
        List<ChannelDocument> channelDocs = ChannelDocument.find(
            "SELECT cd FROM ChannelDocument cd " +
            "JOIN cd.channel c " +
            "JOIN cd.documentOperation do " +
            "JOIN do.operation o " +
            "WHERE c.id = ?1 AND o.id = ?2",
            channelId, operationId
        ).list();
        
        StringBuilder combinedPrompt = new StringBuilder();
        
        for (ChannelDocument channelDoc : channelDocs) {
            if (channelDoc.documentOperation != null) {
                if (channelDoc.documentOperation.systemPrompt != null) {
                    combinedPrompt.append(channelDoc.documentOperation.systemPrompt).append("\n\n");
                }
                if (channelDoc.documentOperation.userPrompt != null) {
                    combinedPrompt.append(channelDoc.documentOperation.userPrompt).append("\n\n");
                }
            }
        }
        
        PromptDto result = new PromptDto();
        result.combinedPrompt = combinedPrompt.toString().trim();
        return result;
    }
    
    public JsonSchemaDto createJsonSchema(Long channelId, Long documentId, Long operationId) {
        ChannelDocument channelDoc = ChannelDocument.find(
            "SELECT cd FROM ChannelDocument cd " +
            "JOIN FETCH cd.channelFieldValidations cfv " +
            "JOIN FETCH cfv.fieldValidation fv " +
            "JOIN FETCH fv.field f " +
            "JOIN FETCH fv.validation v " +
            "JOIN cd.channel c " +
            "JOIN cd.documentOperation do " +
            "JOIN do.document d " +
            "JOIN do.operation o " +
            "WHERE c.id = ?1 AND d.tableId = ?2 AND o.id = ?3",
            channelId, documentId, operationId
        ).firstResult();
        
        if (channelDoc == null) {
            return null;
        }
        
        JsonSchemaDto schema = new JsonSchemaDto();
        schema.title = "Document Extraction Schema";
        schema.properties = new HashMap<>();
        schema.required = new ArrayList<>();
        
        for (ChannelFieldValidation cfv : channelDoc.channelFieldValidations) {
            FieldValidation fv = cfv.fieldValidation;
            String fieldName = fv.field.name;
            String fieldType = mapFieldType(fv.field.type);
            String validationName = fv.validation.name;
            String validationValue = fv.value;
            
            JsonSchemaDto.PropertyDto property = schema.properties.get(fieldName);
            if (property == null) {
                property = new JsonSchemaDto.PropertyDto();
                property.description = fv.field.description != null ? fv.field.description : "";
                property.type = fieldType;
                schema.properties.put(fieldName, property);
                schema.required.add(fieldName);
            }
            
            // Apply validation rules
            switch (validationName.toUpperCase()) {
                case "MIN_LENGTH":
                    property.minLength = Integer.parseInt(validationValue);
                    break;
                case "MAX_LENGTH":
                    property.maxLength = Integer.parseInt(validationValue);
                    break;
                case "REGEX":
                case "PATTERN":
                    property.pattern = validationValue;
                    break;
            }
        }
        
        return schema;
    }
    
    private String mapFieldType(String fieldType) {
        switch (fieldType.toLowerCase()) {
            case "int":
            case "integer":
                return "integer";
            case "double":
            case "float":
            case "decimal":
                return "number";
            case "boolean":
            case "bool":
                return "boolean";
            default:
                return "string";
        }
    }
}