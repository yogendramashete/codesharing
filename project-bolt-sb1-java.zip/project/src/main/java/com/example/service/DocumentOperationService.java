package com.example.service;

import com.example.entity.DocumentOperation;
import com.example.dto.PromptDto;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.transaction.Transactional;
import java.util.List;

@ApplicationScoped
public class DocumentOperationService {
    
    @Transactional
    public DocumentOperation create(DocumentOperation documentOperation) {
        documentOperation.persist();
        return documentOperation;
    }
    
    public List<DocumentOperation> findAll() {
        return DocumentOperation.listAll();
    }
    
    public DocumentOperation findById(Long id) {
        return DocumentOperation.findById(id);
    }
    
    @Transactional
    public DocumentOperation update(Long id, DocumentOperation documentOperation) {
        DocumentOperation existing = DocumentOperation.findById(id);
        if (existing != null) {
            existing.userPrompt = documentOperation.userPrompt;
            existing.systemPrompt = documentOperation.systemPrompt;
            existing.persist();
            return existing;
        }
        return null;
    }
    
    @Transactional
    public boolean delete(Long id) {
        return DocumentOperation.deleteById(id);
    }
    
    public PromptDto getPromptByDocumentAndOperation(Long documentId, Long operationId) {
        DocumentOperation docOp = DocumentOperation.find(
            "document.tableId = ?1 and operation.id = ?2", 
            documentId, operationId
        ).firstResult();
        
        if (docOp != null) {
            return new PromptDto(docOp.userPrompt, docOp.systemPrompt);
        }
        return null;
    }
}