package com.example.service;

import com.example.entity.Api;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.transaction.Transactional;
import java.util.List;

@ApplicationScoped
public class ApiService {
    
    @Transactional
    public Api create(Api api) {
        api.persist();
        return api;
    }
    
    public List<Api> findAll() {
        return Api.listAll();
    }
    
    public Api findById(Long id) {
        return Api.findById(id);
    }
    
    @Transactional
    public Api update(Long id, Api api) {
        Api existing = Api.findById(id);
        if (existing != null) {
            existing.name = api.name;
            existing.url = api.url;
            existing.persist();
            return existing;
        }
        return null;
    }
    
    @Transactional
    public boolean delete(Long id) {
        return Api.deleteById(id);
    }
}