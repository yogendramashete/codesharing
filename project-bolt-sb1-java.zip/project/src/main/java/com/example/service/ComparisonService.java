package com.example.service;

import com.example.entity.Comparison;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.transaction.Transactional;
import java.util.List;

@ApplicationScoped
public class ComparisonService {
    
    @Transactional
    public Comparison create(Comparison comparison) {
        comparison.persist();
        return comparison;
    }
    
    public List<Comparison> findAll() {
        return Comparison.listAll();
    }
    
    public Comparison findById(Long id) {
        return Comparison.findById(id);
    }
    
    @Transactional
    public Comparison update(Long id, Comparison comparison) {
        Comparison existing = Comparison.findById(id);
        if (existing != null) {
            existing.name = comparison.name;
            existing.persist();
            return existing;
        }
        return null;
    }
    
    @Transactional
    public boolean delete(Long id) {
        return Comparison.deleteById(id);
    }
}