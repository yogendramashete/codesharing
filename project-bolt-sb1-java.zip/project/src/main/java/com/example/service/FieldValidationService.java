package com.example.service;

import com.example.entity.FieldValidation;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.transaction.Transactional;
import java.util.List;

@ApplicationScoped
public class FieldValidationService {
    
    @Transactional
    public FieldValidation create(FieldValidation fieldValidation) {
        fieldValidation.persist();
        return fieldValidation;
    }
    
    public List<FieldValidation> findAll() {
        return FieldValidation.listAll();
    }
    
    public FieldValidation findById(Long id) {
        return FieldValidation.findById(id);
    }
    
    @Transactional
    public FieldValidation update(Long id, FieldValidation fieldValidation) {
        FieldValidation existing = FieldValidation.findById(id);
        if (existing != null) {
            existing.value = fieldValidation.value;
            existing.persist();
            return existing;
        }
        return null;
    }
    
    @Transactional
    public boolean delete(Long id) {
        return FieldValidation.deleteById(id);
    }
}