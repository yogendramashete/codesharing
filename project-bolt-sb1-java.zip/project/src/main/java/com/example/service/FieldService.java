package com.example.service;

import com.example.entity.Field;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.transaction.Transactional;
import java.util.List;

@ApplicationScoped
public class FieldService {
    
    @Transactional
    public Field create(Field field) {
        field.persist();
        return field;
    }
    
    public List<Field> findAll() {
        return Field.listAll();
    }
    
    public Field findById(Long id) {
        return Field.findById(id);
    }
    
    @Transactional
    public Field update(Long id, Field field) {
        Field existing = Field.findById(id);
        if (existing != null) {
            existing.name = field.name;
            existing.description = field.description;
            existing.type = field.type;
            existing.persist();
            return existing;
        }
        return null;
    }
    
    @Transactional
    public boolean delete(Long id) {
        return Field.deleteById(id);
    }
}