package com.example.service;

import com.example.entity.Validation;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.transaction.Transactional;
import java.util.List;

@ApplicationScoped
public class ValidationService {
    
    @Transactional
    public Validation create(Validation validation) {
        validation.persist();
        return validation;
    }
    
    public List<Validation> findAll() {
        return Validation.listAll();
    }
    
    public Validation findById(Long id) {
        return Validation.findById(id);
    }
    
    @Transactional
    public Validation update(Long id, Validation validation) {
        Validation existing = Validation.findById(id);
        if (existing != null) {
            existing.name = validation.name;
            existing.persist();
            return existing;
        }
        return null;
    }
    
    @Transactional
    public boolean delete(Long id) {
        return Validation.deleteById(id);
    }
}