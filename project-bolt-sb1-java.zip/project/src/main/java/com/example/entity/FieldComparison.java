package com.example.entity;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;
import jakarta.persistence.*;

@Entity
@Table(name = "field_comparison")
public class FieldComparison extends PanacheEntityBase {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "field_id")
    public Field field;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "comparison_id")
    public Comparison comparison;
}