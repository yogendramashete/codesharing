package com.example.entity;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import java.util.List;

@Entity
@Table(name = "comparison")
public class Comparison extends PanacheEntityBase {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;
    
    @NotBlank
    public String name;
    
    @OneToMany(mappedBy = "comparison", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    public List<FieldComparison> fieldComparisons;
}