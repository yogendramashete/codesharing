package com.example.entity;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;
import jakarta.persistence.*;
import java.util.List;

@Entity
@Table(name = "field_api")
public class FieldApi extends PanacheEntityBase {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "field_id")
    public Field field;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "api_id")
    public Api api;
    
    public String xpath;
    
    @OneToMany(mappedBy = "fieldApi", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    public List<ChannelFieldApi> channelFieldApis;
}