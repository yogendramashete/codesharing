package com.example.entity;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;
import jakarta.persistence.*;

@Entity
@Table(name = "channel_field_api")
public class ChannelFieldApi extends PanacheEntityBase {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "channel_document_id")
    public ChannelDocument channelDocument;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "field_api_id")
    public FieldApi fieldApi;
}