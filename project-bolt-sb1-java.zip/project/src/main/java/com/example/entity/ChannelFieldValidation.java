package com.example.entity;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;
import jakarta.persistence.*;

@Entity
@Table(name = "channel_field_validation")
public class ChannelFieldValidation extends PanacheEntityBase {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "channel_document_id")
    public ChannelDocument channelDocument;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "field_validation_id")
    public FieldValidation fieldValidation;
}