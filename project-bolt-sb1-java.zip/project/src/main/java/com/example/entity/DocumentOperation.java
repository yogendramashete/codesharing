package com.example.entity;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;
import jakarta.persistence.*;
import java.util.List;

@Entity
@Table(name = "document_operation")
public class DocumentOperation extends PanacheEntityBase {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;
    
    @Column(name = "user_prompt", columnDefinition = "TEXT")
    public String userPrompt;
    
    @Column(name = "system_prompt", columnDefinition = "TEXT")
    public String systemPrompt;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "document_id")
    public Document document;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "operation_id")
    public Operation operation;
    
    @OneToMany(mappedBy = "documentOperation", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    public List<ChannelDocument> channelDocuments;
}