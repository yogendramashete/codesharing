package com.example.entity;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;
import jakarta.persistence.*;
import java.util.List;

@Entity
@Table(name = "channel_document")
public class ChannelDocument extends PanacheEntityBase {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "channel_id")
    public Channel channel;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "document_operation_id")
    public DocumentOperation documentOperation;
    
    @OneToMany(mappedBy = "channelDocument", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    public List<ChannelFieldApi> channelFieldApis;
    
    @OneToMany(mappedBy = "channelDocument", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    public List<ChannelFieldValidation> channelFieldValidations;
}