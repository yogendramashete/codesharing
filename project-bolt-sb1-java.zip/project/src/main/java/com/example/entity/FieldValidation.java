package com.example.entity;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;
import jakarta.persistence.*;
import java.util.List;

@Entity
@Table(name = "field_validation")
public class FieldValidation extends PanacheEntityBase {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "field_id")
    public Field field;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "validation_id")
    public Validation validation;
    
    public String value;
    
    @OneToMany(mappedBy = "fieldValidation", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    public List<ChannelFieldValidation> channelFieldValidations;
}