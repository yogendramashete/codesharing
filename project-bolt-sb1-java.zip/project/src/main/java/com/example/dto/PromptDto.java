package com.example.dto;

public class PromptDto {
    public String userPrompt;
    public String systemPrompt;
    public String combinedPrompt;
    
    public PromptDto() {}
    
    public PromptDto(String userPrompt, String systemPrompt) {
        this.userPrompt = userPrompt;
        this.systemPrompt = systemPrompt;
        this.combinedPrompt = (systemPrompt != null ? systemPrompt + "\n\n" : "") + 
                             (userPrompt != null ? userPrompt : "");
    }
}