package com.example.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Map;
import java.util.List;

public class JsonSchemaDto {
    
    @JsonProperty("$schema")
    public String schema = "http://json-schema.org/draft-07/schema#";
    
    public String title;
    public String type = "object";
    public Map<String, PropertyDto> properties;
    public List<String> required;
    
    public static class PropertyDto {
        public String description;
        public String type;
        public Integer minLength;
        public Integer maxLength;
        public String pattern;
    }
}