import React, { useState } from 'react';
import { Upload, Plus, Trash2, Send, RefreshCw, FileText, CheckCircle, XCircle, AlertCircle } from 'lucide-react';

interface ChannelInput {
  key: string;
  value: string;
}

interface FormData {
  externalReferenceId: string;
  channelId: string;
  operationGroup: 'classify' | 'multiple';
  operations: string[];
  documentId: string;
  fileContent: string;
  channelInputs: ChannelInput[];
}

interface SyncResponse {
  externalReferenceId: string;
  correlationId: string;
  status: number;
  message: string;
  data: {
    isDocumentTypeValid?: boolean;
    imageQuality: string;
    errorMsg: string;
  };
}

interface FinalResponse {
  externalReferenceId: string;
  correlationId: string;
  status: number;
  message: string;
  data: {
    documentExtract?: {
      documentDetails: Array<{ key: string; value: string }>;
      errorMsg: string | null;
    };
    documentLookup?: {
      documentDetails: Array<{ key: string; value: string }>;
      errorMsg: string | null;
    };
    validations?: {
      validation: Array<{
        field: string;
        validationType: string;
        output: string;
      }>;
      errorMsg: string | null;
    };
    documentClassify?: {
      documentValue: string;
      errorMsg: string | null;
    };
    errorMsg: string | null;
  };
}

function App() {
  const [formData, setFormData] = useState<FormData>({
    externalReferenceId: `REF-${Date.now()}`,
    channelId: '',
    operationGroup: 'classify',
    operations: ['CLASSIFY'],
    documentId: '',
    fileContent: '',
    channelInputs: []
  });

  const [fileName, setFileName] = useState<string>('');
  const [isLoading, setIsLoading] = useState(false);
  const [isSolaceLoading, setIsSolaceLoading] = useState(false);
  const [syncResponse, setSyncResponse] = useState<SyncResponse | null>(null);
  const [finalResponse, setFinalResponse] = useState<FinalResponse | null>(null);
  const [activeTab, setActiveTab] = useState('documentExtract');
  const [error, setError] = useState<string>('');
  const [useMockData, setUseMockData] = useState(true);

  const multipleOperations = ['VERIFY', 'EXTRACT', 'EXTRACT-VALIDATE', 'LOOKUP'];

  // Check if only VERIFY operation is selected
  const isOnlyVerifyOperation = () => {
    return formData.operations.length === 1 && formData.operations[0] === 'VERIFY';
  };

  // Check if VERIFY operation is included
  const hasVerifyOperation = () => {
    return formData.operations.includes('VERIFY');
  };

  // Mock API responses
  const getMockSyncResponse = (): SyncResponse => {
    const baseResponse = {
      externalReferenceId: formData.externalReferenceId,
      correlationId: `${Math.random().toString(36).substr(2, 8)}-${Math.random().toString(36).substr(2, 4)}-${Math.random().toString(36).substr(2, 4)}-${Math.random().toString(36).substr(2, 4)}-${Math.random().toString(36).substr(2, 12)}`,
      status: 200,
      message: "Success",
      data: {
        imageQuality: "Good",
        errorMsg: "Document processed successfully"
      }
    };

    // Only include isDocumentTypeValid if VERIFY operation is selected
    if (hasVerifyOperation()) {
      baseResponse.data.isDocumentTypeValid = true;
    }

    return baseResponse;
  };

  const getMockFinalResponse = (correlationId: string): FinalResponse => {
    const baseResponse = {
      externalReferenceId: formData.externalReferenceId,
      correlationId,
      status: 200,
      message: "SUCCESS",
      data: {
        errorMsg: null
      }
    };

    // Generate response based on selected operations
    const responseData: any = { errorMsg: null };

    if (formData.operations.includes('CLASSIFY')) {
      responseData.documentClassify = {
        documentValue: formData.documentId || "AD",
        errorMsg: null
      };
    }

    if (formData.operations.includes('EXTRACT')) {
      responseData.documentExtract = {
        documentDetails: [
          { key: "name", value: "John Doe Smith" },
          { key: "documentNumber", value: "DOC123456789" },
          { key: "dateOfBirth", value: "1990-05-15" },
          { key: "address", value: "123 Main Street, City, State" }
        ],
        errorMsg: null
      };
    }

    if (formData.operations.includes('LOOKUP')) {
      responseData.documentLookup = {
        documentDetails: [
          { key: "verificationScore", value: "95.8" },
          { key: "isActive", value: "true" },
          { key: "lastUpdated", value: "2024-01-15" },
          { key: "riskLevel", value: "LOW" }
        ],
        errorMsg: null
      };
    }

    if (formData.operations.includes('EXTRACT-VALIDATE')) {
      // EXTRACT-VALIDATE shows both validations and documentExtract
      responseData.validations = {
        validation: [
          {
            field: "name",
            validationType: "NAME_MATCH",
            output: "93.92"
          },
          {
            field: "documentNumber",
            validationType: "FORMAT_CHECK",
            output: "VALID"
          },
          {
            field: "dateOfBirth",
            validationType: "DATE_VALIDATION",
            output: "VALID"
          }
        ],
        errorMsg: null
      };

      responseData.documentExtract = {
        documentDetails: [
          { key: "name", value: "John Doe Smith" },
          { key: "documentNumber", value: "DOC123456789" },
          { key: "dateOfBirth", value: "1990-05-15" },
          { key: "address", value: "123 Main Street, City, State" }
        ],
        errorMsg: null
      };
    } else if (formData.operations.includes('VERIFY') && !isOnlyVerifyOperation()) {
      // VERIFY with other operations shows validations
      responseData.validations = {
        validation: [
          {
            field: "name",
            validationType: "NAME_MATCH",
            output: "93.92"
          },
          {
            field: "documentNumber",
            validationType: "FORMAT_CHECK",
            output: "VALID"
          }
        ],
        errorMsg: null
      };
    }

    return { ...baseResponse, data: responseData };
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setFileName(file.name);
      const reader = new FileReader();
      reader.onload = (e) => {
        const base64 = e.target?.result as string;
        const base64Content = base64.split(',')[1]; // Remove data:image/jpeg;base64, prefix
        setFormData(prev => ({ ...prev, fileContent: base64Content }));
      };
      reader.readAsDataURL(file);
    }
  };

  const handleOperationGroupChange = (group: 'classify' | 'multiple') => {
    setFormData(prev => ({
      ...prev,
      operationGroup: group,
      operations: group === 'classify' ? ['CLASSIFY'] : [],
      // Clear channel inputs when switching away from operations that need them
      channelInputs: group === 'classify' ? [] : prev.channelInputs
    }));
  };

  const handleMultipleOperationChange = (operation: string, checked: boolean) => {
    setFormData(prev => {
      const newOperations = checked 
        ? [...prev.operations, operation]
        : prev.operations.filter(op => op !== operation);
      
      // Clear channel inputs if no longer needed
      const needsChannelInputs = newOperations.some(op => op === 'EXTRACT-VALIDATE' || op === 'LOOKUP');
      
      return {
        ...prev,
        operations: newOperations,
        channelInputs: needsChannelInputs ? prev.channelInputs : []
      };
    });
  };

  const addChannelInput = () => {
    setFormData(prev => ({
      ...prev,
      channelInputs: [...prev.channelInputs, { key: '', value: '' }]
    }));
  };

  const removeChannelInput = (index: number) => {
    setFormData(prev => ({
      ...prev,
      channelInputs: prev.channelInputs.filter((_, i) => i !== index)
    }));
  };

  const updateChannelInput = (index: number, field: 'key' | 'value', value: string) => {
    setFormData(prev => ({
      ...prev,
      channelInputs: prev.channelInputs.map((input, i) => 
        i === index ? { ...input, [field]: value } : input
      )
    }));
  };

  // Check if channel inputs should be shown
  const shouldShowChannelInputs = formData.operationGroup === 'multiple' && 
    formData.operations.some(op => op === 'EXTRACT-VALIDATE' || op === 'LOOKUP');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError('');
    setSyncResponse(null);
    setFinalResponse(null);

    try {
      const requestData = {
        externalReferenceId: formData.externalReferenceId,
        channelId: formData.channelId,
        operations: formData.operations,
        documentId: formData.documentId,
        data: {
          fileContent: formData.fileContent,
          channelInputs: shouldShowChannelInputs && formData.channelInputs.length > 0 ? formData.channelInputs : null
        }
      };

      if (useMockData) {
        // Simulate API delay
        await new Promise(resolve => setTimeout(resolve, 1500));
        const mockResponse = getMockSyncResponse();
        setSyncResponse(mockResponse);
      } else {
        const response = await fetch('http://localhost:8080/api/idrs', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(requestData)
        });

        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }

        const result = await response.json();
        setSyncResponse(result);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
    } finally {
      setIsLoading(false);
    }
  };

  const checkSolaceResponse = async () => {
    if (!syncResponse?.correlationId) return;

    setIsSolaceLoading(true);
    setError('');

    try {
      if (useMockData) {
        // Simulate API delay
        await new Promise(resolve => setTimeout(resolve, 2000));
        const mockFinalResponse = getMockFinalResponse(syncResponse.correlationId);
        setFinalResponse(mockFinalResponse);
        
        // Set the first available tab as active
        const availableTabs = getAvailableTabs(mockFinalResponse.data);
        if (availableTabs.length > 0) {
          setActiveTab(availableTabs[0]);
        }
      } else {
        const response = await fetch(`http://localhost:8080/api/${syncResponse.correlationId}-SOLACE`);
        
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }

        const result = await response.json();
        setFinalResponse(result);
        
        // Set the first available tab as active
        const availableTabs = getAvailableTabs(result.data);
        if (availableTabs.length > 0) {
          setActiveTab(availableTabs[0]);
        }
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
    } finally {
      setIsSolaceLoading(false);
    }
  };

  // Get available tabs based on response data
  const getAvailableTabs = (data: FinalResponse['data']) => {
    const tabs = [];
    if (data.documentExtract) tabs.push('documentExtract');
    if (data.documentLookup) tabs.push('documentLookup');
    if (data.validations) tabs.push('validations');
    if (data.documentClassify) tabs.push('documentClassify');
    return tabs;
  };

  const getStatusIcon = (status: number) => {
    if (status === 200) return <CheckCircle className="w-5 h-5 text-green-500" />;
    if (status >= 400) return <XCircle className="w-5 h-5 text-red-500" />;
    return <AlertCircle className="w-5 h-5 text-yellow-500" />;
  };

  const renderTabContent = (tabName: string, data: any) => {
    if (!data) return <div className="text-gray-500">No data available</div>;

    if (tabName === 'validations' && data.validation) {
      return (
        <div className="space-y-4">
          {data.validation.map((validation: any, index: number) => (
            <div key={index} className="bg-gray-50 p-4 rounded-lg">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <span className="font-medium text-gray-700">Field:</span>
                  <span className="ml-2">{validation.field}</span>
                </div>
                <div>
                  <span className="font-medium text-gray-700">Type:</span>
                  <span className="ml-2">{validation.validationType}</span>
                </div>
                <div className="col-span-2">
                  <span className="font-medium text-gray-700">Output:</span>
                  <span className="ml-2">{validation.output}</span>
                </div>
              </div>
            </div>
          ))}
          {data.errorMsg && (
            <div className="text-red-600 bg-red-50 p-3 rounded-lg">
              <strong>Error:</strong> {data.errorMsg}
            </div>
          )}
        </div>
      );
    }

    if (tabName === 'documentClassify') {
      return (
        <div className="space-y-4">
          <div className="bg-gray-50 p-4 rounded-lg">
            <span className="font-medium text-gray-700">Document Value:</span>
            <span className="ml-2">{data.documentValue}</span>
          </div>
          {data.errorMsg && (
            <div className="text-red-600 bg-red-50 p-3 rounded-lg">
              <strong>Error:</strong> {data.errorMsg}
            </div>
          )}
        </div>
      );
    }

    if (data.documentDetails) {
      return (
        <div className="space-y-4">
          {data.documentDetails.map((detail: any, index: number) => (
            <div key={index} className="bg-gray-50 p-4 rounded-lg">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <span className="font-medium text-gray-700">Key:</span>
                  <span className="ml-2">{detail.key}</span>
                </div>
                <div>
                  <span className="font-medium text-gray-700">Value:</span>
                  <span className="ml-2">{detail.value}</span>
                </div>
              </div>
            </div>
          ))}
          {data.errorMsg && (
            <div className="text-red-600 bg-red-50 p-3 rounded-lg">
              <strong>Error:</strong> {data.errorMsg}
            </div>
          )}
        </div>
      );
    }

    return <div className="text-gray-500">No data available</div>;
  };

  const getTabDisplayName = (tabName: string) => {
    const names: { [key: string]: string } = {
      documentExtract: 'Document Extract',
      documentLookup: 'Document Lookup',
      validations: 'Validations',
      documentClassify: 'Document Classify'
    };
    return names[tabName] || tabName;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <div className="bg-white rounded-xl shadow-xl overflow-hidden">
            <div className="bg-gradient-to-r from-blue-600 to-indigo-600 px-6 py-4">
              <div className="flex items-center justify-between">
                <h1 className="text-2xl font-bold text-white flex items-center gap-2">
                  <FileText className="w-6 h-6" />
                  IDRS Demo
                </h1>
                <div className="flex items-center gap-2">
                  <label className="flex items-center text-white text-sm">
                    <input
                      type="checkbox"
                      checked={useMockData}
                      onChange={(e) => setUseMockData(e.target.checked)}
                      className="mr-2"
                    />
                    Use Mock Data
                  </label>
                </div>
              </div>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-6">
              {/* Mock Data Notice */}
              {useMockData && (
                <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
                  <div className="flex items-center gap-2 text-amber-700">
                    <AlertCircle className="w-5 h-5" />
                    <span className="font-medium">Demo Mode:</span>
                    <span>Using mock API responses for demonstration. Uncheck "Use Mock Data" to use real API endpoints.</span>
                  </div>
                </div>
              )}

              {/* File Upload Section */}
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-blue-400 transition-colors">
                <input
                  type="file"
                  accept="image/*,.pdf,.doc,.docx"
                  onChange={handleFileUpload}
                  className="hidden"
                  id="file-upload"
                  required
                />
                <label htmlFor="file-upload" className="cursor-pointer">
                  <Upload className="w-12 h-12 text-gray-400 mx-auto mb-2" />
                  <p className="text-gray-600">
                    {fileName ? `Selected: ${fileName}` : 'Click to upload document or image'}
                  </p>
                </label>
              </div>

              {/* Form Fields */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    External Reference ID
                  </label>
                  <input
                    type="text"
                    value={formData.externalReferenceId}
                    onChange={(e) => setFormData(prev => ({ ...prev, externalReferenceId: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Channel ID
                  </label>
                  <input
                    type="text"
                    value={formData.channelId}
                    onChange={(e) => setFormData(prev => ({ ...prev, channelId: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    required
                  />
                </div>

                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Document ID
                  </label>
                  <input
                    type="text"
                    value={formData.documentId}
                    onChange={(e) => setFormData(prev => ({ ...prev, documentId: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    required
                  />
                </div>
              </div>

              {/* Operations Section */}
              <div className="border border-gray-200 rounded-lg p-4">
                <h3 className="text-lg font-medium text-gray-900 mb-4">Operations</h3>
                
                {/* Operation Group Selection */}
                <div className="space-y-4">
                  <div className="flex space-x-6">
                    <label className="flex items-center">
                      <input
                        type="radio"
                        name="operationGroup"
                        value="classify"
                        checked={formData.operationGroup === 'classify'}
                        onChange={(e) => handleOperationGroupChange(e.target.value as 'classify' | 'multiple')}
                        className="mr-2 text-blue-600 focus:ring-blue-500"
                      />
                      <span className="text-sm font-medium text-gray-700">Classification Only</span>
                    </label>
                    <label className="flex items-center">
                      <input
                        type="radio"
                        name="operationGroup"
                        value="multiple"
                        checked={formData.operationGroup === 'multiple'}
                        onChange={(e) => handleOperationGroupChange(e.target.value as 'classify' | 'multiple')}
                        className="mr-2 text-blue-600 focus:ring-blue-500"
                      />
                      <span className="text-sm font-medium text-gray-700">Multiple Operations</span>
                    </label>
                  </div>

                  {/* Classification Group */}
                  {formData.operationGroup === 'classify' && (
                    <div className="bg-blue-50 p-4 rounded-lg">
                      <div className="flex items-center">
                        <input
                          type="checkbox"
                          id="classify"
                          checked={true}
                          disabled
                          className="mr-2 text-blue-600"
                        />
                        <label htmlFor="classify" className="text-sm font-medium text-gray-700">
                          CLASSIFY
                        </label>
                      </div>
                    </div>
                  )}

                  {/* Multiple Operations Group */}
                  {formData.operationGroup === 'multiple' && (
                    <div className="bg-gray-50 p-4 rounded-lg">
                      <div className="grid grid-cols-2 gap-3">
                        {multipleOperations.map((operation) => (
                          <label key={operation} className="flex items-center">
                            <input
                              type="checkbox"
                              checked={formData.operations.includes(operation)}
                              onChange={(e) => handleMultipleOperationChange(operation, e.target.checked)}
                              className="mr-2 text-blue-600 focus:ring-blue-500"
                            />
                            <span className="text-sm font-medium text-gray-700">{operation}</span>
                          </label>
                        ))}
                      </div>
                      {formData.operations.length === 0 && (
                        <p className="text-amber-600 text-sm mt-2">
                          Please select at least one operation
                        </p>
                      )}
                    </div>
                  )}
                </div>
              </div>

              {/* Channel Inputs Section - Only show when EXTRACT-VALIDATE or LOOKUP is selected */}
              {shouldShowChannelInputs && (
                <div className="border border-gray-200 rounded-lg p-4">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-lg font-medium text-gray-900">Channel Inputs</h3>
                    <button
                      type="button"
                      onClick={addChannelInput}
                      className="flex items-center gap-2 px-3 py-1 bg-blue-500 text-white rounded-md hover:bg-blue-600 transition-colors"
                    >
                      <Plus className="w-4 h-4" />
                      Add Input
                    </button>
                  </div>

                  <div className="space-y-3">
                    {formData.channelInputs.map((input, index) => (
                      <div key={index} className="flex gap-3 items-center">
                        <input
                          type="text"
                          placeholder="Key"
                          value={input.key}
                          onChange={(e) => updateChannelInput(index, 'key', e.target.value)}
                          className="flex-1 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                        />
                        <input
                          type="text"
                          placeholder="Value"
                          value={input.value}
                          onChange={(e) => updateChannelInput(index, 'value', e.target.value)}
                          className="flex-1 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                        />
                        <button
                          type="button"
                          onClick={() => removeChannelInput(index)}
                          className="p-2 text-red-500 hover:bg-red-50 rounded-md transition-colors"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                  </div>

                  {formData.channelInputs.length === 0 && (
                    <p className="text-gray-500 text-center py-4">
                      No channel inputs added. Add inputs or leave empty to send null.
                    </p>
                  )}
                </div>
              )}

              {/* Submit Button */}
              <button
                type="submit"
                disabled={isLoading || !formData.fileContent || (formData.operationGroup === 'multiple' && formData.operations.length === 0)}
                className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-md hover:from-blue-700 hover:to-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
              >
                {isLoading ? (
                  <RefreshCw className="w-4 h-4 animate-spin" />
                ) : (
                  <Send className="w-4 h-4" />
                )}
                {isLoading ? 'Processing...' : 'Submit Request'}
              </button>
            </form>

            {/* Error Display */}
            {error && (
              <div className="mx-6 mb-6 p-4 bg-red-50 border border-red-200 rounded-lg">
                <div className="flex items-center gap-2 text-red-700">
                  <XCircle className="w-5 h-5" />
                  <span className="font-medium">Error:</span>
                  <span>{error}</span>
                </div>
              </div>
            )}

            {/* Sync Response */}
            {syncResponse && (
              <div className="mx-6 mb-6 p-4 bg-green-50 border border-green-200 rounded-lg">
                <h3 className="text-lg font-medium text-gray-900 mb-3 flex items-center gap-2">
                  {getStatusIcon(syncResponse.status)}
                  Sync Response
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <span className="font-medium text-gray-700">Correlation ID:</span>
                    <span className="ml-2 font-mono text-sm">{syncResponse.correlationId}</span>
                  </div>
                  <div>
                    <span className="font-medium text-gray-700">Status:</span>
                    <span className="ml-2">{syncResponse.status}</span>
                  </div>
                  {/* Only show Document Valid if VERIFY operation is selected */}
                  {hasVerifyOperation() && syncResponse.data.isDocumentTypeValid !== undefined && (
                    <div>
                      <span className="font-medium text-gray-700">Document Valid:</span>
                      <span className="ml-2">{syncResponse.data.isDocumentTypeValid ? 'Yes' : 'No'}</span>
                    </div>
                  )}
                  <div>
                    <span className="font-medium text-gray-700">Image Quality:</span>
                    <span className="ml-2">{syncResponse.data.imageQuality}</span>
                  </div>
                  <div className="col-span-2">
                    <span className="font-medium text-gray-700">Error Message:</span>
                    <span className="ml-2">{syncResponse.data.errorMsg}</span>
                  </div>
                </div>

                {/* Only show Solace button if NOT only VERIFY operation */}
                {!isOnlyVerifyOperation() && (
                  <button
                    onClick={checkSolaceResponse}
                    disabled={isSolaceLoading}
                    className="mt-4 flex items-center gap-2 px-4 py-2 bg-purple-600 text-white rounded-md hover:bg-purple-700 disabled:opacity-50 transition-colors"
                  >
                    {isSolaceLoading ? (
                      <RefreshCw className="w-4 h-4 animate-spin" />
                    ) : (
                      <RefreshCw className="w-4 h-4" />
                    )}
                    {isSolaceLoading ? 'Checking...' : 'Check Solace Response'}
                  </button>
                )}

                {/* Show completion message for VERIFY only operations */}
                {isOnlyVerifyOperation() && (
                  <div className="mt-4 p-3 bg-blue-50 border border-blue-200 rounded-lg">
                    <div className="flex items-center gap-2 text-blue-700">
                      <CheckCircle className="w-5 h-5" />
                      <span className="font-medium">Verification Complete:</span>
                      <span>Document verification process completed. No additional processing required.</span>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Final Response - Only show if NOT only VERIFY operation */}
            {finalResponse && !isOnlyVerifyOperation() && (
              <div className="mx-6 mb-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
                <h3 className="text-lg font-medium text-gray-900 mb-3 flex items-center gap-2">
                  {getStatusIcon(finalResponse.status)}
                  Final Response
                </h3>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                  <div>
                    <span className="font-medium text-gray-700">Correlation ID:</span>
                    <span className="ml-2 font-mono text-sm">{finalResponse.correlationId}</span>
                  </div>
                  <div>
                    <span className="font-medium text-gray-700">External Reference ID:</span>
                    <span className="ml-2">{finalResponse.externalReferenceId}</span>
                  </div>
                  <div>
                    <span className="font-medium text-gray-700">Status:</span>
                    <span className="ml-2">{finalResponse.status}</span>
                  </div>
                </div>

                {/* Conditional Tabs - Only show tabs for available data */}
                {(() => {
                  const availableTabs = getAvailableTabs(finalResponse.data);
                  
                  if (availableTabs.length === 0) {
                    return (
                      <div className="text-gray-500 text-center py-8">
                        No data sections available for the selected operations.
                      </div>
                    );
                  }

                  return (
                    <>
                      <div className="border-b border-gray-200 mb-4">
                        <nav className="flex space-x-8">
                          {availableTabs.map((tab) => (
                            <button
                              key={tab}
                              onClick={() => setActiveTab(tab)}
                              className={`py-2 px-1 border-b-2 font-medium text-sm ${
                                activeTab === tab
                                  ? 'border-blue-500 text-blue-600'
                                  : 'border-transparent text-gray-500 hover:text-gray-700'
                              }`}
                            >
                              {getTabDisplayName(tab)}
                            </button>
                          ))}
                        </nav>
                      </div>

                      {/* Tab Content */}
                      <div className="min-h-[200px]">
                        {availableTabs.includes(activeTab) ? (
                          renderTabContent(activeTab, finalResponse.data[activeTab as keyof typeof finalResponse.data])
                        ) : (
                          <div className="text-gray-500">No data available for this tab</div>
                        )}
                      </div>
                    </>
                  );
                })()}

                {finalResponse.data.errorMsg && (
                  <div className="mt-4 p-3 bg-red-50 border border-red-200 rounded-lg">
                    <div className="flex items-center gap-2 text-red-700">
                      <XCircle className="w-5 h-5" />
                      <span className="font-medium">Global Error:</span>
                      <span>{finalResponse.data.errorMsg}</span>
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;