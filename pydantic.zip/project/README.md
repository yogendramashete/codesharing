# Document Extraction API

A REST API service that extracts structured data from documents using Google Gemini AI. The service accepts JSON schemas, system prompts, base64-encoded files, and user prompts to dynamically extract specified fields from documents.

## Features

- **Dynamic Schema Validation**: Uses Pydantic models created dynamically from JSON schemas
- **Google Gemini Integration**: Leverages Google's Gemini AI for intelligent document processing
- **Multiple File Format Support**: Handles PDF, images (JPEG, PNG, GIF, WebP, BMP, TIFF)
- **Flexible Field Extraction**: Extract any fields specified in the request
- **RESTful API**: Clean, well-documented REST endpoints
- **Error Handling**: Comprehensive error handling and validation
- **Async Processing**: Built with FastAPI for high performance

## Installation

1. **Clone the repository**
```bash
git clone <repository-url>
cd document-extraction-api
```

2. **Install dependencies**
```bash
pip install -r requirements.txt
```

3. **Set up environment variables**
```bash
cp .env.example .env
# Edit .env and add your Google API key
```

4. **Get Google Gemini API Key**
   - Go to [Google AI Studio](https://makersuite.google.com/app/apikey)
   - Create a new API key
   - Add it to your `.env` file

## Usage

### Start the server
```bash
python run.py
```

The API will be available at `http://localhost:8000`

### API Documentation
- Swagger UI: `http://localhost:8000/docs`
- ReDoc: `http://localhost:8000/redoc`

### Example Request

```bash
curl -X POST "http://localhost:8000/api/v1/extract" \
  -H "Content-Type: application/json" \
  -d '{
    "json_schema": {
      "type": "object",
      "properties": {
        "name": {"type": "string"},
        "email": {"type": "string"},
        "phone": {"type": "string"},
        "address": {"type": "string"}
      },
      "required": ["name", "email"]
    },
    "system_prompt": "You are an expert document analyzer. Extract information accurately from the provided document.",
    "base64_file_content": "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQ...",
    "user_prompt": "Extract contact information from this business card or document",
    "fields_to_extract": ["name", "email", "phone", "address"]
  }'
```

### Example Response

```json
{
  "success": true,
  "extracted_data": {
    "name": "John Doe",
    "email": "john.doe@example.com",
    "phone": "+1-555-0123",
    "address": "123 Main St, City, State 12345"
  },
  "confidence_scores": {
    "name": 0.95,
    "email": 0.98,
    "phone": 0.87,
    "address": 0.92
  },
  "processing_time": 2.34,
  "message": "Extraction completed successfully"
}
```

## API Endpoints

### POST `/api/v1/extract`
Extract structured data from a document.

**Request Body:**
- `json_schema`: JSON schema defining the structure of data to extract
- `system_prompt`: System prompt to guide the AI's behavior
- `base64_file_content`: Base64 encoded file content
- `user_prompt`: User prompt with specific extraction instructions
- `fields_to_extract`: List of field names to extract

### POST `/api/v1/validate-schema`
Validate a JSON schema format.

### GET `/api/v1/supported-formats`
Get list of supported file formats and limitations.

### GET `/health`
Health check endpoint.

## Project Structure

```
app/
├── __init__.py
├── main.py                 # FastAPI application setup
├── config.py              # Configuration settings
├── models/
│   ├── __init__.py
│   ├── request.py         # Request models
│   └── response.py        # Response models
├── services/
│   ├── __init__.py
│   └── gemini_service.py  # Google Gemini integration
├── routes/
│   ├── __init__.py
│   └── extraction.py      # API routes
└── utils/
    ├── __init__.py
    ├── schema_validator.py # Dynamic Pydantic model creation
    └── prompt_builder.py   # Prompt construction utilities
```

## Environment Variables

- `GOOGLE_API_KEY`: Your Google Gemini API key (required)
- `PORT`: Server port (default: 8000)
- `HOST`: Server host (default: 0.0.0.0)

## Supported File Formats

- PDF documents
- Images: JPEG, PNG, GIF, WebP, BMP, TIFF
- Maximum file size: 20MB

## Error Handling

The API provides comprehensive error handling:
- Schema validation errors
- File format validation
- Google API errors
- Processing timeouts
- Invalid base64 content

## Development

### Running in Development Mode
```bash
python run.py
```

### Running Tests
```bash
pytest tests/
```

### Code Formatting
```bash
black app/
flake8 app/
```

## Deployment

### Docker Deployment
```bash
docker build -t document-extraction-api .
docker run -p 8000:8000 --env-file .env document-extraction-api
```

### Production Considerations
- Use a production WSGI server like Gunicorn
- Set up proper logging and monitoring
- Configure rate limiting
- Use environment-specific configuration
- Set up health checks and metrics

## License

MIT License - see LICENSE file for details.