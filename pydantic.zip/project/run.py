#!/usr/bin/env python3
"""
Entry point for the Document Extraction API
"""

import uvicorn
from app.main import app
from app.config import settings

if __name__ == "__main__":
    print("Starting Document Extraction API...")
    print(f"Server will run on http://{settings.HOST}:{settings.PORT}")
    
    uvicorn.run(
        "app.main:app",
        host=settings.HOST,
        port=settings.PORT,
        reload=True,
        log_level="info"
    )