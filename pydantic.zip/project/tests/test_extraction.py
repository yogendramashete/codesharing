import pytest
import json
import base64
from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_health_check():
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json() == {"status": "healthy"}

def test_supported_formats():
    response = client.get("/api/v1/supported-formats")
    assert response.status_code == 200
    data = response.json()
    assert "supported_formats" in data
    assert isinstance(data["supported_formats"], list)

def test_validate_schema_valid():
    valid_schema = {
        "type": "object",
        "properties": {
            "name": {"type": "string"},
            "email": {"type": "string"}
        },
        "required": ["name"]
    }
    
    response = client.post("/api/v1/validate-schema", json=valid_schema)
    assert response.status_code == 200
    data = response.json()
    assert data["valid"] is True

def test_validate_schema_invalid():
    invalid_schema = {
        "type": "invalid",
        "properties": "not_an_object"
    }
    
    response = client.post("/api/v1/validate-schema", json=invalid_schema)
    assert response.status_code == 200
    data = response.json()
    assert data["valid"] is False

@pytest.mark.asyncio
async def test_extraction_endpoint_structure():
    """Test the structure of extraction endpoint without actual API call"""
    
    # Create a simple test image (1x1 pixel PNG) as base64
    test_image_b64 = "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg=="
    
    request_data = {
        "json_schema": {
            "type": "object",
            "properties": {
                "name": {"type": "string"},
                "email": {"type": "string"}
            },
            "required": ["name"]
        },
        "system_prompt": "Extract information from the document",
        "base64_file_content": f"data:image/png;base64,{test_image_b64}",
        "user_prompt": "Extract name and email",
        "fields_to_extract": ["name", "email"]
    }
    
    # This test will fail without actual Google API key, but tests the endpoint structure
    response = client.post("/api/v1/extract", json=request_data)
    
    # Should return 500 due to missing API key, but endpoint should exist
    assert response.status_code in [500, 422]  # 422 for validation, 500 for API key issues