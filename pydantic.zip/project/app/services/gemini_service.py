import google.generativeai as genai
import base64
import json
import time
from typing import Dict, Any, List
from app.config import settings
from app.utils.schema_validator import create_dynamic_model
from app.utils.prompt_builder import build_extraction_prompt

class GeminiService:
    def __init__(self):
        genai.configure(api_key=settings.GOOGLE_API_KEY)
        self.model = genai.GenerativeModel('gemini-1.5-flash')
    
    async def extract_data(
        self,
        json_schema: Dict[str, Any],
        system_prompt: str,
        base64_content: str,
        user_prompt: str,
        fields_to_extract: List[str]
    ) -> Dict[str, Any]:
        """
        Extract structured data from document using Google Gemini
        """
        start_time = time.time()
        
        try:
            # Create dynamic Pydantic model from JSON schema
            DynamicModel = create_dynamic_model(json_schema, fields_to_extract)
            
            # Decode base64 content
            file_data = self._decode_base64_content(base64_content)
            
            # Build extraction prompt
            extraction_prompt = build_extraction_prompt(
                system_prompt, 
                user_prompt, 
                fields_to_extract,
                json_schema
            )
            
            # Prepare content for Gemini
            content = [
                extraction_prompt,
                file_data
            ]
            
            # Generate response
            response = self.model.generate_content(content)
            
            # Parse and validate response
            extracted_data = self._parse_gemini_response(
                response.text, 
                DynamicModel, 
                fields_to_extract
            )
            
            processing_time = time.time() - start_time
            
            return {
                "success": True,
                "extracted_data": extracted_data,
                "processing_time": processing_time,
                "message": "Extraction completed successfully"
            }
            
        except Exception as e:
            processing_time = time.time() - start_time
            return {
                "success": False,
                "error": str(e),
                "processing_time": processing_time
            }
    
    def _decode_base64_content(self, base64_content: str):
        """
        Decode base64 content and prepare for Gemini
        """
        try:
            # Handle data URL format
            if base64_content.startswith('data:'):
                header, data = base64_content.split(',', 1)
                mime_type = header.split(':')[1].split(';')[0]
            else:
                data = base64_content
                mime_type = "application/octet-stream"
            
            # Decode base64
            file_bytes = base64.b64decode(data)
            
            # Return appropriate format for Gemini
            return {
                "mime_type": mime_type,
                "data": file_bytes
            }
            
        except Exception as e:
            raise ValueError(f"Failed to decode base64 content: {str(e)}")
    
    def _parse_gemini_response(
        self, 
        response_text: str, 
        model_class, 
        fields_to_extract: List[str]
    ) -> Dict[str, Any]:
        """
        Parse and validate Gemini response using dynamic Pydantic model
        """
        try:
            # Try to extract JSON from response
            json_start = response_text.find('{')
            json_end = response_text.rfind('}') + 1
            
            if json_start == -1 or json_end == 0:
                # If no JSON found, try to parse the entire response
                json_data = json.loads(response_text)
            else:
                json_str = response_text[json_start:json_end]
                json_data = json.loads(json_str)
            
            # Validate using dynamic model
            validated_data = model_class(**json_data)
            
            # Extract only requested fields
            result = {}
            for field in fields_to_extract:
                if hasattr(validated_data, field):
                    result[field] = getattr(validated_data, field)
                else:
                    result[field] = None
            
            return result
            
        except json.JSONDecodeError as e:
            # Fallback: try to extract fields manually from text
            return self._extract_fields_from_text(response_text, fields_to_extract)
        except Exception as e:
            raise ValueError(f"Failed to parse Gemini response: {str(e)}")
    
    def _extract_fields_from_text(
        self, 
        text: str, 
        fields_to_extract: List[str]
    ) -> Dict[str, Any]:
        """
        Fallback method to extract fields from plain text response
        """
        result = {}
        lines = text.split('\n')
        
        for field in fields_to_extract:
            result[field] = None
            for line in lines:
                if field.lower() in line.lower():
                    # Simple extraction logic - can be enhanced
                    parts = line.split(':', 1)
                    if len(parts) == 2:
                        result[field] = parts[1].strip()
                        break
        
        return result