import os
from typing import Optional

class Settings:
    GOOGLE_API_KEY: Optional[str] = os.getenv("GOOGLE_API_KEY")
    PORT: int = int(os.getenv("PORT", 8000))
    HOST: str = os.getenv("HOST", "0.0.0.0")
    
    def __init__(self):
        if not self.GOOGLE_API_KEY:
            raise ValueError("GOOGLE_API_KEY environment variable is required")

settings = Settings()