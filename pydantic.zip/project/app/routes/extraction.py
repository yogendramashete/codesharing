from fastapi import APIRouter, HTTPException, BackgroundTasks
from fastapi.responses import JSONResponse
import logging
from typing import Dict, Any

from app.models.request import ExtractionRequest
from app.models.response import ExtractionResponse, ErrorResponse
from app.services.gemini_service import GeminiService
from app.utils.schema_validator import validate_json_schema

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

router = APIRouter()
gemini_service = GeminiService()

@router.post("/extract", response_model=ExtractionResponse)
async def extract_data(request: ExtractionRequest):
    """
    Extract structured data from document using Google Gemini
    """
    try:
        # Validate JSON schema
        if not validate_json_schema(request.json_schema):
            raise HTTPException(
                status_code=400,
                detail="Invalid JSON schema format"
            )
        
        # Validate fields to extract
        schema_properties = request.json_schema.get('properties', {})
        invalid_fields = [
            field for field in request.fields_to_extract 
            if field not in schema_properties
        ]
        
        if invalid_fields:
            logger.warning(f"Fields not in schema: {invalid_fields}")
        
        # Process extraction
        result = await gemini_service.extract_data(
            json_schema=request.json_schema,
            system_prompt=request.system_prompt,
            base64_content=request.base64_file_content,
            user_prompt=request.user_prompt,
            fields_to_extract=request.fields_to_extract
        )
        
        if result["success"]:
            return ExtractionResponse(**result)
        else:
            raise HTTPException(
                status_code=500,
                detail=f"Extraction failed: {result.get('error', 'Unknown error')}"
            )
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Unexpected error in extraction: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail=f"Internal server error: {str(e)}"
        )

@router.post("/validate-schema")
async def validate_schema(schema: Dict[str, Any]):
    """
    Validate JSON schema format
    """
    try:
        is_valid = validate_json_schema(schema)
        return {
            "valid": is_valid,
            "message": "Schema is valid" if is_valid else "Invalid schema format"
        }
    except Exception as e:
        return {
            "valid": False,
            "message": f"Schema validation error: {str(e)}"
        }

@router.get("/supported-formats")
async def get_supported_formats():
    """
    Get list of supported file formats
    """
    return {
        "supported_formats": [
            "PDF",
            "JPEG",
            "PNG",
            "GIF",
            "WebP",
            "BMP",
            "TIFF"
        ],
        "max_file_size": "20MB",
        "note": "Files should be provided as base64 encoded content"
    }