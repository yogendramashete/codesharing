from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
import uvicorn
import os
from dotenv import load_dotenv

from app.routes.extraction import router as extraction_router
from app.config import settings

# Load environment variables
load_dotenv()

app = FastAPI(
    title="Document Extraction API",
    description="REST API for extracting structured data from documents using Google Gemini",
    version="1.0.0"
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers
app.include_router(extraction_router, prefix="/api/v1", tags=["extraction"])

@app.get("/")
async def root():
    return {"message": "Document Extraction API is running"}

@app.get("/health")
async def health_check():
    return {"status": "healthy"}

if __name__ == "__main__":
    uvicorn.run(
        "app.main:app",
        host=settings.HOST,
        port=settings.PORT,
        reload=True
    )