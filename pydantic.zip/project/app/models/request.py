from pydantic import BaseModel, Field
from typing import Dict, Any, List, Optional

class ExtractionRequest(BaseModel):
    json_schema: Dict[str, Any] = Field(
        ..., 
        description="JSON schema defining the structure of data to extract"
    )
    system_prompt: str = Field(
        ..., 
        description="System prompt to guide the AI's behavior"
    )
    base64_file_content: str = Field(
        ..., 
        description="Base64 encoded file content to process"
    )
    user_prompt: str = Field(
        ..., 
        description="User prompt with specific extraction instructions"
    )
    fields_to_extract: List[str] = Field(
        ..., 
        description="List of field names to extract from the document"
    )
    
    class Config:
        json_schema_extra = {
            "example": {
                "json_schema": {
                    "type": "object",
                    "properties": {
                        "name": {"type": "string"},
                        "email": {"type": "string"},
                        "phone": {"type": "string"}
                    },
                    "required": ["name", "email"]
                },
                "system_prompt": "You are an expert document analyzer. Extract information accurately from the provided document.",
                "base64_file_content": "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQ...",
                "user_prompt": "Extract the following information from this document",
                "fields_to_extract": ["name", "email", "phone"]
            }
        }