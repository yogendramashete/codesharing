from pydantic import BaseModel
from typing import Dict, Any, Optional

class ExtractionResponse(BaseModel):
    success: bool
    extracted_data: Dict[str, Any]
    confidence_scores: Optional[Dict[str, float]] = None
    processing_time: float
    message: Optional[str] = None
    
    class Config:
        json_schema_extra = {
            "example": {
                "success": True,
                "extracted_data": {
                    "name": "John Doe",
                    "email": "john.doe@example.com",
                    "phone": "+1-555-0123"
                },
                "confidence_scores": {
                    "name": 0.95,
                    "email": 0.98,
                    "phone": 0.87
                },
                "processing_time": 2.34,
                "message": "Extraction completed successfully"
            }
        }

class ErrorResponse(BaseModel):
    success: bool = False
    error: str
    details: Optional[str] = None