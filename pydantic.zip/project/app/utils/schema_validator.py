from pydantic import BaseModel, create_model
from typing import Dict, Any, List, Type

def create_dynamic_model(json_schema: Dict[str, Any], fields: List[str]) -> Type[BaseModel]:
    """
    Create a dynamic Pydantic model from JSON schema
    """
    try:
        # Extract properties from JSON schema
        properties = json_schema.get('properties', {})
        required_fields = json_schema.get('required', [])
        
        # Build field definitions for Pydantic
        field_definitions = {}
        
        for field_name in fields:
            if field_name in properties:
                field_schema = properties[field_name]
                field_type = _get_python_type(field_schema)
                
                # Determine if field is required
                if field_name in required_fields:
                    field_definitions[field_name] = (field_type, ...)
                else:
                    field_definitions[field_name] = (field_type, None)
            else:
                # Default to optional string if not in schema
                field_definitions[field_name] = (str, None)
        
        # Create dynamic model
        DynamicModel = create_model('DynamicExtractionModel', **field_definitions)
        
        return DynamicModel
        
    except Exception as e:
        raise ValueError(f"Failed to create dynamic model: {str(e)}")

def _get_python_type(field_schema: Dict[str, Any]):
    """
    Convert JSON schema type to Python type
    """
    json_type = field_schema.get('type', 'string')
    
    type_mapping = {
        'string': str,
        'integer': int,
        'number': float,
        'boolean': bool,
        'array': list,
        'object': dict
    }
    
    return type_mapping.get(json_type, str)

def validate_json_schema(schema: Dict[str, Any]) -> bool:
    """
    Basic validation of JSON schema structure
    """
    required_keys = ['type', 'properties']
    
    for key in required_keys:
        if key not in schema:
            return False
    
    if schema['type'] != 'object':
        return False
    
    if not isinstance(schema['properties'], dict):
        return False
    
    return True