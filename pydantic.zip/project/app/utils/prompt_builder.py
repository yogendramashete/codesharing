from typing import List, Dict, Any

def build_extraction_prompt(
    system_prompt: str,
    user_prompt: str,
    fields_to_extract: List[str],
    json_schema: Dict[str, Any]
) -> str:
    """
    Build a comprehensive prompt for data extraction
    """
    
    # Format fields list
    fields_list = ", ".join(fields_to_extract)
    
    # Build schema description
    schema_description = _build_schema_description(json_schema, fields_to_extract)
    
    extraction_prompt = f"""
{system_prompt}

TASK: {user_prompt}

FIELDS TO EXTRACT: {fields_list}

SCHEMA REQUIREMENTS:
{schema_description}

INSTRUCTIONS:
1. Analyze the provided document carefully
2. Extract the requested information accurately
3. Return the data in valid JSON format
4. Use null for fields that cannot be found or determined
5. Ensure the response matches the specified schema structure

RESPONSE FORMAT:
Return only a valid JSON object with the extracted data. Example:
{{
    "field1": "extracted_value1",
    "field2": "extracted_value2",
    "field3": null
}}

Begin extraction:
"""
    
    return extraction_prompt.strip()

def _build_schema_description(json_schema: Dict[str, Any], fields: List[str]) -> str:
    """
    Build a human-readable description of the schema requirements
    """
    properties = json_schema.get('properties', {})
    required_fields = json_schema.get('required', [])
    
    descriptions = []
    
    for field in fields:
        if field in properties:
            field_info = properties[field]
            field_type = field_info.get('type', 'string')
            is_required = field in required_fields
            
            desc = f"- {field}: {field_type}"
            if is_required:
                desc += " (required)"
            
            if 'description' in field_info:
                desc += f" - {field_info['description']}"
            
            descriptions.append(desc)
        else:
            descriptions.append(f"- {field}: string (optional)")
    
    return "\n".join(descriptions)